import {NavPage} from './nav.pageobject';

describe('Navigation Menu', () => {
	let navPage: NavPage;

	beforeAll(() => {
		navPage = new NavPage();
		navPage.load();
	});

	it('should have a link to the example page', () => {
		navPage.getNavigationLinks().then((links) => {
			expect(links.length).toBe(1);
			expect(links[0].getText()).toBe('Example Page');
		});
	});
});
