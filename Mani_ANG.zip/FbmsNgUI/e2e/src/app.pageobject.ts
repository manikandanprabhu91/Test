import {browser, element, by} from 'protractor';

export class AppComponentPage {
	load() {
		return browser.get('./');
	}

	getApplicationTitle() {
		return element(by.css('h1')).getText();
	}

	getAngularVersion() {
		return element(by.css('#app-footer p:first-child')).getText();
	}
}
