[![FOSSA Status](https://ford.fossa.com/api/projects/custom%2B1%2Ffrf-starter.svg?type=large)](https://ford.fossa.com/projects/custom%2B1%2Ffrf-starter?ref=badge_large)

[![Documentation Coverage](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/images/coverage-badge-documentation.svg)](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/coverage.html)
[![Unit Test Coverage - Statements](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/images/coverage-badge-statements.svg)](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/unit-test.html)
[![Unit Test Coverage - Branches](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/images/coverage-badge-branches.svg)](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/unit-test.html)
[![Unit Test Coverage - Functions](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/images/coverage-badge-functions.svg)](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/unit-test.html)
[![Unit Test Coverage - Lines](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/images/coverage-badge-lines.svg)](https://frf-starter.apps.pd01i.edc1.cf.ford.com/documentation/unit-test.html)
# Getting Started with the Ford Responsive Framework
To get started with your FBMSNG app, you will need to do the following:
  1. Pull down a copy of this release using your preferred method (.zip download, HTTPS/SSH clone). Place it somewhere convenient.
  1. Install Node.js v12.18.4 on your computer; [Packages are available on Ford's Nexus](https://www.nexus.ford.com/#browse/browse:wamcoe_raw_private_repository:nodejs).
     In order for e2e tests to run, Node.js must be locked at version 12.
  1. Configure command-line proxy settings appropriately - read more in [the Proxy Dev Guide](https://devservices.ford.com/dev-guides?search=Ford%20Proxy%20Servers).
      1. This package utilizes internal sources for installation. These sources work best when proxy settings have either been removed, or have been configured with an appropriate `no_proxy` value.
      1.  Locations where environmental variables are often set can include the following:
          1.  macOS: 
              - Bash`.bashrc`,`.bash_profile`, and /or `.profile`
              - Zsh: `.zshrc` and /or `.profile`
          1.  Windows
              - PowerShell: `Profile.ps1`
              - Git Bash: `.bashrc`, `.bash_profile`, and /or `.profile`
  1. Open a terminal/command prompt inside of the project.
  1. Run a `npm ci`<sup>1</sup>. Please note that this step no longer installs specific build tools for Windows <sup>2</sup>
      1.  Note - If you know your project requires the Windows build tools (Python and Visual Studio build tools), run `npm run windows-build-tools` prior to running `npm ci` <sup>3</sup>
  1. Open the development server with `npm run start-dev` Note: if you need to run for IE11, you will need to start the server with `npm run start-dev-es5`. This is due to the inclusion of differential package builds.
  1. Finally, visit http://localhost:9500 to see your rendered app
  
  <sup>1</sup> `npm ci` is an npm "clean install". This was introduced with npm v6. It ensures that your install is completed in a way that provides package dependencies as close as possible to the list used when we created this starter project.
  
  <sup>2</sup> The Angular 6.x CLI utilized `node-sass` which required one of its dependencies to be compiled on Windows with Python and the Visual Studio Build tools. This was purely a development dependency and in no way affected the ability to create Angular applications on Windows. It did however create several warnings and errors when it failed to build, which in turn created confusion for users. This led us to then include a npm package called `windows-build-tools`. It turns out this package had some bugs, and had issues installing on some computers. Due to these issues, the `windows-build-tools` npm package is removed, and has its functionality manually scripted by WaME in the `windows-build-tools.js` npm script. Note that Angular CLI 8.x and newer no longer relies on `node-sass`, and thus we do not need this script to run as part of the preinstall process; we still include it in the package, though, to ensure teams that need it can opt to run the install.
  
  <sup>3</sup> If you stay with the list of packages listed in this generated application, you should not need the Windows build tools installed. If you add other 3rd party dependencies, though, you may need to install them.

# Pushing to PCF
This package is structured so that it can be pushed to PCF using the `staticfile_buildpack`. The `manifest.yml` file contains the appropriate configuration. Additional configuration for the buildpack is included in additional configuration files, `Staticfile` and `nginx.conf`.

To push this app to PCF, first complete steps 1-5 in the Getting Started section. Then, instead of steps 6 and 7 mentioned above, do the following:
  1. Run a prod build using `npm run build-prod`. This will generate a distribution directory at `<projectroot>/dist`.
  1. Log in to PCF using a `cf login --sso -a <url>` command
  1. Ensure you are targeting the appropriate org with `cf target`
  1. Push the build project using `cf push FBMSNG`. The `manifest.yml` takes the `./dist` folder and pushes it to your app.

Keep in mind that this is meant to be a starting point configuration, and is designed to be changed and adjusted based on your application. Adjustments and configuration changes range from changes in the `manifest.yml` file, to inclusion of additional configuration files and changes in the `angular.json` application build configuration.

# CI Integration with Jenkins
This package includes a Jenkinsfile script which defines how it should be built for CI. In that file, we define the tools required, and the steps to run to test and build the project. This configuration is portable, meaning  this project can be built on any Jenkins instance via a Pipeline job (as long as the required tools are available).

For more information on how this all works, take a look at the [Jenkins pages managed by the SDE team](https://wiki.ford.com/display/SDE/Jenkins).

# Other libraries and features
This starter project is designed to be an empty "scaffold" to help kickstart your development efforts. To that end, it deliberately only includes the minimum set of dependencies required to be effective. There are other libraries, such as Chart.js (dynamic charting), NGXS (reactive-style state management), the angular-in-memory-web-api (helper for in-memory static data for testing), and some others that are approved for use but are not included here. For further information, contact wamcoe@ford.com.

# Designing and theming your frf-starter based application
This project utilizes [PrimeNG Designer](https://www.primefaces.org/designer/primeng), and a theme created by the Web Enablement team called the `blue-oval-theme`. These base theme files are located within `src/assets`. For more information on how to utilize the PrimeNG Designer and make theming changes, please visit our [PrimeNG Designer Showcase](https://github.ford.com/WaMCOE/primeng-designer). Note that this 9.0.0 release of frf-starter only works with the [9.0.0 release of our PrimeNG Designer Showcase theme](https://github.ford.com/WaMCOE/primeng-designer/releases/tag/v9.0.0).  This is due to changes in structure and variables additions/removals that happened between PrimeNG Designer releases.  Newer releases of PrimeNG Designer may work with older frf-starter releases, but are not recommended due to the above stated changes.  

# Migrating from a previous release
Migrating to Angular 9.x is a relatively painless change, even though there are larger build system changes under the hood to enable Ivy. For more information on version migrations between FRF releases, see the [MIGRATION.md docs in our Web DevGuides](https://github.ford.com/WaMCOE/web-devguides/migration)
  
## Notes
-  For more details on the Angular 9.x release, take a look at the [blog post here](https://blog.angular.io/version-9-of-angular-now-available-project-ivy-has-arrived-23c97b63cfa3).

-  For more details on other breaking changes that could come up in your application, take a look at the [Angular Update Guide](https://update.angular.io).

-  WebStorm offers built in Unit Testing Capabilities, but as of @angular\cli 6.0.0, it is required to upgrade WebStorm to 2018.1.4 or greater and change the Karma Package in the configurations (Run > Edit Configurations > Karma package:) to node_modules/@angular/cli rather than node_modules/karma.

# Contact Us
Need to notify us of a bug, have issues, new feature request or simply want to brag? Join the /d/c/s Community Channels!
- [Dev/Central/Station Slack](https://app.slack.com/client/T5V3ZFCD6/C9L83E6DQ)
- [Dev/Central/Station Webex Teams](https://www.webexteams.ford.com/space?r=fz8y)
