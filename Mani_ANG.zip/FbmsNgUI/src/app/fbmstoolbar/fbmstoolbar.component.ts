import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'fbmstoolbar',
  templateUrl: './fbmstoolbar.component.html',
  styleUrls: ['./fbmstoolbar.component.sass']
})
export class FbmstoolbarComponent implements OnInit {
  redirectURL: string;
  constructor() { }

  ngOnInit(): void {
    // if(Number(sessionStorage.getItem('reportLvlCd'))==7 || Number(sessionStorage.getItem('reportLvlCd'))==91 || sessionStorage.getItem('roleName') == 'ITS'){
    //   this.redirectURL = '/accounts-home';
    // }else if(Number(sessionStorage.getItem('reportLvlCd'))!=7 && Number(sessionStorage.getItem('reportLvlCd'))!=90){
    //  this.redirectURL = '/approvals';
    // }else if(sessionStorage.getItem('roleName') == 'ADM'){
    //   this.redirectURL = '/admin-home';
    // }
  }

}
