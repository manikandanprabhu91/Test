import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmstoolbarComponent } from './fbmstoolbar.component';

describe('FbmstoolbarComponent', () => {
  let component: FbmstoolbarComponent;
  let fixture: ComponentFixture<FbmstoolbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmstoolbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmstoolbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
