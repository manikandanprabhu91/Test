import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmsadminComponent } from './fbmsadmin.component';

describe('FbmsadminComponent', () => {
  let component: FbmsadminComponent;
  let fixture: ComponentFixture<FbmsadminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmsadminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmsadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
