import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleLineProposalYearComponent } from './vehicle-line-proposal-year.component';

describe('VehicleLineProposalYearComponent', () => {
  let component: VehicleLineProposalYearComponent;
  let fixture: ComponentFixture<VehicleLineProposalYearComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VehicleLineProposalYearComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VehicleLineProposalYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
