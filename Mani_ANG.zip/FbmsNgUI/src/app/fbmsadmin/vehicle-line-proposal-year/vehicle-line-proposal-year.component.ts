import { Component, OnInit, Inject, } from '@angular/core';
import { DatePipe } from '@angular/common';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Form, FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { RestcallService } from '../../services/restcall.service';
import { ExportsService } from 'src/app/services/exports.service';
import * as moment from 'moment';

@Component({
  selector: 'vehicle-line-proposal-year',
  templateUrl: './vehicle-line-proposal-year.component.html',
  styleUrls: ['./vehicle-line-proposal-year.component.sass']
})
export class VehicleLineProposalYearComponent implements OnInit {
  title = 'datepicker-input-check';
  addEndDate = new FormControl(
    'addEndDate', [
    Validators.required
  ]
  );
  // minDate is the start of today.
  minDate = new Date(new Date().setHours(0, 0, 0, 0));
  proposalYearValues: any;
  tableValues: any;
  loading;
  today: Date;
  currentYear: any;
  modelYearDropdown: any;
  modelYearVal: any;
  vehicleLineVal: any;
  pyvdKey: any;
  vehicleLineDropdown: any;
  bodyStyleVal: any;
  bodyStyleDropdown: any;
  autoEarlyStatus: boolean;
  editIndex: any;
  role: any;
  selectAE: string;
  editStartDate: FormControl;
  editEndDate: FormControl;
  opendialog: boolean;
  addPY: any;
  addPYSelected: any;
  addMY: any;
  addMYSelected: any;
  addVehicle: any;
  addVehSelected: any;
  addBodyStyle: any;
  addBodyStyleSelected: any;
  addAE: any;
  //addEndDate: FormControl;

  controlProgram: any;
  country: any;


  constructor(private Restcallservice: RestcallService, private datePipe: DatePipe, private dialog: MatDialog, private exportExcel: ExportsService) { }

  ngOnInit(): void {
    this.modelYearVal = 0;
    this.vehicleLineVal = 0;
    this.bodyStyleVal = 0;
    this.editStartDate = new FormControl();
    this.editEndDate = new FormControl();
    this.addEndDate = new FormControl();
    this.country = sessionStorage.getItem('countryCode');
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.role = sessionStorage.getItem('roleName');
    this.opendialog = false;
    this.addPY = [];
    this.addPYSelected = 'select';
    this.addMY = [];
    this.addMYSelected = 'select';
    this.addVehicle = [];
    this.addVehSelected = 'select';
    this.addBodyStyle = [];
    this.addBodyStyleSelected = [];
    this.editIndex = null;
    this.autoEarlyStatus = false;
    this.loading = true;
    this.today = new Date;
    this.currentYear = this.datePipe.transform(this.today, 'yyyy');
    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
      if (this.controlProgram != null) {
        let cpymy;
        this.controlProgram.map(val => {
          if (val.currentProposalYearFlag == 'Y') {
            cpymy = val.proposalYearCode;
          }
        });
        this.modelYearLoad(cpymy);

      } else {
        this.modelYearLoad(null)
      }

    }, err => { this.modelYearLoad(null); this.loading = false; this.controlProgram = null });
  }
  modelYearLoad(cpymy) {
    this.modelYearVal = 0; this.vehicleLineVal = 0; this.bodyStyleVal = 0;
    let modelYearUrl = '/fleet-administrations/vehicle-lines/v1/model-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(modelYearUrl).subscribe(respData => {
      respData != null && respData != {} ? this.modelYearDropdown = respData['modelYear'] : this.modelYearDropdown = null;
      if (this.modelYearDropdown != null) {
        this.modelYearVal = 0;
        /* if(cpymy != null){
           this.modelYearDropdown.includes(Number(cpymy)) == true ? this.modelYearVal = Number(cpymy) : this.modelYearVal = this.modelYearDropdown[0];
         }else{
           this.modelYearDropdown.includes(Number(this.currentYear)) == true ? this.modelYearVal = Number(this.currentYear) : this.modelYearVal = this.modelYearDropdown[0] 
         }*/
      } this.modelYearDropdown != null ? this.loadVehicleLine() : this.vehicleLineVal = 0;
    }, err => { this.modelYearDropdown = null; this.loading = false; });
  }
  loadVehicleLine() {
    this.vehicleLineVal = 0; this.bodyStyleVal = 0;
    if (this.modelYearVal != 0) {
      let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line";
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      this.Restcallservice.getData(vehicleUrl).subscribe(respData => {
        this.vehicleLineDropdown = respData.vehicleLine;
        //this.vehicleLineVal = this.vehicleLineDropdown[0].vehLineKey;
        this.vehicleLineVal = 0;
        // this.loadBodyStyle();
        this.vehicleLineDropdown != null ? this.loadBodyStyle() : this.bodyStyleVal = 0;
      }, err => {
        this.loading = false;
        this.vehicleLineVal = null;
        this.vehicleLineDropdown = null;
      });
    }
  }
  loadBodyStyle() {
    this.bodyStyleVal = 0;
    if (this.vehicleLineVal != 0) {
      let bsUrl = '/fleet-administrations/vehicle-line-definitions/v1/body-style';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
      this.Restcallservice.getData(bsUrl).subscribe(respData => {
        this.bodyStyleDropdown = respData.vehicleLineBodyStyle;
        //this.bodyStyleVal = this.bodyStyleDropdown[0].bodyStyleKey;
        this.bodyStyleVal = 0;
        // this.bodyStyleVal = 'select';
        //this.mapTable();
      }, err => { this.loading = false });
    }
  }
  mapTable() {
    this.addPY = [];
    this.addPYSelected = 'select';
    this.addMY = [];
    this.addMYSelected = 'select';
    this.addVehicle = [];
    this.addVehSelected = 'select';
    this.addBodyStyle = [];
    this.addBodyStyleSelected = [];
    this.loading = true;
    this.opendialog = false;
    this.addEndDate.setValue(null);
    this.editEndDate.setValue(null);
    this.editStartDate.setValue(null);
    this.editIndex = null;
    this.selectAE = null;
    let tableDataUrl = '/fleet-administrations/vehicle-line-definitions/v1/vehicleLine-proposalYear-definition';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("bodyStyleKey", this.bodyStyleVal);
    this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
    this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
    this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
      respData != null ? this.tableValues = respData.autoVO : this.tableValues = null;
      this.loading = false;
      this.autoEarlyStatus = respData.autoEarlyBatchStatus != 'COMPLETED' ? false : true;
    }, err => { this.loading = false; this.tableValues = null });
  }
  aeStatus() {
    let aeUrl = '/fleet-administrations/vehicle-line-definitions/v1/vehicleLine-proposalYear-definition/autoEarlyStatus';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.createData(aeUrl, '').subscribe(data => this.autoEarlyStatus = false);
  }
  addCancel() {
    this.opendialog = false;
    this.mapTable();
  }
  cancel() {
    const dialogRef = this.dialog.open(CancelVehiclePY, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'ok') {
        this.editIndex = null;
        this.opendialog = false;
        this.mapTable();
      }
    });
  }
  addnew() {
    this.opendialog = true;
    this.addAE = 'N';
    let getPY = '/fleet-administrations/vehicle-line-definitions/v1/proposalYear';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(getPY).subscribe(data => {
      data != null && data != [] ? this.addPY = data.proposalYear : this.addPY = ''
      this.addPYSelected = 'select';
    });
  }
  loadAddVehicle(addMY) {
    if (addMY != 'select') {
      let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line";
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", this.addMYSelected);
      this.Restcallservice.getData(vehicleUrl).subscribe(respData => { this.addVehicle = respData.vehicleLine; this.addVehSelected = 'select' });
    }
  }
  loadAddBodyStyle(addVeh) {
    if (addVeh != 'select') {
      let bsUrl = '/fleet-administrations/vehicle-line-definitions/v1/bodystyleadd';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("proposalYr", this.addPYSelected);
      this.Restcallservice.setQueryParams("modelYr", this.addMYSelected);
      this.Restcallservice.setQueryParams("vehLineKey", this.addVehSelected);
      this.Restcallservice.getData(bsUrl).subscribe(respData => {
        console.log(respData);
        this.addBodyStyle = respData.bodystyleAdd;
      });
    }
  }
  /*omit_special_char(event)
    {   
       var k;  
       var ks
       k = event.charCode; 
       ks = event.keyCode //         k = event.keyCode;  (Both can be used)
       return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57))|| (ks>= 65 && ks <= 90); 
    }*/










  getErrorMessage(pickerInput: string): string {
    if (!pickerInput || pickerInput === '') {
      return 'Please enter valid date';
    }
    else {
      return this.isMyDateFormat(pickerInput);
    }
  }

  isMyDateFormat(addEndDate: string): string {

    const da = addEndDate.split('/')
    if (da.length !== 3 || da[0].length > 2 || da[1].length > 2 || da[2].length !== 4) {
      return 'Please enter valid date';
    }
    if (addEndDate.length > 10) {
      return 'Invalid input: Please input a string in the form of YYYY-MM-DD';
    }



  }

  isMyDateFormatnew(addEndDate: string): string {
    let newDate = new Date(addEndDate);
    const da = addEndDate.split('-');
    if (da.length !== 3 || da[0].length > 4 || da[1].length > 2 || da[2].length > 2) {
      return 'Please enter valid date';
    }
    if (addEndDate.length > 10) {
      return 'Invalid input: Please input a string in the form of YYYY-MM-DD';
    }
  }

  saveRow() {

    let addEndDateMod = this.datePipe.transform(this.addEndDate.value, 'yyyy-MM-dd');
    let date = this.datePipe.transform(this.addEndDate.value, 'MM/dd/yyyy');

    if (this.Restcallservice.validatedate(date)) {

      this.getErrorMessage(addEndDateMod);

      if (addEndDateMod != null && addEndDateMod.length > 10) {
        this.addEndDate = new FormControl(this.addEndDate, [
          Validators.required,
          //Validators.pattern(DOB_REGEX)
        ]);
      }
      if (addEndDateMod != null && addEndDateMod.length == 10) {

        let bsMod = [];
        this.addBodyStyleSelected.map(data => {
          bsMod.push(data.bodyStyleKey)
        });

        let saveArray = {
          "autoearly": this.addAE,
          "bodystyleKey": bsMod,
          "endDate": addEndDateMod + "T21:56:48.155Z",
          "modelYr": Number(this.addMYSelected),
          "proposalYr": Number(this.addPYSelected),
          "vehLineKey": Number(this.addVehSelected),
        };
        console.log(JSON.stringify(saveArray));
        let saveUrl = '/fleet-administrations/vehicle-line-definitions/v1/vehicleLine-proposalYear-definition';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.createData(saveUrl, JSON.stringify(saveArray)).subscribe(data => this.mapTable());
      }
    } else {
      this.Restcallservice.openFailureSnackBar("", "Invalid date format!")
    }
  }
  ondblclick(ind) {
    if (this.editIndex != ind) {
      this.editIndex = ind;
      this.editStartDate.setValue(new Date(this.tableValues[ind].startDate));
      this.editEndDate.setValue(new Date(this.tableValues[ind].endDate));
      this.selectAE = this.tableValues[ind].autoearlyDate != null && this.tableValues[ind].autoearlyDate != '' ? 'Y' : 'N';
    }
  }
  editSave(ind) {
    let endDate = this.datePipe.transform(this.editEndDate.value, 'yyyy-MM-dd');
    let startDate = this.datePipe.transform(this.editStartDate.value, 'yyyy-MM-dd');
    let date = this.datePipe.transform(this.editEndDate.value, 'MM/dd/yyyy');
    if (this.Restcallservice.validatedate(date)) {
      let pyVal = this.tableValues[ind].pyvdKey;
      let bodyVal = this.tableValues[ind].bodyStyleKey;
      let editsave = {
        "autoEarly": this.selectAE,
        "bodyStyleKey": bodyVal,
        "endDate": endDate + 'T21:07:41.367Z',
        "pyvdKey": pyVal,
        "startDate": startDate + 'T21:06:41.367Z'
      };
      console.log(JSON.stringify(editsave));
      let editUrl = '/fleet-administrations/vehicle-line-definitions/v1/vehicleLine-proposalYear-definition';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.updateData(editUrl, JSON.stringify(editsave)).subscribe(data => this.mapTable());
    } else {
      this.Restcallservice.openFailureSnackBar("", "Invalid date format!")
      // alert("Invalid date format!")
    }
  }

  excelDownload() {
    let downloadData = [];

    let topheader = [];
    let headers = [];
    let title = [];

    headers.push({
      '': 'Model Year',
      ' ': 'Vehicle Line', '  ': 'Body Style', '   ': 'Proposal Year', '    ': 'Start Date',
      '     ': 'End Date', '      ': 'Auto Early ', '       ': 'Activation Date'
    });

    this.tableValues.map(data => {
      downloadData.push({
        "Model Year": this.modelYearVal,
        "Vehicle Line": data.vehicleLine,
        "Body Style": data.bodyStyle,
        "Proposal Year": data.proposalYear,
        "Start Date": data.startDate,
        "End Date": data.endDate,
        "Auto Early": data.autoearlyDate,
        "Activation Date": data.activationDate
      });
    });
    this.exportExcel.exportAsExcelFile(downloadData, 'ProposalYearDefinition', topheader, headers, title, '',
      '', '', '', '', '');
  }

  vehiclePyDelete(ind) {
    const dialogRef = this.dialog.open(DeleteVehiclePY, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'ok') {
        let pyVal = this.tableValues[ind].pyvdKey;
        let bodyVal = this.tableValues[ind].bodyStyleKey;
        let deleteVehicle = '/fleet-administrations/vehicle-line-definitions/v1/vehicleLine-proposalYear-definition/' + pyVal + '/' + bodyVal;
        this.Restcallservice.ngOnInit();
        this.Restcallservice.deleteData(deleteVehicle).subscribe(data => this.mapTable());
      }
    });
  }
}

@Component({
  selector: 'delete-vehicle-py',
  templateUrl: 'delete-vehicle-py.html',
})
export class DeleteVehiclePY {
  constructor(
    public dialogRef: MatDialogRef<DeleteVehiclePY>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'cancel-vehicle-py',
  templateUrl: 'cancel-vehicle-py.html',
})
export class CancelVehiclePY {
  constructor(
    public dialogRef: MatDialogRef<CancelVehiclePY>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
