import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialApprovalRangeComponent } from './financial-approval-range.component';

describe('FinancialApprovalRangeComponent', () => {
  let component: FinancialApprovalRangeComponent;
  let fixture: ComponentFixture<FinancialApprovalRangeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialApprovalRangeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialApprovalRangeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
