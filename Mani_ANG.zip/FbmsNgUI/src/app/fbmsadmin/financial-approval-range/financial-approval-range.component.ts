import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'financial-approval-range',
  templateUrl: './financial-approval-range.component.html',
  styleUrls: ['./financial-approval-range.component.sass']
})
export class FinancialApprovalRangeComponent implements OnInit {
  approvalRangeVals: any;
  loading: boolean;
  country: any;
  constructor(private Restcallservice: RestcallService) { }

  ngOnInit(): void {
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.country = sessionStorage.getItem('countryCode');
    this.loading = true;
    let getDataUrl = '/fleet-administrations/approval-ranges/v1/range';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(getDataUrl).subscribe(respData => {
    respData == null || respData==[] ?  this.approvalRangeVals = null : this.approvalRangeVals = respData.financialApprovalRangeDtoList;
    console.log(this.approvalRangeVals);
    this.loading = false;
    }, err => {
      this.loading = false;
      this.approvalRangeVals = null;
    });
  }

}
