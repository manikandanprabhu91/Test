import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainFinAutoearlyComponent } from './maintain-fin-autoearly.component';

describe('MaintainFinAutoearlyComponent', () => {
  let component: MaintainFinAutoearlyComponent;
  let fixture: ComponentFixture<MaintainFinAutoearlyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainFinAutoearlyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainFinAutoearlyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
