import { Component, OnInit, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'maintain-fin-autoearly',
  templateUrl: './maintain-fin-autoearly.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class MaintainFinAutoearlyComponent implements OnInit {
  countryCode=sessionStorage.getItem('countryCode');
  @ViewChildren("checkboxes") checkboxes: QueryList<ElementRef>;
  loading: boolean;
  tableValues: any;
  valueUpdate: any = [];
  btnEnable: boolean;
  btnCancel: boolean;
  assigneeKey: any;
  autoEarly: any;
  accountName: any;
  fin: any;
  val: any;
  sdaTier1Access: any;
  autoEarlySelection: any;
  masterSelected: boolean;
  spinnerLoad: boolean;
  
  constructor(private Restcallservice: RestcallService) { }
  ngOnInit() {
    this.spinnerLoad = false;
    this.countryCode= sessionStorage.getItem('countryCode');
    this.btnEnable=false;
    this.btnCancel=true;
    this.invoke();
  }

  invoke() {
    let tableUrl = '/fleet-fin-management/fin-auto-early/v1/autoearly';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(tableUrl).subscribe(respData => {
      respData != null ? this.tableValues = respData.maintainFinAutoEarly : this.tableValues = null;
      this.loading = false;
      if (this.tableValues.length > 0) {
        this.tableValues.map(data => {
          if (data.autoEarly == true) {
            this.autoEarlySelection.push({
              accountName: data.accountName,
              fin: data.fin,
              sdaTier1Access: data.sdaTier1Access,
              autoEarly: data.autoEarly,
            })
          }
        });
      }
      this.loading = false;
    }, err => { this.loading = false; this.tableValues = null });
  }
  checkUncheckAll(event) {
    this.btnEnable=true;
    
    const checked = event.target.checked;
    for (var i = 0; i < this.tableValues.length; i++) {
      this.tableValues[i].autoEarly = this.masterSelected;
      if (this.masterSelected == true) {
        this.tableValues[i].autoEarly = 'Y';
      }
      else if (this.masterSelected == false) {
        this.tableValues[i].autoEarly = 'N';
      }
      this.getCheckedItemList(i);
    }
 }

  getCheckedItemList(i) {
   if (this.tableValues[i].autoEarly)
      this.valueUpdate.push(this.tableValues[i]);
  }
  selectEvent(arg1, event) {
    this.btnEnable = true;
    this.btnCancel = true;
    if (event.target.checked==true) {
      this.tableValues.autoEarly = 'Y';
    }
    else if (event.target.checked==false) {
      this.tableValues.autoEarly = 'N';
    }
    this.valueUpdate.push({
      "assigneeKey": arg1['assigneeKey'],
      "autoEarly": this.tableValues.autoEarly,
      "finKey": 0
    });
    
  }  
  saveAE() {
  //console.log(this.valueUpdate)
    let saveArray = {
      autoEarlyVos: this.valueUpdate
    }
    let editUrl = '/fleet-fin-management/fin-auto-early/v1/autoearly';
    this.Restcallservice.ngOnInit();
    this.spinnerLoad = true;
    this.Restcallservice.updateData(editUrl, JSON.stringify(saveArray)).subscribe(data => this.invoke, err =>     this.spinnerLoad = false     );
   }
  cancelAction(){
    this.invoke();
  }

}


