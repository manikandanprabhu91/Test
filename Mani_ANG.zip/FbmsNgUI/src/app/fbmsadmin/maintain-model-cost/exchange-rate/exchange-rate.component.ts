import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'exchange-rate',
  templateUrl: './exchange-rate.component.html',
  styleUrls: ['./exchange-rate.component.sass']
})
export class ExchangeRateComponent implements OnInit {

  addStartDate = new FormControl();
  description = new FormControl();
  fromCurrency= '';
  toCurrency= '';
  type = '';
  ratio = '';
  selectedQueue: string;
  currentQueue: any;
  exchangeRates: any[];
  loading: boolean;

  constructor() { }

  ngOnInit(): void {
    const response = [
      { "description": "From ARMADA", "type": "B", "fromCurrency": "British Pound", "toCurrency": "United States Dollar", "ratio": 1.44, "effectiveDate": "01/01/2019" },
      { "description": "CV UPLOAD DEC B460 V40B", "type": "B", "fromCurrency": "British Pound", "toCurrency": "United States Dollar", "ratio": 1.50, "effectiveDate": "11/12/2019" },
      { "description": "test", "type": "B", "fromCurrency": "British Pound", "toCurrency": "United States Dollar", "ratio": 1.60, "effectiveDate": "04/10/2020" },
      { "description": "From ARMADA", "type": "B", "fromCurrency": "British Pound", "toCurrency": "United States Dollar", "ratio": 1.65, "effectiveDate": "04/10/2020" },
    ]
    this.exchangeRates = response;
    // this.addStartDate = new FormControl();
    this.loading = false;

  }

  onDateChange(newDate: Date) {
    console.log(newDate);
  }

  loadTableData() {

  }

  addExchangeRate() {
    // JSON.stringify({"description": this.description, type: this.type, "fromCurrency": this.fromCurrency, 
    // "toCurrency": this.toCurrency, "ratio": this.ratio, "effectiveDate": this.addStartDate});
    this.exchangeRates.push(JSON.stringify({"description": this.description.value, type: this.type, "fromCurrency": this.fromCurrency, 
    "toCurrency": this.toCurrency, "ratio": this.ratio, "effectiveDate": this.addStartDate.value}));
    return  this.exchangeRates;
  }
}
