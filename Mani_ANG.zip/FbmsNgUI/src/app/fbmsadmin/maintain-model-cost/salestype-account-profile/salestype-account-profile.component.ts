import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'salestype-account-profile',
  templateUrl: './salestype-account-profile.component.html',
  styleUrls: ['./salestype-account-profile.component.sass']
})
export class SalestypeAccountProfileComponent implements OnInit {

  salestype = '';
  dealerAccount = '';
  customerAccount = '';
  leasingCo = '';
  addstartDate =  new FormControl();
  addEndDate =  new FormControl();
  salesTypeAccountList: any[];
  salesTypeSelection: any;

  response = [
    { "salesType": "FAB-DO NOT USE", "dealerAccount": "BELM128", "customerAccount": "BELM128", "leasingCo": "BELM128", "startDate": "01/04/2021", "endDate": "15/04/2021" },
    { "salesType": "MBA-Other Rental", "dealerAccount": "BELM56", "customerAccount": "BELM56", "leasingCo": "BELM56", "startDate": "01/01/2017", "endDate": "" },
    { "salesType": "MAA-MDR", "dealerAccount": "BELM128", "customerAccount": "BELM128", "leasingCo": "BELM128", "startDate": "01/01/2017", "endDate": "02/05/2017" },
    { "salesType": "MBA-Other Rental", "dealerAccount": "BELM56", "customerAccount": "BELM56", "leasingCo": "BELM56", "startDate": "28/10/2016", "endDate": "31/02/2017" },
  ]
  
  constructor() { }

  ngOnInit(): void {
// this.RestCallService.getData("url").subscribe(data=>{
//   this.salesTypeAccountList = data;
// });
    this.salesTypeAccountList = this.response;
  }

  add() {

    this.ngOnInit();
  }

  editRow(e, data) {

    console.log("Test ::::::::::::::::::: "+data);
  }

}
