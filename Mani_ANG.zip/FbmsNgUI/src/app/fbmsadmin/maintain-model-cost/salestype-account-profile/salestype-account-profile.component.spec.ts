import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalestypeAccountProfileComponent } from './salestype-account-profile.component';

describe('SalestypeAccountProfileComponent', () => {
  let component: SalestypeAccountProfileComponent;
  let fixture: ComponentFixture<SalestypeAccountProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalestypeAccountProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalestypeAccountProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
