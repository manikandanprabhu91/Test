import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'maintain-model-cost',
  templateUrl: './maintain-model-cost.component.html',
  styleUrls: ['./maintain-model-cost.component.sass']
})
export class MaintainModelCostComponent implements OnInit {

  country: any;
  
  constructor() { }

  ngOnInit(): void {
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.country= sessionStorage.getItem('countryCode');

  }

}
