import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainModelCostComponent } from './maintain-model-cost.component';

describe('MaintainModelCostComponent', () => {
  let component: MaintainModelCostComponent;
  let fixture: ComponentFixture<MaintainModelCostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainModelCostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainModelCostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
