import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EwCostDataComponent } from './ew-cost-data.component';

describe('EwCostDataComponent', () => {
  let component: EwCostDataComponent;
  let fixture: ComponentFixture<EwCostDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EwCostDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EwCostDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
