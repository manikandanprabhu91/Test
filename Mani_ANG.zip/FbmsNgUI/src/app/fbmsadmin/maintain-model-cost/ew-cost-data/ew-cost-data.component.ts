import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ew-cost-data',
  templateUrl: './ew-cost-data.component.html',
  styleUrls: ['./ew-cost-data.component.sass']
})
export class EwCostDataComponent implements OnInit {

  ewCostDataList: any[];
  ewCostDataSelection: any;

  data = [{ "model": "B479 FISETA VAN", "planType": "ABC", "planDescription": "ABC", "duration": "2021-2022", "miles": "500", "startDistance": "10", "amount": "2000", "startDate": "20/02/2021", "endDate": "10/07/2021" },
  { "model": "B515", "planType": "ECOSPORT", "planDescription": "ECOSPOR Car", "duration": "2020-2021", "miles": "5000", "startDistance": "200", "amount": "2000", "startDate": "04/05/2020", "endDate": "08/04/2021" }]

  constructor() { }

  ngOnInit(): void {
    this.ewCostDataList = this.data;
  }

  SearchEWCostData() {

  }


  UploadCostDataFile() {

  }

  DownloadEWCostDataFile() {

  }


}
