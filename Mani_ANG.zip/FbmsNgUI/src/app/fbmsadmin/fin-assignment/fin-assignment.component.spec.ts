import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinAssignmentComponent } from './fin-assignment.component';

describe('FinAssignmentComponent', () => {
  let component: FinAssignmentComponent;
  let fixture: ComponentFixture<FinAssignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinAssignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
