import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { RestcallService } from 'src/app/services/restcall.service';
import { Router } from 'src/testing/router-stubs';

@Component({
  selector: 'fin-assignment',
  templateUrl: './fin-assignment.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class FinAssignmentComponent implements OnInit {
  tableValues: any[] = [];
  tableFinValues: any[] = [];
  tableManagerValues: any[] = [];
  assignmentForm: FormGroup;
  proposalcontactForm: FormGroup;
  searchFinForm: FormGroup;
  cdsid: String[];
  assignmentType: String[];
  proposalYear: String[];
  selectedFin: any[] = [];
  codeSelect: String;
  byCdsid: boolean;
  assignType: String;
  role: String = sessionStorage.getItem('roleName');
  selectCdsId: String = "Select One";
  selectReassignCdsid: String = "Select One";
  selectFinReassignCdsid: String = "Select One";
  selectAssignmentType: String = "ALL";
  selectProposalYear: number;
  domainCountryCd = sessionStorage.getItem('countryCode');
  configUrl: string = "";
  loading: boolean;
  finData: String;
  finLoadData: any[];
  finAssignmentData: any[];
  proposalYearCode: any[];
  message: String;
  shareEnable: boolean;
  shareDataSave: boolean = false;
  cdsIdPropsal1: String = "";
  specialFinClassification: any[];
  sdaAccessShow: boolean = false;
  specialFinShow: boolean = false;
  loginId: String = sessionStorage.getItem('loginId');
  updateStatus: boolean;
  assignmentTypeUpdate: String;
  updateFin: String;
  updateCdsId: String;
  updateAccountName: String;
  updateSegment: String;
  updateContactCdsId: any;
  updateProgramYear: Number;
  updateSda: boolean = false;
  updateList: any;
  updateShare: boolean = false;
  updateShareVal: any;
  updateShare1Val: any = '';
  updateCdsIdVal: String = '';
  updateDlgBtn: boolean = false;
  count: number = 0;
  copySaveEnable: boolean = true;
  reAssignCancelEnable: boolean = false;
  columnEnable: boolean = true;
  columnEnable1: boolean = false;
  typeEnable: boolean = false;
  managerEnable: boolean = false;
  contactEnable: boolean = false;
  multiContactCdsId: any;
  multicdsid: any;
  controlProgram: any;
  spinnerLoad: boolean;

  constructor(private finform: FormBuilder, private RestcallService: RestcallService,
    private router: Router) { }

  ngOnInit() {
    this.spinnerLoad = false;
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.codeSelect = "Assignment by CDSID";
    this.assignType = "Proposal / Contact New Assignment";
    if (this.role == 'ADM' || this.role == 'ITS') {
      this.setInitialData();
    }
    this.proposalcontactForm = this.finform.group({
      proposalVal: [true],
      contactInfoVal: [true],
      fin: [''],
      accName: [],
      segment: [],
      cdsIdPropsal: ['Select One'],
      cdsIdPropsal1: ['Select One'],
      sdaTier: [true],
      contactcdsId: ['Select One'],
      metrics: [],
      share: [],
      share1: [],
      programYear: [],
      multicdsid: [[]]
    });

    this.assignmentForm = this.finform.group({
      cdsid: [''],
      assignmentType: [''],
      proposalYear: [''],
      finVal: ['', [Validators.maxLength(10)]],
      accountName: [],
      sdaAccess: [],
      specialFin: [''],
      reassignCdsid: ['']
    });
    this.searchFinForm = this.finform.group({
      finVal: ['', [Validators.maxLength(10)]],
      accountName: [],
      reassignCdsid: ['']
    });

    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
      if (this.controlProgram != null) {
        this.selectProposalYear = null;
        this.controlProgram.map(val => {
          if (val.currentProposalYearFlag == 'Y') {
            this.selectProposalYear = val.proposalYearCode;
          }
        });
      }
    }, err => { this.loading = false; this.controlProgram = null; this.spinnerLoad = false });
  }

  setInitialData() {
    this.RestcallService.ngOnInit();
    this.spinnerLoad = true;
    this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
    this.RestcallService.getData('/fleet-fin-management/fin-assignments/v1/fin/cdsid').subscribe(data => {
      if (data != null || data != '') {
        this.cdsid = data.finApprovalCdsId
        var arr = [{ 'cdsId': 'None' }];
        this.cdsid.forEach(element => {
          arr.push({ 'cdsId': element['cdsId'] })
        });
        this.multicdsid = arr;
      } else {
        this.cdsid = [];
        this.multicdsid = [];
      }
      this.spinnerLoad = false;
    }, err=>  this.spinnerLoad = false);
    this.RestcallService.getData('/fleet-fin-management/fin-assignments/v1/fin/admin/type').subscribe(data => {
      this.spinnerLoad = false;
      data != null || data != '' ? this.assignmentType = data.proposalType : this.assignmentType = [];
    }, err=> this.spinnerLoad = false);
    this.RestcallService.getData('/fleet-fin-management/fin-assignments/v1/fin/admin/year').subscribe(data => {
      this.spinnerLoad = false;
      data != null || data != '' ? this.proposalYear = data.proposalYr : this.proposalYear = [];
    }, err=> this.spinnerLoad = false);
  }

  cdsIdSelected() {

  }

  search() {
    this.spinnerLoad = true;
    this.tableValues = [];
    this.loading = true;
    this.configUrl = '/fleet-fin-management/fin-assignments/v1/fin/admin/data';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('proposalType', this.selectAssignmentType.charAt(0));
    this.RestcallService.setQueryParams('proposalYr', this.selectProposalYear);
    if (this.selectCdsId.indexOf("(") != -1 && this.selectCdsId.indexOf(")") != -1) {
      this.RestcallService.setQueryParams('selectedCdsId', this.selectCdsId.substring(this.selectCdsId.indexOf("(") + 1, this.selectCdsId.indexOf(")")));
    } else {
      this.RestcallService.setQueryParams('selectedCdsId', this.selectCdsId);
    }
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.spinnerLoad = false;
      data != null || data != '' ? this.tableValues = data.finReAssignmentData : this.tableValues = [];
      this.loading = false;
      this.reAssignCancelEnable = true;
      if (this.selectAssignmentType.charAt(0) == 'P') {
        this.columnEnable = true;
        this.columnEnable1 = false;
        this.typeEnable = false;
        this.contactEnable = false;
      } else if (this.selectAssignmentType.charAt(0) == 'A') {
        this.columnEnable = true;
        this.columnEnable1 = false;
        this.typeEnable = true;
        this.contactEnable = false;
      } else if (this.selectAssignmentType.charAt(0) == 'M') {
        this.columnEnable1 = true;
        this.columnEnable = false;
        this.typeEnable = false;
        this.contactEnable = false;
      } else if (this.selectAssignmentType.charAt(0) == 'C') {
        this.columnEnable = false;
        this.columnEnable1 = false;
        this.typeEnable = false;
        this.contactEnable = true;
      }
    }, err => this.spinnerLoad = false);
  }

  reAssignFin(selectedFin) {
    var assignKey = selectedFin.map(x => x.assignKey);
    var proposalYr = selectedFin.map(x =>
      x.assignmentType.charAt(0) == "M" ? Number(x.assignmentType.substring(x.assignmentType.indexOf("-") + 1, x.assignmentType.length)) : 0);
    let finCode = selectedFin[0].finCode;
    let reassignCdsid = this.assignmentForm.get('reassignCdsid').value;
    let proposalType = selectedFin.map(x => x.assignmentType.charAt(0));
    if (reassignCdsid != 'Select One') {
      this.configUrl = "/fleet-fin-management/fin-assignments/v1/assignment/fin/reassign";
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
      let finReassignmentByFinRequest = {
        "assignKey": assignKey,
        "mainFinCode": finCode,
        "proposalType": proposalType,
        "proposalYr": proposalYr,
        "toCdsId": reassignCdsid
      }
      this.spinnerLoad = true;
      this.RestcallService.updateData(this.configUrl, JSON.stringify(finReassignmentByFinRequest)).subscribe(data => {
        this.searchFinData();
        this.spinnerLoad = false
        this.assignmentForm.controls['reassignCdsid'].setValue("Select One");
        this.selectedFin = [];
      }, err=> this.spinnerLoad = false);
    }
  }

  reAssign(selectedFin) {
    var assignKey = selectedFin.map(x => x.saKey);
    let cdsid = this.assignmentForm.get('cdsid').value;
    let reassignCdsid = this.assignmentForm.get('reassignCdsid').value;
    this.reAssignCancelEnable = false;
    if (cdsid != 'Select One' && reassignCdsid != 'Select One' && cdsid != reassignCdsid) {
      this.configUrl = "/fleet-fin-management/fin-assignments/v1/fin/reassign/cdsId";
      this.RestcallService.ngOnInit();
      let finAssignmentRequest = {
        "assignKey": assignKey,
        "fromCdsId": this.assignmentForm.get('cdsid').value,
        "proposalYr": this.assignmentForm.get('proposalYear').value,
        "toCdsId": this.assignmentForm.get('reassignCdsid').value
      };
      this.spinnerLoad = true;
      this.RestcallService.updateData(this.configUrl, JSON.stringify(finAssignmentRequest)).subscribe(data => {
        this.spinnerLoad = false
        this.search();
        this.assignmentForm.controls['reassignCdsid'].setValue("Select One");
        this.selectedFin = [];
      }, err=> this.spinnerLoad = false);
    } else {
      this.RestcallService.statusMessage(417, "Existing and to be assigned cdsId's should not be the same");
    }

  }

  finLoad() {
    this.spinnerLoad = true;
    this.proposalcontactForm.controls['accName'].setValue('');
    this.proposalcontactForm.controls['segment'].setValue('');
    this.configUrl = '/fleet-fin-management/fin-assignments/v1/fin/code';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('finCd', this.finData);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.spinnerLoad = false
      data != null || data != '' ? this.finLoadData = data.finAssignmentAcctData : this.finLoadData = [];
      if (this.finLoadData != null) {
        this.proposalcontactForm.controls['fin'].setValue(this.finLoadData['finCode']);
        this.proposalcontactForm.controls['accName'].setValue(this.finLoadData['acctName']);
        this.proposalcontactForm.controls['segment'].setValue(this.finLoadData['segment']);
        this.proposalcontactForm.controls['share'].setValue(100);
        this.shareEnable = false;
      }this.spinnerLoad = false;
    }, err=> this.spinnerLoad = false);
  }

  proposalNewSave() {
    this.loading = true;
    this.message = 'FIN Not Found or May Not Be Available In Your Domain Country '
      + this.domainCountryCd + '. Please Contact Your FBMS Administrator.';
    if (this.assignType == 'Metrics New Assignment') {
      this.metricsSave();
    } else if (this.assignType == 'Proposal / Contact New Assignment') {
      this.proposalSave();
    }
  }

  metricsSave() {
    let accName = this.proposalcontactForm.get('accName').value;
    let segment = this.proposalcontactForm.get('segment').value;
    let cdsIdPropsal = this.proposalcontactForm.get('cdsIdPropsal').value;
    let share = this.proposalcontactForm.get('share').value;
    let fin = this.proposalcontactForm.get('fin').value;
    if (fin == null || fin == '') {
      this.loading = false;
      this.shareDataSave = false;
      this.RestcallService.statusMessage(417, this.message);
    } else if (cdsIdPropsal == "Select One") {
      this.loading = false;
      this.shareDataSave = false;
      this.RestcallService.statusMessage(417, 'Please select a CDS ID');
    } else {
      if (share == 100) {
        this.shareDataSave = true;
      } else {
        this.shareCalculation(share);
      }
    }

    if (this.shareDataSave) {
      let updateUrl = '/fleet-fin-management/fin-assignments/v1/fin/create/metrics';
      let share1 = this.proposalcontactForm.get('share1').value;
      let finCreateMetricRequest = {
        "domainCountryCd": this.domainCountryCd,
        "mainFinCode": fin,
        "metricCdsId": cdsIdPropsal,
        "metricCdsId1": this.cdsIdPropsal1,
        "secondShare": share1 == null && !isNaN(share1) && share1 == '' ? 0 : share1,
        "share": Number(this.proposalcontactForm.get('share').value)
      }
      this.spinnerLoad = true;

      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('proposalYr', Number(this.proposalcontactForm.get('programYear').value));
      this.RestcallService.createData(updateUrl, JSON.stringify(finCreateMetricRequest)).subscribe(err => {this.loading = false; this.spinnerLoad = false },
        data => {
          this.spinnerLoad = false;
          this.loading = false;
          this.proposalNewCancel();
        });
    }
  }

  shareCalculation(share) {
    if (share != null && !isNaN(share) && share != '') {
      let share1 = this.proposalcontactForm.get('share1').value;
      if (!isNaN(share1) && share1 != null && share1 != '') {
        share = Number(share) + Number(share1);
        let cdsIdPropsal1 = this.proposalcontactForm.get('cdsIdPropsal1').value;
        if (share == 100 && cdsIdPropsal1 != "Select One") {
          this.cdsIdPropsal1 = cdsIdPropsal1;
          this.shareDataSave = true;
        } else if (cdsIdPropsal1 == "Select One") {
          this.RestcallService.statusMessage(417, 'Please select the CDS Id for share1');
          this.shareDataSave = false;
        } else {
          let inputVal = this.proposalcontactForm.get('share').value;
          this.RestcallService.statusMessage(417, 'Share Percentage should be equal to 100 % cumulatively');
          this.shareDataSave = false;
        }
      } else {
        this.RestcallService.statusMessage(417, 'Please enter a valid percentage');
        this.shareDataSave = false;
      }
    } else {
      this.RestcallService.statusMessage(417, 'Please enter a valid percentage');
      this.shareDataSave = false;
    }
  }

  proposalSave() {
    let multicdsid = this.proposalcontactForm.get('multicdsid').value;
    let accName = this.proposalcontactForm.get('accName').value;
    let cdsIdPropsal = this.proposalcontactForm.get('cdsIdPropsal').value;
    let contactInfoVal = this.proposalcontactForm.get('contactInfoVal').value;
    let proposalVal = this.proposalcontactForm.get('proposalVal').value;
    let sdaTier1AccessSelected = this.proposalcontactForm.get('sdaTier').value;
    let segment = this.proposalcontactForm.get('segment').value;
    let fin = this.proposalcontactForm.get('fin').value;
    if (fin == null || fin == '') {
      this.loading = false;
      this.RestcallService.statusMessage(417, this.message);
    } else if (contactInfoVal == false && proposalVal == false) {
      this.loading = false;
      this.RestcallService.statusMessage(417, 'Please select either Proposal or Contact Check box');
    } else {
      let updateUrl = '/fleet-fin-management/fin-assignments/v1/fin/create';
      let contactcdsId = [];
      if (multicdsid.length > 0) {
        multicdsid.forEach(element => {
          contactcdsId.push(element['cdsId']);
        });
      } else {
        contactcdsId.push('Select One')
      }

      let finCreateRequest = {
        "contactCdsId": contactcdsId,
        "contactCheck": contactInfoVal,
        "domainCountryCd": this.domainCountryCd,
        "mainFinCode": fin,
        "proposalCdsId": cdsIdPropsal,
        "proposalCheck": proposalVal,
        "sdaTier1AccessSelected": sdaTier1AccessSelected == true ? 'Y' : 'N'
      }
      this.RestcallService.ngOnInit();
      this.spinnerLoad = true;
      this.RestcallService.createData(updateUrl, JSON.stringify(finCreateRequest)).subscribe(err => {this.loading = false; this.spinnerLoad = false },
        data => {
          this.spinnerLoad = false;
          this.loading = false;
          let check = data.substring(0, 5);
          if (check != 'Error') {
            this.proposalNewCancel();
          }
        });
    }
  }

  radioGroup() {
    if (this.assignType == 'Copy all Metrics PY+1') {
      this.configUrl = '/fleet-fin-management/fin-assignments/v1/copy/proposal/year';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
      this.RestcallService.getData(this.configUrl).subscribe(data => {
        this.spinnerLoad = false;
        data != null || data != '' ? this.proposalYearCode = data.proposalYearCode : this.proposalYearCode = [];
        this.proposalcontactForm.controls['metrics'].setValue(this.proposalYearCode != null ? this.proposalYearCode[0] : '');
      });
    } else if (this.assignType == 'Metrics New Assignment') {
      this.proposalcontactForm.controls['programYear'].setValue(this.selectProposalYear);
    }
    this.proposalNewCancel();
  }

  copyCancel() {
    this.proposalNewCancel();
    this.assignType = 'Proposal / Contact New Assignment';
  }

  copySave() {
    let sampleRequest = {
      "domainCountryCd": this.domainCountryCd
    }

    let updateUrl = '/fleet-fin-management/fin-assignments/v1/copy/py/metrics';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('proposalYr', Number(this.proposalcontactForm.get('metrics').value));
    this.spinnerLoad = true;
    this.RestcallService.createData(updateUrl, JSON.stringify(sampleRequest)).subscribe(data => {
      this.loading = false;
      this.spinnerLoad = false;
      this.copySaveEnable = false;
    }, err => {this.loading = false; this.spinnerLoad = false});
    this.proposalNewCancel();
  }

  proposalNewCancel() {
    this.proposalcontactForm.controls['accName'].setValue('');
    this.proposalcontactForm.controls['segment'].setValue('');
    this.proposalcontactForm.controls['fin'].setValue('');
    this.proposalcontactForm.controls['cdsIdPropsal'].setValue("Select One");
    this.proposalcontactForm.controls['contactcdsId'].setValue("Select One");
    this.proposalcontactForm.controls['contactInfoVal'].setValue(true);
    this.proposalcontactForm.controls['proposalVal'].setValue(true);
    this.proposalcontactForm.controls['sdaTier'].setValue(true);
    this.proposalcontactForm.controls['metrics'].setValue(this.proposalYearCode != null ? this.proposalYearCode[0] : '');
    this.proposalcontactForm.controls['share'].setValue('');
    this.proposalcontactForm.controls['share1'].setValue('');
    this.proposalcontactForm.controls['cdsIdPropsal1'].setValue("Select One");
    this.proposalcontactForm.controls['programYear'].setValue(this.selectProposalYear);
    this.shareEnable = false;
    this.copySaveEnable = true;
  }

  shareChange() {
    let inputVal = this.proposalcontactForm.get('share').value;
    if (!isNaN(inputVal) && inputVal != null && inputVal != '') {
      this.shareEnable = inputVal >= 100 ? false : true;
    } else {
      this.shareEnable = false;
    }
  }

  shareUpdateChange() {
    let inputVal = this.updateShareVal;
    if (!isNaN(inputVal) && inputVal != null && inputVal != '') {
      this.updateShare = inputVal >= 100 ? false : true;
      this.count = this.count + 1;
      if (this.count > 0) {
        this.updateDlgBtn = true;
      }
    } else {
      this.updateShare = false;
    }
  }

  reAssignCancel() {
    this.assignmentForm.controls['reassignCdsid'].setValue("Select One");
    this.selectedFin = [];
    this.router.navigate(['/admin-home']);
  }

  reAssignFinCancel() {
    this.assignmentForm.controls['reassignCdsid'].setValue("Select One");
    this.selectedFin = [];
    this.tableFinValues = [];
    this.codeSelect = "Assignment by CDSID";
  }

  searchFinData() {
    this.tableFinValues = [];
    this.spinnerLoad = true;
    this.configUrl = '/fleet-fin-management/fin-assignments/v1/assignment/fin/data';
    this.assignmentForm.controls['accountName'].setValue('');
    this.assignmentForm.controls['sdaAccess'].setValue(false);
    this.assignmentForm.controls.sdaAccess.disable();
    this.assignmentForm.controls['specialFin'].setValue('');
    this.assignmentForm.controls.specialFin.disable();
    this.specialFinShow = false;
    this.assignmentForm.controls.sdaAccess.disable();
    this.sdaAccessShow = false;


    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
    this.RestcallService.setQueryParams('finCd', this.assignmentForm.get('finVal').value);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.spinnerLoad = false;
      data != null || data != '' ? this.tableFinValues = data.finAssignmentDataByFinCodes : this.tableFinValues = [];
      this.assignmentForm.controls['accountName'].setValue(data != null || data != '' ? this.tableFinValues[0].acctName : '');
      if (this.tableFinValues != null) {
        if (this.domainCountryCd == 'USA') {
          this.assignmentForm.controls.sdaAccess.enable();
        }
        let length = this.tableFinValues.length;
        if (length > 0) {
          this.assignmentForm.controls['sdaAccess'].setValue(this.tableFinValues[length - 1].sellingDlr == "Y" ? true : false);
        } else {
          this.assignmentForm.controls['sdaAccess'].setValue(false);
        }
        this.sdaAccessShow = true;
        if (this.tableFinValues[0].specialClassification != null) {
          this.configUrl = '/fleet-fin-management/fin-assignments/v1/assignment/special/fin';
          this.RestcallService.ngOnInit();
          this.spinnerLoad = true;
          this.RestcallService.getData(this.configUrl).subscribe(data => {
            this.spinnerLoad = true;
            data != null || data != '' ? this.specialFinClassification = data.specialFinClassification : this.specialFinClassification = [];
            this.assignmentForm.controls['specialFin'].setValue(this.specialFinClassification != null ? this.specialFinClassification[0] : '');
            this.assignmentForm.controls['sdaAccess'].setValue(true);
            this.assignmentForm.controls.specialFin.enable();
            this.specialFinShow = true;
          });
        } else {
          this.assignmentForm.controls.specialFin.disable();
          this.specialFinShow = false;
        }
      } else {
        this.assignmentForm.controls.sdaAccess.disable();
        this.sdaAccessShow = false;
      }
    }, err=> this.spinnerLoad = false);
  }

  managerSearch() {
    this.tableManagerValues = [];
    this.searchFinForm.controls['accountName'].setValue('');
    this.managerEnable = false;
    this.configUrl = '/fleet-fin-management/fin-assignments/v1/assignment/fin/data';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
    this.RestcallService.setQueryParams('finCd', this.searchFinForm.get('finVal').value);
    this.spinnerLoad = true;
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.tableManagerValues = data.finAssignmentDataByFinCodes : this.tableManagerValues = [];
      this.managerEnable = true;
      this.spinnerLoad = false;
      this.searchFinForm.controls['accountName'].setValue(data != null || data != '' ? this.tableManagerValues[0].acctName : '');
    }, err=> this.spinnerLoad = false);
  }

  codeRadioGroup() {
    this.tableValues = [];
    this.specialFinClassification = [];
    this.assignType = "Proposal / Contact New Assignment";
    this.proposalNewCancel();
    this.assignmentForm.controls['cdsid'].setValue("Select One");
    this.assignmentForm.controls['reassignCdsid'].setValue("Select One");
    this.selectedFin = [];
    if (this.codeSelect == 'Assignment by FIN') {
      this.assignmentForm.controls.sdaAccess.disable();
      this.assignmentForm.controls.specialFin.disable();
      this.sdaAccessShow = false;
      this.specialFinShow = false;
      this.tableFinValues = [];
      this.assignmentForm.controls['finVal'].setValue('');
      this.assignmentForm.controls['accountName'].setValue('');
      this.assignmentForm.controls['sdaAccess'].setValue(false);
    }
  }

  finClassiClick() {
    this.configUrl = "/fleet-fin-management/fin-assignments/v1/assignment/special/fin/classification";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
    let finSpecialFinRequest = {
      "mainFinCode": this.assignmentForm.get('finVal').value,
      "specialFinCode": this.assignmentForm.get('specialFin').value['accountClassCode']
    };
    this.spinnerLoad = true;
    this.RestcallService.updateData(this.configUrl, JSON.stringify(finSpecialFinRequest)).subscribe(data => {
      this.spinnerLoad = false;
      this.assignmentForm.controls.sdaAccess.disable();
      this.assignmentForm.controls.specialFin.disable();
      this.sdaAccessShow = false;
      this.specialFinShow = false;
    }, err=>     this.spinnerLoad = false    );
  }

  reAssignManager(data) {
    this.configUrl = "/fleet-fin-management/fin-assignments/v1/self/fin/assignment";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('domainCountryCd', this.domainCountryCd);
    this.RestcallService.setQueryParams('proposalYr', this.selectProposalYear);
    if (this.selectReassignCdsid == 'None') {
      this.RestcallService.setQueryParams('selectedCdsId', 'None');
    } else {
      this.RestcallService.setQueryParams('selectedCdsId', this.loginId);
    }
    let request = { "finAssignmentDataByFinCodeList": data };
    this.spinnerLoad = true;
    this.RestcallService.updateData(this.configUrl, request).subscribe(data => {
      this.spinnerLoad = false;
      this.selectedFin = [];
      this.searchFinForm.controls['reassignCdsid'].setValue("Select One");
      this.managerSearch();
    }, err => {
      this.spinnerLoad = false;
      this.selectedFin = [];
      this.searchFinForm.controls['reassignCdsid'].setValue("Select One");
    });
  }

  reAssignCancelManager() {
    this.selectedFin = [];
    this.searchFinForm.controls['reassignCdsid'].setValue("Select One");
    this.searchFinForm.controls['finVal'].setValue("");
    this.searchFinForm.controls['accountName'].setValue("");
    this.tableManagerValues = [];
    this.managerEnable = false;
  }

  update(val) {
    if (this.domainCountryCd == 'USA') {
      this.updateDlgBtn = val.assignmentType == "P" ? true : false;
    }
    this.updateCdsIdVal = "";
    this.updateShare1Val = "";
    this.configUrl = "/fleet-fin-management/fin-assignments/v1/fin/code/update";
    this.spinnerLoad = true;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('finCd', val.finCode);
    this.RestcallService.setQueryParams('proposalType', val.assignmentType);
    this.RestcallService.setQueryParams('proposalYr', this.selectProposalYear);
    this.RestcallService.setQueryParams('selectedCdsId', this.selectCdsId);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.spinnerLoad = false;
      data != null || data != '' ? this.updateList = data.finAssignmentUpdateData : this.updateList = [];
      if (val.assignmentType == 'P') {
        this.updateSda = this.updateList[0].sellingDlrFlag == "Y" ? true : false;
        this.assignmentTypeUpdate = 'Proposal';
      } else if (val.assignmentType == 'C') {
        this.assignmentTypeUpdate = 'Contact Info';
      } else {
        this.assignmentTypeUpdate = 'Metrics';
        this.updateShare = this.updateList[0].metrics == 100 ? false : true;
        this.updateList.map(val => {
          if (val.cdsId == this.selectCdsId) {
            this.updateShareVal = val.metrics;
          } else {
            this.updateShare1Val = val.metrics;
          }
        });
      }
      this.updateFin = val.finCode;
      this.updateCdsId = this.selectCdsId;
      this.updateAccountName = val.accountName;
      this.updateSegment = 'Commercial';
      this.updateContactCdsId = "";
      this.updateProgramYear = this.selectProposalYear;
      this.updateStatus = true;
    }, err=> this.spinnerLoad = false);
  }

  clickUpload() {
    let finUpdateRequest;
    if (this.assignmentTypeUpdate == 'Contact Info') {
      let contactcdsId = [];
      if (this.updateContactCdsId.length > 0) {
        this.updateContactCdsId.forEach(element => {
          contactcdsId.push(element['cdsId'])
        });
      } else {
        contactcdsId.push('Select One')
      }
      finUpdateRequest = {
        "contactCdsId": contactcdsId,
        "metricsCdsId": "",
        "sdaTier1AccessSelected": "",
        "secondShare": 0,
        "share": 0
      }
      this.updateSave(finUpdateRequest)
    } else if (this.assignmentTypeUpdate == 'Proposal') {
      finUpdateRequest = {
        "contactCdsId": [""],
        "metricsCdsId": "",
        "sdaTier1AccessSelected": this.updateSda == true ? 'Y' : 'N',
        "secondShare": 0,
        "share": 0
      }
      this.updateSave(finUpdateRequest)
    } else if (this.assignmentTypeUpdate == 'Metrics') {
      if (this.updateShareVal == 100) {
        let finUpdateRequest = {
          "contactCdsId": [""],
          "metricsCdsId": this.updateCdsIdVal['cdsId'],
          "sdaTier1AccessSelected": this.updateSda == true ? 'Y' : 'N',
          "secondShare": 0,
          "share": this.updateShareVal
        }
        this.updateSave(finUpdateRequest)
      } else {
        this.updateMetricsCheck(this.updateShareVal)
      }
    }
  }

  updateMetricsCheck(shares) {
    let share1 = this.updateShare1Val;
    let share = shares;
    if (!isNaN(share1) && share1 != null && share1 != '') {
      share = Number(share) + Number(share1);
      if (share == 100) {
        let finUpdateRequest = {
          "contactCdsId": [""],
          "metricsCdsId": this.updateCdsIdVal['cdsId'],
          "sdaTier1AccessSelected": this.updateSda == true ? 'Y' : 'N',
          "secondShare": share1,
          "share": shares
        }
        this.updateSave(finUpdateRequest)
      } else {
        this.RestcallService.statusMessage(417, 'Share Percentage should be equal to 100 % cumulatively');
      }
    } else {
      this.RestcallService.statusMessage(417, 'Please enter a valid percentage');
    }
  }

  updateSave(finUpdateRequest) {
    this.configUrl = "/fleet-fin-management/fin-assignments/v1/fin/assignment/update";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('finCd', this.updateFin);
    this.RestcallService.setQueryParams('proposalType', this.assignmentTypeUpdate.charAt(0));
    this.RestcallService.setQueryParams('proposalYr', this.updateProgramYear);
    this.RestcallService.setQueryParams('selectedCdsId', this.updateCdsId);
    this.spinnerLoad = true;
    this.RestcallService.updateData(this.configUrl, JSON.stringify(finUpdateRequest)).subscribe(data => {
      this.spinnerLoad = false;
      this.updateStatus = false;
      this.updateCdsIdVal = '';
      this.updateShare1Val = '';
      this.updateDlgBtn = false;
      this.search();
      this.updateCdsIdVal = "";
      this.updateShare1Val = "";
    }, err => {
      this.spinnerLoad = false;
      this.updateStatus = false;
      this.updateCdsIdVal = '';
      this.updateShare1Val = '';
      this.updateDlgBtn = false;
      this.updateCdsIdVal = "";
      this.updateShare1Val = "";
    });
  }

  clickCancel() {
    this.updateStatus = false;
    this.updateCdsIdVal = '';
    this.updateShare1Val = '';
    this.updateDlgBtn = false;
    this.updateCdsIdVal = "";
    this.updateShare1Val = "";
  }

  contactCdsIdValChange() {
    if (this.updateContactCdsId == '' || this.updateContactCdsId['cdsId'] == this.updateCdsId) {
      this.updateDlgBtn = false;
    } else {
      this.updateDlgBtn = true;
    }
  }

  updateShare1ValChange() {
    if (this.updateCdsIdVal != '' && this.updateCdsIdVal['cdsId'] != this.updateCdsId && this.updateShare1Val != '' &&
      !isNaN(this.updateShare1Val)) {
      this.updateDlgBtn = true;
    } else {
      this.updateDlgBtn = false;
    }
  }
}
