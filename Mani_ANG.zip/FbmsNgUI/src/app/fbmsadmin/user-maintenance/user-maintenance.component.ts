import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Dialog } from 'primeng/dialog';
import { Table } from 'primeng/table';

@Component({
  selector: 'user-maintenance',
  templateUrl: './user-maintenance.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class UserMaintenanceComponent implements OnInit {
  @ViewChild(Table) templateRight: Table;
  categoryDetail: any[];
  fordPersonDetails: any[];
  statusData: any[];
  statusAddData: any[];
  searchTerms: any[];
  populatingDataVo: any[];
  populateRoleList: any[];
  populateOrganizationList: any[];
  populatingSalutationList: any[];
  populatingZoneList: any[];
  populatingRegionList: any[];
  populatingStateList: any[];
  configUrl: string = "";
  searchCategoryVal: string = "";
  searchTermVal: string = "";
  roleOnChange: string = "";
  statusVal: string = "";
  searchTermInputVal: string = "";
  searchTerm: boolean = false;
  searchinput: boolean = false;
  status: boolean = false;
  message: string;
  searchTermsData: string[];
  addDialog: boolean = false;
  checked: boolean = false;
  errorMsgDetails: any[];
  statusDetails: any[];
  userStaus: boolean = false;
  statusZone: string = "";
  stausSalutationDesc: string = "";
  statusCdsId: string = "";
  statusFront: string = "";
  statusBack: string = "";
  uploadedFiles: any[] = [];
  uploadSignature: boolean = false;
  addnewPerson: boolean = false;
  createPerson: FormGroup;
  dealToAuthFlag: String = "";
  addHide: boolean;
  btnSaveHide: boolean = false;
  tableEdit: String = 'true';
  editRow: number;
  val: String = 'Edit';
  countryCode = sessionStorage.getItem('countryCode');
  fordPersonArray: any;
  updateFordPersonArray: any;
  loading: boolean;
  record: boolean;
  role = sessionStorage.getItem('roleName');
  cancelCheck: string;
  @ViewChild('inputFile') myInputVariable: ElementRef;
  updateUserCdsId: string;
  uploadSign: boolean;
  is_edit: string = "true";
  addGenericCdsId: string;
  @ViewChild(Dialog) dialog;
  totalCount: number;
  clickCount: number = 0;
  dealToAuthorFlagUpdate: boolean = false;
  addGenericCdsIdUpdate: String;
  regionNameUpdate: String;
  fordOrgCodeUpdate: String;
  roleMap: any;
  salutationMap: any;
  zoneMap: any;
  updateSaveEnable: boolean = false;
  updateDomainCountry: String;
  fileToUpload: File;
  spinner: boolean = false;

  constructor(private RestcallService: RestcallService, private fb: FormBuilder, private route: ActivatedRoute) {
    this.createPerson = this.fb.group({
      addCdsId: ['', ([Validators.required])],
      fordOrgCode: ['', ([Validators.required])],
      addStatus: ['', ([Validators.required])],
      addRole: ['', ([Validators.required])],
      addSupervisor: [''],
      addDomainCountry: [{ value: '', disabled: true }],
      regionName: ['', Validators.required],
      zoneCd: [{ value: '', disabled: true }, Validators.required],
      salutationDesc: [''],
      addFirstName: ['', ([Validators.required, Validators.maxLength(30)])],
      addLastName: ['', ([Validators.required, Validators.maxLength(30)])],
      addAddressLine1: ['', ([Validators.maxLength(50)])],
      addAddressLine2: ['', ([Validators.maxLength(50)])],
      addCity: ['', ([Validators.maxLength(40)])],
      stateCd: ['', ([Validators.required])],
      addZipCode: ['', ([Validators.maxLength(15)])],
      addPhone: ['', ([Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      addFax: ['', ([Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      addMobile: ['', ([Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      dealToAuthorFlag: [{ value: '', disabled: true }],
      addGenericCdsId: [{ value: '', disabled: true }]
    });
  }

  ngOnInit(): void {
    this.addHide = this.role == 'ADM' ? true : false;
    this.setAddPerson();
    this.record = true;
    this.uploadSign = false;
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.configUrl = "/fleet-user-management/fleet-users/v1/category-details";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.categoryDetail = data.categoryDetailsList : this.categoryDetail = [];
      this.searchCategoryVal = data != null || data != '' ? this.categoryDetail[0] : '';
    });
  }

  setAddPerson() {
    if (this.countryCode == "USA") {
      this.createPerson.controls['addDomainCountry'].setValue('UNITED STATES');
      this.updateDomainCountry = 'UNITED STATES';
    } else if (this.countryCode == "MEX") {
      this.createPerson.controls['addDomainCountry'].setValue('MEXICO');
      this.updateDomainCountry = 'MEXICO';
    } else if (this.countryCode == "CAN") {
      this.createPerson.controls['addDomainCountry'].setValue('CANADA');
      this.updateDomainCountry = 'CANADA';
    }
  }

  searchCategorySelected(searchCategoryVal: string) {
    this.searchCategoryVal = searchCategoryVal;
    if (searchCategoryVal == 'CDSID') {
      this.btnSaveHide = false;
      this.searchTerm = false;
      this.searchinput = true;
      this.status = false;
    } else if (searchCategoryVal == 'Organization' || searchCategoryVal == 'Role') {
      this.btnSaveHide = false;
      this.searchTerm = true;
      this.searchinput = false;
      this.status = true;
      this.searchTermData(this.searchCategoryVal, false);
      this.searchTermData('Status', true);
    } else if (searchCategoryVal == 'Supervisor CDSID') {
      this.btnSaveHide = false;
      this.searchTerm = false;
      this.searchinput = true;
      this.status = true;
      this.searchTermData('Status', true);
    } else if (searchCategoryVal == 'Status') {
      this.btnSaveHide = false;
      this.searchTerm = true;
      this.searchinput = false;
      this.status = false;
      this.searchTermData(this.searchCategoryVal, false);
    } else {
      this.searchTerm = false;
      this.searchinput = false;
      this.status = false;
      this.btnSaveHide = false;
    }
  }

  searchTermData(searchData: string, status: boolean) {
    this.configUrl = "/fleet-user-management/fleet-users/v1/search-term";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('searchCategory', searchData);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      if (status) {
        data != null || data != '' ? this.statusData = data.searchTerms : this.statusData = [];
        data != null || data != '' ? this.statusData.push('All') : this.statusData = [];
      } else {
        data != null || data != '' ? this.searchTermsData = data.searchTerms : this.searchTermsData = [];
      }
    });
  }

  searchTermSelected(searchTermVal: string) {
    this.searchTermVal = searchTermVal;
    this.checkSeach();
  }

  statusSelected(statusVal: string) {
    this.statusVal = statusVal;
    this.btnSaveHide = true;
    this.checkSeach();
  }

  onChangeEvent() {
    this.checkSeach();
  }

  checkSeach() {
    if ((this.searchCategoryVal == 'Organization' || this.searchCategoryVal == 'Role')
      && this.searchTermVal != "" && this.statusVal != "") {
      this.btnSaveHide = true;
    } else if ((this.searchCategoryVal == 'Status')
      && this.searchTermVal != "") {
      this.btnSaveHide = true;
    } else if ((this.searchCategoryVal == 'Supervisor CDSID')
      && this.searchTermInputVal.length != 0 && this.statusVal != "") {
      this.btnSaveHide = true;
    } else if (this.searchCategoryVal == 'CDSID'
      && this.searchTermInputVal.length != 0) {
      this.btnSaveHide = true;
    } else {
      this.btnSaveHide = false;
    }
  }
  findData(reset: String) {
    this.editRow = -1;
    this.record = true;
    this.clickCount = 0;
    if (reset == "reset") {
      this.templateRight.reset();
    }
    this.loading = true;
    this.configUrl = "/fleet-user-management/fleet-users/v1/ford-person";
    this.RestcallService.ngOnInit();
    if (this.checkData(this.searchCategoryVal, 'Search Category')) {
      this.RestcallService.setQueryParams('searchCategory', this.searchCategoryVal);
      if (this.searchCategoryVal == 'CDSID' &&
        this.checkData(this.searchTermInputVal, 'Search Term')) {
        this.RestcallService.setQueryParams('searchTerm', this.searchTermInputVal);
        this.RestcallService.setQueryParams('status', 'ALL');
      } else if ((this.searchCategoryVal == 'Organization' || this.searchCategoryVal == 'Role')
        && this.checkData(this.searchTermVal, 'Search Term') &&
        this.checkData(this.statusVal, 'Status')) {
        this.RestcallService.setQueryParams('searchTerm', this.searchTermVal);
        this.RestcallService.setQueryParams('status', this.statusVal);
      } else if (this.searchCategoryVal == 'Supervisor CDSID' &&
        this.checkData(this.searchTermInputVal, 'Search Term') &&
        this.checkData(this.statusVal, 'Status')) {
        this.RestcallService.setQueryParams('searchTerm', this.searchTermInputVal);
        this.RestcallService.setQueryParams('status', this.statusVal);
      } else if (this.searchCategoryVal == 'Status' &&
        this.checkData(this.searchTermVal, 'Status')) {
        this.RestcallService.setQueryParams('searchTerm', this.searchTermVal);
        this.RestcallService.setQueryParams('status', this.searchTermVal);
      } else {
        if (this.role == 'ADM') {
          this.addnewPerson = false;
          this.addHide = true;
          this.createPerson.reset();
          this.setAddPerson();
        }
      }
      if (this.searchCategoryVal != '' && this.searchCategoryVal != '') {
        this.RestcallService.getData(this.configUrl).subscribe(data => {
          data != null || data != '' ? this.fordPersonDetails = data.fordPersonDetails : this.fordPersonDetails = [];
          this.loading = false;
          if (this.role == 'ADM') {
            this.addnewPerson = false;
            this.addHide = true;
            this.createPerson.reset();
            this.setAddPerson();
          }
          if (this.fordPersonDetails.length == 0) {
            this.RestcallService.statusMessage(data.status, 'Record does not exist.');
          }
        }, err => {
          this.loading = false;
          if (this.role == 'ADM') {
            this.addnewPerson = false;
            this.addHide = true;
            this.createPerson.reset();
            this.setAddPerson();
          }
        });
      } else {
        this.loading = false;
        if (this.role == 'ADM') {
          this.addnewPerson = false;
          this.addHide = true;
          this.createPerson.reset();
          this.setAddPerson();
        }
      }
    }
    this.fordPersonDetails != null ? this.totalCount = this.fordPersonDetails.length : this.totalCount = 0;
  }

  checkData(checkDataVal: string, msg: string) {
    if ((checkDataVal.length != 0)) {
      return true;
    }
    this.message = msg;
    return false;
  }

  searchCategoryClick() {
    this.searchTermVal = "";
    this.statusVal = "";
    this.searchTermInputVal = "";
  }

  createNew() {
    this.addnewPerson = true;
    this.record = false;
    this.addHide = true;
    this.getDataForCreate();
    this.addDialog = true;
    this.statusAddData = [
      { label: 'A', value: 'A' },
      { label: 'I', value: 'I' }
    ];
    if (this.role == 'ADM') {
      this.addHide = false;
    }
    this.createPerson.controls['addStatus'].setValue(this.statusAddData[0]);
  }

  getDataForCreate() {
    this.configUrl = "/fleet-user-management/fleet-users/v1/person-data";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.setDataForCreate(data.populatingDataVo) : this.populatingDataVo = [];
    });
  }

  setDataForCreate(populatingDataVo) {
    this.populateRoleList = populatingDataVo.populateRoleList;
    this.populateOrganizationList = populatingDataVo.populateOrganizationList;
    this.populatingSalutationList = populatingDataVo.populatingSalutationList;
    this.populatingZoneList = populatingDataVo.populatingZoneList;
    this.populatingRegionList = populatingDataVo.populatingRegionList;
    this.populatingStateList = populatingDataVo.populatingStateList;
    this.roleMap = new Map(this.populateRoleList.map(i => [i.titleCode, i.saKey]));
    this.salutationMap = new Map(this.populatingSalutationList.map(i => [i.salutationDesc, i.salutationCd]));
    this.zoneMap = new Map(this.populatingZoneList.map(i => [i.zoneCd, i.zoneDescription]));
  }

  saveContact(createPerson) {
    if (this.createPerson.value != null) {
      let addSupervisor = this.createPerson.get('addSupervisor').value;
      if (addSupervisor == '') {
        this.RestcallService.statusMessage(417, 'Supervisor CDSID need to be entered');
      } else if (addSupervisor.toUpperCase() == this.createPerson.get('addCdsId').value.toUpperCase()) {
        this.RestcallService.statusMessage(417, 'Please make sure Supervisor Cdsid and Cdsid are different ');
      } else {
        let zone;
        let zoneCd;
        let saveUrl = '/fleet-user-management/fleet-users/v1/ford-person';
        this.RestcallService.ngOnInit();
        if (this.createPerson.get('dealToAuthorFlag').value == true) {
          this.dealToAuthFlag = 'Y';
        } else {
          this.dealToAuthFlag = 'N';
        }
        if (this.createPerson.get('fordOrgCode').value['fordOrgCode'] == 'CVO') {
          zone = this.createPerson.get('zoneCd').value == null ||
            this.createPerson.get('zoneCd').value == '' ? '' : this.createPerson.get('zoneCd').value['zoneDescription'];
          zoneCd = this.createPerson.get('zoneCd').value == null ||
            this.createPerson.get('zoneCd').value == '' ? '' : this.createPerson.get('zoneCd').value['zoneCd'];
        } else {
          zone = '';
          zoneCd = '';
        }


        this.fordPersonArray = {
          "addressLine1": this.createPerson.get('addAddressLine1').value == null ||
            this.createPerson.get('addAddressLine1').value == '' ? '' : this.createPerson.get('addAddressLine1').value,
          "addressLine2": this.createPerson.get('addAddressLine2').value == null ||
            this.createPerson.get('addAddressLine2').value == '' ? '' : this.createPerson.get('addAddressLine2').value,
          "cdsId": this.createPerson.get('addCdsId').value == null ||
            this.createPerson.get('addCdsId').value == '' ? '' : this.createPerson.get('addCdsId').value.toUpperCase(),
          "city": this.createPerson.get('addCity').value == null ||
            this.createPerson.get('addCity').value == '' ? '' : this.createPerson.get('addCity').value,
          "country": this.updateDomainCountry,
          "dealToAuthFlag": this.dealToAuthFlag,
          "fax": this.createPerson.get('addFax').value == null || this.createPerson.get('addFax').value == '' ? '' : this.createPerson.get('addFax').value,
          "firstName": this.createPerson.get('addFirstName').value == null ||
            this.createPerson.get('addFirstName').value == '' ? '' : this.createPerson.get('addFirstName').value,
          "genericNamCdsId": this.createPerson.get('addGenericCdsId').value == null ||
            this.createPerson.get('addGenericCdsId').value == '' ? '' : this.createPerson.get('addGenericCdsId').value,
          "lastName": this.createPerson.get('addLastName').value == null ||
            this.createPerson.get('addLastName').value == '' ? '' : this.createPerson.get('addLastName').value,
          "mobile": this.createPerson.get('addMobile').value == null ||
            this.createPerson.get('addMobile').value == '' ? '' : this.createPerson.get('addMobile').value,
          "organization": this.createPerson.get('fordOrgCode').value == null ||
            this.createPerson.get('fordOrgCode').value == '' ? '' : this.createPerson.get('fordOrgCode').value['fordOrgCode'],
          "phone": this.createPerson.get('addPhone').value == null ||
            this.createPerson.get('addPhone').value == '' ? '' : this.createPerson.get('addPhone').value,
          "region": this.createPerson.get('regionName').value == null ||
            this.createPerson.get('regionName').value == '' ? '' : this.createPerson.get('regionName').value['regionName'],
          "role": this.createPerson.get('addRole').value == null ||
            this.createPerson.get('addRole').value == '' ? '' : this.createPerson.get('addRole').value['titleCode'],
          "roleCd": this.createPerson.get('addRole').value == null ||
            this.createPerson.get('addRole').value == '' ? '' : this.createPerson.get('addRole').value['saKey'],
          "salutationCd": this.createPerson.get('salutationDesc').value == "" || this.createPerson.get('salutationDesc').value == null ? '' : this.createPerson.get('salutationDesc').value['salutationCd'],
          "salutationDesc": this.createPerson.get('salutationDesc').value == "" || this.createPerson.get('salutationDesc').value == null ? '' : this.createPerson.get('salutationDesc').value['salutationDesc'],
          "state": this.createPerson.get('stateCd').value == null ||
            this.createPerson.get('stateCd').value == '' ? '' : this.createPerson.get('stateCd').value,
          "statusFlag": this.createPerson.get('addStatus').value['value'],
          "superVisorCdsId": this.createPerson.get('addSupervisor').value == null ||
            this.createPerson.get('addSupervisor').value == '' ? '' : this.createPerson.get('addSupervisor').value.toUpperCase(),
          "zipCode": this.createPerson.get('addZipCode').value == null ||
            this.createPerson.get('addZipCode').value == '' ? '' : this.createPerson.get('addZipCode').value,
          "zone": zone,
          "zoneCd": zoneCd
        }
        let fordPersonVo = this.fordPersonArray;
        this.RestcallService.createData(saveUrl, JSON.stringify(fordPersonVo)).subscribe(data => {
          this.findData('');
        });
      }
    }
  }

  checkValue(event, createPerson) {
    if (event.target.checked) {
      this.addGenericCdsId = 'RTL' + createPerson.get('addLastName').value;
      let length = this.addGenericCdsId.length;
      if (!(length >= 8)) {
        for (let index = length; index <= 8; index++) {
          this.addGenericCdsId = this.addGenericCdsId + '0';
        }
      }
      this.createPerson.controls['addGenericCdsId'].setValue(this.addGenericCdsId.substring(0, 8));
    } else {
      this.createPerson.controls['addGenericCdsId'].setValue('');
    }
  }

  updateClicked(ind) {
    this.editRow = ind;
    this.addnewPerson = true;
  }

  setStatusClicked(onepick) {
    this.statusZone = onepick.zone;
    this.stausSalutationDesc = onepick.salutationDesc == null || onepick.salutationDesc == ''
      ? '' : onepick.salutationDesc;
    onepick.salutationDesc;
    this.statusCdsId = onepick.cdsId;
    this.statusFront = onepick.statusFlag;
    this.statusBack = onepick.statusFlag == 'I' ? "A" : "I";
    this.userStaus = true;
  }

  uploadSignatureClicked(cdsId) {
    this.uploadSignature = true;
    this.updateUserCdsId = cdsId;
  }

  updateUploadSignature() {
    this.spinner = true;
    this.uploadSign = false;
    this.uploadSignature = false;
    let uploadUrl = "/fleet-user-management/fleet-users/v1/signature-upload";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('updateUserCdsId', this.updateUserCdsId);
    this.RestcallService.uploadFile(uploadUrl, this.fileToUpload, 'file', '').subscribe(data => {
      this.findData('');
      this.myInputVariable.nativeElement.value = '';
      this.spinner = false;
    }, err => {
      this.findData('');
      this.myInputVariable.nativeElement.value = '';
      this.spinner = false;
    });
  }

  cancelUploadSignature() {
    this.uploadSignature = false;
    this.myInputVariable.nativeElement.value = '';
    this.uploadSign = false;
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadSign = true;
  }

  roleChange(createPerson) {
    let titleCode = this.createPerson.get('addRole').value['titleCode'];
    if (titleCode == 'ROM' || titleCode == 'RSM') {
      this.createPerson.controls.dealToAuthorFlag.enable();
    } else {
      this.createPerson.controls['addGenericCdsId'].setValue('');
      this.createPerson.controls['dealToAuthorFlag'].setValue(false);
      this.createPerson.controls.dealToAuthorFlag.disable();
    }
    if (titleCode == 'ADM' || titleCode == 'CTL' || titleCode == 'RVW') {
      this.createPerson.controls['regionName'].setValue(this.populatingRegionList[0]);
      this.createPerson.controls.regionName.disable();

    } else {
      this.createPerson.controls['regionName'].setValue('');
      this.createPerson.controls.regionName.enable();
    }
  }

  orgChange(createPerson) {
    let titleCode = this.createPerson.get('fordOrgCode').value['fordOrgCode'];
    if (titleCode == 'CVO') {
      this.createPerson.controls.zoneCd.enable();
    } else {
      this.createPerson.controls.zoneCd.disable();
      this.createPerson.controls['zoneCd'].setValue('');
    }
  }

  cancel() {
    if (this.role == 'ADM') {
      this.addnewPerson = false;
      this.addHide = true;
      this.record = true;
      this.createPerson.reset();
      this.setAddPerson();
    }
  }

  updateStatus(status, statusCdsId) {
    this.configUrl = "/fleet-user-management/fleet-users/v1/status";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('status', status);
    this.RestcallService.setQueryParams('updateUserCdsId', statusCdsId);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.RestcallService.statusMessage(200, data.msgDesc);
      this.userStaus = false;
      this.findData('');
    });
  }

  addCdsIdInput() {
    this.cdsIdDetails(this.createPerson.get('addCdsId').value);
  }

  cdsIdDetails(cdsId) {
    this.configUrl = "/fleet-user-management/fleet-users/v1/cds-id-details";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('updateUserCdsId', cdsId);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data == null || data == '' ? this.setEmptyData() : this.setCdsIdDetails(data.cdsIdDetailsVo);
      data == null || data == '' ? this.RestcallService.statusMessage(417, cdsId + ' not exist.') : '';
    });
  }

  setEmptyData() {
    this.createPerson.controls['addAddressLine1'].setValue('');
    this.createPerson.controls['addAddressLine2'].setValue('');
    this.createPerson.controls['addCity'].setValue('');
    this.createPerson.controls['addFirstName'].setValue('');
    this.createPerson.controls['addLastName'].setValue('');
    this.createPerson.controls['addSupervisor'].setValue('');
    this.createPerson.controls['addMobile'].setValue('');
    this.createPerson.controls['addPhone'].setValue('');
    this.createPerson.controls['addZipCode'].setValue('');
    this.createPerson.controls['addFax'].setValue('');
    this.createPerson.controls['stateCd'].setValue('');
  }

  setCdsIdDetails(data) {
    this.createPerson.controls['addAddressLine1'].setValue(data.address1);
    this.createPerson.controls['addAddressLine2'].setValue(data.address3);
    this.createPerson.controls['addCity'].setValue(data.city);
    this.createPerson.controls['addFirstName'].setValue(data.firstName);
    this.createPerson.controls['addLastName'].setValue(data.lastName);
    this.createPerson.controls['addSupervisor'].setValue(data.fordManagerCDSID);
    this.createPerson.controls['addMobile'].setValue(data.mobile);
    this.createPerson.controls['addPhone'].setValue(data.phoneNumber);
    this.createPerson.controls['addZipCode'].setValue(data.postalCode);
    this.createPerson.controls['addFax'].setValue(data.fax);
    this.createPerson.controls['stateCd'].setValue(data.state);
  }
  addZipCode
  cancelStatus(event) {
    this.userStaus = false;
    this.findData('');
  }

  editEnable(ind) {
    if (this.role == 'ADM') {
      this.updateSaveEnable = false;
      if (this.clickCount == 0) {
        this.createPerson.reset();
        this.clickCount = 1;
      }
      this.addnewPerson = false;
      this.addHide = false;
      if (this.editRow == ind) {
      } else {
        this.editRow = ind;
        this.mapEdit();
        this.editContact(true);
      }
    }
  }

  mapEdit() {
    this.updateSaveEnable = false;
    if (this.editRow != null) {
      this.getDataForCreate();
      this.dealToAuthorFlagUpdate = this.fordPersonDetails[this.editRow].genericNamCdsId != ''
        && this.fordPersonDetails[this.editRow].genericNamCdsId != null ? true : false;
      let titleCode = this.fordPersonDetails[this.editRow].role;
      if (titleCode == 'ROM' || titleCode == 'RSM') {
        this.createPerson.controls.dealToAuthorFlag.enable();
        this.addGenericCdsIdUpdate = this.fordPersonDetails[this.editRow].genericNamCdsId;
      } else {
        this.createPerson.controls['addGenericCdsId'].setValue('');
        this.createPerson.controls['dealToAuthorFlag'].setValue(false);
        this.createPerson.controls.dealToAuthorFlag.disable();
        this.addGenericCdsIdUpdate = '';
      }
      if (titleCode == 'ADM' || titleCode == 'CTL' || titleCode == 'RVW') {
        this.createPerson.controls['regionName'].setValue(this.populatingRegionList[0].regionName);
        this.createPerson.controls.regionName.disable();
        this.regionNameUpdate = this.populatingRegionList[0].regionName;
      } else {
        this.createPerson.controls['regionName'].setValue('');
        this.createPerson.controls.regionName.enable();
        this.regionNameUpdate = this.fordPersonDetails[this.editRow].region;
      }
      if (this.fordPersonDetails[this.editRow].organization == 'CVO') {
        this.createPerson.controls.zoneCd.enable();
        this.fordOrgCodeUpdate = this.fordPersonDetails[this.editRow].zoneCd;
      } else {
        this.createPerson.controls.zoneCd.disable();
        this.createPerson.controls['zoneCd'].setValue('');
        this.fordOrgCodeUpdate = this.fordPersonDetails[this.editRow].zoneCd;
      }
      this.createPerson.patchValue({
        addCdsId: this.fordPersonDetails[this.editRow].cdsId ? this.fordPersonDetails[this.editRow].cdsId : '',
        fordOrgCode: this.fordPersonDetails[this.editRow].organization ? this.fordPersonDetails[this.editRow].organization : '',
        addStatus: this.fordPersonDetails[this.editRow].statusFlag ? this.fordPersonDetails[this.editRow].statusFlag : '',
        addRole: this.fordPersonDetails[this.editRow].role ? this.fordPersonDetails[this.editRow].role : '',
        addSupervisor: this.fordPersonDetails[this.editRow].superVisorCdsId ? this.fordPersonDetails[this.editRow].superVisorCdsId : '',
        addDomainCountry: this.fordPersonDetails[this.editRow].country ? this.fordPersonDetails[this.editRow].country : '',
        regionName: this.fordPersonDetails[this.editRow].region ? this.fordPersonDetails[this.editRow].region : '',
        zoneCd: this.fordPersonDetails[this.editRow].zoneCd ? this.fordPersonDetails[this.editRow].zoneCd : '',
        salutationDesc: this.fordPersonDetails[this.editRow].salutationDesc ? this.fordPersonDetails[this.editRow].salutationDesc : '',
        addFirstName: this.fordPersonDetails[this.editRow].firstName ? this.fordPersonDetails[this.editRow].firstName : '',
        addLastName: this.fordPersonDetails[this.editRow].lastName ? this.fordPersonDetails[this.editRow].lastName : '',
        addAddressLine1: this.fordPersonDetails[this.editRow].addressLine1 ? this.fordPersonDetails[this.editRow].addressLine1 : '',
        addAddressLine2: this.fordPersonDetails[this.editRow].addressLine2 ? this.fordPersonDetails[this.editRow].addressLine2 : '',
        addCity: this.fordPersonDetails[this.editRow].addCity ? this.fordPersonDetails[this.editRow].addCity : '',
        stateCd: this.fordPersonDetails[this.editRow].state ? this.fordPersonDetails[this.editRow].state : '',
        addZipCode: this.fordPersonDetails[this.editRow].zipCode ? this.fordPersonDetails[this.editRow].zipCode : '',
        addPhone: this.fordPersonDetails[this.editRow].phone ? this.fordPersonDetails[this.editRow].phone : '',
        addFax: this.fordPersonDetails[this.editRow].fax ? this.fordPersonDetails[this.editRow].fax : '',
        addMobile: this.fordPersonDetails[this.editRow].mobile ? this.fordPersonDetails[this.editRow].mobile : '',
        addGenericCdsId: this.fordPersonDetails[this.editRow].genericNamCdsId ? this.fordPersonDetails[this.editRow].genericNamCdsId : ''
      });
    }
  }

  roleEditChange() {
    this.createPerson.get("addRole").valueChanges.subscribe(data => {
      let titleCode = data;
      if (titleCode == 'ROM' || titleCode == 'RSM') {
        this.createPerson.controls.dealToAuthorFlag.enable();
      } else {
        this.createPerson.controls['addGenericCdsId'].setValue('');
        this.createPerson.controls['dealToAuthorFlag'].setValue(false);
        this.createPerson.controls.dealToAuthorFlag.disable();
      }
      if (titleCode == 'ADM' || titleCode == 'CTL' || titleCode == 'RVW') {
        this.createPerson.controls['regionName'].setValue(this.populatingRegionList[0].regionName);
        this.createPerson.controls.regionName.disable();
        this.regionNameUpdate = this.populatingRegionList[0].regionName;
      } else {
        this.createPerson.controls['regionName'].setValue('');
        this.createPerson.controls.regionName.enable();
        this.regionNameUpdate = '';
      }
    });
  }

  orgEditChange() {
    this.createPerson.get("fordOrgCode").valueChanges.subscribe(data => {
      let titleCode = data;
      if (titleCode == 'CVO') {
        this.createPerson.controls.zoneCd.enable();
        this.fordOrgCodeUpdate = '';
      } else {
        this.createPerson.controls.zoneCd.disable();
        this.createPerson.controls['zoneCd'].setValue('');
        this.fordOrgCodeUpdate = '';
      }
    });
  }

  setRegionNameUpdate() {
    this.createPerson.get("regionName").valueChanges.subscribe(data => {
      this.regionNameUpdate = data;
    });
  }

  editContact(update) {
    if (update) {
      this.createPerson.valueChanges.subscribe(data => {
        let dealToAuthFlag;
        let zone;
        let zoneCd;
        let region;
        if (data['addCdsId'] != null && this.zoneMap != null) {
          if (this.dealToAuthorFlagUpdate == true) {
            dealToAuthFlag = 'Y';
          } else {
            dealToAuthFlag = 'N';
          }
          if (data['fordOrgCode'] == 'CVO') {
            zone = data['zoneCd'] == null || data['zoneCd'] == '' ? '' : this.zoneMap.get(data['zoneCd']);
            zoneCd = data['zoneCd'] == null || data['zoneCd'] == '' ? '' : data['zoneCd'];
          } else {
            zone = '';
            zoneCd = '';
          }
          if (data['fordOrgCode'] == 'ADM' || data['fordOrgCode'] == 'CTL' || data['fordOrgCode'] == 'RVW') {
            region = data['regionName'];
          } else {
            region = this.regionNameUpdate;
          }

          this.updateFordPersonArray = [];
          this.updateFordPersonArray = {
            "addressLine1": data['addAddressLine1'] == null || data['addAddressLine1'] == '' ? '' : data['addAddressLine1'],
            "addressLine2": data['addAddressLine2'] == null || data['addAddressLine2'] == '' ? '' : data['addAddressLine2'],
            "cdsId": data['addCdsId'] == null || data['addCdsId'] == '' ? '' : data['addCdsId'].toUpperCase(),
            "city": data['addCity'] == null || data['addCity'] == '' ? '' : data['addCity'],
            "country": this.updateDomainCountry,
            "dealToAuthFlag": dealToAuthFlag,
            "fax": data['addFax'] == null || data['addFax'] == '' ? '' : data['addFax'],
            "firstName": data['addFirstName'] == null || data['addFirstName'] == '' ? '' : data['addFirstName'],
            "genericNamCdsId": this.addGenericCdsIdUpdate,
            "lastName": data['addLastName'] == null || data['addLastName'] == '' ? '' : data['addLastName'],
            "mobile": data['addMobile'] == null || data['addMobile'] == '' ? '' : data['addMobile'],
            "organization": data['fordOrgCode'] == null || data['fordOrgCode'] == '' ? '' : data['fordOrgCode'],
            "phone": data['addPhone'] == null || data['addPhone'] == '' ? '' : data['addPhone'],
            "region": region,
            "role": data['addRole'] == null || data['addRole'] == '' ? '' : data['addRole'],
            "roleCd": data['addRole'] == null || data['addRole'] == '' ? '' : this.roleMap.get(data['addRole']),
            "salutationCd": data['salutationDesc'] == "" || data['salutationDesc'] == null ? '' : this.salutationMap.get(data['salutationDesc']),
            "salutationDesc": data['salutationDesc'] == "" || data['salutationDesc'] == null ? '' : data['salutationDesc'],
            "state": data['stateCd'] == null || data['stateCd'] == '' ? '' : data['stateCd'],
            "statusFlag": data['addStatus'],
            "superVisorCdsId": data['addSupervisor'] == null || data['addSupervisor'] == '' ? '' : data['addSupervisor'].toUpperCase(),
            "zipCode": data['addZipCode'] == null || data['addZipCode'] == '' ? '' : data['addZipCode'],
            "zone": zone,
            "zoneCd": zoneCd
          }
          this.updateSaveEnable = true;
        }
      });
    } else if (this.updateFordPersonArray.region == '') {
      this.RestcallService.statusMessage(417, 'Please select the Region');
    } else if (this.updateFordPersonArray.zone == '' && this.updateFordPersonArray.organization == 'CVO') {
      this.RestcallService.statusMessage(417, 'Zone is mandatory');
    } else {
      if (this.updateFordPersonArray.superVisorCdsId == '') {
        this.RestcallService.statusMessage(417, 'Supervisor CDSID need to be entered');
      } else if (this.updateFordPersonArray.superVisorCdsId == this.updateFordPersonArray.cdsId) {
        this.RestcallService.statusMessage(417, 'Please make sure Supervisor Cdsid and Cdsid are different ')
      } else {
        let updateUrl = '/fleet-user-management/fleet-users/v1/ford-person';
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('updateUserCdsId', this.updateFordPersonArray.cdsId);
        let fordPersonVo = this.updateFordPersonArray;
        this.RestcallService.updateData(updateUrl, JSON.stringify(fordPersonVo)).subscribe(data => {
          this.findData('');
          this.updateSaveEnable = false;
        });
        this.editRow = -1;
        this.addHide = true;
        this.createPerson.reset();
        this.clickCount = 0;
        this.dealToAuthorFlagUpdate = false;
      }
    }
  }

  editCancel() {
    this.editRow = -1;
    this.addHide = true;
    this.createPerson.reset();
    this.clickCount = 0;
    this.dealToAuthorFlagUpdate = false;
    this.updateSaveEnable = false;
  }

  addSupervisorEvent() {
    let addSupervisor = this.createPerson.get('addSupervisor').value;
    if (addSupervisor != "") {
      this.configUrl = "/fleet-user-management/fleet-users/v1/cds-id-details";
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('updateUserCdsId', addSupervisor);
      this.RestcallService.getData(this.configUrl).subscribe(data => {
        data == null || data == '' ? this.RestcallService.statusMessage(417, addSupervisor + ' not exist.') : '';
      });
    }
  }
}
