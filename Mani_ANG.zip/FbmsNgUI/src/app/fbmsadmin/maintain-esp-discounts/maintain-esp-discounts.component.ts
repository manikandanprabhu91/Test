import { DatePipe } from '@angular/common';
import { Component, OnInit,Inject } from '@angular/core';
import { Form, FormBuilder, FormGroup,FormControl, Validators } from '@angular/forms';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'maintain-esp-discounts',
  templateUrl: './maintain-esp-discounts.component.html',
  styleUrls: ['./maintain-esp-discounts.component.sass']
})
export class MaintainEspDiscountsComponent implements OnInit { 
countryCode=sessionStorage.getItem('countryCode');
  opendialog: boolean;
  reportLevel = sessionStorage.getItem('reportLvlCd');
  role = sessionStorage.getItem('roleName');
  bodyStyles:any;
  modelYearDropdown: any;
  modelYearVal: any;
  vehicleLineVal: any;
  vehicleLineDropdown: any;
  contractDropdown:any;
  bodyStyleVal: any;
  bodyStyleDropdown: any;
  loading: boolean;
  today: Date;
  currentYear: any;
  vehicleLineTable: any;
  bodyStyleTable: any;
  bodyStyleGroupTable: any;
  addVehNew: boolean;
  editVehInd: number;
  vehLineDesc:any;
  selectOpt: any;
  vehicleCopySelection: any;
  editVehDesc: any;
  errorDesc: boolean;
  addVehLineMy: any;
  addVehLine: any;
  addVehLineDesc: any;
  addVehLineDiv: any;
  addVehLineDivDropdown:any;
  addVehLineCT:any
  addAmount:number
  addDuration:number
  bodyStyleDesc:any
  addMiles:number
  addDeductible:number
  addVehLineCTDropdown:any
  addbs: any;
  editException: any;
  addExceptionType: boolean;
  addbsGrp: any;
  addBsDD: any;
  submitted = false;
  addContracttypes:any;
  addaddBsDD:any;
  editbgbs: any;
  addvehicleLineDropdown:any;
  checkboxDisabled: boolean = true;
  isAbcChecked:boolean=false;
  ish:boolean=true;
 hellochecked:boolean=true;
 contractTypeDescription:any
 addCopyChecked:any
 editespValue:any
 editcostValue:number
 form: FormGroup;
 esptrue:any;
 numberRegEx = /\-?\d*\.?\d{1,2}/;
 btnSaveHide=true;
 controlProgram: any;
 private formSubmitAttempt: boolean;
  constructor(private Restcallservice: RestcallService, private datePipe: DatePipe,private formBuilder: FormBuilder, private dialog: MatDialog) {
   
   }  
  //model year dropdown onload
  ngOnInit(): void {
    this.bodyStyleVal = 'ALL';
    this.vehicleLineVal='ALL';
    this.checkboxDisabled=false;
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.vehicleCopySelection = [];
    this.selectOpt = null;
    this.loading = true;
    this.today = new Date;
   let modelYearUrl = '/fleet-administrations/esp-discounts/v1/model-years';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(modelYearUrl).subscribe(respData => {
    respData != null ? this.modelYearDropdown = respData.modelYear: this.modelYearDropdown = null;
    this.modelYearDropdown.includes(Number(this.currentYear)) == true ? this.modelYearVal = Number(this.currentYear) : this.modelYearVal = this.modelYearDropdown[0] 
    this.modelYearDropdown != null ? this.loadVehicleLine(): '';
    this.loading= false;
    }, err => {this.modelYearDropdown = null; this.loading = false;});
  }

  displayFieldCss(field: string) {
   console.log("The current field haserror for Field:"+ field + this.isFieldValid(field));
    console.log("The current field hasFeedback for Field:"+  field + this.isFieldValid(field));
    return {
      
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field) 
    };

  }
 
isFieldValid(field: string) {
  return (!this.form.get(field).valid && this.form.get(field).touched) ||
    (this.form.get(field).untouched && this.formSubmitAttempt);
}
 //Vehicle line dropdown values 
  loadVehicleLine(){
    this.vehicleLineDropdown = null;
    this.bodyStyleDropdown = null;
    //this.vehicleLineVal = 'select';
  let vehicleUrl = '/fleet-administrations/esp-discounts/v1/vehicle';
    this.Restcallservice.ngOnInit();
    let modelYearValarray=this.modelYearVal;
    let modval=modelYearValarray[0];
    this.Restcallservice.setQueryParams("modelYear",modelYearValarray);
    this.vehicleLineVal = 'ALL';this.bodyStyleVal = 'ALL';
   this.Restcallservice.getData(vehicleUrl).subscribe(respData => {this.vehicleLineDropdown = respData.espVehBodyVOS;
 this.vehicleLineVal = 'ALL';this.bodyStyleVal = 'ALL';
 this.vehicleLineDropdown != null ? this.loadBodyStyle(): this.bodyStyleVal = 'ALL';
  }, err=>{
    this.loading = false;
    this.vehLineDesc = null;
    this.vehicleLineDropdown = null;
  });
}

//Vehicle line dropdown values -for add
loadAddVehicle(addMY){
  this.addVehLine = 'select';
  this.addbs = 'select';
  if(addMY != 'select'){
    let vehicleUrl = '/fleet-administrations/esp-discounts/v1/vehicle';
    this.Restcallservice.ngOnInit();
    //let modelYearValarray=this.modelYearVal;
    let modval=addMY;
    this.addVehLine='select';
    this.addbs='select';
    this.Restcallservice.setQueryParams("modelYear",modval);
   this.Restcallservice.getData(vehicleUrl).subscribe(respData => {this.addvehicleLineDropdown = respData.espVehBodyVOS; 
  // this.addVehLine=this.addvehicleLineDropdown[0].vehLineKey;
   this.addVehLine='select';this.addbs='select';
   this.addvehicleLineDropdown != null ? this.loadaddBodyStyle(this.addVehLine): this.addbs='select';
   this.loadaddBodyStyle(this.addVehLine);

});
}   
}
//load bodystyle -for add
loadaddBodyStyle(Veh){
  this.addvehicleLineDropdown.map(data => {  
        if(data.vehLineKey ==Veh){
          this.addaddBsDD = data.bodyStyles;
          this.addbs = this.addaddBsDD[0].bodyStyleKey;
         // this.addbs='select';
        }
      });
      this.addbs='select';
    }

//body style values loaded
   loadBodyStyle(){
    //this.bodyStyleVal = 'select';
     this.bodyStyleDropdown = null;
this.vehicleLineDropdown.map(data => {
      if(data.vehLineKey == this.vehicleLineVal){
        this.bodyStyleDropdown = data.bodyStyles;
        data.bodyStyles != null ? this.bodyStyleVal = this.bodyStyleDropdown[0].bodyStyleKey : this.bodyStyleVal = 'select';
      }
    });
    this.bodyStyleVal='ALL';
    //this.tableGet();
    }
     
    
 //Table functionality
  tableGet(){
      this.selectOpt == 'vehicleLine' ;
      this.addVehNew = false;
      this.vehicleCopySelection = [];
      this.addbs = null;
      this.editVehDesc = null;
      this.editVehInd = null;
      this.editException = null;
      this.addVehLineCT = 'select';
      this.addVehLineMy = 'select';
      this.addVehLineDiv = 'select';
      this.addVehLineDesc = null;
      this.addVehLine = null;
      this.addbsGrp = null;
      this.addBsDD = null;
     this.addExceptionType = null;
      this.vehicleLineTable = null;
      this.bodyStyleTable = null;
     this.loading = true;
      let tableDataUrl = '/fleet-administrations/esp-discounts/v1/esp-option-discount';
    this.Restcallservice.ngOnInit();
  this.Restcallservice.setQueryParams("bodyStyleKey",this.bodyStyleVal);
    this.Restcallservice.setQueryParams("modelYear",this.modelYearVal);
    this.Restcallservice.setQueryParams("vehLineKey",this.vehicleLineVal);
   this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
      respData !=null ? this.vehicleLineTable = respData.espOptionDetails : this.vehicleLineTable = null;
      this.loading = false;
    }, err => {this.loading=false; this.vehicleLineTable = null});
  }

 //Edit
 editVehRow(ind, optVal){
  if(this.role == 'ADM' && this.editVehInd!= ind){
  
    this.addVehNew=false
    this.editVehDesc = null;
    this.editVehInd = ind;
    this.editcostValue = this.vehicleLineTable[ind].cost; 
    this.editespValue = this.vehicleLineTable[ind].invalidESP; 
    if(optVal == 'vehicleLine'){
      this.editVehDesc = this.vehicleLineTable[ind].status 
    }
 
  }
}

//Add row event when icon is clicked
addRow(selectOpt){
this.opendialog = true;
this.formSubmitAttempt = false;   
 this.addVehNew = true;
 //this.addVehLineMy = this.modelYearVal;
 this.addVehLineMy='select';
 this.addVehLine='select';
this.addContracttypes='select'
 this.addbs='select';
 this.loadAddVehicle(this.addVehLineMy);
 this.loadContractTypes();

this.form = new FormGroup({
  myearcontrol :new FormControl(),
  vehcontrol: new FormControl(),
  bdystyle: new FormControl(),
  contr: new FormControl(),
  durat: new FormControl( '', [Validators.pattern(this.numberRegEx) ]),
  name: new FormControl( '', [Validators.pattern(this.numberRegEx) ]),
  deduct: new FormControl( '', [Validators.pattern(this.numberRegEx) ]),
  amt: new FormControl( '', [Validators.pattern(this.numberRegEx) ])
});
//Validators.pattern(/^[0-9]\d*$/)

}
//loading bodystyle dropdown for add 
loadAddBs(){
  this.addBsDD = null;
  this.vehicleLineDropdown.map(data => {
    if(data.vehLineKey == this.vehicleLineVal){
      this.addBsDD = data.bodyStyles;
      this.addbs = this.addBsDD[0].bodyStyleKey;
    }
  });
}   
//loading contracttype dropdown for add 
loadContractTypes(){
   this.contractDropdown = null;
  let addContractUrl = '/fleet-administrations/esp-discounts/v1/contract-types';
  this.Restcallservice.ngOnInit();
  // this.Restcallservice.setQueryParams("vehLineKey", this.addVehLine);
  this.Restcallservice.getData(addContractUrl).subscribe(data => {
    data != null ? this.contractDropdown = data.espContractTypeList : this.contractDropdown = null;
   this.addContracttypes = 'select';
  });
}
 onSubmit() {
      let a=true;
      this.formSubmitAttempt = true;
      Object.keys(this.form.controls).forEach(field => {  
        const control = this.form.get(field).value; 
    if(control=="undefined" || control=="select" || control==null || control=='')
    {
   this.form.valid==false;
      a=false;
      this.form.get(field).setErrors({'incorrect': true});
     }
    
    });

      if (a) {
        console.log('form submitted');
        let addArray = {};
        let contract=this.addContracttypes;
        let bkey=Number(this.addbs);
        let finalArray = {
        "bodyStyleKey": bkey,
          "contractTypeCode": contract,
          "cost":Number(this.addAmount),
          "deductible":Number(this.addDeductible),
          "duration":Number(this.addDuration),
          "espOptionCheck":"true",
          "invalidESP": "true",
          "miles":Number(this.addMiles)
       }
          console.log(JSON.stringify(finalArray));
          let addUrl = '/fleet-administrations/esp-discounts/v1/esp-option-discount';
          this.Restcallservice.ngOnInit();
         this.Restcallservice.createData(addUrl, JSON.stringify(finalArray)).subscribe(data => this.tableGet());
       this.form.reset();
        this.formSubmitAttempt = false;
         this.opendialog = false;
        }
    }
//delete later cancel -for add
  cancel(){
    const dialogRef = this.dialog.open(CancelVl, {width: '300px'});
    dialogRef.afterClosed().subscribe(data => {
      if(data == 'ok'){
        this.addVehNew = false;
        this.editVehInd = null;
        this.addbs = null;
        this.addBsDD = null;
        this.addContracttypes=null;
        this.addDuration=null;
        this.addMiles=null;
        this.addDeductible=null;
        this.addAmount=null;
}
    });
}

// cancel -for update
  editcancel(){
    const dialogRef = this.dialog.open(CancelVl, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'ok'){
          this.addVehNew = false;
          this.editVehInd = null;
          this.addbs = null;
          this.addBsDD = null;
          this.addContracttypes=null;
  }
      });
  }
 //Update 
 saveVehicleLine(eoKey,index){
  let vlSave={
     bodyStyleKey : this.vehicleLineTable[index].bodyStyleKey,
     contractTypeCode: this.vehicleLineTable[index].contractTypeCode,
     cost : this.editcostValue ,
     deductible:this.vehicleLineTable[index].deductible,
     duration:this.vehicleLineTable[index].duration,
      espOptionCheck:this.vehicleLineTable[index].espOptionCheck,
   invalidESP:this.editespValue,  
      miles : this.vehicleLineTable[index].miles
 } 
 let vehUpdateUrl = '/fleet-administrations/esp-discounts/v1/esp-option-discount';
  this.Restcallservice.ngOnInit();
  this.Restcallservice.setQueryParams("eoKey",eoKey);
  this.Restcallservice.updateData(vehUpdateUrl, JSON.stringify(vlSave)).subscribe(data => this.tableGet());
}
vehiclePyDelete(ind){
  const dialogRef = this.dialog.open(DeleteVehiclePY, {width: '300px'});
  dialogRef.afterClosed().subscribe(data => {
    if(data == 'ok'){
      let eoKeyVal=this.vehicleLineTable[ind].eoKey;
      let deleteVehicle = '/fleet-administrations/esp-discounts/v1/esp-option-discount';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("eoKey",eoKeyVal);
      this.Restcallservice.deleteData(deleteVehicle).subscribe(data => this.tableGet());
    }
  });
}
// Copy
copy(){
  let copyVehArray = [];

     this.vehicleCopySelection.map(data => {
      // data.espOptionCheck=true;
      // data.alreadyCopied=true;
       copyVehArray.push(data.eoKey); 
      // copyVehArray.push(data.espOptionCheck); 
     });
      let a=copyVehArray[0]

      let finalArray = {
        "eoKeys": 
          copyVehArray,
        
        }
        console.log(JSON.stringify(finalArray));
    let copyVehUrl = '/fleet-administrations/esp-discounts/v1/esp-option-discount/copy-model-year-plus-one';
     this.Restcallservice.ngOnInit();
     this.Restcallservice.createData(copyVehUrl, JSON.stringify(finalArray)).subscribe(data => this.tableGet());
   }
 }

//Delete Dialog Box
@Component({
selector: 'delete-vehicle-py',
templateUrl: 'delete-vehicle-py.html',
})
export class DeleteVehiclePY {
constructor(
public dialogRef: MatDialogRef<DeleteVehiclePY>, @Inject(MAT_DIALOG_DATA) public data: any) {
}
onYesClick(){
  this.dialogRef.close('ok');
}
onNoClick(): void {
this.dialogRef.close();
}
}

//Dialog box for cancel
@Component({
  selector: 'cancel-vl',
  templateUrl: 'cancel-vl.html',
  })
  export class CancelVl {
  constructor(
  public dialogRef: MatDialogRef<CancelVl>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}








