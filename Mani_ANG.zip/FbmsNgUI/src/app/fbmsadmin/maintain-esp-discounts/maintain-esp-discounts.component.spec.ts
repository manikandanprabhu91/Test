import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainEspDiscountsComponent } from './maintain-esp-discounts.component';

describe('MaintainEspDiscountsComponent', () => {
  let component: MaintainEspDiscountsComponent;
  let fixture: ComponentFixture<MaintainEspDiscountsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainEspDiscountsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainEspDiscountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
