import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DealerStockReplacementComponent } from './dealer-stock-replacement.component';

describe('DealerStockReplacementComponent', () => {
  let component: DealerStockReplacementComponent;
  let fixture: ComponentFixture<DealerStockReplacementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DealerStockReplacementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DealerStockReplacementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
