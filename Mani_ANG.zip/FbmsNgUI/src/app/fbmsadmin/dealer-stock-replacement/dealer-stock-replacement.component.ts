import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, of, Subscription } from 'rxjs';
import { tap, startWith, debounceTime, distinctUntilChanged, switchMap, map, finalize } from 'rxjs/operators';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { UserauthcheckService } from 'src/app/services/userauthcheck.service';

export interface Brand {
}
@Component({
  selector: 'dealer-stock-replacement',
  templateUrl: './dealer-stock-replacement.component.html',
  styleUrls: ['./dealer-stock-replacement.component.sass']
})
export class DealerStockReplacementComponent implements OnInit {
  dealer: any;
  myControl = new FormControl();
  options: string[] = [];
  data: any;
  copyVehArray = [];
  loading: boolean;
  dealerDropdown: any;
  //currentyear for ModelYear
  currentYear: number = new Date().getFullYear();
  modelYearVal: any;
  vehicleLineDropdown: any;
  vehicleLineVal: any;
  vehLineDesc: any;
  bodyStyleVal: any;
  country: any;
  catlogDropdown: any;
  exteriorVal: any;
  interiorVal: any;
  exteriorDropdown: any;
  interiorDropdown: any;
  floorPlanDaysVal: any;
  vehicleLineTable: any;
  catlogvalidate: any;
  dealvalidate: any;
  extdesc: any;
  intdesc: any;
  vinVal: any;
  Select: String = 'Select';
  agingVal: any;
  cdsId: any;
  statusVal: any;
  vehicleCopySelection: any;
  dealerCodeVal: any;
  dealercodedescription: any;
  bodyKey: any;
  form: FormGroup;
  textareaVal: any;
  brands: Brand[] = [
    30, 45, 60, 90, 120, 150, 180
  ];
  private formSubmitAttempt: boolean;
  constructor(private Restcallservice: RestcallService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
     
    this.modelYearVal = this.currentYear;
    this.vehicleLineVal = 0;
    this.bodyStyleVal = 0;
    this.data = null;
    this.vehicleLineDropdown = [];
    this.invokeDealerCode();
    this.exteriorDropdown = [];
    this.interiorDropdown = [];
    this.vehicleCopySelection = null;
    this.form = new FormGroup({
      modelyearvalidate: new FormControl(),
      vehiclevalidate: new FormControl(),
      dealvalidate: new FormControl(),
      catlogvalidate: new FormControl(),

    });

  }
  updated() {
    this.options = [];
    if (this.myControl.value.length >= 3) {
      let all = this.dealer;
      let searchedWord = this.myControl.value
      for (let key in all) {
        let real = all[key].search(new RegExp(searchedWord, "i"));
        if (real != -1) {
          this.options.push(all[key])
        }
      }
    } else {
      this.options = []
    }
  }

  invokeDealerCode() {
    //loading Dealercode values
    let modelYearUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/dealer-info';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(modelYearUrl).subscribe(respData => {
      this.dealerDropdown = respData.dealerInfo;
      this.dealercodedescription = respData.dealerInfo;
      this.filterDealval(this.dealercodedescription);
      this.dealerCodeVal = respData.dealerInfo[0].dealerCode;
      this.modelYearVal = this.currentYear;
      this.vehicleLineVal = this.Select;
      this.bodyStyleVal = this.Select;
      this.loadVehicleLine();
    }, err => { this.dealerDropdown = null; this.loading = false; });
  }

  filterDealval(deal) {
    let temparr = [];
    deal.map(data => {
      this.copyVehArray.push({
        "description": data.description,
      });
    });
    console.log(this.copyVehArray);
    let ddKey = Object.values(this.copyVehArray);
    console.log(ddKey);
    this.copyVehArray.forEach(function (object) {
      var desc = object.description;
      temparr.push(desc);
    });
     this.dealer = temparr;
   }


  //loading VehicleLine dropdown values based on ModelYear Selection
  loadVehicleLine() {
    //this.dealvalidate.clearValidators();
    this.vehicleCopySelection = null;
    //this.vehicleLineDropdown=0;
    this.vehicleLineVal=0;
   // this.catlogDropdown = 0;
    this.bodyStyleVal= 0;
    this.exteriorDropdown = [];
    this.interiorDropdown = [];
    let vehicleUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-line';
    this.Restcallservice.ngOnInit();
    let modelYearValarray = this.modelYearVal;
    let modval = modelYearValarray[0];
    this.Restcallservice.setQueryParams("modelYear", modelYearValarray);
    this.Restcallservice.getData(vehicleUrl).subscribe(respData => {
      respData != null
      ? this.vehicleLineDropdown = respData.vehicleLineDtoList : this.vehicleLineDropdown = null;
   if (this.vehicleLineDropdown != null) {
       //this.vehicleLineVal = this.vehicleLineDropdown[0];
       this.vehicleLineVal = 0;
       this.bodyStyleVal=0;
       //this.loadBodyStyle();
      }
      else {
        //this.vehicleLineDropdown = null;
        //this.catlogDropdown = null;
        this.vehicleLineVal = 0;
        this.bodyStyleVal = 0;
        
      }
    }, err => {
      this.loading = false;
      //this.vehLineDesc = null;
      //this.vehicleLineDropdown = null;
      this.vehicleLineVal = 0;
    });
  }


  //loading Catlog/Bodystyle dropdown values based on VehicleLIne Selection
  loadBodyStyle() {
    //this.dealvalidate.clearValidators();
    this.vehicleCopySelection = null;
    //this.bodyStyleVal = this.Select;
    this.exteriorDropdown = [];
    this.interiorDropdown = [];
    //this.catlogDropdown=0;
    this.bodyStyleVal=0;
    let catlogUrl = '/fleet-administrations/vehicle-lines/v1/body-style/' + this.modelYearVal + '/' + this.vehicleLineVal;
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(catlogUrl).subscribe(respData => {
      respData != null
      ? this.catlogDropdown = respData.bodyStyleList : this.catlogDropdown = null;
      //dont remove the below lines
     // this.bodyStyleVal = this.catlogDropdown[0].bodyStyleCode;
     this.bodyKey = this.catlogDropdown[0].bodyStyleKey;
     this.bodyStyleVal=0;
      this.loading = false;
     
    },err => {
      this.loading = false;
      
      this.bodyStyleVal = 0;
    });
  }

  //Get Colors Click Event
  getColors() {
    this.vehicleCopySelection = null;
    let de = this.form.get('dealvalidate').value;
    if (this.form.get('dealvalidate').value == "" || this.form.get('dealvalidate').value == null) {
      this.form = this.formBuilder.group({
        dealvalidate: ['', Validators.required],
      });
    }
    if (this.form.get('dealvalidate').value != null && this.form.get('dealvalidate').value != "") {
      this.exteriorDropdown = [];
      this.interiorDropdown = [];
      this.loading = true;
      let colorDataUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/colors/' + this.modelYearVal
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("catalogCode", this.bodyStyleVal);
      this.Restcallservice.getData(colorDataUrl).subscribe(respData => {
        this.exteriorDropdown = respData.colorsObject.exteriorColors.color;
        this.interiorDropdown = respData.colorsObject.interiorColors.color;
        this.extdesc = this.exteriorDropdown[0].description;
        this.intdesc = this.interiorDropdown[0].description;
        if (this.exteriorDropdown[0].description == "        ") {
          this.exteriorDropdown[0].description = 'None';
          this.exteriorVal = this.exteriorDropdown[0].code;
        }
        else { this.exteriorVal = this.exteriorDropdown[0].code; }
        if (this.interiorDropdown[0].description == "        ") {
          this.interiorDropdown[0].description = 'None';
          this.interiorVal = this.interiorDropdown[0].code;
        }
        else {
          this.interiorVal = this.interiorDropdown[0].code;
        }
        this.floorPlanDaysVal = this.brands[0];
        this.loading = false;
        this.invokeTable(this.exteriorVal, this.interiorVal);
      }, err => { this.loading = false; });
    }
  }
 invokeTable(newexteriorVal, newinteriorVal) {
    let tableDataUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/available-vins/' + this.modelYearVal
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("catalogCode", this.bodyStyleVal);
    this.Restcallservice.setQueryParams("model-year", this.modelYearVal);
    let addArray = {
      "exteriorColorCodes": [newexteriorVal],
      "interiorColorCodes": [newinteriorVal],
    };
    this.vehicleLineTable=null;
    this.Restcallservice.createData(tableDataUrl, JSON.stringify(addArray)).subscribe(data =>  {
      data != null ? this.vehicleLineTable = data : this.vehicleLineTable = null;
   });
    this.exteriorVal = newexteriorVal;
    this.interiorVal = newinteriorVal;
  }  
 //invoice
  invoice(rowIndex) {
    let dealercoderetrieval; 
    if (this.form.get('dealvalidate').value != null && this.form.get('dealvalidate').value != "") {
      let vinDetailsVoList = [];
      this.cdsId = sessionStorage.getItem('loginId');
      let modDate;
      this.vehicleCopySelection.map(data => {
        vinDetailsVoList.push({
          "acctMgrId": this.cdsId,
          "aging": data.aging,
          "blockedDate": null,
          "exteriorColorCode": data.extColorCode,
          "exteriorColorDesc": data.extColorDesc,
          "interiorColorCode": data.intColorCode,
          "interiorColorDesc": data.intColorDesc,
          "status": data.vinStatus,
          "vinCode": data.vinCode
        })
      });
      let matchval = this.data.match(/\((.*)\)/);
      if (matchval != null) {
        dealercoderetrieval = this.data.match(/\((.*)\)/).pop();
      }
      else { dealercoderetrieval = this.data }
      let finalcopyVeh = {
        "dealerCode": dealercoderetrieval,
        "flrPlnDays": this.floorPlanDaysVal,
        "splInstructions": this.textareaVal,
        vinDetailsVoList
      }
      var result = console.log(JSON.stringify(finalcopyVeh));
      let copyVehUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/dealer-vins/' + this.modelYearVal;
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("bodyStyleKey", this.bodyKey);
      this.Restcallservice.setQueryParams("catalogCode", this.bodyStyleVal);
      this.Restcallservice.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => this.getColors());
    }
  }
}






