import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlProgramYearComponent } from './control-program-year.component';

describe('ControlProgramYearComponent', () => {
  let component: ControlProgramYearComponent;
  let fixture: ComponentFixture<ControlProgramYearComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlProgramYearComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlProgramYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
