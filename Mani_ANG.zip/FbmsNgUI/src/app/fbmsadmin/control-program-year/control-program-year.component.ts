import { Component, OnInit, Inject,ViewChildren, QueryList, ElementRef } from '@angular/core';
import { RestcallService } from '../../services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, Validators } from '@angular/forms';
import { ExportsService } from '../../services/exports.service';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';

@Component({
  selector: 'control-program-year',
  templateUrl: './control-program-year.component.html',
  styleUrls: ['./control-program-year.component.sass']
})
export class ControlProgramYearComponent implements OnInit {
  @ViewChildren("checkboxes") checkboxes: QueryList<ElementRef>;
  controlProgram: any;
  loading: boolean;
  purgeProgram: any;
  selectOpt: any;
  controlVal: any;
  purgeVal: any;
  controlEdit: number;
  controlAdd: boolean;
  role = sessionStorage.getItem('roleName');
  addPy : FormControl;
  addStartDate: FormControl;
  addEndDate: FormControl;
  addArchived: string;
  addAE : string;
  addCPY: string;
  editStartDate: FormControl;
  editEndDate: any;
  editArchived: string;
  editAE : string;
  editCPY: string;
  segment: string;
  endPY: any;
  endPYVals: any;
  purgeSelection: any;
  country: any;
  selectedVals: any;
  unselectedVals: any;
  newval:any;
  valueUpdate: any = [];
  masterSelected: boolean;
  constructor(private Restcallservice: RestcallService, private dialog: MatDialog, private exportExcel : ExportsService, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.editStartDate = new FormControl();
    this.editEndDate = new FormControl();
    this.addStartDate = new FormControl();
    this.addEndDate = new FormControl();
//     let myMoment: moment.Moment = moment("06/08/2021");
// alert(myMoment);
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.country = sessionStorage.getItem('countryCode');
    this.addPy = new FormControl('', [Validators.pattern("^[0-9]*$"), Validators.min(1900), Validators.max(9999), Validators.maxLength(4)]);
    this.addArchived = '';
    this.addAE = '';
    this.addCPY = '';
    this.purgeSelection =[];
    this.controlEdit = null;
    this.controlAdd = false;
    this.segment = 'Commercial';
    this.editArchived = '';
    this.editAE = '';
    this.editCPY = '';
    this.selectOpt = 'control'
   
	  if(this.country == 'USA'){
      this.endPYValsGet();
    } 
    if(this.selectOpt == 'control'){
      this.loading=true;
    }
    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
    }, err=> {this.loading = false; this.controlProgram = null });

  }
  endPYValsGet(){
    let pyGetUrl = '/fleet-administrations/program-years/v1/purge-program-year/matrix';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(pyGetUrl).subscribe(data => {
      console.log(data);
      data == null || data == "" ? this.endPYVals = null : this.endPYVals = data.purgeMatrixDetails;
      if(this.endPYVals != null){
        this.endPY = this.endPYVals[this.segment][0];
        //this.purgeGet();
      }

    });
  }

  purgeGet(){
    
    this.selectedVals =[];
    this.unselectedVals = [];
    if(this.selectOpt == 'purge'){
      this.loading=true;
    }
    this.purgeSelection=[];
    let purgeUrl = '/fleet-administrations/program-years/v1/purge-program-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("segment", this.segment);
    this.Restcallservice.setQueryParams("endYear", this.endPY);
    this.Restcallservice.getData(purgeUrl).subscribe(data => {
      data == null || data == "" ? this.purgeProgram = null : this.purgeProgram = data.purgeViewResponseList;
      if(this.purgeProgram.length > 0){
        this.purgeProgram.map(data => {
          if(data.purged == true){
            this.purgeSelection.push({acctName: data.acctName,
            endYear: data.endYear,
            finCode: data.finCode,
            finKey: data.finKey,
            purged: data.purged,
            segmentGroupType: data.segmentGroupType
          })
          }
        });
      }
      this.loading = false;
    }, err=> {this.loading = false; this.purgeProgram = null });
    
  this.masterSelected=false;
  this.valueUpdate=[];
  }
  addRow(){
    this.controlAdd = true;  
    this.addAE='N';
    this.addCPY='N';
    this.addArchived='N';

    this.controlEdit =null;
    this.editStartDate.setValue(null);
    this.editEndDate.setValue(null);
    this.editArchived=null;
    this.editAE=null;
    this.editCPY=null;

  }
  editRow(ind, startDate, endDate){
    this.controlEdit = ind;
    this.controlAdd = false;
    this.addPy.reset;
    this.addEndDate.setValue(null);
    this.addStartDate.setValue(null);
    this.addArchived=null;
    this.addAE=null;
    this.addCPY=null;
    this.editStartDate.setValue(new Date(startDate));
    this.editEndDate.setValue(new Date(endDate));
    this.editArchived = this.controlProgram[ind].archiveFlag;
    this.editAE = this.controlProgram[ind].activateAutoEarlyFlag;
    this.editCPY = this.controlProgram[ind].currentProposalYearFlag;
  }
  
  saveControl(proposalYearCode) {
    let saveArray = {};
    // const date_regex =   new RegExp('\b(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}\b');// /^\d{2}\/\d{2}\/\d{4}$/ ;
    // let date_regex =   new RegExp('(1[0-2]|0[1-9])/(3[01]|[12][0-9]|0[1-9])/[0-9]{4}');// /^\d{2}\/\d{2}\/\d{4}$/ ;
    // let regx = new RegExp('^(0?[1-9]|1[0-2])[\/](0?[1-9]|[1-2][0-9]|3[01])');
    let date = this.datePipe.transform(this.editEndDate.value, 'MM/dd/yyyy');
    let endDate = this.datePipe.transform(this.addEndDate.value, 'MM/dd/yyyy');
    if (this.Restcallservice.validatedate(date)) {
      if (this.controlAdd == true && this.controlEdit == null) {
        saveArray = {
          "activateAutoEarlyFlag": this.addAE,
          "archiveFlag": this.addArchived,
          "currentProposalYearFlag": this.addCPY,
          "endYear": this.datePipe.transform(this.addEndDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z',
          "proposalYearCode": Number(this.addPy.value),
          "startYear": this.datePipe.transform(this.addStartDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z'
        }
        console.log(JSON.stringify(saveArray));
        let saveUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.createData(saveUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit());
      }
      else if (this.controlAdd == false && this.controlEdit != null) {
        let editsaveArray = {};
        let editStartDateMod = this.datePipe.transform(this.editStartDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z';
        let editEndDateMod = this.datePipe.transform(this.editEndDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z';
        editsaveArray = {
          "activateAutoEarlyFlag": this.editAE,
          "archiveFlag": this.editArchived,
          "currentProposalYearFlag": this.editCPY,
          "endYear": editEndDateMod,
          "proposalYearCode": proposalYearCode,
          "startYear": editStartDateMod
        }
        console.log(JSON.stringify(editsaveArray));
        let editSaveUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.updateData(editSaveUrl, JSON.stringify(editsaveArray)).subscribe(data => this.ngOnInit());
      }
    } else if (this.Restcallservice.validatedate(endDate)) {
      if (this.controlAdd == true && this.controlEdit == null) {
        saveArray = {
          "activateAutoEarlyFlag": this.addAE,
          "archiveFlag": this.addArchived,
          "currentProposalYearFlag": this.addCPY,
          "endYear": this.datePipe.transform(this.addEndDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z',
          "proposalYearCode": Number(this.addPy.value),
          "startYear": this.datePipe.transform(this.addStartDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z'
        }
        console.log(JSON.stringify(saveArray));
        let saveUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.createData(saveUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit());
      }
      else if (this.controlAdd == false && this.controlEdit != null) {
        let editsaveArray = {};
        let editStartDateMod = this.datePipe.transform(this.editStartDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z';
        let editEndDateMod = this.datePipe.transform(this.editEndDate.value, 'yyyy-MM-dd') + 'T19:13:45.864Z';
        editsaveArray = {
          "activateAutoEarlyFlag": this.editAE,
          "archiveFlag": this.editArchived,
          "currentProposalYearFlag": this.editCPY,
          "endYear": editEndDateMod,
          "proposalYearCode": proposalYearCode,
          "startYear": editStartDateMod
        }
        console.log(JSON.stringify(editsaveArray));
        let editSaveUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.updateData(editSaveUrl, JSON.stringify(editsaveArray)).subscribe(data => this.ngOnInit());
      }
    } else {
      this.Restcallservice.openFailureSnackBar("", "Invalid date format!")
      // alert("Invalid date format!")
    }


  }

  cancelControl(){
    const dialogRef = this.dialog.open(CancelConfirm, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'ok'){
      this.ngOnInit();
        }
      });
  }


/*  selectunselect(accountVal)
  {
    this.rowSelect(accountVal);
    this.rowUnSelect(accountVal);
  }*/
  //on Row select
  rowSelect(event){
    this.unselectedVals=[];
    console.log(event.data.finKey);
    if(this.selectedVals.length > 0){
      if(this.selectedVals.includes(event.data.finKey) == false){
        this.selectedVals.push(event.data.finKey);
      }
    }else{
      this.unselectedVals=[];
      this.selectedVals.push(event.data.finKey);
     
    }
    let a=this.selectedVals;
    console.log(this.selectedVals);

  }


  //onrow unselect
  rowUnSelect(event){  
    this.selectedVals=[];
  if(this.selectedVals.length > 0){
      if(this.selectedVals.includes(event.data.finKey) == true){
        let duplicateSelection = this.selectedVals;
        duplicateSelection.map((data, index) => {
          if(data == event.data.finKey){
            this.selectedVals.splice(index, 1);
          }
        });
      }else{
        if(this.unselectedVals.length > 0){
          if(this.unselectedVals.includes(event.data.finKey)== true){
            let duplicateSelection = this.selectedVals;
            duplicateSelection.map((data, index) => {
              if(data == event.data.finKey){
                this.unselectedVals.splice(index, 1);
              }
            });
          }else{
            this.unselectedVals.push(event.data.finKey);
            this.selectedVals=[];
          }
        }      
        else{
          this.unselectedVals.push(event.data.finKey);
          this.selectedVals=[];
        }
      }
    }else{
      if(this.unselectedVals.length > 0 && this.selectedVals >0){
        if(this.unselectedVals.includes(event.data.finKey)== true){
          let duplicateSelection = this.selectedVals;
          duplicateSelection.map((data, index) => {
            if(data == event.data.finKey){
              this.unselectedVals.splice(index, 1);
            }
          });
        }else{
          this.unselectedVals.push(event.data.finKey);
          this.selectedVals=[];
        }
      }
      else{
        this.unselectedVals.push(event.data.finKey);
        let a=this.unselectedVals;
        this.selectedVals=[];
      }
    }
    console.log(this.unselectedVals);
  }



  purge(){
   if(this.selectedVals.length > 0 || this.unselectedVals.length > 0){
      const dialogRef = this.dialog.open(PurgeConfirm, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'purge'){
      let selectPurgeArray=[];
      if(this.selectedVals.length > 0){
        this.selectedVals.map(data => {
          this.purgeProgram.map(val => {
            if(data == val.finKey){
              if(val.purged==false)
              {
                val.purged=true;
              }
              selectPurgeArray.push({
                    "finMasterKey": val.finKey,
                    "proposalYearCode": val.endYear,
                    "purged": val.purged
                  });
            }
          })

        });
      }
      if(this.unselectedVals.length > 0){
          this.unselectedVals.map(data => {
            this.purgeProgram.map(val => {
              if(data == val.finKey){
                if(val.purged==true)
                {
                  val.purged=false;
                }
                selectPurgeArray.push({
                      "finMasterKey": val.finKey,
                      "proposalYearCode": val.endYear,
                      "purged": val.purged
                    });
              }
            })
          });
      }
      // this.purgeSelection.map(data => {
      //   selectPurgeArray.push({
      //     "finMasterKey": data.finKey,
      //     "proposalYearCode": data.endYear,
      //     "purged": true
      //   });
      // });
      let purgeArray;
      purgeArray =JSON.stringify({purgeProgramYearRequestList: selectPurgeArray});
      
      console.log(purgeArray);
      let purgeUrl ='/fleet-administrations/program-years/v1/purge-program-year';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.createData(purgeUrl,purgeArray).subscribe(data => this.purgeGet());

        }
      });
    }  
  }
  checkUncheckAll(event) {
    this.valueUpdate=[];
    const checked = event.target.checked;
    for (var i = 0; i < this.purgeProgram.length; i++) {
     // this.purgeProgram[i].purged = this.masterSelected;
      if (this.masterSelected == true &&  this.purgeProgram[i].purged==false) {
        this.purgeProgram[i].purged = true;
        this.getCheckedItemList(i);
      }
      else if (this.masterSelected == false &&  this.purgeProgram[i].purged==true) {
        this.purgeProgram[i].purged = false;
        this.getCheckedItemList(i);
      }
     
    }
 }

 getCheckedItemList(i) {
  //if (this.purgeProgram[i].purged)
    // this.valueUpdate.push(this.purgeProgram[i]);

    this.valueUpdate.push({
      "finMasterKey": this.purgeProgram[i].finKey,
      "proposalYearCode": this.purgeProgram[i].endYear,
      "purged": this.purgeProgram[i].purged  
 });

 }




  selectEvent(arg1, event) {
    //this.valueUpdate=[];
    if (event.target.checked==true) {
      this.purgeProgram.purged = true;
    }
    else if (event.target.checked==false) {
      this.purgeProgram.purged = false;
    }
    this.valueUpdate.push({
      "finMasterKey": arg1['finKey'],
      "proposalYearCode": arg1['endYear'],
      "purged": this.purgeProgram.purged  
 });
    
  }  

  saveAE() {
   
   /* let purgeArray;
    let saveArray={
      purgeProgramYearRequestList: this.valueUpdate
    }*/
    //const dialogRef = this.dialog.open(PurgeConfirm, {width: '300px'});
   // dialogRef.afterClosed().subscribe(data => {
     // if(data == 'purge'){
    let selectPurgeArray=[];
    this.valueUpdate.map(dat => {
         selectPurgeArray.push({
          "finMasterKey": dat.finMasterKey,
           "proposalYearCode": dat.proposalYearCode,
         "purged": dat.purged
           });
      });

      let purgeArray;
      purgeArray =JSON.stringify({purgeProgramYearRequestList: selectPurgeArray});

     
      
        if(purgeArray !="{\"purgeProgramYearRequestList\":[]}"){
          const dialogRef = this.dialog.open(PurgeConfirm, {width: '300px'});
          dialogRef.afterClosed().subscribe(data => {
            if(data == 'purge'){
   // purgeArray =JSON.stringify({purgeProgramYearRequestList: this.valueUpdate});
   
    console.log(purgeArray);
    let editUrl ='/fleet-administrations/program-years/v1/purge-program-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.createData(editUrl,purgeArray).subscribe(data => this.purgeGet());
    this.valueUpdate=[];
            }
        });
    //  }
      }
   // });
    }
//}  

  controlDelete(proposalYearCode){
    const dialogRef = this.dialog.open(DeleteControlPY, {width: '300px'});
    dialogRef.afterClosed().subscribe(data => {
      if(data == 'delete'){
    let controlDelUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("proposalYearCode", proposalYearCode);
    this.Restcallservice.deleteData(controlDelUrl).subscribe(data => this.ngOnInit());
    }
  });
  }

  downloadExcel(){
    let downloadData=[];
    let topheader = [];
    let headers = [];
    let title = [];
    
    headers.push({'':'Account Name', 
      ' ':'FIN Code', '  ':'Segment', '   ':'End Year'});

    this.purgeProgram.map(data =>{
      downloadData.push({
        "Account Name": data.acctName,
        "FIN Code": data.finCode,
        "Segment": data.segmentGroupType,
        "End Year": data.endYear
      });
    } );
    this.exportExcel.exportAsExcelFile(downloadData, 'PurgeProgramYearData', topheader,headers,title, '',
		'', '', '', '', '');
  }

  

}



@Component({
  selector: 'delete-control-py',
  templateUrl: 'delete-control-py.html',
  })
  export class DeleteControlPY {
  constructor(
  public dialogRef: MatDialogRef<DeleteControlPY>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}

@Component({
  selector: 'purge-confirm',
  templateUrl: 'purge-confirm.html',
  })
  export class PurgeConfirm {
  constructor(
  public dialogRef: MatDialogRef<PurgeConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('purge');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}


@Component({
  selector: 'cancel-confirm',
  templateUrl: 'cancel-confirm.html',
  })
  export class CancelConfirm {
  constructor(
  public dialogRef: MatDialogRef<CancelConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
