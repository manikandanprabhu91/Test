import { Component, OnInit, ViewChild } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DatePipe, formatDate } from '@angular/common';
import { Table } from 'primeng/table';
import { ExportsService } from 'src/app/services/exports.service';

@Component({
	selector: 'assignment-of-proceeds',
	templateUrl: './assignment-of-proceeds.component.html',
	styleUrls: ['../fbmsadmin.component.sass'],
})
export class AssignmentOfProceedsComponent implements OnInit {
	@ViewChild(Table) templateAssignmentReport: Table;
	@ViewChild(Table) templateAssignee: Table;
	@ViewChild(Table) templateRight: Table;
	selectOpt: any;
	selectMaintainOpt: any;
	configUrl: string = '';
	activeProposalYear: any[];
	cdsIdList: any['ALL'];
	assigneeList: any[];
	assignmentReportList: any[];
	activeYear: any;
	cdsId: string;
	proposalYearChange: boolean;
	operationalViewChange: boolean;
	loading: boolean;
	userStaus: boolean;
	maintainViewChange: boolean;
	aopSearchValueChange: boolean;
	stateList: any[];
	operationalViewList: any[];
	operationalView: any;
	state: any;
	searchValue: any;
	searchValueChange: boolean;
	role = sessionStorage.getItem('roleName');
	statusFront: any;
	statusBack: any;
	assigneeCode: any;
	aopStatusUpdate: any;
	saveArray: any[];
	maintainOperationalView: any;
	maintainsearchValue: any;
	maintainStatus: any = 'All';
	maintainProposalYear: any;
	addNewAssignee: boolean = false;
	createAssignee: FormGroup;
	createMaintain: FormGroup;
	record: boolean = true;
	records: boolean = true;
	newAssigneeCode: any;
	editRow: number;
	addressKey: number;
	assigneeVo: any;
	editEnableCheck: boolean = false;
	assignmentList: any[];
	addMaintainAssignee: boolean = false;
	count: number = 1;
	showAssigneeAdd: boolean = true;
	showMaintainAdd: boolean = true;
	editAssigneeEnable: boolean = false;
	aopEnable: boolean = true;
	controlProgram: any;
	selectProposalYear: number;
	finFlag: boolean = false;
	assigneeCodeFlag: boolean = false;

	constructor(private RestcallService: RestcallService, private route: ActivatedRoute,
		private datePipe: DatePipe, private fb: FormBuilder, private exportExcel: ExportsService) {
		this.createAssignee = this.fb.group({
			assigneeName: ['', [Validators.required, Validators.maxLength(50)]],
			assigneeCode: ['', [Validators.maxLength(8)]],
			status: ['', [Validators.required]],
			attnTo: ['', [Validators.maxLength(50)]],
			addressLine1: ['', [Validators.required, Validators.maxLength(50)]],
			addressLine2: ['', [Validators.maxLength(50)]],
			city: ['', [Validators.required, Validators.maxLength(40)]],
			state: ['', [Validators.required]],
			zipCode: ['', [Validators.maxLength(15)]],
			eftSupplierCode: ['', Validators.maxLength(8)],
			eftBeginDate: [null, Validators.maxLength(10)],
			eftEndDate: [null, Validators.maxLength(10)]
		});

		this.createMaintain = this.fb.group({
			fin: ['', [Validators.required]],
			accountName: [''],
			proposalYear: ['', [Validators.required]],
			assigneeCode: ['', [Validators.required]],
			assigneeName: [''],
			status: ['', [Validators.required]],
			startDate: [''],
			endDate: ['']
		});
	}

	ngOnInit(): void {
		const body = document.getElementsByTagName('body')[0];
		body.classList.add('sidebar-collapse');
		let page = this.route.snapshot.queryParamMap.get('page');
		let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
		this.RestcallService.ngOnInit();
		this.RestcallService.getData(controlUrl).subscribe(data => {
			data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
			this.loading = false;
			if (this.controlProgram != null) {
				this.selectProposalYear = null;
				this.controlProgram.map(val => {
					if (val.currentProposalYearFlag == 'Y') {
						this.selectProposalYear = val.proposalYearCode;
					}
				});
			}
		}, err => { this.loading = false; this.controlProgram = null });
		this.activeYear = 'Select One';
		this.selectOpt = page != null ? page : 'aopAssignee';
		this.selectMaintainOpt = this.selectOpt == 'aopAssignee' ? 'aopAssignee' : '';
		if (this.selectOpt == 'aopAssignee' && this.role == 'RSM') {
			this.aopEnable = false;
		} else {
			this.aopEnable = true;
			this.configUrl = this.selectOpt == 'aopAssignee'
				? '/fleet-administrations/finance-assignments/v1/assignee/state'
				: '/fleet-administrations/finance-assignments-reports/v1/report/proposalYear';
			this.RestcallService.ngOnInit();
			this.RestcallService.getData(this.configUrl).subscribe((data) => {
				if (this.selectOpt == 'aopAssignee') {
					data != null || data != '' ? this.setData(data) : this.setData('');
				} else {
					data != null || data != '' ? (this.activeProposalYear = data.activeProposalYear) : (this.activeProposalYear = []);
				}
			});
		}
	}

	setData(data) {
		this.stateList = data != '' ? data.stateDtoList : [];
		this.operationalViewList = data != '' ? data.operationalViewList : [];
		this.operationalView = 'Select One';
		this.state = 'All';
	}

	activeProposalYearSelected() {
		this.proposalYearChange =
			this.activeYear != 'Select One' ? true : false;
		this.cdsId = 'ALL';
		this.configUrl = '/fleet-administrations/finance-assignments-reports/v1/report/cdsId';
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('activeProposalYear', this.activeYear);
		this.cdsIdList = [];
		this.RestcallService.getData(this.configUrl).subscribe((data) => {
			data != null || data != '' ? (this.cdsIdList = data.cdsIdList) : (this.cdsIdList = []);
		});
	}

	operationalViewSelected() {
		this.operationalViewChange = this.operationalView != 'Select One' ? true : false;
		this.searchValueChange = false;
	}

	searchValueInput() {
		if (this.operationalView != 'Select One' && this.searchValue != '') {
			this.searchValueChange = true;
		} else {
			this.searchValueChange = false;
		}
	}

	maintainSearchValueInput() {
		if (this.maintainOperationalView != 'Select One' && this.maintainsearchValue != '') {
			this.aopSearchValueChange = true;
		} else {
			this.aopSearchValueChange = false;
		}
	}

	searchReport(Status) {
		this.loading = true;
		if (Status) {
			this.templateAssignmentReport.reset();
		}
		this.configUrl = '/fleet-administrations/finance-assignments-reports/v1/report';
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('activeProposalYear', this.activeYear);
		this.RestcallService.setQueryParams('selectedCdsId', this.cdsId);
		this.assignmentReportList = [];
		this.RestcallService.getData(this.configUrl).subscribe((data) => {
			this.loading = false;
			data != null || data != '' ? (this.assignmentReportList = data.assignmentReportList)
				: (this.assignmentReportList = []);
		});
	}

	searchMaintain(Status) {
		this.loading = true;
		if (Status) {
			this.templateAssignee.reset();
		}
		this.record = true;
		this.addNewAssignee = false;
		this.createAssignee.reset();
		this.editRow = null;
		this.showAssigneeAdd = true;
		this.configUrl = '/fleet-administrations/finance-assignments/v1/assignee';
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('operationalView', this.operationalView);
		this.RestcallService.setQueryParams('searchValue', this.searchValue);
		this.RestcallService.setQueryParams('state', this.state);
		this.assigneeList = [];
		this.RestcallService.getData(this.configUrl).subscribe((data) => {
			this.loading = false;
			data != null || data != '' ? (this.assigneeList = data.assigneeList) : (this.assigneeList = []);
		}, err => this.loading = false);
	}


	setStatusClicked(onepick) {
		this.assigneeCode = onepick;
		this.statusFront = onepick.status == 'I' ? 'Inactive' : 'Active';
		this.statusBack = onepick.status == 'I' ? 'Active' : 'Inactive';
		this.userStaus = true;
	}

	aopStatusClicked(onepick) {
		this.aopStatusUpdate = onepick;
		this.statusFront = onepick.status == 'I' ? 'Inactive' : 'Active';
		this.statusBack = onepick.status == 'I' ? 'Active' : 'Inactive';
		this.userStaus = true;
	}

	updateStatus() {
		if (this.selectMaintainOpt == 'aopAssignee') {
			let updateUrl = '/fleet-administrations/finance-assignments/v1/assignee';
			this.RestcallService.ngOnInit();
			this.RestcallService.setQueryParams('mode', 'UPDATE_ASSIGNEE_STATUS');
			this.RestcallService.updateData(updateUrl, this.assigneeCode).subscribe(data => {
				this.userStaus = false;
				this.searchMaintain(false);
			}, err => {
				this.userStaus = false;
				this.searchMaintain(false);
			});
		} else {
			let updateUrl = '/fleet-administrations/finance-assignments/v1/assignment-of-proceeds/status';
			this.RestcallService.ngOnInit();
			this.RestcallService.setQueryParams('operationalView', this.maintainOperationalView);
			this.RestcallService.setQueryParams('proposalYr', this.maintainProposalYear);
			this.RestcallService.setQueryParams('searchValue', this.maintainsearchValue);
			this.RestcallService.setQueryParams('status', this.maintainStatus);
			let request = {
				"assignmentProceedsList": [
					{
						"accountName": this.aopStatusUpdate['accountName'],
						"assigneeCode": this.aopStatusUpdate['assigneeCode'],
						"assigneeName": this.aopStatusUpdate['assigneeName'],
						"endDate": this.aopStatusUpdate['endDate'],
						"finCode": this.aopStatusUpdate['finCode'],
						"finKey": this.aopStatusUpdate['finKey'],
						"proposalYr": this.aopStatusUpdate['proposalYr'],
						"startDate": this.aopStatusUpdate['startDate'],
						"status": this.aopStatusUpdate['status']
					}
				]
			};
			this.RestcallService.updateData(updateUrl, request).subscribe(data => {
				this.userStaus = false;
				this.aopSearchMaintain(false);
			}, err => {
				this.userStaus = false;
				this.aopSearchMaintain(false);
			});
		}
	}

	cancelStatus() {
		this.userStaus = false;
		if (this.selectMaintainOpt == 'aopAssignee') {
			this.searchMaintain(false);
		} else {
			this.aopSearchMaintain(false);
		}
	}

	maintainOperationalViewSelected() {
		this.maintainViewChange = this.maintainOperationalView != 'Select One' ? true : false;
		this.aopSearchValueChange = false;
		this.proposalYear();
	}

	proposalYear() {
		if (this.count == 1) {
			this.configUrl = '/fleet-administrations/finance-assignments-reports/v1/report/proposalYear';
			this.RestcallService.ngOnInit();
			this.RestcallService.getData(this.configUrl).subscribe((data) => {
				data != null || data != '' ? (this.activeProposalYear = data.activeProposalYear) : (this.activeProposalYear = []);
				this.count = 2;
			});
		}
	}

	radioGroup() {
		this.operationalViewChange = false;
		this.maintainViewChange = false;
		this.searchValueChange = false;
		this.aopSearchValueChange = false;
		this.maintainStatus = 'All';
		this.maintainProposalYear = String(this.selectProposalYear);
		this.maintainsearchValue = '';
		this.maintainOperationalView = 'Select One';
		this.state = 'All';
		this.searchValue = '';
		this.operationalView = 'Select One';
		this.assigneeList = [];
		this.editRow = null;
		this.createAssignee.reset();
		this.assignmentList = [];
		this.createMaintain.reset();
		this.addNewAssignee = false;
		this.record = true;
		this.showAssigneeAdd = true;
		this.addMaintainAssignee = false;
		this.records = true;
		this.showMaintainAdd = true;
	}

	assigneeNameClick() {
		this.assignmentReportList = [];
	}

	createNewAssignee() {
		if (this.role == 'ADM' && !this.editEnableCheck) {
			this.showAssigneeAdd = false;
			this.createAssignee.reset();
			this.addNewAssignee = true;
			this.record = false;
			this.configUrl = '/fleet-administrations/finance-assignments/v1/assignee/new-assignee-code';
			this.RestcallService.ngOnInit();
			this.RestcallService.getData(this.configUrl).subscribe((data) => {
				data != null || data != '' ? (this.newAssigneeCode = data.newAssigneeCode) : (this.newAssigneeCode = []);
				this.createAssignee.controls['assigneeCode'].setValue(this.newAssigneeCode);
			});
		}
	}

	saveNewAssignee() {
		if (this.role == 'ADM') {
			if (this.createAssignee.get('state').value != 'All') {
				this.addNewAssignee = false;
				this.record = true;
				let saveUrl = '/fleet-administrations/finance-assignments/v1/assignee';
				let assigneeVo = {
					addressKey: 0,
					addressLine1:
						this.createAssignee.get('addressLine1').value == ''
							? null : this.createAssignee.get('addressLine1').value,
					addressLine2:
						this.createAssignee.get('addressLine2').value == ''
							? null : this.createAssignee.get('addressLine2').value,
					assigneeCode:
						this.createAssignee.get('assigneeCode').value == ''
							? null : this.createAssignee.get('assigneeCode').value,
					assigneeName:
						this.createAssignee.get('assigneeName').value == ''
							? null : this.createAssignee.get('assigneeName').value,
					attentionTo:
						this.createAssignee.get('attnTo').value == ''
							? null : this.createAssignee.get('attnTo').value,
					city:
						this.createAssignee.get('city').value == ''
							? null : this.createAssignee.get('city').value,
					eftEndDate:
						this.createAssignee.get('eftEndDate').value == null
							? null : formatDate(this.createAssignee.get('eftEndDate').value, 'MM/dd/yyyy', 'en'),
					eftStartDate:
						this.createAssignee.get('eftBeginDate').value == null
							? null : formatDate(this.createAssignee.get('eftBeginDate').value, 'MM/dd/yyyy', 'en'),
					state:
						this.createAssignee.get('state').value == null
							? null : this.createAssignee.get('state').value,
					status:
						this.createAssignee.get('status').value == '' || this.createAssignee.get('status').value == null
							? null : this.createAssignee.get('status').value.charAt(0),
					supplierEftCode:
						this.createAssignee.get('eftSupplierCode').value == ''
							? null : this.createAssignee.get('eftSupplierCode').value,
					zipcode:
						this.createAssignee.get('zipCode').value == ''
							? null : this.createAssignee.get('zipCode').value,
				};
				this.RestcallService.ngOnInit();
				this.RestcallService.createData(saveUrl, assigneeVo).subscribe((data) => {
					this.assignmentReportList = [];
					this.createAssignee.reset();
					this.showAssigneeAdd = true;
					if (this.searchValueChange == true) {
						this.searchMaintain(false);
					}
				});
			} else {
				this.RestcallService.statusMessage(417, 'Please select the State');
			}
		}
	}

	cancelNewAssignee() {
		if (this.role == 'ADM') {
			this.addNewAssignee = false;
			this.record = true;
			this.createAssignee.reset();
			this.showAssigneeAdd = true;
		}
	}

	editEnable(ind, onepick) {
		if (!(this.editRow == ind) && this.role == 'ADM' && !this.addNewAssignee) {
			this.editAssigneeEnable = false;
			this.editEnableCheck = true;
			this.editRow = ind;
			this.mapEdit();
			this.editAssignee(true);
			this.addressKey = onepick.addressKey;
			this.showAssigneeAdd = false;
		}
	}

	editAssignee(update) {
		if (update) {
			this.createAssignee.valueChanges.subscribe((data) => {
				this.assigneeVo = {
					addressKey: this.addressKey,
					addressLine1: data['addressLine1'] == '' ? null : data['addressLine1'],
					addressLine2: data['addressLine2'] == '' ? null : data['addressLine2'],
					assigneeCode: data['assigneeCode'] == '' ? null : data['assigneeCode'],
					assigneeName: data['assigneeName'] == '' ? null : data['assigneeName'],
					attentionTo: data['attnTo'] == '' ? null : data['attnTo'],
					city: data['city'] == '' ? null : data['city'],
					eftEndDate: data['eftEndDate'] == null ? null : formatDate(data['eftEndDate'], 'MM/dd/yyyy', 'en'),
					eftStartDate: data['eftBeginDate'] == null ? null : formatDate(data['eftBeginDate'], 'MM/dd/yyyy', 'en'),
					state: data['state'] == '' ? null : data['state'],
					status: data['status'] == '' || data['status'] == null ? null : data['status'].charAt(0),
					supplierEftCode: data['eftSupplierCode'] == '' ? null : data['eftSupplierCode'],
					zipcode: data['zipCode'] == '' ? null : data['zipCode'],
				};
				this.editAssigneeEnable = true;
			});
		} else {
			let updateUrl = '/fleet-administrations/finance-assignments/v1/assignee';
			this.RestcallService.ngOnInit();
			this.RestcallService.setQueryParams('mode', 'UPDATE_ASSIGNEE');
			this.RestcallService.updateData(updateUrl, this.assigneeVo).subscribe(data => {
				this.searchMaintain(false);
				this.createAssignee.reset();
				this.editRow = null;
				this.editEnableCheck = false;
				this.showAssigneeAdd = true;
				if (this.searchValueChange == true) {
					this.searchMaintain(false);
				}
			});
		}
	}

	editCancel() {
		this.editEnableCheck = false;
		this.editRow = null;
		this.createAssignee.reset();
		this.showAssigneeAdd = true;
	}

	mapEdit() {
		if (this.editRow != null) {
			this.createAssignee.patchValue({
				assigneeName: this.assigneeList[this.editRow].assigneeName
					? this.assigneeList[this.editRow].assigneeName : '',
				assigneeCode: this.assigneeList[this.editRow].assigneeCode
					? this.assigneeList[this.editRow].assigneeCode : '',
				status: this.assigneeList[this.editRow].status == 'A' ? 'Active' : 'Inactive',
				attnTo: this.assigneeList[this.editRow].attentionTo
					? this.assigneeList[this.editRow].attentionTo : '',
				addressLine1: this.assigneeList[this.editRow].addressLine1
					? this.assigneeList[this.editRow].addressLine1 : '',
				addressLine2: this.assigneeList[this.editRow].addressLine2
					? this.assigneeList[this.editRow].addressLine2 : '',
				city: this.assigneeList[this.editRow].city
					? this.assigneeList[this.editRow].city : '',
				state: this.assigneeList[this.editRow].state
					? this.assigneeList[this.editRow].state : '',
				zipCode: this.assigneeList[this.editRow].zipcode
					? this.assigneeList[this.editRow].zipcode : '',
				eftSupplierCode: this.assigneeList[this.editRow].supplierEftCode
					? this.assigneeList[this.editRow].supplierEftCode : '',
				eftBeginDate: this.assigneeList[this.editRow].eftStartDate
					? formatDate(this.assigneeList[this.editRow].eftStartDate, 'yyyy-MM-dd', 'en') : null,
				eftEndDate: this.assigneeList[this.editRow].eftEndDate
					? formatDate(this.assigneeList[this.editRow].eftEndDate, 'yyyy-MM-dd', 'en') : null,
			});
		}
	}

	aopSearchMaintain(status) {
		this.loading = true;
		this.records = true;
		if (status) {
			this.templateRight.reset();
		}
		this.addMaintainAssignee = false;
		this.showMaintainAdd = true;
		this.configUrl = '/fleet-administrations/finance-assignments/v1/assignment-of-proceeds';
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('operationalView', this.maintainOperationalView);
		this.RestcallService.setQueryParams('proposalYr', this.maintainProposalYear);
		this.RestcallService.setQueryParams('searchValue', this.maintainsearchValue);
		this.RestcallService.setQueryParams('status', this.maintainStatus);
		this.assignmentList = [];
		this.RestcallService.getData(this.configUrl).subscribe((data) => {
			this.loading = false;
			data != null || data != '' ? this.assignmentList = data.assignmentList : '';
		}, err => this.loading = false);
	}

	createMaintainAssignee() {
		this.showMaintainAdd = false;
		this.createMaintain.reset();
		this.addMaintainAssignee = true;
		this.records = false;
		this.proposalYear();
	}

	aopAdd() {
		if (this.role == 'ADM') {
			if (this.createMaintain.get('proposalYear').value != 'All') {
				let saveUrl = '/fleet-administrations/finance-assignments/v1/assignment-of-proceeds';
				let assignmentProceedsVo = {
					accountName: this.createMaintain.get('accountName').value == '' ? null : this.createMaintain.get('accountName').value,
					assigneeCode: this.createMaintain.get('assigneeCode').value == '' ? null : this.createMaintain.get('assigneeCode').value,
					assigneeName: this.createMaintain.get('assigneeName').value == '' ? null : this.createMaintain.get('assigneeName').value,
					endDate: this.createMaintain.get('endDate').value == '' ? null : this.createMaintain.get('endDate').value,
					finCode: this.createMaintain.get('fin').value == '' ? null : this.createMaintain.get('fin').value,
					finKey: 0,
					proposalYr: this.createMaintain.get('proposalYear').value == '' ? null : this.createMaintain.get('proposalYear').value,
					startDate: this.createMaintain.get('startDate').value == '' ? null : this.createMaintain.get('startDate').value,
					status: this.createMaintain.get('status').value == '' ? null : this.createMaintain.get('status').value.charAt(0)
				};
				this.RestcallService.ngOnInit();
				this.RestcallService.createData(saveUrl, assignmentProceedsVo).subscribe(
					(data) => {
						this.assignmentReportList = [];
						this.createAssignee.reset();
						this.showMaintainAdd = true;
						if (this.aopSearchValueChange == true) {
							this.aopSearchMaintain(false);
						}
					}, err => {
						this.assignmentReportList = [];
						this.createAssignee.reset();
						this.showMaintainAdd = true;
					}
				);
			} else {
				this.RestcallService.statusMessage(417, 'Please select the State');
			}
		}
		this.addMaintainAssignee = false;
		this.records = true;
	}

	aopCancel() {
		this.addMaintainAssignee = false;
		this.records = true;
		this.createAssignee.reset();
		this.showMaintainAdd = true;
		this.finFlag = false;
		this.assigneeCodeFlag = false;
	}

	finChange() {
		let data = this.createMaintain.get('fin').value;
		this.finFlag = false;
		if (data != '') {
			this.loading = true;
			this.configUrl = '/fleet-administrations/finance-assignments/v1/assignment-of-proceeds/fin-code-name';
			this.RestcallService.ngOnInit();
			this.RestcallService.setQueryParams('finCode', data);
			this.RestcallService.getData(this.configUrl).subscribe((data) => {
				this.loading = false;
				data != null || data != '' ? this.createMaintain.controls['accountName'].setValue(data.finCodeName) : '';
			}, err => {
				this.loading = false;
				this.createMaintain.controls['accountName'].setValue('');
				this.finFlag = true;
			});
		} else {
			this.createMaintain.controls['accountName'].setValue('');
		}
	}

	assigneeCodeChange() {
		let data = this.createMaintain.get('assigneeCode').value;
		this.assigneeCodeFlag = false;
		if (data != '') {
			this.loading = true;
			this.configUrl = '/fleet-administrations/finance-assignments/v1/assignment-of-proceeds/assignee-code-name';
			this.RestcallService.ngOnInit();
			this.RestcallService.setQueryParams('assigneeCode', data);
			this.RestcallService.getData(this.configUrl).subscribe((data) => {
				this.loading = false;
				data != null || data != '' ? this.createMaintain.controls['assigneeName'].setValue(data.assigneeCodeName) : '';
			}, err => {
				this.loading = false;
				this.createMaintain.controls['assigneeName'].setValue('');
				this.assigneeCodeFlag = true;
			});
		} else {
			this.createMaintain.controls['assigneeName'].setValue('');
		}
	}

	downloadExcel() {
		let downloadData = [];
		let topheader = [];
		let headers = [];
		let title = [];
		title.push({
			'': '',
			' ': '', '  ': '', '   ': 'Assignment of Proceeds Report'
		});

		topheader.push({
			'': 'Proposal Year',
			' ': this.activeYear
		});

		headers.push({
			'': 'Account Manager',
			' ': 'FIN', '  ': 'Account Name', '   ': 'Payment Type', '    ': 'Start Date',
			'     ': 'Assignee', '      ': 'Start Date ', '       ': 'SDA All $',
			'        ': 'Tier 1 $ Only All', '         ': 'Tier 1 $ Only All Partial'
		});


		if (this.assignmentReportList != null)
			this.assignmentReportList
				.map(data => {
					downloadData.push(Object.values({
						"Account Manager": data.accountManager != null ? data.accountManager : " ",
						"FIN": data.assigneeCode != null ? data.assigneeCode : " ",
						"Account Name": data.accountName != null ? data.accountName : " ",
						"Payment Type": data.payment != null ? data.payment : " ",
						"Start Date": data.letterStartDate != null ? data.letterStartDate : " ",
						"Assignee": data.assigneeName != null ? data.assigneeName : " ",
						"Start Date ": data.sdaStartDate != null ? data.sdaStartDate : " ",
						"SDA All $": data.sdaAll != null ? data.sdaAll : " ",
						"Tier 1 $ Only All": data.tierOne != null ? data.tierOne : " ",
						"Tier 1 $ Only All Partial": data.tierOnePartial != null ? data.tierOnePartial : " "
					}));
				});

		this.exportExcel.exportAsExcelFile(downloadData, 'AssignmentofProceeds', topheader, headers, title, '',
		'', '', '', '', '');

	}
}
