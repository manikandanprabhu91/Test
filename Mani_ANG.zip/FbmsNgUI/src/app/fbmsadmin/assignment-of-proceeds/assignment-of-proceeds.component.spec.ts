import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignmentOfProceedsComponent } from './assignment-of-proceeds.component';

describe('AssignmentOfProceedsComponent', () => {
  let component: AssignmentOfProceedsComponent;
  let fixture: ComponentFixture<AssignmentOfProceedsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignmentOfProceedsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignmentOfProceedsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
