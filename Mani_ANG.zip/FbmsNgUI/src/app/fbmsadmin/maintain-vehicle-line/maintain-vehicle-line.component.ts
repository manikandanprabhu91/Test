import { DatePipe } from '@angular/common';
import { Component, OnInit, Inject } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'maintain-vehicle-line',
  templateUrl: './maintain-vehicle-line.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class MaintainVehicleLineComponent implements OnInit {
  country: any;
  reportLevel: any;
  role: any;
  modelYearDropdown: any;
  modelYearVal: any;
  vehicleLineVal: any;
  vehicleLineDropdown: any;
  bodyStyleVal: any;
  bodyStyleDropdown: any;
  loading: boolean;
  today: Date;
  currentYear: any;
  vehicleLineTable: any;
  bodyStyleTable: any;
  bodyStyleGroupTable: any;
  addVehNew: boolean;
  editVehInd: number;
  selectOpt: any;
  vehicleCopySelection: any;
  editVehDesc: any;
  errorDesc: boolean;
  addVehLineMy: any;
  addVehLine: any;
  addVehLineDesc: any;
  addVehLineDiv: any;
  addVehLineDivDropdown:any;
  addVehLineCT:any
  addVehLineCTDropdown:any
  addbs: any;
  editException: any;
  addExceptionType: boolean;
  addbsGrp: any;
  addBsDD: any;
  editbgbs: any;
  controlProgram: any;
  addVLDD: any;
  verify:any;btnSaveHide:any;
  spinnerLoad: boolean;
  constructor(private Restcallservice: RestcallService, private datePipe: DatePipe, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.spinnerLoad = false;
    this.btnSaveHide=false;
    this.country=sessionStorage.getItem('countryCode');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.role = sessionStorage.getItem('roleName');
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.vehicleCopySelection = [];
    this.selectOpt = 'vehicleLine';
    this.loading = true;
    this.today = new Date;
    this.currentYear = this.datePipe.transform(this.today, 'yyyy');
    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
      if(this.controlProgram != null){
        let cpymy;
        this.controlProgram.map(val =>{
          if(val.currentProposalYearFlag =='Y'){
            cpymy = val.proposalYearCode;
          }
        });
        this.modelYearLoad(cpymy);

      }else{
        this.modelYearLoad(null)
      }
      
    }, err=> {this.modelYearLoad(null); this.loading = false; this.controlProgram = null });
  }
  modelYearLoad(cpymy){
    let modelYearUrl = '/fleet-administrations/vehicle-lines/v1/model-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(modelYearUrl).subscribe(respData => {
     respData != null ? this.modelYearDropdown = respData.modelYear: this.modelYearDropdown = null;
    if(this.modelYearDropdown != null){
      if(cpymy != null){
        this.modelYearDropdown.includes(Number(cpymy)) == true ? this.modelYearVal = Number(cpymy) : this.modelYearVal = this.modelYearDropdown[0];
      }else{
        this.modelYearDropdown.includes(Number(this.currentYear)) == true ? this.modelYearVal = Number(this.currentYear) : this.modelYearVal = this.modelYearDropdown[0] 
      }
    }
    this.modelYearDropdown != null ? this.loadVehicleLine(this.modelYearVal): '';
    this.loading= false;
    if(this.selectOpt =='vehicleLine'){
      this.vehLineTable();
    }
    }, err => {this.modelYearDropdown = null; this.loading = false;});
  }
  loadVehicleLine(modelYear){
    this.vehicleLineDropdown = null;
    this.vehicleLineVal = 0;

    let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line";
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("modelYear",modelYear );
    this.Restcallservice.getData(vehicleUrl).subscribe(respData => {this.vehicleLineDropdown = respData.vehicleLine;
    this.vehicleLineVal = 0;
    if(this.country =='USA'){
      this.loadBodyStyle(modelYear,this.vehicleLineVal );
    }
    this.loading = false;
    if(this.selectOpt =='bodyStyle'){
      //this.bsTable();
    }
    }, err=>{
      this.loading = false;
      this.vehicleLineVal = null;
      this.vehicleLineDropdown = null;
    });
  }
   loadBodyStyle(modelYear, vehicle){
     if(this.country == "USA"){
       this.bodyStyleDropdown = null;
       this.bodyStyleVal =0;
      let bsUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-body-group/'+this.modelYearVal+'/'+this.vehicleLineVal;
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", modelYear);
      this.Restcallservice.setQueryParams("vehLineKey", vehicle);
      this.Restcallservice.getData(bsUrl).subscribe(respData => {
      this.bodyStyleDropdown = respData.bodyGroups;
      this.bodyStyleVal = 0;
      this.loading = false;
      if(this.selectOpt =='bodyStyleGroup'){
        //this.bsGroupTable();
      }
      }, err=> {this.loading= false;});
     }

    }
    trigger(event) {
      console.log("You entered: ", event.target.value);
     var isEqual = event.target.value.toUpperCase();
      if(isEqual=="ALL")
      {
        this.verify="ALL";
        this.btnSaveHide=false;
      }
      if(isEqual!='ALL')
      
      {
      this.btnSaveHide=true;
      }
    }
    tableGet(){
      this.selectOpt == 'vehicleLine' ? this.vehLineTable() :
      this.selectOpt == 'bodyStyle' ? this.bsTable() :
      this.selectOpt == 'bodyStyleGroup' ? this.bsGroupTable() : '';
    }

    vehLineTable(){
      this.bodyStyleTable = null;
      this.bodyStyleGroupTable = null;
      this.addVehNew = false;
      this.vehicleCopySelection = [];
      this.addbs = null;
      this.editVehDesc = null;
      this.editVehInd = null;
      this.editException = null;
      this.addVehLineCT = 'select';
      this.addVehLineMy = 'select';
      this.addVehLineDiv = 'select';
      this.addVehLineDesc = null;
      this.addVehLine = null;
      this.addExceptionType = null;
      this.addbsGrp = null;
      this.addBsDD = null;
      this.editbgbs = null;
      this.loading = true;
      let tableDataUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-line';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("bodyStyleKey",this.bodyStyleVal);
    this.Restcallservice.setQueryParams("modelYear",this.modelYearVal);
    this.Restcallservice.setQueryParams("vehLineKey",this.vehicleLineVal);
    this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
      respData !=null ? this.vehicleLineTable = respData.vehicleLineDtoList : this.vehicleLineTable = null;
      this.loading = false;
    }, err => {this.loading=false; this.vehicleLineTable = null});
  }
  bsTable(){  
    this.addVehNew = false;
      this.vehicleCopySelection = [];
      this.addbs = null;
      this.editVehDesc = null;
      this.editVehInd = null;
      this.editException = null;
      this.addVehLineCT = 'select';
      this.addVehLineMy = 'select';
      this.addVehLineDiv = 'select';
      this.addVehLineDesc = null;
      this.addVehLine = null;
      this.addExceptionType = null;
      this.addbsGrp = null;
      this.addBsDD = null;
      this.editbgbs = null;

    this.vehicleLineTable = null;
    this.bodyStyleGroupTable = null;
    this.loading = true;
    let tableDataUrl = '/fleet-administrations/vehicle-lines/v1/body-style/'+this.modelYearVal+'/'+this.vehicleLineVal;
  this.Restcallservice.ngOnInit();
  // this.Restcallservice.setQueryParams("modelYear",this.modelYearVal);
  // this.Restcallservice.setQueryParams("vehLineKey",this.vehicleLineVal);
  this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
    respData !=null ? this.bodyStyleTable = respData.bodyStyleList : this.bodyStyleTable = null;
    this.loading = false;
  }, err => {this.loading=false; this.bodyStyleTable = null});
}
    bsGroupTable(){
      this.addVehNew = false;
      this.vehicleCopySelection = [];
      this.addbs = null;
      this.editVehDesc = null;
      this.editVehInd = null;
      this.editException = null;
      this.addVehLineCT = 'select';
      this.addVehLineMy = 'select';
      this.addVehLineDiv = 'select';
      this.addVehLineDesc = null;
      this.addVehLine = null;
      this.addbsGrp = null;
      this.addBsDD = null;
      this.editbgbs = null;

      this.addExceptionType = null;
      this.vehicleLineTable = null;
      this.bodyStyleTable = null;
      this.loading = true;
      let tableDataUrl = '/fleet-administrations/vehicle-lines/v1/body-group-styles/'+this.modelYearVal+'/'+this.vehicleLineVal+'/'+this.bodyStyleVal;
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
      respData != null ? this.bodyStyleGroupTable = respData.bodyGroupsList : this.bodyStyleGroupTable = null;
      this.loading = false;
    }, err => {this.loading=false; this.bodyStyleGroupTable = null});
  }

  cancel(){
    const dialogRef = this.dialog.open(CancelVl, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'ok'){
          this.addVehNew = false;
          this.editVehInd = null;
          this.editVehDesc = null;
          this.editException = null;
          this.addVehLineCT = 'select';
          this.addVehLineMy = 'select';
          this.addVehLineDiv = 'select';
          this.addVehLineDesc = null;
          this.addVehLine = null;
          this.addbs = null;
          this.addbsGrp = null;
          this.addBsDD = null;
          this.editbgbs = null;

        }
      });
  }

  //Add
  addRow(selectOpt){
    this.editVehInd = null;
    this.addVehNew = true;
    if(selectOpt == 'vehicleLine'){
      let addVehicleUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-division';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.getData(addVehicleUrl).subscribe(data => {
        data != null ? this.addVehLineDivDropdown = data.divisionCode : this.addVehLineDivDropdown = null;
        data != null ? this.addVehLineCTDropdown = data.carOrTruck : this.addVehLineCTDropdown = null;
        this.addVehLineCT = 'C';
        this.addVehLineDiv = 'C';
        this.addVehLineMy = this.modelYearVal;
      });
      
    }
    else if(selectOpt=='bodyStyle'){
      this.addVehLineMy = this.modelYearVal;
      this.loadAddVehicleLineBody(this.addVehLineMy);
    }else if(selectOpt=='bodyStyleGroup'){
        this.addVehLineMy = this.modelYearVal;
        this.loadAddVehicleLine(this.addVehLineMy);
        //this.loadAddBs();
    }
   
  }
  loadAddVehicleLineBody(modelYear){  
    this.addVLDD = null;
    this.addVehLine = 0;
   //let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style";
    let vehicleUrl = '/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("modelYear",modelYear );
    this.Restcallservice.getData(vehicleUrl).subscribe(respData => { this.addVLDD = respData.vehicleLine;
      console.log(respData);
      this.addVehLine=this.addVLDD[0].vehLineKey;
      // = 0;
   
    }, err=>{
      this.addVehLine = null;
      this.addVLDD = null;
    });
  }














  loadAddVehicleLine(modelYear){
    this.addVLDD = null;
    this.addVehLine = 0;
    //let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/vehicle-line-body-grp";
    let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line";
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("modelYear",modelYear );
    this.Restcallservice.getData(vehicleUrl).subscribe(respData => {this.addVLDD = respData.vehicleLine;
      console.log(respData);
    this.addVehLine = this.addVLDD[0].vehLineKey;
    this.newloadAddBs(modelYear,this.addVehLine );
    }, err=>{
      this.addVehLine = null;
      this.addVLDD = null;
    });
  }



  newloadAddBs(modelYear,addVehLine){
    this.addBsDD = null;
 
   let bsUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-body-group/'+modelYear+'/'+addVehLine;
   this.Restcallservice.ngOnInit();
   this.Restcallservice.setQueryParams("modelYear", modelYear);
   this.Restcallservice.setQueryParams("vehLineKey", addVehLine);
   this.Restcallservice.getData(bsUrl).subscribe(respData => {
   this.addBsDD = respData.bodyGroups;
   this.addbs = 0;
   this.loading = false;


    /*let addVehicleUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-body-styles/'+this.addVehLine;
    this.Restcallservice.ngOnInit();
    // this.Restcallservice.setQueryParams("vehLineKey", this.addVehLine);
    this.Restcallservice.getData(addVehicleUrl).subscribe(data => {
      data != null ? this.addBsDD = data.bodyStyles : this.addBsDD = null;*/
    });
  }



















  loadAddBs(){
    this.addBsDD = null;
    let addVehicleUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-body-styles/'+this.addVehLine;
    this.Restcallservice.ngOnInit();
    // this.Restcallservice.setQueryParams("vehLineKey", this.addVehLine);
    this.Restcallservice.getData(addVehicleUrl).subscribe(data => {
      data != null ? this.addBsDD = data.bodyStyles : this.addBsDD = null;
    });
  }

  addFunction(saveOpt){
    let addArray = {};
    if(saveOpt == 'vehicleLine'){
      addArray = {
        "carOrTruck": this.addVehLineCT,
        "description": this.addVehLineDesc,
        "division": this.addVehLineDiv,
        "modelYear": this.addVehLineMy,
        "vehicleLine": this.addVehLine,
        "vehicleLineKey": 0
      };

      let addUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-line';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
      this.spinnerLoad = true;
      this.Restcallservice.createData(addUrl, JSON.stringify(addArray)).subscribe(data => this.vehLineTable(), err=> this.spinnerLoad = false );
     
    }else if(saveOpt == 'bodyStyle'){
      let finalArray = {
        "bodyStyleCode": this.addbs,
        "bodyStyleDesc": this.addVehLineDesc,
        "exceptionCheck": this.addExceptionType
      }
      let addUrl = '/fleet-administrations/vehicle-lines/v1/body-style/'+this.modelYearVal+'/'+this.addVehLine;
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = true; 
      // this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      // this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
      this.Restcallservice.createData(addUrl, JSON.stringify(finalArray)).subscribe(data => this.bsTable(), err=> this.spinnerLoad = false );

    }else if(saveOpt == 'bodyStyleGroup'){
      let finalArray = {
        "bodyGroupDescription": this.addVehLineDesc,
        "bodyStyleKeys": this.addbs
      }
      let addUrl = '/fleet-administrations/vehicle-lines/v1/body-group-styles/'+this.addVehLine+'/'+this.addbsGrp;
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = true; 
      // this.Restcallservice.setQueryParams("bodyGrpCd", this.addbsGrp);
      // this.Restcallservice.setQueryParams("vehLineKey", this.addVehLine);
      this.Restcallservice.createData(addUrl, JSON.stringify(finalArray)).subscribe(data => this.bsGroupTable(), err=>this.spinnerLoad = false );

    }
  }

  //Edit
  editVehRow(ind, optVal){
    this.addVehNew = false;
    if(this.role == 'ADM' && this.editVehInd!= ind){
      this.editVehDesc = null;
      this.editVehInd = ind;
      if(optVal == 'vehicleLine'){
        this.editVehDesc = this.vehicleLineTable[ind].description 
      }else if(optVal == 'bodyStyle'){
        this.editVehDesc = this.bodyStyleTable[ind].bodyStyleDesc;
        this.editException = this.bodyStyleTable[ind].exceptionOutOfAll == 'Y' ? true : false
      }
      else if(optVal == 'bodyStyleGroup'){
        this.editbgbs = null;
        this.addVehLine = this.bodyStyleGroupTable[ind].vehicleLineKey;
        this.loadAddBs();
        this.editVehDesc = this.bodyStyleGroupTable[ind].bodyGroupDescription;
      } 
    }

  }
  exceptionSet(){
    const dialogRef = this.dialog.open(SaveConfirm, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'cancel'){
          this.editException = !this.editException;
        }
      });
  }
    //Update VehicleLine
    saveVehicleLine(vlKey){
      let vlSave= {
        "carOrTruck": "string",
        "description": "string",
        "division": "string",
        "modelYear": 0,
        "vehicleLine": "string",
        "vehicleLineKey": 0
      };
      this.vehicleLineTable.map(data => {
        if(data.vehicleLineKey == vlKey){
          vlSave.carOrTruck = data.carOrTruck,
          vlSave.description = this.editVehDesc,
          vlSave.division = data.division ,
          vlSave.modelYear = data.modelYear,
          vlSave.vehicleLine = data.vehicleLine ,
          vlSave.vehicleLineKey = Number(data.vehicleLineKey)
        }
      });
      let vehUpdateUrl = '/fleet-administrations/vehicle-lines/v1/vehicle-line';
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = true;
      this.Restcallservice.updateData(vehUpdateUrl, JSON.stringify(vlSave)).subscribe(data => this.vehLineTable(), err=> this.spinnerLoad = false);
    }

    //edit Bodystyle
    updateBs(bsCode,vehnewcode){
      let newval=vehnewcode;
      let updateArray = {
        "bodyStyleCode": bsCode,
        "bodyStyleDesc": this.editVehDesc,
        "exceptionCheck": this.editException
      }
      console.log( JSON.stringify(updateArray));
      let vbsUpdateUrl = '/fleet-administrations/vehicle-lines/v1/body-style/'+this.modelYearVal+'/'+newval;
      this.Restcallservice.ngOnInit();
      // this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      // this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
      this.spinnerLoad = true; 
      this.Restcallservice.updateData(vbsUpdateUrl, JSON.stringify(updateArray)).subscribe(data => this.bsTable(), err=> this.spinnerLoad = false);
    }
    //edit bsGroup 
    updateBsGroup(bGrpKey){
      let updateArray = {
        "bodyGroupDescription": this.editVehDesc,
        "bodyStyleKeys": this.editbgbs == null ? [] : this.editbgbs
      }
      this.spinnerLoad = true;
      let vbsUpdateUrl = '/fleet-administrations/vehicle-lines/v1/body-group-styles-bodyGroupKey/'+bGrpKey;
      this.Restcallservice.ngOnInit();
      this.Restcallservice.updateData(vbsUpdateUrl, JSON.stringify(updateArray)).subscribe(data => this.bsGroupTable(), err=> this.spinnerLoad = false);
    }

  // Copy
  copy(copyTab){
    if(this.vehicleCopySelection.length > 0){
    if(copyTab =='vehicleLine'){
      let copyVehArray = [];
      this.vehicleCopySelection.map(data => {
        copyVehArray.push({
          "carOrTruck": data.carOrTruck,
          "description": data.description,
          "division": data.division,
          "modelYear": data.modelYear,
          "vehicleLine": data.vehicleLine,
          "vehicleLineKey": data.vehicleLineKey
        });
      });
      let finalcopyVeh = {
        "copyRequest": copyVehArray
      }
      let copyVehUrl = '/fleet-administrations/vehicle-lines/v1/copy-vehicle-line';
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = true; 
      this.Restcallservice.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => this.vehLineTable(), err=> this.spinnerLoad = false);
    }
    else if(copyTab == 'bodyStyle'){
      let copyVehArray = [];
      this.vehicleCopySelection.map(data => {
        copyVehArray.push({
          "bodyStyleCode": data.bodyStyleCode,
          "bodyStyleDesc": data.bodyStyleDesc,
          "bodyStyleKey": data.bodyStyleKey,
          "copyModelYearCheck": data.copyModelYearCheck ,
          "exceptionModifiedDate": null,
          "exceptionOutOfAll": data.exceptionOutOfAll,
          "vehicleCode": data.vehicleCode,
          "vehicleLine": data.vehicleLine
        })
      });
      let finalcopyVeh = {
        "copyRequest": copyVehArray
      }
      let copyVehUrl = '/fleet-administrations/vehicle-lines/v1/copy-body-style/'+this.modelYearVal;
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = true; 
      // this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      this.Restcallservice.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => this.bsTable(), err=> this.spinnerLoad = false);
    }
    else if(copyTab == 'bodyStyleGroup'){
      let copyVehArray = [];
      this.vehicleCopySelection.map(data => {
        copyVehArray.push(data.bodyGroupKey);
      });
      let finalcopyVeh = {
        "bodyGrpKeyList": copyVehArray
      }
      let copyVehUrl = '/fleet-administrations/vehicle-lines/v1/body-group-styles-modelYear/'+this.modelYearVal;
      this.Restcallservice.ngOnInit();
      this.spinnerLoad = false; 
      this.Restcallservice.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => this.bsGroupTable(),err=> this.spinnerLoad = false);
    }
  }
}
}



@Component({
  selector: 'cancel-vl',
  templateUrl: 'cancel-vl.html',
  })
  export class CancelVl {
  constructor(
  public dialogRef: MatDialogRef<CancelVl>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}

@Component({
  selector: 'save-confirm',
  templateUrl: 'save-confirm.html',
  })
  export class SaveConfirm {
  constructor(
  public dialogRef: MatDialogRef<SaveConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
  this.dialogRef.close('cancel');
  }
}
