import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaintainVehicleLineComponent } from './maintain-vehicle-line.component';

describe('MaintainVehicleLineComponent', () => {
  let component: MaintainVehicleLineComponent;
  let fixture: ComponentFixture<MaintainVehicleLineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaintainVehicleLineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaintainVehicleLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
