import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FoeFinAssignmentComponent } from './foe-fin-assignment.component';

describe('FoeFinAssignmentComponent', () => {
  let component: FoeFinAssignmentComponent;
  let fixture: ComponentFixture<FoeFinAssignmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FoeFinAssignmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FoeFinAssignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
