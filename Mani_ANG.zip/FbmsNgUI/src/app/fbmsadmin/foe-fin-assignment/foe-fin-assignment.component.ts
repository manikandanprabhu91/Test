import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { MatRadioButton, MatRadioChange } from '@angular/material/radio';
import { RestcallService } from 'src/app/services/restcall.service';
import { Router } from 'src/testing/router-stubs';
@Component({
  selector: 'foe-fin-assignment',
  templateUrl: './foe-fin-assignment.component.html',
  styleUrls: ['./foe-fin-assignment.component.sass']
})
export class FoeFinAssignmentComponent implements OnInit {
  opendialog:any;
  codeSelect: String;
  constructor(private finform: FormBuilder, private RestcallService: RestcallService,
    private router: Router) { }

  ngOnInit(): void {
    this.codeSelect = "Assignment by CDSID";  
  }
  proposalEvent(){
    this.opendialog=true;
  }

  onChange(radioidchange: MatRadioChange) {
    console.log(radioidchange.value);
    let assign: MatRadioButton = radioidchange.source;
    console.log(assign.name);
    console.log(assign.checked);
    console.log(assign.inputId);
 } 


}
  