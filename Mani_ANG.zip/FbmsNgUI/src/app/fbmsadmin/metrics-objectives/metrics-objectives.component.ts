import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'metrics-objectives',
  templateUrl: './metrics-objectives.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class MetricsObjectivesComponent implements OnInit {

  uploadMetricsObjectives: boolean = false;
  proposalYearVal: String = String((new Date()).getFullYear());
  namVal: String = 'All';
  vehicleLineVal: String = 'All';
  volumeTypeVal: String = 'All';
  configUrl: String = "";
  activeProposalYear: any[];
  nam: any[];
  volume: any[];
  vehicle: any;
  metricsObjectives: any[] = [];
  loading: boolean;
  @ViewChild(Table) templateRight: Table;
  fileToUpload: any;
  uploadFileStatus: boolean = false;
  financialFile: String;
  role: String = sessionStorage.getItem('roleName');
  country: String = sessionStorage.getItem('countryCode');
  spinner: boolean = false;

  constructor(private RestcallService: RestcallService) { }

  ngOnInit(): void {
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/proposal-year";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.activeProposalYear = data.activeProposalYear : this.activeProposalYear = [];
    });
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/nam";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.nam = data.nam : this.nam = [];
    });
    this.namValChange();
    this.proposalYearValChange();
  }

  proposalYearValChange() {
    this.vehicleLineVal = 'All';
    this.vehicle = [];
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/vehicle";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('proposalYear', this.proposalYearVal);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.vehicle = data.vehicleLine : this.vehicle = [];
    });
  }

  namValChange() {
    this.volumeTypeVal = 'All';
    this.volume = [];
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/volume";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('nam', this.namVal);
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.volume = data.volume : this.volume = [];
    });
  }

  loadTable() {
    this.loading = true;
    this.metricsObjectives = [];
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/metrics";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('nam', this.namVal);
    this.RestcallService.setQueryParams('proposalYear', this.proposalYearVal);
    this.RestcallService.setQueryParams('volume', this.volumeTypeVal);
    if (this.vehicleLineVal != 'All') {
      this.RestcallService.setQueryParams('vehicle', this.vehicleLineVal['vehLineKey']);
    } else {
      this.RestcallService.setQueryParams('vehicle', this.vehicleLineVal);
    }
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.templateRight.reset();
      if (this.metricsObjectives != null || this.metricsObjectives != []) {
        this.loading = false;
      }
      data != null || data != '' ? this.metricsObjectives = data.metricsObjectives : this.metricsObjectives = [];
    });
  }

  upload() {
    this.uploadMetricsObjectives = true;
  }

  uploadFile() {
    this.spinner = true;
    let uploadUrl = '/fleet-administrations/metrics-objectives/v1/metrics-upload';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("proposalYear", this.proposalYearVal);
    this.RestcallService.uploadFile(uploadUrl, this.fileToUpload, 'metricsDataFile', '').subscribe(data => {
      this.loadTable();
      this.proposalYearValChange();
      this.namValChange();
      this.fileToUpload = null;
      this.financialFile = '';
      this.spinner = false;
    }, err => {
      this.proposalYearValChange();
      this.namValChange();
      this.fileToUpload = null;
      this.financialFile = '';
      this.spinner = false;
    });
    this.uploadMetricsObjectives = false;
    this.uploadFileStatus = false;
  }

  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    this.uploadFileStatus = true;
  }

  excelDownload() {
    this.configUrl = "/fleet-administrations/metrics-objectives/v1/metrics-download";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('nam', this.namVal);
    this.RestcallService.setQueryParams('proposalYear', this.proposalYearVal);
    this.RestcallService.setQueryParams('volume', this.volumeTypeVal);
    if (this.vehicleLineVal != 'All') {
      this.RestcallService.setQueryParams('vehicle', this.vehicleLineVal['vehLineKey']);
    } else {
      this.RestcallService.setQueryParams('vehicle', this.vehicleLineVal);
    }
    this.RestcallService.downloadExcel(this.configUrl, "MetricsObjectives.xlsx");
  }

  cancel() {
    this.fileToUpload = null;
    this.financialFile = '';
    this.uploadFileStatus = false;
  }

}
