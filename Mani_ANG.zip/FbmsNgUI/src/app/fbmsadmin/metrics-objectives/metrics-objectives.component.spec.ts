import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MetricsObjectivesComponent } from './metrics-objectives.component';

describe('MetricsObjectivesComponent', () => {
  let component: MetricsObjectivesComponent;
  let fixture: ComponentFixture<MetricsObjectivesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MetricsObjectivesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MetricsObjectivesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
