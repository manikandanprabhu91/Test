import { Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import { TreeNode } from 'primeng/api';
import { Router } from '@angular/router';
import { RestcallService } from '../services/restcall.service';


@Component({
  selector: 'fbmsadmin',
  templateUrl: './fbmsadmin.component.html',
  styleUrls: ['./fbmsadmin.component.sass']
})
export class FbmsadminComponent implements OnInit {

  role: any;
  reportLevel: any;
  loginId: any;
  country: any;
  openDialog: boolean;
  fileToUpload: any;
  message: any;
  unSuccessFullVins: any;
  msgDesc: any;
  @ViewChild('myInput')
  myInputVariable: ElementRef;

  constructor(private router: Router, private Restcallservice: RestcallService) { }

  ngOnInit() {
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.country = sessionStorage.getItem('countryCode');
    this.loginId = sessionStorage.getItem('loginId');
    this.openDialog = false;
    //clearing history session
    if(sessionStorage.getItem("history") == "History"){
			sessionStorage.setItem("proposalKey", "");
			sessionStorage.setItem("finKey", "");
			sessionStorage.setItem("proposalYear", "");
      sessionStorage.setItem("accountName", "");
      sessionStorage.setItem("history", "") ;
      sessionStorage.setItem("proposalAssignee", "");	
			sessionStorage.setItem("vernumR", "");	
			sessionStorage.setItem("finCd", "");
    }
  }
  callingVin() {
    if (this.country == "MEX" && this.role == "ADM") {
      this.openDialog = true;
    }
  }
  excelDownload() {
    let downloadUrl = '/fleet-administrations/a1-vins/v1/template';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.downloadExcel(downloadUrl, 'UploadA1VINsData.xlsx');
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  uploadFile() {

    const fileType = this.fileToUpload.name.split('.')[1];
    if (fileType == 'xlsx') {
      let uploadUrl = '/fleet-administrations/a1-vins/v1/upload-a1-vins';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.uploadFile(uploadUrl, this.fileToUpload, 'financeDataFile', 'uploadA1').subscribe(data => {
        this.message = data;
        this.msgDesc = this.message.msgDesc;
        this.unSuccessFullVins = this.message.unSuccessFullVins;
      });
    } else {
      alert("Invalid File type - Please ensure the file type is 'Microsoft Excel Worksheet (.xlsx)")
    }
  }

  dialogClose() {
    this.openDialog = false;
    this.fileToUpload = null;
    this.myInputVariable.nativeElement.value = "";
    this.msgDesc= null;
    this.unSuccessFullVins = null;
    this.ngOnInit()
  }
}