import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControllerRoutingThresholdComponent } from './controller-routing-threshold.component';

describe('ControllerRoutingThresholdComponent', () => {
  let component: ControllerRoutingThresholdComponent;
  let fixture: ComponentFixture<ControllerRoutingThresholdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControllerRoutingThresholdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControllerRoutingThresholdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
