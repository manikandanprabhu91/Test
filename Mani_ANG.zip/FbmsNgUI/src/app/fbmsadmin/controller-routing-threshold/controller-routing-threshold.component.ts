import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'controller-routing-threshold',
  templateUrl: './controller-routing-threshold.component.html',
  styleUrls: ['./controller-routing-threshold.component.sass']
})
export class ControllerRoutingThresholdComponent implements OnInit {
thresholdVals: any;
loading: boolean;

  constructor(private Restcallservice: RestcallService) { }

  ngOnInit(): void {
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.loading = true;
    let getThresholdUrl = '/fleet-administrations/thresholds/v1/controller';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(getThresholdUrl).subscribe(respData => {
    respData == null || respData==[] ?  this.thresholdVals = null : this.thresholdVals = respData.controllerThresholdList;
    this.loading = false;
    },err => {
      this.loading = false;
      this.thresholdVals = null
    });
  }

}
