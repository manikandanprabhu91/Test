import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'government-fin',
  templateUrl: './government-fin.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class GovernmentFinComponent implements OnInit {
  loading: boolean;
  govloading:boolean;
  tableValues: any;
  accountManagerList: any;
  titleCd: any;
  valueUpdate: any =[];
  btnEnable: boolean;

  constructor(private Restcallservice: RestcallService) { }

  ngOnInit(): void {
    this.govloading=false;
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.titleCd = 'GAM';
    this.loading = true;
    this.valueUpdate =[];
    this.btnEnable= false;

    let accountManagerUrl ='/fleet-administrations/government-assignments/v1/fin/accountManagers';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("titleCd", this.titleCd);
    this.Restcallservice.getData(accountManagerUrl).subscribe(data => {
      data != null ? this.accountManagerList = data.accountManagerList : this.accountManagerList = null;
    });
    let tableUrl ='/fleet-administrations/government-assignments/v1/fin/states';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(tableUrl).subscribe(respData => {
      respData != null? this.tableValues = respData.stateList : this.tableValues = null;
      this.loading = false;
    }, err => {this.loading = false; this.tableValues = null});
  }
  cancel(){
    this.ngOnInit();
  }
  selectEvent(state, stateCode, event){
    this.btnEnable = true;
  this.valueUpdate.push({
    "accountMngrName": event.target.value,
    "state": state,
    "stateCode": stateCode
  });
  }
  save(){
    
    let saveArray ={
      "stateAccountManagerInfo": this.valueUpdate
    };
    let saveUrl ='/fleet-administrations/government-assignments/v1/fin';
    this.Restcallservice.ngOnInit();
    this.govloading=true;
    this.loading=true;
    this.Restcallservice.updateData(saveUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit());
    
  }  
}
