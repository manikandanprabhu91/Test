import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GovernmentFinComponent } from './government-fin.component';

describe('GovernmentFinComponent', () => {
  let component: GovernmentFinComponent;
  let fixture: ComponentFixture<GovernmentFinComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GovernmentFinComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GovernmentFinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
