import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposallettertemplateComponent } from './proposallettertemplate.component';

describe('ProposallettertemplateComponent', () => {
  let component: ProposallettertemplateComponent;
  let fixture: ComponentFixture<ProposallettertemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposallettertemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposallettertemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
