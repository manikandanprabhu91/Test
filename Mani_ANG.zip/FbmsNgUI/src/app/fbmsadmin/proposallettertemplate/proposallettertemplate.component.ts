import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'proposallettertemplate',
  templateUrl: './proposallettertemplate.component.html',
  styleUrls: ['../fbmsadmin.component.sass']
})
export class ProposallettertemplateComponent implements OnInit {

  loading: boolean;
  configUrl: string = "";
  propLetterTemplate: any[];
  templateName: any[];
  uploadSignature: boolean = false;
  selectedLetterTemplate: any = null;
  letterTemplate: boolean;
  uploadBtn: boolean;
  uploadTemplate: boolean = false;
  letterUploadTemplate: boolean = false;
  @ViewChild('inputFile') myInputVariable: ElementRef;
  textArea: string;
  fileType: String = "";
  fileToUpload: File;

  constructor(private RestcallService: RestcallService) { }

  ngOnInit(): void {
    this.loading = true;
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.uploadBtn = sessionStorage.getItem('roleName') == 'ITS' ? true : false;
    this.letterTemplate = false;
    this.dataFetch();
  }

  dataFetch() {
    this.configUrl = "/fleet-administrations/letter-templates/v1/proposal";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.propLetterTemplate = data.propLetterTempVos : this.propLetterTemplate = [];
      this.loading = false;
    });
  }

  download(letterData) {
    let wordlDownloadUrl = "/fleet-administrations/letter-templates/v1/download";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("tempId", letterData.letterKey);
    this.RestcallService.downloadProposalLetter(wordlDownloadUrl, 'ProposalLetterTemplate.doc');
  }

  upload() {
    this.uploadTemplate = true;
    this.selectedLetterTemplate = null;
    this.configUrl = "/fleet-administrations/letter-templates/v1/upload";
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      data != null || data != '' ? this.templateName = data.templateNameDtoList : this.templateName = [];
    });
  }

  uploadDoc() {
    if (this.fileToUpload.type != "" && this.fileToUpload.type == "text/xml") {
      this.propLetterTemplate = [];
      this.loading = true;
      this.uploadBtn = false;
      this.configUrl = "/fleet-administrations/letter-templates/v1/upload";
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("Description", this.textArea);
      this.RestcallService.setQueryParams("Template Code", this.selectedLetterTemplate['templateCd']);
      this.RestcallService.setQueryParams("Template Key", this.selectedLetterTemplate['templateKey']);
      this.RestcallService.uploadFile(this.configUrl, this.fileToUpload, 'file', '').subscribe(data => {
        this.dataFetch();
        this.uploadBtn = true;
      }, err => {
        this.dataFetch();
        this.uploadBtn = true;
      });
      this.uploadTemplate = false;
      this.letterUploadTemplate = false;
      this.myInputVariable.nativeElement.value = '';
      this.textArea = '';
    } else {
      this.RestcallService.statusMessage(417, "Unable to Upload the Document.");
    }
  }

  uploadDocCancel() {
    this.uploadTemplate = false;
    this.myInputVariable.nativeElement.value = '';
    this.textArea = '';
    this.letterUploadTemplate = false;
  }

  handleFileInput(files: FileList) {
    this.letterUploadTemplate = true;
    this.fileToUpload = files.item(0);
  }

  selectMonth() {
    this.letterTemplate = true;
  }
}