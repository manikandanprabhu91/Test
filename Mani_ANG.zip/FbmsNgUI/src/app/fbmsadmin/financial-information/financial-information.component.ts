import { DatePipe, NgStyle } from '@angular/common';
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ExportsService } from '../../services/exports.service';
import { RestcallService } from '../../services/restcall.service';
import { FbmsadminComponent } from '../fbmsadmin.component';


@Component({
  selector: 'financial-information',
  templateUrl: './financial-information.component.html',
  styleUrls: ['./financial-information.component.sass'],
})
export class FinancialInformationComponent implements OnInit {
  modelYearDropdown: any;
  openDialog: boolean;
  modelYearVal: any;
  vehicleLineDropdown: any;
  vehicleLineVal: any;
  effectiveDate: FormControl;
  currentYear: any;
  segment: string;
  // bodyStyleDropdown: any;
  // bodyStyleVal: any;
  tableValues: any;
  loading;
  cars2: any[];
  today: any;
  fileToUpload: any;
  storeData: any;
  jsonData: any;
  countryCode: any;
  controlProgram: any;
  fleetType: any;
  role = sessionStorage.getItem('roleName');
  cols: { field: string; header: string; }[];


  constructor(private Restcallservice: RestcallService, private datePipe: DatePipe, private exportExcel: ExportsService) { }

  ngOnInit(): void {

    this.cols = [
      { field: 'vehicleLine', header: 'Vehicle Description' },
      { field: 'bodyStyleGroup', header: 'Body Style Group' },
      { field: 'segment', header: 'Segment' },
      { field: 'finClassification', header: 'Special Fin Classification' },
      { field: 'revenue', header: 'Prior MY FVA Calculated Revenue' },
      { field: 'contributionCost', header: 'Prior MY FVA Calculated Contribution Cost'  },
      { field: 'currYrRevChg', header: 'Revenue (YOY Delta)' },
      { field: 'currYrContCost', header: 'Contribution Cost - (YOY Delta)' },
      { field: 'bodyStyleThreshold', header: 'Threshold (%)' },
      { field: 'target1', header: '1 C-0 R-1' },
      { field: 'target2', header: '2  C-50 R-151' },
      { field: 'target3', header: '3 C-100 R-500' },
      { field: 'target4', header: '4 C-200 R-1000' },
      { field: 'target5', header: '5 C-500 R-2000' },
      { field: 'targetYOY', header: 'YOY Target VM ' },
      { field: 'baseIncentives', header: 'Base Incentives' },
      { field: 'effectiveDate', header: 'Effective Date' }
    ];



    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.countryCode = sessionStorage.getItem('countryCode');
    this.openDialog = false;
    this.vehicleLineVal = 'ALL';
    this.segment = 'ALL';
    this.fleetType = 'ALL';
   //this.loading = true;
    this.today = new Date;
    this.effectiveDate = new FormControl(new Date());
    this.currentYear = this.datePipe.transform(this.today, 'yyyy');

    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
      if (this.controlProgram != null) {
        let cpymy;
        this.controlProgram.map(val => {
          if (val.currentProposalYearFlag == 'Y') {
            cpymy = val.proposalYearCode;
          }
        });
        this.modelYearLoad(cpymy);

      } else {
        this.modelYearLoad(null)
      }

    }, err => { this.modelYearLoad(null); this.loading = false; this.controlProgram = null });
  }
  modelYearLoad(cpymy) {
    let modelYearUrl = '/fleet-administrations/vehicle-lines/v1/model-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(modelYearUrl).subscribe(respData => {
      respData != null ? this.modelYearDropdown = respData['modelYear'] : this.modelYearDropdown = null;
      if (this.modelYearDropdown != null) {
        if (cpymy != null) {
          this.modelYearDropdown.includes(Number(cpymy)) == true ? this.modelYearVal = Number(cpymy) : this.modelYearVal = this.modelYearDropdown[0];
        } else {
          this.modelYearDropdown.includes(Number(this.currentYear)) == true ? this.modelYearVal = Number(this.currentYear) : this.modelYearVal = this.modelYearDropdown[0]
        }
      } this.modelYearDropdown != null ? this.loadVehicleLine() : '';
    }, err => { this.modelYearDropdown = null });
  }
  loadVehicleLine() {
    this.vehicleLineVal = 'ALL';
    this.vehicleLineDropdown = null;
    let vehicleUrl = "/fleet-administrations/vehicle-lines/v1/body-style-vehicle-line";
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
    this.Restcallservice.getData(vehicleUrl).subscribe(respData => {
      this.vehicleLineDropdown = respData.vehicleLine;
      this.vehicleLineVal = 'ALL';
      //this.loadTable();
    }, err => {
      this.vehicleLineVal = null;
      this.vehicleLineDropdown = null;
    });
  }
  // loadBodyStyle(){
  //   let bsUrl = '/fleet-administrations/vehicle-lines/v1/body-style/'+this.modelYearVal+'/'+this.vehicleLineVal;
  //   this.Restcallservice.ngOnInit();
  //   this.Restcallservice.getData(bsUrl).subscribe(respData => this.bodyStyleDropdown = respData.vehicleLine);
  //   this.bodyStyleVal = 'ALL';
  // }
  loadTable() {
    this.openDialog = false;
    this.tableValues = null;
    this.loading = true;
    let tableDataUrl = '/fleet-administrations/vehicle-finances/v1/finance-data';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("effectiveDate", this.datePipe.transform(this.effectiveDate.value, 'MM/dd/yyyy'));
    if (sessionStorage.getItem('countryCode') == 'MEX') {
      this.Restcallservice.setQueryParams("fleetPgmType", this.fleetType);
    }
    if (sessionStorage.getItem('countryCode') == 'USA') {
      this.Restcallservice.setQueryParams("segment", this.segment);
    }
    this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
    this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
    this.Restcallservice.getData(tableDataUrl).subscribe(respData => {
      if (this.countryCode == "USA") {
        respData != null ? this.tableValues = respData.maintainFinanceDataVOList : this.tableValues = null;
      }
      if (this.countryCode == "MEX") {
        respData != null ? this.tableValues = respData.mexFinanceDataVOList : this.tableValues = null;
      }
      this.loading = false;
    }, err => { this.loading = false; this.tableValues = null });
  }

  upload() {
    this.openDialog = true;
  }
  dialogClose() {
    this.openDialog = false;
    this.fileToUpload = null;
  }
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
  }

  uploadFile() {
    const fileType = this.fileToUpload.name.split('.')[1];
    if (fileType == 'xlsx') {
      let uploadUrl = '/fleet-administrations/vehicle-finances/v1/finance-data-excel';
      this.Restcallservice.ngOnInit();
      this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
      this.Restcallservice.uploadFile(uploadUrl, this.fileToUpload, 'financeDataFile', '').subscribe(data => this.loadTable());
    } else {
      alert("Invalid File type - Please ensure the file type is 'Microsoft Excel Worksheet (.xlsx)")
    }
  }

  excelDownload() {
    if(this.tableValues != null){
    let excelDownloadUrl = '/fleet-administrations/vehicle-finances/v1/finance-data-excel';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("effectiveDate", this.datePipe.transform(this.effectiveDate.value, 'MM/dd/yyyy'));
    if (sessionStorage.getItem('countryCode') == 'MEX') {
      this.Restcallservice.setQueryParams("fleetPgmType", this.fleetType);
    }

    if (sessionStorage.getItem('countryCode') == 'USA') {
      this.Restcallservice.setQueryParams("segment", this.segment);
    }
    this.Restcallservice.setQueryParams("modelYear", this.modelYearVal);
    this.Restcallservice.setQueryParams("vehLineKey", this.vehicleLineVal);
    this.Restcallservice.downloadExcel(excelDownloadUrl, "FinancialData.xlsx");

    let downloadDoc = [];
    this.tableValues.map(data => {
      downloadDoc.push({
        "Model Year": data.modelYear,
        "Vehicle Line": data.vehicleLine,
        "Body Style": data.bodyStyle,
        "Body Style Group": data.bodyStyleGroup,
        "Segment": data.segment,
        "Special Fin Classification": data.finClassification,
        "Prior MY FVA Calculated Revenue": data.currYrRevChg,
        "Prior MY FVA Calculated Contribution Cost": data.currYrContCost,
        "Revenue (YOY Delta)": data.revenue,
        "Contribution Cost - (YOY Delta)": data.contributionCost,
        "Threshold (%)": data.bodyStyleThreshold,
        "Target 1": data.target1,
        "Target 2": data.target2,
        "Target 3": data.target3,
        "Target 4": data.target4,
        "Target 5": data.target5,
        "YOY Target VM": data.targetYOY,
        "Base Incentive": data.baseIncentives,
        "Effective Date": data.effectiveDate
      });
    });
    const header = ["Model Year", "Vehicle Line", "Body Style", "Body Style Group", "Segment", "Special Fin Classification", "Prior MY FVA Calculated Revenue", "Prior MY FVA Calculated Contribution Cost", "Revenue (YOY Delta)", "Contribution Cost - (YOY Delta)", "Threshold (%)", "Target 1", "Target 2", "Target 3", "Target 4", "Target 5", "YOY Target VM", "Base Incentive", "Effective Date"];
    // this.exportExcel.exportExcellReport(downloadDoc, header, "", "", "", "MaintainFinancialData");
  }
  
  else if(this.tableValues != null || this.loading==false){
    this.Restcallservice.statusMessage(417, 'Record does not exist');}
  }


}
