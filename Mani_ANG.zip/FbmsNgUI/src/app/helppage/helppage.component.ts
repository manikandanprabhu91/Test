import { Component, OnInit } from '@angular/core';
import { RestcallService } from '../services/restcall.service';

@Component({
  selector: 'helppage',
  templateUrl: './helppage.component.html',
  styleUrls: ['./helppage.component.sass']
})
export class HelppageComponent implements OnInit {
  country: any;

  constructor(private Restcallservice: RestcallService) { }

  ngOnInit(): void {
    this.country = sessionStorage.getItem("countryCode");
  }

  guide(type) {
    let docUrl = '/fleet-letters-management/s3/buckets/files/download/user-guide';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("fileType", type);
    this.Restcallservice.downloadCpaLetter(docUrl, "application/msword", type + ".doc");
  }

}
