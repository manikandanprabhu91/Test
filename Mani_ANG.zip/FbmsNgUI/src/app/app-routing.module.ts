import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//Oauth
import { AuthGuardService } from './oauth-callback/auth-guard.service';
import { OAuthCallbackComponent } from './oauth-callback/oauth-callback.component';

//FBMS
import { FbmscontactComponent } from './fbmscontact/fbmscontact.component';
import { FbmscontainerComponent } from './fbmscontainer/fbmscontainer.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { InvaliduserComponent } from './invaliduser/invaliduser.component';
import { ProposalLandingComponent } from './fbmscontainer/proposal-landing/proposal-landing.component';
import { LogoutComponent } from './logout/logout.component';
import { ProposalHistoryComponent } from './fbmscontainer/proposal-history/proposal-history.component';
import { ApprovalsComponent } from './approvals/approvals.component';
import { VehicleLineProposalYearComponent } from './fbmsadmin/vehicle-line-proposal-year/vehicle-line-proposal-year.component';
import { FinancialInformationComponent } from './fbmsadmin/financial-information/financial-information.component';
import { ControlProgramYearComponent } from './fbmsadmin/control-program-year/control-program-year.component';
import { FbmsadminComponent } from './fbmsadmin/fbmsadmin.component';
import { UserMaintenanceComponent } from './fbmsadmin/user-maintenance/user-maintenance.component';
import { ControllerRoutingThresholdComponent } from './fbmsadmin/controller-routing-threshold/controller-routing-threshold.component';
import { FinancialApprovalRangeComponent } from './fbmsadmin/financial-approval-range/financial-approval-range.component';
import { ProposallettertemplateComponent } from './fbmsadmin/proposallettertemplate/proposallettertemplate.component';
import { FinAssignmentComponent } from './fbmsadmin/fin-assignment/fin-assignment.component';
import { FoeFinAssignmentComponent } from './fbmsadmin/foe-fin-assignment/foe-fin-assignment.component';
import { GovernmentFinComponent } from './fbmsadmin/government-fin/government-fin.component';
import { CustomerAcceptanceViewComponent } from './fbmscontainer/customer-acceptance-view/customer-acceptance-view.component';
import { MaintainVehicleLineComponent } from './fbmsadmin/maintain-vehicle-line/maintain-vehicle-line.component';
import { MaintainFinAutoearlyComponent } from './fbmsadmin/maintain-fin-autoearly/maintain-fin-autoearly.component';
import { MaintainEspDiscountsComponent } from './fbmsadmin/maintain-esp-discounts/maintain-esp-discounts.component';
import { AssignmentOfProceedsComponent } from './fbmsadmin/assignment-of-proceeds/assignment-of-proceeds.component';
import { FinSearchComponent } from './fin-search/fin-search.component';
import { MetricsObjectivesComponent } from './fbmsadmin/metrics-objectives/metrics-objectives.component';
import { DealerStockReplacementComponent } from './fbmsadmin/dealer-stock-replacement/dealer-stock-replacement.component';
import { FinancialDetailedViewComponent } from './fbmscontainer/proposal-landing/summaryandsubmit/financial-detailed-view/financial-detailed-view.component';
import { HelppageComponent } from './helppage/helppage.component';
import { MaintainModelCostComponent } from './fbmsadmin/maintain-model-cost/maintain-model-cost.component';

const routes: Routes = [
	{
		path: 'oauth-callback',
		component: OAuthCallbackComponent
	},
	{
		path: 'invalid-access',
		component: InvaliduserComponent,
	},
	{
		path: 'help',
		component: HelppageComponent,
	},

	{
		path: '', redirectTo: '/accounts-home', pathMatch: 'full', data: { breadcrumb: 'Accounts Home' },


	},
	{
		path: 'accounts-home',
		component: FbmscontainerComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Accounts Home' }
	},
	{
		path: 'accounts',
		data: {
			breadcrumb: 'Accounts Home'
		},
		children: [
			{
				path: '',
				component: FbmscontainerComponent,
				canActivate: [AuthGuardService]
			},
			{
				path: 'proposal',
				component: ProposalLandingComponent,
				canActivate: [AuthGuardService],
				data: {
					breadcrumb: 'Proposal'
				},
			},
			{
				path: 'contact-info',
				component: FbmscontactComponent,
				canActivate: [AuthGuardService],
				data: {
					breadcrumb: 'Contact Info'
				},
			},
			// {
			// 	path: 'proposal-history',
			// 	component: ProposalHistoryComponent,
			// 	canActivate: [AuthGuardService],
			// 	data: { breadcrumb: 'Proposal History' }
			// },
			{
				path: 'customer-acceptance-view',
				component: CustomerAcceptanceViewComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Customer Acceptance' }
			},
			{
				path: 'proposal-history',
				component: ProposalHistoryComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Proposal History' }
				},
				{
					path: 'history',
					data: {
						breadcrumb: 'Proposal History'
					},
					children: [
						{
							path: '',
							component: ProposalHistoryComponent,
							canActivate: [AuthGuardService]
						},
						{
							path: 'proposal',
							component: ProposalLandingComponent,
							canActivate: [AuthGuardService],
							data: {
								breadcrumb: 'Proposal'
							},
						}
					]
			},

		]
	},
	// {
	// 	path: 'proposal-history',
	// 	component: ProposalHistoryComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Proposal History' }
	// 	},
	// 	{
	// 		path: 'history',
	// 		data: {
	// 			breadcrumb: 'Proposal History'
	// 		},
	// 		children: [
	// 			{
	// 				path: '',
	// 				component: ProposalHistoryComponent,
	// 				canActivate: [AuthGuardService]
	// 			},
	// 			{
	// 				path: 'proposal',
	// 				component: ProposalLandingComponent,
	// 				canActivate: [AuthGuardService],
	// 				data: {
	// 					breadcrumb: 'Proposal'
	// 				},
	// 			}
	// 		]
	// },

	{
		path: 'fin-search',
		component: FinSearchComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Fin Search' }

	},

	{
		path: 'contact-info',
		component: FbmscontactComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Contact Info' }
	},

	{
		path: 'financial-detailed-grid',
		component: FinancialDetailedViewComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Financial Detailed Grid' }
	},

	{
		path: 'approvals',
		component: ApprovalsComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Approvals' },
		},
		{
			path: 'approval',
			data: {
				breadcrumb: 'Approvals'
			},
			children: [
				{
					path: '',
					component: ApprovalsComponent,
					canActivate: [AuthGuardService]
				},
				{
					path: 'proposal',
					component: ProposalLandingComponent,
					canActivate: [AuthGuardService],
					data: {
						breadcrumb: 'Proposal'
					},
				},
				{
					path: 'contact-info',
					component: FbmscontactComponent,
					canActivate: [AuthGuardService],
					data: {
						breadcrumb: 'Contact Info'
					}
				},
				{
					path: 'proposal-history',
					component: ProposalHistoryComponent,
					canActivate: [AuthGuardService],
					data: { breadcrumb: 'Proposal History' }
				},
				{
					path: 'history',
					data: {
						breadcrumb: 'Proposal History'
					},
					children: [
						{
							path: '',
							component: ProposalHistoryComponent,
							canActivate: [AuthGuardService]
						},
						{
							path: 'proposal',
							component: ProposalLandingComponent,
							canActivate: [AuthGuardService],
							data: {
								breadcrumb: 'Proposal'
							},
						}
					]
			},
			]
	},
	{
		path: 'admin-home',
		component: FbmsadminComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Admin Home' }
	},

	{
		path: 'admin',
		data: {
			breadcrumb: 'Admin Home'
		},
		children: [
			{
				path: '',
				component: FbmsadminComponent,
				canActivate: [AuthGuardService]
			},
			{
				path: 'fin-assignment',
				component: FinAssignmentComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'FIN Assignment' }
			},
            {
				path: 'foe-fin-assignment',
				component: FoeFinAssignmentComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'FIN Assignment' }
			},

			
			{
				path: 'user-maintenance',
				component: UserMaintenanceComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'User Maintenance' }
			},
			{
				path: 'metrics-objectives',
				component: MetricsObjectivesComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Metrics Objectives' }
			},
			{
				path: 'vehicle-line-data',
				component: MaintainVehicleLineComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Vehicle Line Data' }
			},
			{
				path: 'assignment-of-proceeds',
				component: AssignmentOfProceedsComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Assignment Of Proceeds' }
			},
			{
				path: 'proposal-letter-template',
				component: ProposallettertemplateComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Proposal Letter Template' }
			},
			{
				path: 'vehicle-line-py-definition',
				component: VehicleLineProposalYearComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Vehicle Line Py Definition' }
			},
			{
				path: 'financial-information',
				component: FinancialInformationComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Financial Information' }
			},
			{
				path: 'control-program-year',
				component: ControlProgramYearComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Control Program Year' }
			},
			{
				path: 'control-routing-threshold',
				component: ControllerRoutingThresholdComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Control Routing Threshold' }
			},
			{
				path: 'financial-approval-range',
				component: FinancialApprovalRangeComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Financial Approval Range' }
			},
			{
				path: 'government-fin',
				component: GovernmentFinComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Government FIN' }
			},
			{
				path: 'maintain-fin-autoearly',
				component: MaintainFinAutoearlyComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Maintain Fin Autoearly' }
			},
			{
				path: 'maintain-esp-discounts',
				component: MaintainEspDiscountsComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Maintain ESP Discounts' }
			},
			{
				path: 'dealer-stock-replacement',
				component: DealerStockReplacementComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Dealer Stock Replacement' }
			},
			{
				path: 'maintain-model-cost',
				component: MaintainModelCostComponent,
				canActivate: [AuthGuardService],
				data: { breadcrumb: 'Maintain Model Cost' }
				
			},

		]
	},
	{
		path: 'dealer-stock-replacement',
		component: DealerStockReplacementComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Dealer Stock Replacement' }
	},
	// {
	// 	path: 'fin-assignment',
	// 	component: FinAssignmentComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'FIN Assignment' }
	// },
	// {
	// 	path: 'user-maintenance',
	// 	component: UserMaintenanceComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'User Maintenance' }
	// },
	// {
	// 	path: 'metrics-objectives',
	// 	component: MetricsObjectivesComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Metrics Objectives' }
	// },
	// {
	// 	path: 'vehicle-line-data',
	// 	component: MaintainVehicleLineComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Vehicle Line Date' }
	// },
	// {
	// 	path: 'assignment-of-proceeds',
	// 	component: AssignmentOfProceedsComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Assignment Of Proceeds' }
	// },
	// {
	// 	path: 'proposal-letter-template',
	// 	component: ProposallettertemplateComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Proposal Letter Template' }
	// },
	// {
	// 	path: 'vehicle-line-py-definition',
	// 	component: VehicleLineProposalYearComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Vehicle Line Py Definition' }
	// },
	// {
	// 	path: 'financial-information',
	// 	component: FinancialInformationComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Financial Information' }
	// },
	// {
	// 	path: 'control-program-year',
	// 	component: ControlProgramYearComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Control Program Year' }
	// },
	// {
	// 	path: 'control-routing-threshold',
	// 	component: ControllerRoutingThresholdComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Control Routing Threshold' }
	// },
	// {
	// 	path: 'financial-approval-range',
	// 	component: FinancialApprovalRangeComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Financial Approval Range' }
	// },
	// {
	// 	path: 'government-fin',
	// 	component: GovernmentFinComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Government FIN' }
	// },
	// {
	// 	path: 'maintain-fin-autoearly',
	// 	component: MaintainFinAutoearlyComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Maintain Fin Autoearly' }
	// },
	// {
	// 	path: 'maintain-esp-discounts',
	// 	component: MaintainEspDiscountsComponent,
	// 	canActivate: [AuthGuardService],
	// 	data: { breadcrumb: 'Maintain ESP Discounts' }
	// },
	{
		path: 'assignment-of-proceeds',
		component: AssignmentOfProceedsComponent,
		canActivate: [AuthGuardService],
		data: { breadcrumb: 'Assignment Of Proceeds' }
	},

	{
		path: 'logout',
		component: LogoutComponent,
		canActivate: [AuthGuardService]
	},
	{
		path: '404', component: NotFoundComponent
	},
	{
		path: '**', redirectTo: '/404',
		pathMatch: 'full'
	}

];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule {
}
