import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinAssignmentApprovalComponent } from './fin-assignment-approval.component';

describe('FinAssignmentApprovalComponent', () => {
  let component: FinAssignmentApprovalComponent;
  let fixture: ComponentFixture<FinAssignmentApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinAssignmentApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinAssignmentApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
