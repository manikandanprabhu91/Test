import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';

@Component({
  selector: 'fin-assignment-approval',
  templateUrl: './fin-assignment-approval.component.html',
  styleUrls: ['../approvals.component.sass']
})
export class FinAssignmentApprovalComponent implements OnInit {
  tableValues: any;
  currentQueue: any;
  selectedQueue: string;
  loading: boolean;
  selectedFin: any;
  reportLevel: string;
  cdsId: string;

  constructor(private RestcallService: RestcallService) { }

  ngOnInit(): void {
    this.tableValues = [];
    this.selectedFin = [];
    this.cdsId = sessionStorage.getItem('loginId');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.loading = true;
    let currentQueueUrl = "/fleet-fin-management/fin-assignments/v1/fin";
    // let currentQueueUrl = '/currentQueue';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('domainCountryCd', 'USA')
    this.RestcallService.getData(currentQueueUrl).subscribe(data => {
      data != null || data != '' ? this.currentQueue = data.finApprovalQueue : this.currentQueue = [];
      if (this.currentQueue.length > 0) {
        let personMatch = this.currentQueue.includes(sessionStorage.getItem('loginId'));
        personMatch == true ? this.selectedQueue = sessionStorage.getItem('loginId') : this.selectedQueue = this.currentQueue[0];
        this.loadTableData();
      }
    });
  }
  loadTableData() {
    this.loading = true;
    if (this.selectedQueue != null || this.selectedQueue != '') {
      let tableDataUrl = "/fleet-fin-management/fin-assignments/v1/fin/approval";
      // let tableDataUrl = '/historyValues';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('selectedApprovedId', this.selectedQueue);
      this.RestcallService.getData(tableDataUrl).subscribe(data => {
        data ? this.tableValues = data.finApprovalData : this.tableValues = null;
        this.loading = false;
      }, err => { this.tableValues = null; this.loading = false });
    }
  }
  //Save or Reject Approval
  updateRequest(status) {

    if (this.selectedFin.length > 0) {
      let finCodes = [];
      let finKey = [];
      let approverId = this.selectedQueue;
      this.selectedFin.map(data => {
        finCodes.push(data.mainFinCode);
        finKey.push(data.finReassignKey);
      });
      let updateRequestVal = {
        "approveProcess": status,
        "finReassignKey": finKey,
        "mainFinCode": finCodes,
        "selectedApprovedId": approverId
      }
      let updateUrl = '/fleet-fin-management/fin-assignments/v1/approve-reject';
      this.RestcallService.ngOnInit();
      this.RestcallService.createData(updateUrl, JSON.stringify(updateRequestVal)).subscribe(data => {
        this.loadTableData();
      });
    }

  }
}


