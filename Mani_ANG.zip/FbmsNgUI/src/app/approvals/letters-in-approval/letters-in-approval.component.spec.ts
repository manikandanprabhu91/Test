import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LettersInApprovalComponent } from './letters-in-approval.component';

describe('LettersInApprovalComponent', () => {
  let component: LettersInApprovalComponent;
  let fixture: ComponentFixture<LettersInApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LettersInApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LettersInApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
