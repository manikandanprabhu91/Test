import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { Router } from 'src/testing/router-stubs';


@Component({
  selector: 'letters-in-approval',
  templateUrl: './letters-in-approval.component.html',
  styleUrls: ['../approvals.component.sass']
})
export class LettersInApprovalComponent implements OnInit {
  tableValues: any;
  currentQueue: any;
  selectedQueue: string;
  loading: boolean;
  selectedFin: any;
  role: string;
  reportLevel: string;
  cpaArray: any;
  letterRenderUrl:any;
  footerSection:any;
  proposalAssignee:any;
  loginId:any;
    constructor(private RestcallService : RestcallService,private router: Router) { }

    ngOnInit(): void {
      this.reportLevel = sessionStorage.getItem('reportLvlCd');
      this.loginId=sessionStorage.getItem('loginId');
      this.loading = true;
      let currentQueueUrl = "/fleet-letters-management/approvals/v1/current-queue";
      // let currentQueueUrl = '/currentQueue';
      this.RestcallService.ngOnInit();
      this.RestcallService.getData(currentQueueUrl).subscribe(data => {
        data != null && data != '' ? this.currentQueue = data.currentQueue : this.currentQueue = [];
        if(this.currentQueue.length > 0){
          let personMatch = this.currentQueue.includes(sessionStorage.getItem('loginId'));
          personMatch == true ? this.selectedQueue = sessionStorage.getItem('loginId') : this.selectedQueue= this.currentQueue[0];
          this.loadTableData();
        }
      });
    }
    loadTableData(){
      if(this.selectedQueue != null || this.selectedQueue != ''){
        this.loading= true;
        let tableUrl = "/fleet-letters-management/approvals/v1/letters_in_approval";
        // let historyUrl = '/historyValues';
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('approverId', this.selectedQueue );
        this.RestcallService.getData(tableUrl).subscribe(data => {
           data != null && data != {} ? this.tableValues = data.lettersInApproval : this.tableValues = null;
          this.loading = false;
        }, err => {this.loading = false;this.tableValues = null});
      }
    }
    //Save or Reject Approval
    // updateRequest(){
    //   console.log(this.selectedFin);
    //   if(this.selectedFin.length > 0){
    //     let finCodes = [];
    //     let approverId = "";
    //     this.selectedFin.map(data => {
    //       finCodes.push(data.mainFinCode);
    //     });

    //   // let updateUrl = '/fin-assignment/v1/approve-reject';
    //   // let updateRequest = {
    //   //   "approveProcess": true,
    //   //   "mainFinCode": finCodes,
    //   //   "selectedApprovedId": approverId
    //   //   }
    //   // this.RestcallService.ngOnInit();
    //   // this.RestcallService.createData(updateUrl, updateRequest).subscribe(data => this.ngOnInit);
    //   }

    // }
  
 cpaLetterRender(programyrVersion,proposalKey,proposalStatus){
  sessionStorage.setItem("approval", "Yes");
  sessionStorage.setItem("CustAcc", "Yes");
  sessionStorage.setItem("proposalKey", proposalKey);
  sessionStorage.setItem("proposalStatus", proposalStatus);
  //sessionStorage.setItem("proposalAssignee", this.proposalAssignee);
  //this.router.navigateByUrl('/accounts/proposal?proposalKey='+proposalKey+'&tab=6'+'&viewletter=true');
  this.router.navigateByUrl('/accounts/proposal?proposalKey='+proposalKey+'&tab=6'+'&viewletter=true');
 }
}
