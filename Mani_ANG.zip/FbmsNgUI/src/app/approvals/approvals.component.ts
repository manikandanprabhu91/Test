import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.sass']
})
export class ApprovalsComponent implements OnInit {

  constructor() { }
  country: any;
  ngOnInit(): void {
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.country= sessionStorage.getItem('countryCode');
  }

}
