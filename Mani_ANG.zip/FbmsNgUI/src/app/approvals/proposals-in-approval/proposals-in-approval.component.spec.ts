import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalsInApprovalComponent } from './proposals-in-approval.component';

describe('ProposalsInApprovalComponent', () => {
  let component: ProposalsInApprovalComponent;
  let fixture: ComponentFixture<ProposalsInApprovalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposalsInApprovalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalsInApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
