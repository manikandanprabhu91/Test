import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import {MatMenuTrigger} from '@angular/material/menu';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'proposals-in-approval',
  templateUrl: './proposals-in-approval.component.html',
  styleUrls: ['../approvals.component.sass']
})
export class ProposalsInApprovalComponent implements OnInit {

  tableValues: any;
  currentQueue: any;
  accountVals: any;
  selectedQueue: string;
  selectedAccount: any;
  selectedVals: any;
  loading: boolean;
  reportLevel: string;
  cdsId : string;
  queueSelect: string;
  countryCode: any;
  propStatus: any;
  openDialog: boolean;
  proposalKey: any;
  actionComments: any;
  propAction: any;
  propstatusVal:any;
  reportLevelEnable: boolean; 
  userLevel: any;
  queueReportLevelCode: any;
    constructor(private RestcallService : RestcallService, private dialog: MatDialog) { }
    @ViewChild('menuTrigger') menuTrigger: MatMenuTrigger;

    ngOnInit(): void {
      this.openDialog = false;
      this.actionComments= '';
      this.propAction=null;
      this.countryCode = sessionStorage.getItem('countryCode');
      this.queueSelect = 'currentQueue'
      this.cdsId = sessionStorage.getItem('loginId');
      this.reportLevel = sessionStorage.getItem('reportLvlCd');
      this.reportLevelCondition();
      this.loading = true;
      let currentQueueUrl = "/fleet-proposal-orchestrator/proposals/v1/proposal-queue";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('reportLevelCd', sessionStorage.getItem('reportLvlCd'));
    // let currentQueueUrl = '/proposalApproval';
    this.RestcallService.getData(currentQueueUrl).subscribe(data => {
      data != null || data != '' ? this.currentQueue = data.currentQueue : this.currentQueue = [];
      data != null || data != '' ? this.accountVals = data.accountsQueue : this.accountVals = [];
     // console.log(data.accountsQueue);
      if(this.currentQueue.length > 0){
        let personMatch = this.currentQueue.includes(sessionStorage.getItem('loginId'));
        personMatch == true ? this.selectedQueue = sessionStorage.getItem('loginId') : this.selectedQueue= this.currentQueue[0];
      }
      if(this.accountVals.length > 0){

        this.selectedAccount = this.accountVals[0].finKey;
      }
      this.loadTableData(this.queueSelect);
     }, err => {this.loading= false; this.tableValues = null});
    }

    loadTableData(queueOpt){
      this.loading = true;
      if(this.selectedQueue != null || this.selectedQueue != '' || this.selectedAccount != null || this.selectedAccount !=''){
        let proposalTableUrl = "/fleet-proposal-orchestrator/proposals/v1/proposals-in-approval";
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('accountsQueue', this.selectedAccount );
        this.RestcallService.setQueryParams('currentQueue', this.selectedQueue );
        this.RestcallService.setQueryParams('queue', queueOpt);
        this.RestcallService.setQueryParams('reportLevelCd', sessionStorage.getItem('reportLvlCd')  );
        // let proposalTableUrl = '/proposalApprovalTable';
        this.RestcallService.getData(proposalTableUrl).subscribe(data => {
          sessionStorage.setItem("approval", "Yes");
          data == null || data == '' ?  this.tableValues = null : this.tableValues = data.proposalInApprovalVoList;
          this.loading = false;
          console.log(this.tableValues)
        }, err => {this.loading= false; this.tableValues = null});
      }
    }
    propStat(propStatus, key,propstatusval){
      this.propAction = propStatus;
      this.proposalKey = key;
      this.openDialog = true;
      this.propstatusVal=propstatusval;
    }
    saveAction(){
      let saveArray={
        "cdsid": sessionStorage.getItem('loginId'),
        "inProcess": "N",
        "proposalKey": this.proposalKey,
        "proposalNoteDescription": this.actionComments,
        "statusCd": this.propstatusVal
      };
      console.log(JSON.stringify(saveArray));
      let actUrl ='/fleet-proposal-summary/proposals/v1/submit-actions';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('action',this.propAction);
      this.RestcallService.setQueryParams('proposalKey',this.proposalKey);
      this.RestcallService.setQueryParams('highPriorityFlag', false);
      this.RestcallService.createData(actUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit());
    }
    cancelAction(){
      if(confirm('Are you sure you want to cancel the Action ?')){
        this.ngOnInit();
      }
    }

    reportLevelCondition() {
      if((this.reportLevel == '6' || this.reportLevel == '7') && this.countryCode == 'USA') {
        this.userLevel = Number(this.reportLevel) * 2;
      } else if((this.reportLevel == '9' || this.reportLevel == '8') && this.countryCode == 'MEX') {
        this.userLevel = Number(this.reportLevel) + 4;
      } else {
        this.userLevel = Number(this.reportLevel);
      }
    }

    queueReportLevel(queueReportLevelCode) {
      if((queueReportLevelCode == '6' || queueReportLevelCode == '7') && this.countryCode == 'USA') {
        return Number(queueReportLevelCode) * 2;
      } else if((queueReportLevelCode == '9' || queueReportLevelCode == '8') && this.countryCode == 'MEX') {
        return Number(queueReportLevelCode) + 4;
      } else {
        return Number(queueReportLevelCode);
      }
    }
  }
