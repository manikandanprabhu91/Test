import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { HttpParams } from '@angular/common/http';
declare var $: any;

@Component({
	selector: 'proposal-history',
	templateUrl: './proposal-history.component.html',
	styleUrls: ['../fbmscontainer.component.sass']
})
export class ProposalHistoryComponent implements OnInit {

	proposalDisplay: boolean;
	userDealAuthFlag: boolean;
	proposal: boolean;
	isShown: boolean;
	isProposalYearShown: boolean;
	configUrl: string = "";
	role: any;
	reportLevel: any;
	country: any;
	copyFinVal: any;
	proposalKey: any;
	finKey: any;
	finCd: any;
	proposalAssignee: any;
	proposalAssigneeFlag: boolean = false;
	cdsId: any;
	vernumR: any;
	accountName: any;
	proposalYear: any;
	historyValue: any[];
	finAndAccountName: any[];
	copyFinAndAccountName: any[];
	proposalYearAndVersion: any[];
	copyProposalYearAndVersion: any[];
	finCodeSelected: any[];
	finKeySelected: any[];
	proposalVersionSelected: any[];
	proposalYrSelected: any[];
	comments: string = "";
	copyDisplay: boolean;
	historyLabel: string;
	currVer: any;
	currPY: any;
	prevVer: any;
	currStatus: any;
	copyTypeVal: any;
	commentVal: any;
	copyFinCd: any;
	copyFinKey: any;
	copyProposalKey: any;
	copyYear: any;
	copyVersion: any;
	loading: boolean;
	accountNameVal: any;
	proposalYearVal: any;
	copyYearAndVerVal: any;
	copyFinArray = new Array();
	copyYearAndVer = new Array();
	copyShow: boolean = true;
	copyEnable: boolean = true;
	modifiedCPA: boolean;
	propsalList: any[];
	statusMsg: any;
	fleetRating: any;
	spinnerLoad: boolean;
	proposalStatus: any;
	constructor(private RestcallService: RestcallService, private route: ActivatedRoute) { }

	ngOnInit(): void {
		this.spinnerLoad = false;
		const body = document.getElementsByTagName('body')[0];
		body.classList.add('sidebar-collapse');
		this.role = sessionStorage.getItem('roleName');
		this.reportLevel = sessionStorage.getItem('reportLvlCd');
		this.country = sessionStorage.getItem('countryCode');
		this.proposal = sessionStorage.getItem('roleName') == 'NAM' ? true : false;
		this.proposalDisplay = false;
		this.isShown = false;
		this.isProposalYearShown = false;
		this.cdsId = sessionStorage.getItem('loginId');
		this.userDealAuthFlag = false;
		if (sessionStorage.getItem("dealAuthFlag") == "Y") {
			this.userDealAuthFlag = true;
		}
		if (sessionStorage.getItem("history") == "History") {
			this.proposalKey = sessionStorage.getItem("proposalKey");
			this.finKey = sessionStorage.getItem("finKey");
			this.proposalYear = sessionStorage.getItem("proposalYear");
			this.accountName = sessionStorage.getItem("accountName");
			this.proposalAssignee = sessionStorage.getItem("proposalAssignee")
			this.vernumR = sessionStorage.getItem("vernumR");
			this.finCd = sessionStorage.getItem("finCd");
		} else {
			this.proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
			this.finKey = this.route.snapshot.queryParamMap.get('finKey');
			this.finCd = this.route.snapshot.queryParamMap.get('finCd');
			this.proposalYear = this.route.snapshot.queryParamMap.get('proposalYear');
			this.accountName = this.route.snapshot.queryParamMap.get('accountName');
			this.proposalKey = this.route.snapshot.queryParamMap.get('proposalKey');
			this.vernumR = this.route.snapshot.queryParamMap.get('vernumR');
		}
		if (this.proposalAssignee.indexOf(this.cdsId) !== -1) {
			this.proposalAssigneeFlag = true;
		}

		this.copyTypeVal = null;
		this.commentVal = '';
		this.copyFinCd = this.finCd;
		this.copyProposalKey = null;
		this.copyFinKey = this.finKey;
		this.copyYear = null;
		this.copyVersion = null;
		this.setProposal(this.proposalYear);

		if (this.proposalKey != null) {
			this.loadData();
			sessionStorage.setItem("history", "History");
			sessionStorage.setItem("proposalKey", this.proposalKey);
			sessionStorage.setItem("finKey", this.finKey);
			sessionStorage.setItem("proposalYear", this.proposalYear);
			sessionStorage.setItem("accountName", this.accountName);
			sessionStorage.setItem("proposalAssignee", this.proposalAssignee);
			sessionStorage.setItem("vernumR", this.vernumR);
			sessionStorage.setItem("finCd", this.finCd);
			sessionStorage.setItem("optionsel", "Option");
			this.fleetRatingLabel();
		} else {
			this.historyValue = [];
		}
		this.historyLabel = this.accountName + ' ( ' + this.finCd + ' ) - ' + this.proposalYear;
		//this.fleetRatingLabel();
	}
	fleetRatingLabel() {

		const proposal = this.route.snapshot.queryParamMap.get('proposalKey');
		this.configUrl = '/fleet-proposal-orchestrator/proposals/v1/proposal/' + this.proposalKey;
		this.RestcallService.ngOnInit();
		// this.configUrl = "/propHead";
		this.RestcallService.getData(this.configUrl).subscribe(proposalData => this.mapProposalfleet(proposalData));
	}
	mapProposalfleet(proposalData) {
		this.proposalKey = proposalData.proposalHeaderInfoDTO['proposalSaKey'];
		if (this.country == "MEX") {
			this.fleetRating = proposalData.fleetRating;
		}
	}
	loadData() {
		this.configUrl = "/fleet-proposal-orchestrator/proposals/v1/proposal-history/" + this.proposalKey;
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('finKey', this.finKey);
		this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
		this.RestcallService.getData(this.configUrl).subscribe(data => this.mapDataVals(data));
	}

	mapDataVals(data) {
		let propYr = [];
		let propVer = [];
		this.modifiedCPA = false;
		data != null || data != '' ? this.historyValue = data.proposalHistory : this.historyValue = [];
		if (this.historyValue != null) {
			this.historyValue.map(data => {
				propYr.push(data.proposalYear);
				propVer.push(Number(data.proposalYearVersion.substring(7)));
				if (data.modifyLetterStatus == '#') {
					this.modifiedCPA = true;
				}
			});
			this.currPY = propYr.reduce((a, b) => Math.max(a, b));
			this.currVer = propVer.reduce((a, b) => Math.max(a, b));
			this.prevVer = ('' + this.currPY) + (' - ') + (this.currVer - 1);
			this.currVer = ('' + this.currPY) + (' - ') + (this.currVer);

			this.historyValue.map(data => {
				if (this.currPY == data.proposalYear && this.currVer == data.proposalYearVersion) {
					this.currStatus = data.status;
				}
			});
		}
		this.loading = false;
	}

	setProposal(year) {
		// let year = this.route.snapshot.queryParamMap.get('proposalYear');
		if (year == 'ALL' || year == null) {
			this.proposalYear = new Date().getFullYear();
		} else {
			this.proposalYear = year;
		}
	}

	createProposal() {
		this.proposalDisplay = true;
		this.configUrl = "/fleet-fin-orchestrator/fin-operating-unit/v1/account-name";
		this.RestcallService.ngOnInit();
		this.RestcallService.getData(this.configUrl).subscribe(data => {
			data != null || data != '' ? this.finAndAccountName = data.finAndAccountNameList : this.finAndAccountName = [];
			if (this.finAndAccountName != null) {
				let exactaccount = this.retrieval(this.accountName);
				this.accountNameVal = this.finAndAccountName[exactaccount];
				this.accountNameSelected(this.accountNameVal);
			}
		});
	}



	retrieval(valSelect) {
		let indexvalue;
		var valKey = valSelect;
		for (var i = 0; i < this.finAndAccountName.length; i++) {
			if (this.finAndAccountName[i].accountName == valKey) {
				indexvalue = i;
			}
		}
		return indexvalue;
	}




	cancelAction() {
		this.proposalDisplay = false;
		this.isShown = false;
		this.isProposalYearShown = false;
	}

	createNewProposal() {
		this.loading = true;
		this.configUrl = "/fleet-proposal-orchestrator/proposals/v1/proposals";
		this.RestcallService.queryParams = new HttpParams().set('cdsId', sessionStorage.getItem('loginId'));
		this.RestcallService.setQueryParams('countryCd', sessionStorage.getItem('countryCode'));
		this.RestcallService.setQueryParams('comments', this.comments);
		this.RestcallService.setQueryParams('finKey', this.finKeySelected);
		this.RestcallService.setQueryParams('finCd', this.finCodeSelected);
		this.RestcallService.setQueryParams('proposalYrVer', this.proposalVersionSelected);
		this.RestcallService.setQueryParams('proposalYr', this.proposalYrSelected);
		this.RestcallService.createData(this.configUrl, '').subscribe(data => {
			if (this.proposalKey != null) {
				this.loadData();
				this.historyValue = [];
			} else {
				this.loading = false;
			}
			this.RestcallService.statusMessage(201, 'New Version Successfully Created');
			// window.location.href = 'accounts/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;
			// if (data.body.copyWarningsVos != null && data.body.copyWarningsVos.length > 0) {
			// 	this.statusMsg = 'New Version Successfully Created';
			// 	this.propsalList = data.body.copyWarningsVos;
			// 	$('#exampleModalLong').modal('show');
			// } else {
			// 	this.RestcallService.openSuccessSnackBar("200", "New Proposal has been Successfully Created");
			// 	this.modelPopoupRedirect();
			// }
			window.location.href = 'accounts/history/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;

		}, err => this.loading = false);
	}

	modelPopoupRedirect() {
		window.location.href = 'accounts/history/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;
	}

	accountNameSelected(accountNameVal) {
		this.finCodeSelected = accountNameVal['finCode'];
		this.finKeySelected = accountNameVal['finKey'];
		this.isProposalYearShown = true;
		this.configUrl = "/fleet-proposal-orchestrator/proposals/v1/proposal-year-and-version";
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('finKey', this.finKeySelected);
		this.RestcallService.getData(this.configUrl).subscribe(data => {
			data != null || data != '' ? this.proposalYearAndVersion = data.proposalYearAndVersionVoList : this.proposalYearAndVersion = [];
			this.proposalYearVal = this.proposalYearAndVersion[0];
			this.proposalYearSelected(this.proposalYearVal);
		});
	}

	proposalYearSelected(proposalYearVal) {
		this.proposalVersionSelected = proposalYearVal['proposalVersion'];
		this.proposalYrSelected = proposalYearVal['proposalYear'];
		this.isShown = true;
	}

	acceptOrDeclineProposal(proposalKey, cpaLetterExist) {
		if (cpaLetterExist) {
			window.location.href = '/accounts/history/proposal?proposalAssignee=' + this.proposalAssignee + '&proposalKey=' + proposalKey + '&tab=6' + '&viewletter=true';
		} else {
			this.RestcallService.statusMessage(417, 'Unable to display Proposal Letter - "letter does not exist".');
		}
	}

	acceptOrDeclineProposalMex(proposalKey, cpaLetterExist) {
		if (cpaLetterExist) {
			window.location.href = '/accounts/history/proposal?proposalAssignee=' + this.proposalAssignee + '&proposalKey=' + proposalKey + '&tab=4' + '&viewletter=true';
		} else {
			this.RestcallService.statusMessage(417, 'Unable to display Proposal Letter - "letter does not exist".');
		}
	}

	//Copy To types
	copyTypes(type, vals) {

		this.copyProposalKey = vals.proposalKey;
		this.copyYear = vals.proposalYear;
		this.copyVersion = Number(vals.proposalYearVersion.substring(7));
		this.copyDisplay = true;
		this.commentVal = '';
		this.copyTypeVal = type;
		this.copyFinVal = '';
		this.copyYearAndVerVal = '';

		if (type == 'fin') {
			this.copyShow = false;
			this.copyEnable = false;
			this.copyFinAndAccountName = [];
			this.configUrl = "/fleet-fin-orchestrator/fin-operating-unit/v1/account-name";
			this.RestcallService.ngOnInit();
			this.RestcallService.getData(this.configUrl).subscribe(data => {
				data != null || data != '' ? this.copyFinAndAccountName = data.finAndAccountNameList : this.copyFinAndAccountName = [];
				this.formDataCopy();
			});
		} else {
			this.copyShow = true;
			this.copyEnable = true;
		}
	}

	formDataCopy() {
		var data = [];
		for (var val in this.copyFinAndAccountName) {
			if (this.copyFinAndAccountName[val].finCode != this.finCd) {
				data.push({
					"fin": this.copyFinAndAccountName[val].accountName + ' ' + '('
						+ this.copyFinAndAccountName[val].finCode + ')',
					"finKey": this.copyFinAndAccountName[val].finKey,
					"finCode": this.copyFinAndAccountName[val].finCode
				});
			}

		}
		this.copyFinArray = data;
	}

	copyFin() {
		var copyData = [];
		this.configUrl = "/fleet-proposal-orchestrator/proposals/v1/proposal-year-and-version";
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('finKey', this.copyFinVal['finKey']);
		this.RestcallService.getData(this.configUrl).subscribe(data => {
			data != null || data != '' ? this.copyProposalYearAndVersion = data.proposalYearAndVersionVoList : this.copyProposalYearAndVersion = [];
			let addYear = Number(this.proposalYear) + 1;
			for (var val in this.copyProposalYearAndVersion) {
				this.copyYearAndVer = [];
				if (this.copyProposalYearAndVersion[val].proposalYear == this.proposalYear
					|| this.copyProposalYearAndVersion[val].proposalYear == addYear) {
					copyData.push({
						"Year": this.copyProposalYearAndVersion[val].proposalYear + ' ' + '-' + this.copyProposalYearAndVersion[val].proposalVersion,
						"copyYear": this.copyProposalYearAndVersion[val].proposalYear,
						"copyVer": this.copyProposalYearAndVersion[val].proposalVersion
					});
				}
			}
			this.copyYearAndVerVal = '';
			if (copyData.length == 1) {
				copyData.push({
					"Year": addYear + '-' + '1',
					"copyYear": addYear,
					"copyVer": 1
				});
			}
			this.copyYearAndVer = copyData;
		});
	}

	copyYearAndVerSelect() {
		this.copyEnable = true;
	}

	//Recall Proposal
	propStat(propStatus, key, status) {
		this.copyTypeVal = propStatus;
		this.copyProposalKey = key;
		this.copyDisplay = true;
		this.commentVal = '';
		this.proposalStatus = status;
	}

	cancel() {
		this.copyDisplay = false;
	}

	copy() {
		this.copyDisplay = false;

		if (this.copyTypeVal == "RECALL_PROPOSAL") {
			if (confirm('Any prior approvals from your level and above will be lost and the proposal would need to gt re-approved. Note that revisions, if any, done by the first level approver(' + sessionStorage.getItem("loginId") + ') will not be able to lost as a result of recall. Do you want to continue with RECALL?')) {
				this.spinnerLoad = true;

				let saveArray = {
					"cdsid": sessionStorage.getItem('loginId'),
					"inProcess": "N",
					"proposalKey": this.copyProposalKey,
					"proposalNoteDescription": this.commentVal,
					"statusCd": this.proposalStatus
				};
				let actUrl = '/fleet-proposal-summary/proposals/v1/submit-actions';
				this.RestcallService.ngOnInit();
				this.RestcallService.setQueryParams('action', this.copyTypeVal);
				this.RestcallService.setQueryParams('proposalKey', this.copyProposalKey);
				this.RestcallService.setQueryParams('highPriorityFlag', false);
				this.RestcallService.createData(actUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit(),
				err=> this.spinnerLoad = false);
			}
		} else {
			this.spinnerLoad = true;

			let copytype;
			if (this.copyTypeVal == 'new') {
				copytype = 'COPY_NEW_PROPOSAL_VERSION';
			}
			if (this.copyTypeVal == 'deal') {
				copytype = 'COPY_NEW_PROPOSAL_DEAL'
			}
			if (this.copyTypeVal == 'fin') {
				copytype = 'COPY_NEW_PROPOSAL_FIN'
			}
			let copyArray = {}
			let copyUrl = '/fleet-proposal-orchestrator/proposals/v1/proposals/copy';
			this.RestcallService.ngOnInit();
			if (this.copyTypeVal == 'fin') {
				this.RestcallService.setQueryParams("finCd", this.copyFinVal['finCode']);
				this.RestcallService.setQueryParams("finKey", Number(this.copyFinVal['finKey']));
				this.RestcallService.setQueryParams("proposalYr", Number(this.copyYearAndVerVal['copyYear']));
				this.RestcallService.setQueryParams("proposalYrVer", Number(this.copyYearAndVerVal['copyVer']));
			} else {
				this.RestcallService.setQueryParams("finCd", this.copyFinCd);
				this.RestcallService.setQueryParams("finKey", Number(this.copyFinKey));
				if (copytype == 'COPY_NEW_PROPOSAL_DEAL') {
					this.RestcallService.setQueryParams("proposalYr", Number(this.copyYear + 1));
				} else {
					this.RestcallService.setQueryParams("proposalYr", Number(this.copyYear));
				}
				this.RestcallService.setQueryParams("proposalYrVer", Number(this.copyVersion));
			}
			this.RestcallService.setQueryParams("comments", this.commentVal);
			this.RestcallService.setQueryParams("copyType", copytype);
			this.RestcallService.setQueryParams("sourceProposalKey", Number(this.copyProposalKey));
			this.RestcallService.createData(copyUrl, copyArray).subscribe(data => {
				this.copyDisplay = false;
				// if (data.body.copyWarningsVos != null) {
				// 	this.statusMsg = 'Proposal Copied Successfully';
				// 	this.propsalList = data.body.copyWarningsVos;
				// 	$('#exampleModal').modal('show');
				// }
				// this.RestcallService.statusMessage(201, 'Proposal Copied Successfully');
				// window.location.href = 'accounts/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;
				this.propsalList = data.body.copyWarningsVos;
				sessionStorage.setItem("warning", "Warning");
				sessionStorage.setItem("copyWarningsVos", JSON.stringify(this.propsalList));
				this.RestcallService.openSuccessSnackBar("200", "New Proposal has been Successfully Created");
				window.location.href = 'accounts/history/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;

			}, err => {
				this.spinnerLoad = false;
				this.copyDisplay = false;
				this.ngOnInit();
			});
		}
	}

}
