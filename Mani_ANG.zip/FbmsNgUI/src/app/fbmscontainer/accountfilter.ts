export class AccountFilter {
    opvSelected: String;
    dpdSelected: String;
    pySelected: String;
    statusSelected: String;
    includeProposal: any;
    includeSubfin: any;
}