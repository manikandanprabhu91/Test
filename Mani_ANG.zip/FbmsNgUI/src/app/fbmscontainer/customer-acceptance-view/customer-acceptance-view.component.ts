import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { Router } from 'src/testing/router-stubs';

@Component({
	selector: 'customer-acceptance-view',
	templateUrl: './customer-acceptance-view.component.html',
	styleUrls: ['../fbmscontainer.component.sass']
})
export class CustomerAcceptanceViewComponent implements OnInit {

	finKey: number;
	finCd: any;
	accountName: any;
	proposalYear: number;
	configUrl: string = "";
	customerAcceptanceArray: any[];
	loginId:any;
	role: string;
	loading: boolean;
	proposalAssignee:any;

	constructor(private RestcallService: RestcallService, private route: ActivatedRoute,private router: Router) { }

	ngOnInit(): void {
		this.loading = true;
		this.loginId = sessionStorage.getItem('loginId');
		this.proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
		this.finCd = this.route.snapshot.queryParamMap.get('finCd');
		this.accountName = this.route.snapshot.queryParamMap.get('accountName');
		this.finKey = Number(this.route.snapshot.queryParamMap.get('finKey'));
		this.setProposal();
		this.configUrl = "/fleet-letters-management/customer-acceptance/v1/customer-acceptance";
		this.RestcallService.ngOnInit();
		this.RestcallService.setQueryParams('finKey', this.finKey);
		this.RestcallService.setQueryParams('proposalYear', this.proposalYear);
		this.RestcallService.getData(this.configUrl).subscribe(data => {
			data != null || data != '' ? this.customerAcceptanceArray = data.customerAcceptanceVoList : this.customerAcceptanceArray = [];
		});
		this.loading = false;
	}

	setProposal() {
		let year = this.route.snapshot.queryParamMap.get('proposalYear');
		if (year == 'ALL' || year == null) {
			this.proposalYear = new Date().getFullYear();
		} else {
			this.proposalYear = Number(year);
		}
	}  
	cpaLetterRender(programyrVersion,proposalKey,proposalStatus){
		sessionStorage.setItem("CustAcc", "Yes");
		sessionStorage.setItem("proposalKey", proposalKey);
		sessionStorage.setItem("proposalStatus", proposalStatus);
		sessionStorage.setItem("proposalAssignee", this.proposalAssignee);
		this.router.navigateByUrl('/accounts/proposal?proposalAssignee='+this.proposalAssignee+'&proposalKey='+proposalKey+'&tab=6'+'&viewletter=true');
	   }
}
