import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerAcceptanceViewComponent } from './customer-acceptance-view.component';

describe('CustomerAcceptanceViewComponent', () => {
  let component: CustomerAcceptanceViewComponent;
  let fixture: ComponentFixture<CustomerAcceptanceViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerAcceptanceViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerAcceptanceViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
