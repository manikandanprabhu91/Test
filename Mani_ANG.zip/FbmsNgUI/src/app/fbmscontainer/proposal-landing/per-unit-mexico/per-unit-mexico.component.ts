import { DatePipe } from '@angular/common';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { RestcallService } from 'src/app/services/restcall.service';
import { formatDate } from "@angular/common";

@Component({
  selector: 'per-unit-mexico',
  templateUrl: './per-unit-mexico.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class PerUnitMexicoComponent implements OnInit {
  proposalKey: any;
  finKey: any;
  proposalYear: any;
  proposalVersion: any;
  proposalStatus: any;
  nonFinancialEdit: any;
  propCdsId: any;
  loginId: any;
  reportLevel: any;
  role: any;
  today: any;
  fleetRating: any;
  fomPerunitAS: boolean;
  fomVehicleTableAS: boolean;
  dealervalue:any;
  quotdatevin:any;
  proposalInfo: any;
  priorYrActuals: any;
  dealerInfo: any;
  quotationDate: FormControl;
  quotationValDate: String;
  waitingList: any;
  mlvTotal: any;
  dealerSelect: any;
  splIns: any;
  floorPlan: any;
  volumeData: any;
  loading: boolean;
  selectionArray: any;
  editRows: any;
  opendialog: boolean;
  addModelYear: any;
  addModelYearSelect: any;
  addVehicleLine: any;
  addVehicleLineSelect: any;
  addCatalog: any;
  addCatalogSelect: any;
  bodyStyleKeyMap: any;
  addFleet: any;
  addFleetSelect: any;
  addmarket: any;
  addFleetPrice: any;
  addFleetIncentive: any;
  addMlv: any;
  addCompStock: any;
  addGetVehicleData: any;
  tempAddVehicle: any;
  newVehicle: any;
  mpArray: any;
  saveDisplay: boolean
  editablePvikey: any;
  addError: boolean;
  editError: boolean;
  //vin added below
  openVindialog: boolean;
  catlogvindesc: any;
  catlogvincode: any;
  modelyearvin: any;
  exteriorDropdown: any;
  interiorDropdown: any;
  exteriorVal: any;
  interiorVal: any;
  extdesc: any;
  intdesc: any;
  vehicleLineTable: any;
  vehicleCopySelection: any;
  blockedvehicleCopySelection:any;
  cdsId: any;
  bodyKey: any;
  dealvalue: any;
  blockeddata: any;
  blockedentry: any;
  unblockedentry: any;
  blockingdate: any;
  blockingid: any;
  blockingvin: any;
  blockVal: any;
  blockedvehicleLineTable: any;
  addVehNew: any;
  bodykeyvinval: any;
  todayDate: any;
  qDateMod: any;
  accountnamevin:any;
  saveEvent: boolean = true;
  @ViewChild('myListbox') multiSelectVariable;
  count: number = 0;
  constructor(private RestcallService: RestcallService, private datePipe: DatePipe) { }

  @Input() proposalArray: any;

  ngOnInit(): void {
    this.quotationDate = new FormControl();

    this.proposalKey = this.proposalArray[0];
    this.finKey = this.proposalArray[1];
    this.proposalYear = this.proposalArray[2];
    this.proposalVersion = this.proposalArray[3];
    this.proposalStatus = this.proposalArray[4];
    this.propCdsId = this.proposalArray[6];
    this.fleetRating = this.proposalArray[10];
    this.accountnamevin=this.proposalArray[7] + "(" + this.proposalArray[8] + ")";
    this.today = new Date;
    this.today = this.datePipe.transform(this.today, 'yyyy-MM-dd');
    this.loginId = sessionStorage.getItem('loginId');
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.addCatalogSelect = [];
    this.editablePvikey = [];  
    this.formgetData();
    this.volumeTable();
    //vin added below  
    this.exteriorDropdown = [];
    this.interiorDropdown = [];
    this.vehicleCopySelection = null;
    this.fomPerunitAS = false;

  }
  formgetData() {
    let proposalUrl = '/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive/' + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
    this.RestcallService.getData(proposalUrl).subscribe(data => {
      data != null ? this.priorYrActuals = data.priorYrActuals : this.priorYrActuals = "";
      data != null ? this.proposalInfo = data.proposalExtraInfoDto : this.proposalInfo = null;
      data != null ? this.dealerInfo = data.dealerInfo : this.dealerInfo = null;
      this.mapVals();
    });
  }
  mapVals() {
    if (this.proposalInfo != null) {
      var date = formatDate(this.proposalInfo.proposalExpirationDate, 'MM/dd/yyyy', 'en-US');
      this.quotationDate.setValue(new Date(date));
      this.quotationValDate = date;
      this.quotationDate.value < this.today ? this.fomPerunitAS = false : '';
      this.waitingList = this.proposalInfo.waitingListFlag;
      this.dealerSelect = this.proposalInfo.dealerFinKey;
      this.floorPlan = this.proposalInfo.floorPlanDays;
      this.splIns = this.proposalInfo.specialInstructionDesc;
    }
  }
  rowSelect() {
    if(this.editablePvikey.length < 0) {
      this.cancelAction();
    }
  }
  cancelChanges() {
    this.formgetData();
  }
  valueChange(field, event) {
    // if(field == 'quote'){
    //   this.quotationDate = event;
    // }
    if ((this.splIns != null ? this.splIns.length > 38 : '') || this.quotationDate.value < this.today) {
      this.fomPerunitAS = false;
    } else {
      this.fomPerunitAS = true;
    }

  }
  quotationDateChange(event) {
    this.fomPerunitAS = true;
    this.quotationValDate = this.datePipe.transform(this.quotationDate.value, 'MM/dd/yyyy');
  }

  saveForm() {

    this.todayDate = new Date();
    var dd = String(this.todayDate.getDate()).padStart(2, '0');
    var mm = String(this.todayDate.getMonth() + 1).padStart(2, '0');
    var yyyy = this.todayDate.getFullYear();

    this.todayDate = yyyy + '-' + mm + '-' + dd;

    this.qDateMod = this.datePipe.transform(this.quotationDate.value, 'yyyy-MM-dd');
    var varDate = new Date(this.qDateMod);
    var currentDate = new Date(this.todayDate);
    var time = new Date();
    if (varDate >= currentDate) {
      var hour = String(time.getHours()).length > 1 ? String(time.getHours()) : '0' + String(time.getHours());
      var minutes = String(time.getMinutes()).length > 1 ? String(time.getMinutes()) : '0' + String(time.getMinutes());
      var seconds = String(time.getSeconds()).length > 1 ? String(time.getSeconds()) : '0' + String(time.getSeconds());
      var milliseconds = String(time.getMilliseconds()).length > 2 ? String(time.getMilliseconds()) :
        String(time.getMilliseconds()).length > 1 ? '0' + String(time.getMilliseconds()) : '00' + String(time.getMilliseconds());

      this.qDateMod = this.qDateMod + 'T' + hour + ':' + minutes + ':' + seconds + '.' + milliseconds + 'Z';
      // this.qDateMod = this.qDateMod + 'T' + '12' + ':' + '10' + ':' + '15' + '.' + '20' + 'Z';
      var qDateMod = this.qDateMod;
      let saveArray = {
        "proposalKey": this.proposalKey,
        "dealerFinKey": this.dealerSelect,
        "floorPlnDays": this.floorPlan,
        "quoteExpDate": qDateMod,
        "waitingList": this.waitingList,
        "specialInst": this.splIns
      };
      let saveUrl = '/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("finKey", this.finKey);
      this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
      this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
      this.RestcallService.updateData(saveUrl, JSON.stringify(saveArray)).subscribe(data => this.ngOnInit());
    } else {
      this.RestcallService.statusMessage('417', "Quotation Expiration Date must be greater than or equal to current date .");
    }

  }
  //Vehicle Volume Table
  volumeTable() {
    this.fomPerunitAS = false;
    this.addError = false;
    this.editError = false;
    this.saveDisplay = false;
    this.tempAddVehicle = [];
    this.newVehicle = [];
    this.loading = true;
    this.selectionArray = [];
    this.opendialog = false;
    this.editablePvikey = [];
    this.editRows = [];
    this.addCatalogSelect = [];
    this.addGetVehicleData = [];
    let tableGet = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(tableGet).subscribe(data => this.mapTableVals(data), err => { this.loading = false; this.volumeData = null });
  }
  mapTableVals(data) {
    if (data != null) {
      this.fomPerunitAS = false;
      this.volumeData = data.vehicleDetailsVos;
      this.editRows = this.volumeData;
      this.mlvTotal = this.volumeData.map(val => Number(val.vehMlv)).reduce((curr, prev) => Number(curr) + Number(prev), 0);
      this.loading = false;
    }
    else {
      this.fomPerunitAS = false;
      this.volumeData = null;
      this.mlvTotal = 0;
      this.loading = false;
    }
  }
  multiDelete() {
    let deleteUrl = "/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/" + this.proposalKey;
    let deleteArray = [];
    this.selectionArray.map(data => {
      deleteArray.push(data.pvikey)
    });
    this.RestcallService.ngOnInit();
    this.RestcallService.updateData(deleteUrl, deleteArray).subscribe(data => this.volumeTable());
  }
  //Cancel Action for Table
  cancelAction() {
    this.volumeTable();
  }
  ondblclick(pvikey) {
    if ((this.proposalStatus != "NEW" ? true : this.propCdsId == this.loginId ? false : true) && (this.proposalStatus != "REV" ? true : this.reportLevel == 6 ? false : true) || this.role == "ADM") {

    } else {
      if (this.editablePvikey.length > 0) {
        if (!this.editablePvikey.includes(pvikey)) {
          this.editablePvikey.push(pvikey);
        }
      } else {
        this.editablePvikey.push(pvikey);
      }
    }
  }
  multiEdit() {
    this.editablePvikey = [];
    this.selectionArray.map(data => {
      this.editablePvikey.push(data.pvikey);
    });
  }

  editChangeVals(field, pvikey, event) {
    if (field == 'editFleetPrice') {
      if (isNaN(event.target.value) || event.target.value > 9999999 || event.target.value < 1) {
        alert('Fleet Price is Numeric field which accepts 7 digits max');
        this.editError = true;
        this.fomVehicleTableAS = false;
      }
      else {
        this.editError = false;
        this.fomVehicleTableAS = true;
        this.editRows.map(val => {
          if (val.pvikey == pvikey) {
            val.pviExtraInfoVo.fleetPrice = Number(event.target.value);
          }
        });
      }
    }
    if (field == 'editMlv') {
      if (isNaN(event.target.value) || event.target.value > 999999 || event.target.value < 1) {
        alert('MLV is Numeric field which accepts 6 digits max');
        this.editError = true;
        this.fomVehicleTableAS = false;
      }
      else {
        this.editError = false;
        this.fomVehicleTableAS = true;
        this.editRows.map(val => {
          if (val.pvikey == pvikey) {
            val.vehMlv = Number(event.target.value);

          }
        });
      }
    }
    if (field == 'editCompStock') {
      this.editRows.map(val => {
        if (val.pvikey == pvikey) {
          val.pviExtraInfoVo.companyStock = event.target.value;
        }
      });
    }
  }

  //Edit Save
  saveRow() {
    let saveArray = [];
    this.editRows.map(data => {
      if (this.editablePvikey.includes(data.pvikey)) {
        saveArray.push({
          "bodystylekey": data.bodystylekey,
          "companyStock": data.pviExtraInfoVo.companyStock,
          "fleetIncentive": data.pviExtraInfoVo.fleetIncentive,
          "fleetPrice": data.pviExtraInfoVo.fleetPrice,
          "fleetType": data.pviExtraInfoVo.fleetType == 'Business Case' ? 'BC' : data.pviExtraInfoVo.fleetType,
          "marketingProgram": data.pviExtraInfoVo.marketingProgram,
          "pvikey": data.pvikey,
          "vehMlv": data.vehMlv
        });
      }
    });
    let FinalSaveArray = {
      "tierVolumeList": [],
      "vehicleDetailsVos": saveArray
    }
    let editSaveUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey + '/' + this.proposalYear;
    this.RestcallService.ngOnInit();
    this.RestcallService.createData(editSaveUrl, JSON.stringify(FinalSaveArray)).subscribe(data => this.volumeTable());
  }
  //Add New Vehicle
  addNewVehicle() {
    this.count = 0;
    this.loading = true;
    let addUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/new-vehicle-info/' + this.proposalKey + '/' + this.proposalYear;
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(addUrl).subscribe(data => {
      this.opendialog = true;
      this.addGetVehicleData = data.modelYearVehLineBdyStlMap;
      this.addModelYear = Object.keys(data.modelYearVehLineBdyStlMap);

      this.addModelYearSelect = this.addModelYear.includes(this.proposalYear) ? this.proposalYear : this.addModelYear[0];
      this.addVehicleLineGet();
      this.loading = false;
    },
      err => this.loading = false);
  }
  addVehicleLineGet() {
    this.addVehicleLine = Object.keys(this.addGetVehicleData[this.addModelYearSelect]);
    this.addVehicleLineSelect = 'select';
    this.count = 0;
  }
  addCatalogGet() {
    this.addCatalogSelect = [];
    if (this.addVehicleLineSelect != 'select') {
      this.addCatalog = this.addGetVehicleData[this.addModelYearSelect][this.addVehicleLineSelect];
    }
    if(this.count != 0 && this.addVehicleLineSelect !="select") {
      this.multiSelectVariable.filterValue = "";
    }
    this.count = this.addVehicleLineSelect !="select" ? 1 : 0;
  }
  tempAdd() {
    let addDuplicate: boolean;
    addDuplicate = false;
    if (this.tempAddVehicle.length > 0) {
      this.bodyStyleKeyMap = new Map(this.tempAddVehicle.map(i => [i.bodystylekey, i.bodystylekey]));
      this.addCatalogSelect.map(data => {
          if (this.bodyStyleKeyMap.get(data['bodyStyleKey']) == null ) {
            this.tempAddVehicle.push({
              "bodystylekey": data.bodyStyleKey,
              "catalog": data.bodyStyleCode,
              "companyStock": "N",
              "fleetIncentive": 0,
              "fleetPrice": 0,
              "fleetType": null,
              "marketingProgram": null,
              "pvikey": 0,
              "vehMlv": 0,
              'modelYear': this.addModelYearSelect,
              'vehicleLine': this.addVehicleLineSelect,
            });
          }
      });
    } else {
      this.addCatalogSelect.map(data => {
        this.tempAddVehicle.push({
          "bodystylekey": data.bodyStyleKey,
          "catalog": data.bodyStyleCode,
          "companyStock": "N",
          "fleetIncentive": 0,
          "fleetPrice": 0,
          "fleetType": null,
          "marketingProgram": null,
          "pvikey": 0,
          "vehMlv": 0,
          'modelYear': this.addModelYearSelect,
          'vehicleLine': this.addVehicleLineSelect,

        });
      });
    }
    this.enableSave();
  }

  enableSave() {
    const invalidFleet = this.tempAddVehicle.filter(val => val.fleetType === null || val.fleetType === 'select');
    if (invalidFleet.length == 0) {
      this.saveDisplay = true;
    }
    else {
      this.saveDisplay = false;
    }
  }

  marketProgramGet(action, bsKey, pvikey, event) {
    // this.saveDisplay = true;
    if (event.target.value != 'Business Case' && event.target.value != 'BC' && event.target.value != 'select') {
      let mpUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/marketing-program/' + bsKey + '/' + event.target.value;
      this.RestcallService.ngOnInit();
      this.RestcallService.getData(mpUrl).subscribe(data => {
        let marketingProgramVals;
        data != null ? marketingProgramVals = data.marketingProgram : marketingProgramVals = null;
        if (marketingProgramVals == null) {
          this.RestcallService.statusMessage(417, "Please select any other Fleet type");
          if (action == 'add') {
            this.addError = true;
            this.tempAddVehicle.map(val => {
              if (val.bodystylekey == bsKey) {
                val.fleetType = 'select';
              }

            });
          } else if (action == 'edit' && event.target.value != 'select') {
            this.editError = true;
            this.fomVehicleTableAS = false;
            this.editRows.map(val => {
              if (val.pvikey == pvikey) {
                val.pviExtraInfoVo.fleetType = 'select';
              }
            });
          }
        } else {
          if (action == 'add') {
            this.addError = false;

            this.tempAddVehicle.map(val => {
              if (val.bodystylekey == bsKey) {
                val.fleetType = marketingProgramVals.fleetRating;
                val.fleetPrice = marketingProgramVals.fleetPrice;
                val.fleetIncentive = marketingProgramVals.fleetIncentive;
                val.marketingProgram = marketingProgramVals.marketingProgram;
              }
            });
          } else if (action == 'edit' && event.target.value != 'select') {
            this.editError = false;
            this.fomVehicleTableAS = true;
            this.editRows.map(val => {
              if (val.pvikey == pvikey) {
                val.pviExtraInfoVo.fleetType = marketingProgramVals.fleetRating;
                val.pviExtraInfoVo.fleetPrice = marketingProgramVals.fleetPrice;
                val.pviExtraInfoVo.fleetIncentive = marketingProgramVals.fleetIncentive;
                val.pviExtraInfoVo.marketingProgram = marketingProgramVals.marketingProgram;
              }
            });
          }

        }
        this.enableSave();
      });
    }
    else {
      if (action == 'add') {
        this.addError = false;

        this.tempAddVehicle.map(val => {
          if (val.bodystylekey == bsKey) {
            val.fleetType = event.target.value;
            val.fleetPrice = 1;
            val.fleetIncentive = 0;
            val.marketingProgram = null;
          }
        });
      } else if (action == 'edit' && event.target.value != 'select') {
        this.editError = false;

        this.editRows.map(val => {
          if (val.pvikey == pvikey) {
            val.pviExtraInfoVo.fleetType = event.target.value;
            val.pviExtraInfoVo.fleetPrice = 1;
            val.pviExtraInfoVo.fleetIncentive = 0;
            val.pviExtraInfoVo.marketingProgram = null;
          }
        });
      }
      this.enableSave();
    }
  }


  addValues(field, bsKey, event) {
    if (field == 'fleetPrice') {
      if (isNaN(event.target.value) || event.target.value > 9999999 || event.target.value < 1) {
        alert('Fleet Price is Numeric field which accepts 7 digits max');
        this.addError = true;

      }
      else {
        this.addError = false;

        this.tempAddVehicle.map(val => {
          if (val.bodystylekey == bsKey) {
            val.fleetPrice = Number(event.target.value);
          }
        });
      }
    }
    if (field == 'mlv') {
      if (isNaN(event.target.value) || event.target.value > 999999 || event.target.value < 0) {
        alert('Fleet Price is Numeric field which accepts 6 digits max');
        this.addError = true;

      }
      else {
        this.addError = false;

        this.tempAddVehicle.map(val => {
          if (val.bodystylekey == bsKey) {
            val.vehMlv = Number(event.target.value);
          }
        });
      }
    }
    if (field == 'compStock') {
      this.tempAddVehicle.map(val => {
        if (val.bodystylekey == bsKey) {
          val.companyStock = event.target.value;
        }
      });
    }
  }
  saveAddVehicle() {
    this.saveEvent = false;
    let finalArray = {
      vehicleDetailsVos: this.tempAddVehicle
    }
    let saveUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey + '/' + this.addModelYearSelect;
    this.RestcallService.ngOnInit();
    this.RestcallService.createData(saveUrl, JSON.stringify(finalArray)).subscribe(data => {this.volumeTable(), this.saveEvent = true});
  }
   //Vin allocation
   vinallocation(quot,index, vehvinval, bodyvinval, catvinval, modyrvinval, bodykeyvinval) {
    this.openVindialog = true;
    this.quotdatevin= this.datePipe.transform(this.quotationDate.value, 'MM/dd/yyyy');
     
     this.catlogvindesc = vehvinval + "-" + bodyvinval ;
     this.catlogvincode = catvinval;
     this.modelyearvin = modyrvinval;  
     this.bodykeyvinval = bodykeyvinval;
     var dealret = this.dealerCoderetrieval(this.dealerSelect);
     this.exteriorDropdown = [];
     this.interiorDropdown = [];
     this.vehicleCopySelection=null;
     this.blockedvehicleCopySelection=null;
     this.vehicleLineTable=null;
     this.invokeBlockedTable();
     
   }  
 
   dealerCoderetrieval(dealerSelect) {
     
     var dealKey = dealerSelect;
     var deal;
     var desc;
     for (var i = 0; i < this.dealerInfo.length; i++) {
       // commenting this.dealerInfo[i].some(function(item){
 
       if (this.dealerInfo[i].dealerKey == dealKey) {
         deal = this.dealerInfo[i].dealerCode;
         desc = this.dealerInfo[i].description;
         this.dealervalue=desc;
       }
       // });
     }
     return deal;
   }
   cancelVin() {
     this.exteriorDropdown = [];
     this.interiorDropdown = [];
     this.vehicleCopySelection = null;
     this.openVindialog = false;
   }
 
 
   //Get Colors Click Event
   getColors() {
    
 
     let colorDataUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/colors/' + this.modelyearvin
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.getData(colorDataUrl).subscribe(respData => {
       this.vehicleLineTable=respData.colorsObject;
       this.exteriorDropdown = this.vehicleLineTable.exteriorColors.color;
       this.interiorDropdown = this.vehicleLineTable.interiorColors.color;
      this.exteriorVal = this.exteriorDropdown[0].code;
       this.interiorVal = this.interiorDropdown[0].code;
       this.extdesc = this.exteriorDropdown[0].description;
       this.intdesc = this.interiorDropdown[0].description;
       
       this.loading = false;
       //.invokeTable(this.exteriorVal, this.interiorVal);
     }, err => { this.loading = false; });
   }
 
   invokeTable(newexteriorVal, newinteriorVal) {
     //Table details
     let tableDataUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/available-vins/' + this.modelyearvin
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.setQueryParams("model-year", this.modelyearvin);
     let addArray = {
       "exteriorColorCodes": [newexteriorVal],
       "interiorColorCodes": [newinteriorVal],
     };
     this.unblockedentry = 'value';
     this.blockedentry = 0;
     this.blockVal = 'No';
     this.RestcallService.createDealer(tableDataUrl, JSON.stringify(addArray)).subscribe(data => {
       data != null ? this.vehicleLineTable = data.vehicleResponseVo.vehicles : this.vehicleLineTable = null;
       //this.invokeBlockedTable();
     });
     this.invokeBlockedTable();
   }
 
   //block
   block(rowIndex) {
     var dealret = this.dealerCoderetrieval(this.dealerSelect);
     let vinDetailsVoList = [];
     this.cdsId = sessionStorage.getItem('loginId');
     let latest_date = this.datePipe.transform(this.today, 'MM/dd/yyyy');
     let dateString = latest_date.toString();
     let vinele;
     this.vehicleCopySelection.map(data => {
       vinDetailsVoList.push({
         "acctMgrId": this.cdsId,
         "aging": data.aging,
         "blockedDate": dateString,
         "exteriorColorCode": data.extColorCode,
         "exteriorColorDesc": data.extColorDesc,
         "interiorColorCode": data.intColorCode,
         "interiorColorDesc": data.intColorDesc,
         "status": data.vinStatus,
         "vinCode": data.vinCode
       })
     });
     let finalcopyVeh = {
       "dealerCode": dealret,
       "flrPlnDays": "",
       "splInstructions": "",
       vinDetailsVoList
     }
     let copyVehUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/block-vins/' + this.proposalKey + "/" + this.modelyearvin;
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("bodyStyleKey", this.bodykeyvinval);
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.setQueryParams("model-year", this.modelyearvin);
     this.RestcallService.setQueryParams("proposal-key", this.proposalKey);
     this.blockVal = 'Yes'; 
     this.RestcallService.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data =>
       {
         this.invokeBlockedTable();
         this.invokeTable(this.exteriorVal, this.interiorVal);
         this.vehicleCopySelection=null;
         this.vehicleCopySelection.length=[];
       }, err => { this.loading = false; });
       
   }
 
 
   invokeBlockedTable() {
     //Table details
     let tableDataUrlblock = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/' + this.proposalKey + "/" + this.modelyearvin;
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.setQueryParams("model-year", this.modelyearvin);
     this.RestcallService.setQueryParams("proposal-key", this.proposalKey);
     this.blockedentry = 'value';
     this.unblockedentry = 0;
     this.RestcallService.getData(tableDataUrlblock).subscribe(respData => {
       respData != null
         ? this.blockedvehicleLineTable = respData.blockedVinDtos : this.blockedvehicleLineTable = null;
    /*   this.blockedvehicleLineTable.map(data => {
         this.blockedvehicleLineTable.push({
           "vinCode": data.vinCode,
           "vinStatus": data.vinStatus,
           "proposalKey": this.proposalKey,
           "bodyStyleKey": this.bodykeyvinval,
           "intColourCode": data.intColorCode,
           "intColourDesc": data.intColorDesc,
           "extColourCode": data.extColorCode,
           "extColourDesc": data.extColorDesc,
           "vinAging": data.vinAging,
           "namCdsId": data.namCdsId,
           "processedTimeStamp": data.processedTimeStamp
         })
 
       });*/
     });
 
 
   }
 
   //block
   unblock() {
     let vinList = [];
     this.blockedvehicleCopySelection.map(data => {
       vinList.push(data.vinCode)
     });
     let finalcopyVeh = vinList;
     let copyVehUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/unblock-vins/' + this.proposalKey + "/" + this.modelyearvin;
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.setQueryParams("model-year", this.modelyearvin);
     this.RestcallService.setQueryParams("proposal-key", this.proposalKey);
     this.blockVal = 'Yes';
     this.RestcallService.updateData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data =>
       {
        this.invokeBlockedTable();  
         //this.invokeTable(this.exteriorVal, this.interiorVal);
         //this.invokeBlockedTable();
         //this.vehicleCopySelection=null;
         //this.vehicleCopySelection.length=[];
       
         this.exteriorDropdown.length=[];
         this.interiorDropdown.length=[];
         this. vehicleLineTable=null;
         this.blockedvehicleCopySelection=null;
         this.blockedvehicleCopySelection.length=[];
        
         //this.invokeBlockedTable();
       }, err => { this.loading = false; });
   }
 
 
   //invoice
   invoice(rowIndex) {
     let floorPlan = this.proposalInfo.floorPlanDays;
     let specialInst = this.proposalInfo.specialInstructionDesc;  
     if (specialInst == null) {
       specialInst = "";
     }
     else {
       specialInst = this.proposalInfo.specialInstructionDesc;
     }
     var dealret = this.dealerCoderetrieval(this.dealerSelect);
     let vinDetailsVoList = [];
     this.cdsId = sessionStorage.getItem('loginId');
     let modDate;
     this.vehicleCopySelection.map(data => {
       vinDetailsVoList.push({
         "acctMgrId": this.cdsId,
         "aging": data.aging,
         "blockedDate": null,
         "exteriorColorCode": data.extColorCode,
         "exteriorColorDesc": data.extColorDesc,
         "interiorColorCode": data.intColorCode,
         "interiorColorDesc": data.intColorDesc,
         "status": data.vinStatus,
         "vinCode": data.vinCode
       })
     });
     let finalcopyVeh = {
       "dealerCode": dealret,
       "flrPlnDays": floorPlan,
       "splInstructions": specialInst,
       vinDetailsVoList
     }
     let copyVehUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/invoice-vins/' +  this.proposalKey + "/" +this.modelyearvin;
     this.RestcallService.ngOnInit();
     this.RestcallService.setQueryParams("bodyStyleKey", this.bodykeyvinval);
     this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
     this.RestcallService.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => 
       {
         this.invokeBlockedTable();
         this.invokeTable(this.exteriorVal, this.interiorVal);
         this.vehicleCopySelection=null;
         this.vehicleCopySelection.length=[];
         this.blockedvehicleCopySelection=null;
         this.blockedvehicleCopySelection.length=[];
       }, err => { this.loading = false; });
   }
 
 
 
 //invoice
 invoiceunblock(rowIndex) {
   let floorPlan = this.proposalInfo.floorPlanDays;
   let specialInst = this.proposalInfo.specialInstructionDesc;
   if (specialInst == null) {
     specialInst = "";
   }
   else {
     specialInst = this.proposalInfo.specialInstructionDesc;
   }
   var dealret = this.dealerCoderetrieval(this.dealerSelect);
   let vinDetailsVoList = [];
   this.cdsId = sessionStorage.getItem('loginId');
   let modDate;
   this.blockedvehicleCopySelection.map(data => {
     vinDetailsVoList.push({
       "acctMgrId": this.cdsId,
       "aging": data.vinAging,
       "blockedDate": data.processedTimeStamp,
       "exteriorColorCode": data.extColourCode,
       "exteriorColorDesc": data.extColourDesc,
       "interiorColorCode": data.intColourCode,
       "interiorColorDesc": data.intColourDesc,
       "status": data.vinStatus,
       "vinCode": data.vinCode
     })
   });
   let finalcopyVeh = {
     "dealerCode": dealret,
     "flrPlnDays": floorPlan,
     "splInstructions": specialInst,
     vinDetailsVoList
   }
   let copyVehUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/vin-allocation/invoice-blkd-vins/'+  this.proposalKey + "/" +this.modelyearvin;
   this.RestcallService.ngOnInit();
   this.RestcallService.setQueryParams("bodyStyleKey", this.bodykeyvinval);
   this.RestcallService.setQueryParams("catalogCode", this.catlogvincode);
   this.RestcallService.createData(copyVehUrl, JSON.stringify(finalcopyVeh)).subscribe(data => 
     {
       this.invokeBlockedTable();
      // this.invokeTable(this.exteriorVal, this.interiorVal);
      // this.vehicleCopySelection=null;
     //  this.vehicleCopySelection.length=[];
       this.blockedvehicleCopySelection=null;
       this.blockedvehicleCopySelection.length=[];
     }, err => { this.loading = false; });
 }
 
 
 
 
} 