import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerUnitMexicoComponent } from './per-unit-mexico.component';

describe('PerUnitMexicoComponent', () => {
  let component: PerUnitMexicoComponent;
  let fixture: ComponentFixture<PerUnitMexicoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerUnitMexicoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerUnitMexicoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
