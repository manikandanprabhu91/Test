import { Component, Input, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { RestcallService } from '../../../services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { SummaryandsubmitComponent } from '../summaryandsubmit/summaryandsubmit.component';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { Router } from 'src/testing/router-stubs';
import { Key } from 'protractor';

@Component({
  selector: 'per-unit-incentive',
  templateUrl: './per-unit-incentive.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class PerUnitIncentiveComponent {
  configUrl: string;
  screenData!: any;
  perUnitFormData: FormGroup;
  checkFormDifference: FormGroup;
  country: any;

  countRentalRepurchase: boolean;
  endYearLoop: any;
  enableEndYear: boolean;
  endYearSelect: number;
  autoEarlyCheck: any;
  yoySelected;
  yoyColor: any;
  yoyOptions: any;
  startPYear: number;
  yoymodelYear: any;
  yoyinp1: FormControl;
  yoyinp2: FormControl;
  yoyinp3: FormControl;

  aggregateDropdown: any;
  proposalAssignee: any;
  aggddSelected1: any;
  aggddSelected2: any;
  aggValues: any;
  aggAmount1: FormControl;
  aggAmount2: FormControl;


  volumeData: any;
  sellingDealer: any;
  paymentRouting: any;
  paymentOption: any;
  discountTier: any;
  tierCount: number = 0;
  addOptionDisplay: boolean;
  deleteAllDisplay: boolean;
  individualCheckOption;
  eachCheck: boolean;
  ddPrevState: string;
  mlvTotal: number;
  tierVolume: FormGroup;
  //Adding new vehicle
  newVehicleData: [];
  newmodelYeardropdown: any;
  newModelYearSelected: number;
  vehicleLineSelect: any;
  vehicleLinePopulate: any;
  bodyStylePopulate: any;
  bodyStyleSelect: any;
  addNewTextBox: any;
  editableRow: any;
  proposalYear: number;
  proposalVersion: number;
  finKey: number;
  proposalKey: number;
  yoyValues: any;
  loading: boolean;
  selectionArray: any;
  tierLevelValue: any;
  tierLevelError: any;
  tier1: FormControl;
  tier2: FormControl;
  tier3: FormControl;
  tier4: FormControl;
  tier5: FormControl;
  tier6: FormControl;
  editTier: any;
  editArray: any;
  tier1Val;
  tier2Val;
  tier3Val;
  tier4Val;
  tier5Val;
  tier6Val;
  tier1Array: any;
  opendialog: boolean;
  newVehicleLine: any;
  addnewVehArray: any;
  aeData: any;
  addTiers: any;
  addErrors: any;
  respHighlight: any;
  role: any;
  reportLevel: any;
  proposalStatus: any;
  nonFinancialEdit: any;
  perUnitAS: boolean;
  aggAS: boolean;
  yoyAS: boolean;
  vehicleTableAS: boolean;
  aggHighlight: any;
  aggHighDesc1: any;
  aggHighDesc2: any;
  aggHighAmt1: any;
  aggHighAmt2: any;
  edittier1Error: boolean;
  edittier2Error: boolean;
  edittier3Error: boolean;
  edittier4Error: boolean;
  edittier5Error: boolean;
  edittier6Error: boolean;
  editmlvError: boolean;
  editrepurError: boolean;
  tier1Error: boolean;
  tier2Error: boolean;
  tier3Error: boolean;
  tier4Error: boolean;
  tier5Error: boolean;
  tier6Error: boolean;
  mlvError: boolean;
  repurError: boolean;
  loginId = sessionStorage.getItem('loginId');
  propCdsId: any;
  showSave: boolean = true;
  showEdit: boolean = true;
  showDelete: boolean = true;
  bodyStyleKeyMap: any;
  modelYearMap: any;
  multiEditData: any;
  saveEvent: boolean = true;
  dblclickFlag: boolean = true;
  multiEditDataMap: any;
  maxLenError1: boolean;
  maxLenError2: boolean;
  spinnerLoad: boolean;
  @ViewChild('myListbox') multiSelectVariable;
  vehicleLineDataValidation: any;

  @Input() proposalArray: any;
  @ViewChild(SummaryandsubmitComponent) summary: SummaryandsubmitComponent;

  constructor(private RestcallService: RestcallService, private fb: FormBuilder, private route: ActivatedRoute, private router: Router, private dialog: MatDialog, private http: HttpClient) { }

  ngOnInit(): void {
    this.spinnerLoad = false;
    this.tier1 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.tier2 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.tier3 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.tier4 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.tier5 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.tier6 = new FormControl(null, [Validators.pattern("^[0-9]*$"), Validators.maxLength(5), Validators.max(99999), Validators.min(0)]);
    this.proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
    this.country = sessionStorage.getItem('countryCode');
    this.perUnitAS = false;
    this.aggAS = false;
    this.yoyAS = false;
    this.vehicleTableAS = false;
    this.opendialog = false;
    this.selectionArray = [];
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.loading = true;
    this.proposalKey = this.proposalArray[0];
    this.finKey = this.proposalArray[1];
    this.proposalYear = this.proposalArray[2];
    this.proposalVersion = this.proposalArray[3];
    this.proposalStatus = this.proposalArray[4];
    this.nonFinancialEdit = this.proposalArray[5];
    this.propCdsId = this.proposalArray[6];
    this.perUnitInit();
    this.aggregateInit();
    this.vehicleVolumeCall();
    this.aggHighDesc1 = false;
    this.aggHighDesc2 = false;
    this.aggHighAmt1 = false;
    this.aggHighAmt2 = false;
    // this.perUnitFormData = this.fb.group({
    //   letterMinQty: ['', [Validators.pattern("^[0-9]*$"), Validators.min(1)]],
    //   longTermDemoR:[''],
    //   multiYearDealFlag:[''],
    //   endYear:[0],
    //   paymentType:[''],
    //   priceProtectionLevelCd:[''],
    //   qfcFlag:[''],
    //   xplanRequiredFlag:[''],
    //   telematicsIndicatorFlg:['']
    // });
  }
  perUnitInit() {
    this.spinnerLoad = false;
    this.perUnitAS = false;
    this.yoyAS = false;

    this.sellingDealer = null;
    this.configUrl = "/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive/" + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('finKey', this.finKey);
    this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
    this.RestcallService.setQueryParams('proposalYrVer', this.proposalVersion);
    //  this.configUrl = "/perunitvalue";
    this.RestcallService.getData(this.configUrl).subscribe(respData => {
      this.mapvalues(respData);
    });

  }
  //Perunit map values
  mapvalues(respData) {
    this.spinnerLoad = false;

    this.screenData = respData;
    this.mlvTotal = 0;
    this.yoySelected = this.screenData.proposalDto.yoyCd;
    this.yoySelected != null ? this.yoyInit() : '';
    this.endYearLoop = [this.screenData.proposalDto.multiYearStartYear + 1, this.screenData.proposalDto.multiYearStartYear + 2,
    this.screenData.proposalDto.multiYearStartYear + 3, this.screenData.proposalDto.multiYearStartYear + 4];
    this.enableEndYear = this.screenData.proposalDto.multiYearDealFlag;
    //Related to vehicle Volume
    this.countRentalRepurchase = this.screenData.proposalDto.countRentalRepurchFlag;
    this.sellingDealer = this.screenData.proposalDto.sellingDealerFlag;
    this.perUnitFormData = this.fb.group({
      letterMinQty: [this.screenData.proposalDto.letterMinQty, [Validators.pattern("^[0-9]*$"), Validators.min(1)]],
      longTermDemoR: [this.screenData.proposalDto.longTermDemoR],
      multiYearDealFlag: [this.screenData.proposalDto.multiYearDealFlag],
      endYear: [this.endYearLoop.includes(this.screenData.proposalDto.multiYearEndYear) ? this.screenData.proposalDto.multiYearEndYear : 0],
      paymentType: [this.screenData.proposalDto.paymentType],
      priceProtectionLevelCd: [this.screenData.proposalDto.priceProtectionLevelCd],
      qfcFlag: [this.screenData.proposalDto.qfcFlag],
      xplanRequiredFlag: [this.screenData.proposalDto.xplanRequiredFlag],
      telematicsIndicatorFlg: [this.screenData.proposalDto.telematicsIndicatorFlg]
    });
    // this.perUnitFormData.setValue({
    //   letterMinQty: this.screenData.proposalDto.letterMinQty,
    //   longTermDemoR: this.screenData.proposalDto.longTermDemoR,
    //   multiYearDealFlag: this.screenData.proposalDto.multiYearDealFlag,
    //   endYear: this.endYearLoop.includes(this.screenData.proposalDto.multiYearEndYear) ? this.screenData.proposalDto.multiYearEndYear : 0,
    //   paymentType: this.screenData.proposalDto.paymentType,
    //   priceProtectionLevelCd: this.screenData.proposalDto.priceProtectionLevelCd,
    //   qfcFlag: this.screenData.proposalDto.qfcFlag,
    //   xplanRequiredFlag: this.screenData.proposalDto.xplanRequiredFlag,
    //   telematicsIndicatorFlg:this.screenData.proposalDto.telematicsIndicatorFlg
    // });
    this.perUnitFormData.valueChanges.subscribe(data => {
      this.perUnitFormData.invalid ? this.perUnitAS = false : this.perUnitAS = true
    })

  }
  yoyInit() {
    this.spinnerLoad = false;

    this.yoyinp1 = new FormControl('', [Validators.pattern("^[0-9]+(.[0-9]{0,2})?$"), Validators.maxLength(5), Validators.max(100), Validators.min(0)]);
    this.yoyinp2 = new FormControl('', [Validators.pattern("^[0-9]+(.[0-9]{0,2})?$"), Validators.maxLength(5), Validators.max(100), Validators.min(0)]);
    this.yoyinp3 = new FormControl('', [Validators.pattern("^[0-9]+(.[0-9]{0,2})?$"), Validators.maxLength(5), Validators.max(100), Validators.min(0)]);
    this.yoyinp1.setValue(0);
    this.yoyinp2.setValue(0);
    this.yoyinp3.setValue(0);
    this.yoyValues = [];
    this.yoyColor = [false, false, false];
    this.startPYear = this.proposalYear;
    this.yoymodelYear = [this.startPYear + 1, this.startPYear + 2, this.startPYear + 3];
    this.yoyOptions = [{ yoyKey: 'NON', yoyDesc: "None" }, { yoyKey: 'ITI', yoyDesc: "Intro to Intro" }, { yoyKey: 'FTI', yoyDesc: "Final To Intro" }];

    if (this.yoySelected != 'NON') {
      let yoyCall = "/fleet-proposal-bonuses/bonuses/v1/price-protection-year-over-year";
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams('finKey', this.finKey);
      this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
      this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
      this.RestcallService.setQueryParams('version', this.proposalVersion);
      this.RestcallService.setQueryParams('yoyCode', this.yoySelected);
      // let yoyCall = "/yoy";
      this.RestcallService.getData(yoyCall).subscribe(data => {
        data != null && data.yoyResponseList ? this.yoyValues = data.yoyResponseList : this.yoyValues = [];
        data != null && data.yoyColorDifferenceDtoList ? this.yoyColor = data.yoyColorDifferenceDtoList : this.yoyColor = [false, false, false];
        if (this.yoyValues != null || this.yoyValues != []) {
          this.yoyValues.map(data => {
            if (Number(data.modelYear) == Number(this.yoymodelYear[0])) {
              this.yoyinp1.setValue(data.percentageIncrease);
            } else if (Number(data.modelYear) == Number(this.yoymodelYear[1])) {
              this.yoyinp2.setValue(data.percentageIncrease);
            } else if (Number(data.modelYear) == Number(this.yoymodelYear[2])) {
              this.yoyinp3.setValue(data.percentageIncrease);
            }
          });
          this.yoyColor.map(data => {
            if (Number(data.modelYear) == Number(this.yoymodelYear[0])) {
              if (data.percentageIncrease == true) {
                this.yoyColor[0] = true;
              }
            } else if (Number(data.modelYear) == Number(this.yoymodelYear[1])) {
              if (data.percentageIncrease == true) {
                this.yoyColor[1] = true;
              }
            } else if (Number(data.modelYear) == Number(this.yoymodelYear[2])) {
              if (data.percentageIncrease == true) {
                this.yoyColor[2] = true;
              }
            }
          });
        }
        this.yoyinp1.valueChanges.subscribe(data => {
          this.yoyinp1.invalid ? this.yoyAS = false : this.yoyAS = true
        });
        this.yoyinp2.valueChanges.subscribe(data => {
          this.yoyinp2.invalid ? this.yoyAS = false : this.yoyAS = true
        });
        this.yoyinp3.valueChanges.subscribe(data => {
          this.yoyinp3.invalid ? this.yoyAS = false : this.yoyAS = true
        });
      });

    }


  }
  aggregateInit() {
    // Aggregate Incentive
    this.spinnerLoad = false;

    this.aggAS = false;
    this.aggHighDesc1 = false;
    this.aggHighDesc2 = false;
    this.aggHighAmt1 = false;
    this.aggHighAmt2 = false;
    this.aggddSelected1 = "0";
    this.aggddSelected2 = "0";
    this.maxLenError1 = false;
    this.maxLenError2 = false;


    this.aggAmount1 = new FormControl(0, [Validators.pattern("^[0-9,]*$"), Validators.maxLength(10)]);
    this.aggAmount2 = new FormControl(0, [Validators.pattern("^[0-9,]*$"), Validators.maxLength(10)]);

    let aggregatedropdownUrl = '/fleet-proposal-bonuses/bonuses/v1/aggregate-incentive-type';
    this.RestcallService.ngOnInit();
    // let aggregatedropdownUrl = '/aggregate';
    this.RestcallService.getData(aggregatedropdownUrl).subscribe(ddVal => {
      ddVal != null ? this.aggregateDropdown = ddVal.aggregateIncentiveTypes : this.aggregateDropdown = null;
    });
    let aggFetchUrl = '/fleet-proposal-bonuses/bonuses/v1/aggregate-incentive-definition';
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("version", this.proposalVersion);
    // let aggFetchUrl = '/aggregateValue';
    this.RestcallService.getData(aggFetchUrl).subscribe(data => {
      data != null ? this.aggValues = data.aggregateIncentiveResponses : this.aggValues = null;
      data != null ? this.aggHighlight = data.aggregateIncentiveColorDifferenceDtoList : this.aggHighlight = null;

      //Hightlight
      if (this.aggHighlight != null && this.aggHighlight.length > 0) {
        this.aggHighlight.map((data, index) => {
          if (index == 0) {
            this.aggHighDesc1 = data.aggregateIncentiveCodeFlag;
            this.aggHighAmt1 = data.aggregateIncentiveAmountFlag;
          }
          if (index == 1) {
            this.aggHighDesc2 = data.aggregateIncentiveCodeFlag;
            this.aggHighAmt2 = data.aggregateIncentiveAmountFlag;
          }
        });
      }
      if (this.aggValues != null && this.aggValues.length >= 1) {
        this.aggddSelected1 = this.aggValues[0].aggregateIncentiveCode;
        this.aggAmount1.setValue(this.aggValues[0].aggregateIncentiveAmount);
        this.aggAmount1.value > 0 ? this.aggAmount1.setValue(this.aggAmount1.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")) : '';

        if (this.aggValues != null && this.aggValues.length >= 2) {
          this.aggddSelected2 = this.aggValues[1].aggregateIncentiveCode;
          this.aggAmount2.setValue(this.aggValues[1].aggregateIncentiveAmount);
          this.aggAmount2.value > 0 ? this.aggAmount2.setValue(this.aggAmount2.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")) : '';

        }
      } else if (this.aggValues == null || this.aggValues.length == 0) {
        this.aggddSelected1 = '0';
        this.aggddSelected2 = '0';
        this.aggAmount1.setValue(0);
        this.aggAmount2.setValue(0);
      }
      this.aggAmount1.valueChanges.subscribe(data => {
        this.aggAmount1.invalid ? this.aggAS = false : this.aggAS = true
      });
      this.aggAmount2.valueChanges.subscribe(data => {
        this.aggAmount2.invalid ? this.aggAS = false : this.aggAS = true
      });
    });
  }


  //Setting Validators while Aggegate dropdown selected
  setaggAmountOneValid(passParam) {
    this.aggAS = true;
    if (passParam == 'aggAmount1') {
      (this.aggAmount1.value > 0 && this.aggAmount1.value.length > 8) ? this.maxLenError1 = true : this.maxLenError1 = false
      if (this.aggAmount1.value == "" || this.aggAmount1.value == 0 || this.aggAmount1.value == null) {
        this.aggddSelected1 = '0';
        this.aggAmount1.setValue(0);
      } else {
        this.aggAmount1.setValue(this.aggAmount1.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
      }
    }
    if (this.aggddSelected1 != '0') {
      this.aggAmount1.setValidators([Validators.pattern("^[0-9,]*$"), Validators.required, Validators.min(1), Validators.maxLength(10)]);
      this.aggAmount1.updateValueAndValidity();
    } else {
      this.aggAmount1.setValue(0);
      this.maxLenError1 = false;
      this.aggAmount1.setValidators([Validators.pattern("^[0-9,]*$"), Validators.maxLength(10)]);
      this.aggAmount1.updateValueAndValidity();
    }
  }
  setaggAmountTwoValid(passParam) {
    this.aggAS = true;
    if (passParam == 'aggAmount2') {
      (this.aggAmount2.value > 0 && this.aggAmount2.value.length) > 8 ? this.maxLenError2 = true : this.maxLenError2 = false

      if (this.aggAmount2.value == "" || this.aggAmount2.value == 0 || this.aggAmount2.value == null) {
        this.aggddSelected2 = '0'
        this.aggAmount2.setValue(0);
      }
      else {
        this.aggAmount2.setValue(this.aggAmount2.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
      }
    }
    if (this.aggddSelected2 != '0') {
      this.aggAmount2.setValidators([Validators.pattern("^[0-9,]*$"), Validators.required, Validators.min(1), Validators.maxLength(10)]);
      // this.aggAmount2.setValidators([Validators.pattern("^[0-9]{1,3}(,[0-9]{3})*(([\\.,]{1}[0-9]*)|())$"), Validators.required, Validators.min(1), Validators.maxLength(10)]);
      this.aggAmount2.updateValueAndValidity();
    } else {
      this.aggAmount2.setValue(0);
      this.maxLenError2 = false;
      this.aggAmount2.setValidators([Validators.pattern("^[0-9,]*$"), Validators.maxLength(10)]);
      this.aggAmount2.updateValueAndValidity();
    }
  }

  //CommonSave
  saveChanges() {
    this.spinnerLoad = true;

    this.aggregateSave();
    //Perunit form data
    this.perUnitFormData.get('multiYearDealFlag').value == false ? this.perUnitFormData.patchValue({ endYear: 0 }) : '';
    let saveArray = {
      "letterMinQty": this.perUnitFormData.get('letterMinQty').value,
      "longTermDemoR": this.perUnitFormData.get('longTermDemoR').value,
      "multiYearDealFlag": this.perUnitFormData.get('multiYearDealFlag').value,
      "multiYearEndYear": this.perUnitFormData.get('endYear').value,
      "paymentType": this.perUnitFormData.get('paymentType').value,
      "priceProtectionLevelCd": this.perUnitFormData.get('priceProtectionLevelCd').value,
      "proposalKey": this.proposalKey,
      "qfcFlag": this.perUnitFormData.get('qfcFlag').value,
      "xplanRequiredFlag": this.perUnitFormData.get('xplanRequiredFlag').value,
      "multiYearStartYear": this.screenData.proposalDto.multiYearStartYear,
      "telematicsIndicatorFlag": this.perUnitFormData.get('telematicsIndicatorFlg').value
    };
    let saveUrl = '/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
    this.RestcallService.updateData(saveUrl, JSON.stringify(saveArray)).subscribe(respData => this.yoySave(),
    err=> this.spinnerLoad = false);
    //remove below comment
    //this.reloadfunction();
    //

  }
  reloadfunction() {
    if (this.country == 'USA') {
      this.router.navigate(['/accounts/proposal'], { queryParams: { proposalAssignee: this.proposalAssignee, proposalKey: this.proposalKey } })
        .then(() => {
          window.location.reload();
        })

    }

  }

  //Yoy Save
  yoySave() {
    if (this.yoySelected == 'NON') {
      this.yoyinp1.setValue(0);
      this.yoyinp2.setValue(0);
      this.yoyinp3.setValue(0);
    }
    let yoyUpdate = {
      "proposalKey": this.proposalKey,
      "yoYRequestList": [
        {
          "modelYear": this.yoymodelYear[0],
          "percentageIncrease": Number(this.yoyinp1.value)
        },
        {
          "modelYear": this.yoymodelYear[1],
          "percentageIncrease": Number(this.yoyinp2.value)
        },
        {
          "modelYear": this.yoymodelYear[2],
          "percentageIncrease": Number(this.yoyinp3.value)
        }
      ],
      "yoyCd": this.yoySelected
    };
    let yoyCall = "/fleet-proposal-orchestrator/proposals/v1/yoycode";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
    this.RestcallService.setQueryParams('yoyCode', this.yoySelected);
    this.RestcallService.updateData(yoyCall, JSON.stringify(yoyUpdate)).subscribe(data => this.perUnitInit() ,
    err=> this.spinnerLoad = false);
  }
  //LengthCheck
  maxLenCheck(field) {
    if (field == 'aggAmount1') {
      this.aggAmount1.value.length >= 8 ? this.maxLenError1 = true : this.maxLenError1 = false;
    }
    if (field == 'aggAmount2') {
      this.aggAmount2.value.length >= 8 ? this.maxLenError2 = true : this.maxLenError2 = false;
    }
  }
  //focus
  onInputFocus(field) {
    if (field == 'aggAmount1') {
      this.aggAmount1.value.length > 3 ? this.aggAmount1.setValue(this.aggAmount1.value.replaceAll(',', '')) : '';
    }
    if (field == 'aggAmount2') {
      this.aggAmount2.value.length > 3 ? this.aggAmount2.setValue(this.aggAmount2.value.replaceAll(',', '')) : '';
    }
  }
  //Aggregate Save
  aggregateSave() {

    this.aggAmount1.value.length > 3 ? this.aggAmount1.setValue(this.aggAmount1.value.replaceAll(',', '')) : '';
    this.aggAmount2.value.length > 3 ? this.aggAmount2.setValue(this.aggAmount2.value.replaceAll(',', '')) : '';

    if (this.aggValues == null && Number(this.aggAmount1.value) == 0 && Number(this.aggAmount2.value) == 0) {

    } else {
      let aggArray = [];

      if (this.aggValues == null || this.aggValues.length == 0) {
        if (this.aggddSelected1 != '0') {
          aggArray.push({
            "aggregateIncentiveCode": this.aggddSelected1,
            "aggregateIncentiveAmount": Number(this.aggAmount1.value)
          })
        }
        if (this.aggddSelected2 != '0') {
          aggArray.push({
            "aggregateIncentiveCode": this.aggddSelected2,
            "aggregateIncentiveAmount": Number(this.aggAmount2.value)
          })
        }
      } else if (this.aggValues != null || this.aggValues.length > 0) {

        if (this.aggValues.length >= 1) {

          if (this.aggValues[0].aggregateIncentiveCode == this.aggddSelected1) {
            if (this.aggValues[0].aggregateIncentiveAmount != Number(this.aggAmount1.value)) {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected1,
                "aggregateIncentiveAmount": Number(this.aggAmount1.value)
              })
            }
          }
          else if (this.aggValues[0].aggregateIncentiveCode == this.aggddSelected2) {
            if (this.aggValues[0].aggregateIncentiveAmount != Number(this.aggAmount2.value)) {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected2,
                "aggregateIncentiveAmount": Number(this.aggAmount2.value)
              })
            }
          }
          else if (this.aggValues[0].aggregateIncentiveCode != this.aggddSelected1 && this.aggValues[0].aggregateIncentiveCode != this.aggddSelected2) {
            if (this.aggddSelected1 != '0') {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected1,
                "aggregateIncentiveAmount": Number(this.aggAmount1.value)
              })
            }
            aggArray.push({
              "aggregateIncentiveCode": this.aggValues[0].aggregateIncentiveCode,
              "aggregateIncentiveAmount": 0
            })
          }
          if (this.aggValues.length == 1) {

            if (this.aggddSelected2 != '0') {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected2,
                "aggregateIncentiveAmount": Number(this.aggAmount2.value)
              })
            }

          }
        } if (this.aggValues.length >= 2) {
          if (this.aggValues[1].aggregateIncentiveCode == this.aggddSelected1) {
            if (this.aggValues[1].aggregateIncentiveAmount != Number(this.aggAmount1.value)) {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected1,
                "aggregateIncentiveAmount": Number(this.aggAmount1.value)
              })
            }
          }
          else if (this.aggValues[1].aggregateIncentiveCode == this.aggddSelected2) {
            if (this.aggValues[1].aggregateIncentiveAmount != Number(this.aggAmount2.value)) {
              aggArray.push({
                "aggregateIncentiveCode": this.aggddSelected2,
                "aggregateIncentiveAmount": Number(this.aggAmount2.value)
              })
            }
          }
          else if (this.aggValues[1].aggregateIncentiveCode != this.aggddSelected1 && this.aggValues[1].aggregateIncentiveCode != this.aggddSelected2) {
            if (this.aggValues.length >= 2) {
              if (this.aggddSelected2 != '0') {
                aggArray.push({
                  "aggregateIncentiveCode": this.aggddSelected2,
                  "aggregateIncentiveAmount": Number(this.aggAmount2.value)
                })
              }
            }
            aggArray.push({
              "aggregateIncentiveCode": this.aggValues[1].aggregateIncentiveCode,
              "aggregateIncentiveAmount": 0
            })
          }
        }
      }

      if (aggArray.length > 0) {
        let saveAgg = {
          "aggregateIncentiveDefinitions": aggArray
        }
        console.log(JSON.stringify(saveAgg));
        let aggSaveUrl = '/fleet-proposal-bonuses/bonuses/v1/aggregate-incentive-definition';
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
        this.RestcallService.createData(aggSaveUrl, JSON.stringify(saveAgg)).subscribe(data => { this.aggregateInit() },
        err=> this.spinnerLoad = false);
      }
    }
  }
  cancelChanges() {
    this.spinnerLoad = false
    this.ngOnInit();
  }
  endYearAction() {
    this.enableEndYear = this.perUnitFormData.get('multiYearDealFlag').value;
  }
  //Aggregate and YOY
  yoyChange(event) {
    this.yoySelected = event.value;
  }
  // vehicle volume Data
  vehicleVolumeCall() {
    this.spinnerLoad = false;

    this.vehicleTableAS = false;
    this.edittier1Error = false;
    this.edittier2Error = false;
    this.edittier3Error = false;
    this.edittier4Error = false;
    this.edittier5Error = false;
    this.edittier6Error = false;
    this.editmlvError = false;
    this.tier1Error = false;
    this.tier2Error = false;
    this.tier3Error = false;
    this.tier4Error = false;
    this.tier5Error = false;
    this.tier6Error = false;
    this.mlvError = false;
    this.bodyStylePopulate = [];
    this.bodyStyleSelect = [];
    this.vehicleLineSelect = 'select';
    this.tierCount = null;
    this.ddPrevState = null;
    this.addnewVehArray = [];
    this.addTiers = [];
    this.newVehicleLine = [];
    this.opendialog = false;
    this.tier1Array = []
    this.editArray = [];
    this.editTier = [];
    this.tierLevelError = null;
    this.tierLevelValue = [];
    this.selectionArray = [];
    this.editableRow = [];
    this.addOptionDisplay = false;
    this.deleteAllDisplay = false;
    this.paymentOption = ["A", "B", "C", "D"];
    if (this.dblclickFlag == true) {
      this.multiEditData = [];
    }
    let tableUrl = "/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/" + this.proposalKey;
    this.RestcallService.ngOnInit();
    // let tableUrl = "/vehicleVolumeActual";
    this.RestcallService.getData(tableUrl).subscribe(respData => this.mapVolume(respData), err => this.mapVolume(null));
  }
  mapVolume(respData) {
    this.spinnerLoad = false;

    if (respData == null) {
      this.respHighlight = null;
      this.discountTier = [];
      this.volumeData = [];
    }
    else if (respData != null) {
      this.respHighlight = respData;
      this.discountTier = respData.tierVolumeList;
      this.volumeData = respData.vehicleDetailsVos;
      this.loading = false;

      if (this.volumeData) {
        this.vehicleLineDataValidation = [];
        this.mlvTotal = this.volumeData.map(val => Number(val.vehMlv)).reduce((curr, prev) => Number(curr) + Number(prev), 0);
        this.volumeData.map(tierData => {
          if (tierData.tierIncentiveToDealer == "Y") {
            this.tierCount++;
          }
          let amount = tierData.tierIncentives[0].tierInctvAmount;
          let key = tierData.pvikey;
          this.vehicleLineDataValidation.push({ 'key': key, 'value': amount });
        });
        if(this.vehicleLineDataValidation != []) {
          this.RestcallService.vehicleLineDataValidationMap = new Map(this.vehicleLineDataValidation.map(i => [i.key, i.value]));
        } else {
          this.RestcallService.vehicleLineDataValidationMap = new Map();
        }
        if (this.sellingDealer != null) {

          this.sellingDealer == true ? this.paymentRouting = this.paymentOption[0] :
            this.tierCount == this.volumeData.length ? this.paymentRouting = this.paymentOption[1] :
              this.tierCount == 0 ? this.paymentRouting = this.paymentOption[3] :
                this.tierCount > 0 && this.tierCount != this.volumeData.length ? this.paymentRouting = this.paymentOption[2] : this.paymentRouting = this.paymentOption[3];

          // this.summary.ssPaymentRouting = this.paymentRouting;
          sessionStorage.setItem('paymentRouting', this.paymentRouting);
        }
      }
      this.tier1Val = this.discountTier != null && this.discountTier.length >= 1 ? this.discountTier[0].tierVolume : 0;
      this.tier2Val = this.discountTier != null && this.discountTier.length >= 2 ? this.discountTier[1].tierVolume : 0;
      this.tier3Val = this.discountTier != null && this.discountTier.length >= 3 ? this.discountTier[2].tierVolume : 0;
      this.tier4Val = this.discountTier != null && this.discountTier.length >= 4 ? this.discountTier[3].tierVolume : 0;
      this.tier5Val = this.discountTier != null && this.discountTier.length >= 5 ? this.discountTier[4].tierVolume : 0;
      this.tier6Val = this.discountTier != null && this.discountTier.length >= 6 ? this.discountTier[5].tierVolume : 0;

      this.tier1.setValue(this.tier1Val);
      this.tier2.setValue(this.tier2Val);
      this.tier3.setValue(this.tier3Val);
      this.tier4.setValue(this.tier4Val);
      this.tier5.setValue(this.tier5Val);
      this.tier6.setValue(this.tier6Val);

      // this.tier1.valueChanges.subscribe(data =>{
      //   this.tier1.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
      // this.tier2.valueChanges.subscribe(data =>{
      //   this.tier2.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
      // this.tier3.valueChanges.subscribe(data =>{
      //   this.tier3.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
      // this.tier4.valueChanges.subscribe(data =>{
      //   this.tier4.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
      // this.tier5.valueChanges.subscribe(data =>{
      //   this.tier5.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
      // this.tier6.valueChanges.subscribe(data =>{
      //   this.tier6.invalid  ? this.vehicleTableAS = false : this.vehicleTableAS=true;
      // });
    }

  }
  //Payment Routing and Count Rental auto Save
  speSave() {
    this.spinnerLoad = true;

    let speSave = {
      "letterMinQty": this.perUnitFormData.get('letterMinQty').value,
      "proposalKey": this.proposalKey,
      "sellingDealerFlag": this.paymentRouting == 'A' ? true : false,
      "countRentalRepurchFlag": this.countRentalRepurchase,
    };
    let saveUrl = '/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
    this.RestcallService.updateData(saveUrl, JSON.stringify(speSave)).subscribe(respData => {
      this.perUnitInit();
    },
    err=> this.spinnerLoad = false);
  }

  rowSelect() {
    this.selectionArray.length > 0 ? this.deleteAllDisplay = true : this.deleteAllDisplay = false;
  }

  rowUnSelect() {
    this.selectionArray.length == 0 ? this.deleteAllDisplay = false : this.deleteAllDisplay = true;
  }

  multiDelete() {
    this.spinnerLoad = false;

    const dialogRef = this.dialog.open(VehicleDeleteConfirm, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'delete') {
        let deleteArray = [];
        if (this.selectionArray.length > 0) {
          this.selectionArray.map(data => {
            deleteArray.push(data.pvikey);
          })
          let deleteVehicleUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey;
          this.RestcallService.ngOnInit();
          this.RestcallService.updateData(deleteVehicleUrl, deleteArray).subscribe(data => this.ngOnInit(),
          err=> this.spinnerLoad = false);
        }
      }
    });
  }
  tierRest(tier) {
    tier == 1 ? this.tier1.setValue(this.tier1Val) : '';
    tier == 2 ? this.tier2.setValue(this.tier2Val) : '';
    tier == 3 ? this.tier3.setValue(this.tier3Val) : '';
    tier == 4 ? this.tier4.setValue(this.tier4Val) : '';
    tier == 5 ? this.tier5.setValue(this.tier5Val) : '';
    tier == 6 ? this.tier6.setValue(this.tier6Val) : '';
  }
  tierLevelChange(tier, event) {
    if (isNaN(event.target.value) || Number(event.target.value) >= 100000) {

    } else {
      let successorTierExist;
      let currentTierExist;
      let preceedTierExist;
      successorTierExist = false;
      currentTierExist = false;
      preceedTierExist = false;
      this.discountTier.map(data => {
        if (data.tierLevel == tier - 1) {
          preceedTierExist = true;
        }
        if (data.tierLevel == tier + 1) {
          successorTierExist = true;
        }
        if (data.tierLevel == tier) {
          currentTierExist = true;
        }
      });

      if (event.target.value == '' || Number(event.target.value) == 0) {
        if (tier == 1) {
          this.RestcallService.statusMessage(417, "The tier 1 volume must be 1 or larger.");
          this.tierRest(tier);
        }
        else if (currentTierExist == false && tier != 1) {
          this.tierRest(tier);
        } else if (currentTierExist == true && tier != 1) {
          if (successorTierExist == true) {
            this.RestcallService.statusMessage(417, "Please delete successor tiers before deleting Tier " + tier);
            this.tierRest(tier);
          } else if (successorTierExist == false) {
            const dialogRef = this.dialog.open(TierDelete, { width: '300px' });
            dialogRef.afterClosed().subscribe(data => {
              if (data == 'delete') {
                let tierDelete = "/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/" + this.proposalKey + '/' + tier;
                this.RestcallService.ngOnInit();
                this.RestcallService.setQueryParams("tierLevel", tier);
                this.RestcallService.deleteData(tierDelete).subscribe(data => { this.vehicleVolumeCall() });
              } else {
                this.tierRest(tier);
              }
            });
          }
        }
      }
      //Tier volume > 0 or not null
      else if (Number(event.target.value) > 0) {
        if (tier == 1 && this.perUnitFormData.get('paymentType').value == 'O') {
          this.RestcallService.statusMessage(417, "Tier1 volume must be 1 and cannot be changed unless the payment option is changed from OFF-Invoice to something else.");
          this.tierRest(tier);
        } else if (tier == 1 && this.perUnitFormData.get('paymentType').value != 'O') {
          if (successorTierExist == false) {
            let tierArray = {};
            let changeTier = [];
            const dialogRef = this.dialog.open(TierChange, { width: '300px', data: [{}] });
            dialogRef.afterClosed().subscribe(data => {
              if (data == 'change') {
                this.volumeData.map(tab => {
                  tab['tierIncentives'].map(inc => {
                    if (inc.tierLevel == tier) {
                      changeTier.push({
                        "pviKey": inc.pviKey,
                        "tierInctvAmount": inc.tierInctvAmount,
                        "tierLevel": inc.tierLevel
                      });
                    }
                  })
                });
                tierArray = {
                  "tierIncentives": changeTier,
                  "tierVolume": Number(event.target.value)
                }
                let tierChangeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey + '/' + tier;
                this.RestcallService.ngOnInit();
                this.RestcallService.updateData(tierChangeUrl, JSON.stringify(tierArray)).subscribe(data => this.vehicleVolumeCall());
              } else {
                this.tierRest(tier);
              }
            });
          } else if (successorTierExist == true) {
            let successorTierCheck = false;
            this.discountTier.map(data => {
              if (data.tierLevel == tier + 1) {
                if (Number(event.target.value) >= data.tierVolume) {
                  this.RestcallService.statusMessage(417, "Tier " + tier + " should be less than Tier " + data.tierLevel);
                  successorTierCheck = true;
                  this.tierRest(tier);
                }
              }
            });
            if (successorTierCheck == false) {
              let tierArray = {};
              let changeTier = [];
              const dialogRef = this.dialog.open(TierChange, { width: '300px', data: [{}] });
              dialogRef.afterClosed().subscribe(data => {
                if (data == 'change') {
                  this.volumeData.map(tab => {
                    tab['tierIncentives'].map(inc => {
                      if (inc.tierLevel == tier) {
                        changeTier.push({
                          "pviKey": inc.pviKey,
                          "tierInctvAmount": inc.tierInctvAmount,
                          "tierLevel": inc.tierLevel
                        });
                      }
                    })
                  });
                  tierArray = {
                    "tierIncentives": changeTier,
                    "tierVolume": Number(event.target.value)
                  }

                  let tierChangeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey + '/' + tier;
                  this.RestcallService.ngOnInit();
                  this.RestcallService.updateData(tierChangeUrl, JSON.stringify(tierArray)).subscribe(data => this.vehicleVolumeCall());
                } else {
                  this.tierRest(tier);
                }
              });
            }

          }
        } else if (tier != 1 && currentTierExist == false) {
          if (preceedTierExist == false) {
            this.RestcallService.statusMessage(417, "Please fill value for the Tier-" + (tier - 1) + " first");
            this.tierRest(tier);
          } else {
            let preceedTierValCheck;
            preceedTierValCheck = false
            this.discountTier.map(data => {
              if (data.tierLevel == tier - 1) {
                if (Number(event.target.value) <= data.tierVolume) {
                  this.RestcallService.statusMessage(417, "Tier " + tier + " should be greater than Tier " + data.tierLevel);
                  preceedTierValCheck = true;
                  this.tierRest(tier);
                }
              }
            });
            if (preceedTierValCheck == false) {
              let tierArray = {};
              let copyTier = [];
              const dialogRef = this.dialog.open(CopyTier, { width: '300px' });
              dialogRef.afterClosed().subscribe(data => {
                if (data == 'copy') {
                  this.volumeData.map(tab => {
                    tab['tierIncentives'].map(inc => {
                      if (inc.tierLevel == tier - 1) {
                        copyTier.push({
                          "pviKey": inc.pviKey,
                          "tierInctvAmount": inc.tierInctvAmount,
                          "tierLevel": inc.tierLevel
                        });
                      }
                    })
                  });
                } else {
                  this.volumeData.map(tab => {
                    tab['tierIncentives'].map(inc => {
                      if (inc.tierLevel == tier - 1) {
                        copyTier.push({
                          "pviKey": inc.pviKey,
                          "tierInctvAmount": 0,
                          "tierLevel": inc.tierLevel
                        });
                      }
                    })
                  });
                }
                tierArray = {
                  "tierIncentives": copyTier,
                  "tierVolume": Number(event.target.value)
                }
                let tierChangeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey + '/' + tier;
                this.RestcallService.ngOnInit();
                this.RestcallService.updateData(tierChangeUrl, JSON.stringify(tierArray)).subscribe(data => this.vehicleVolumeCall());
              });
            }

          }
        }
        else if (tier != 1 && currentTierExist == true) {
          let condCheck;
          condCheck = 0;
          if (preceedTierExist == false) {
            this.RestcallService.statusMessage(417, "Please fill value for the Tier-" + (tier - 1) + " first");
            condCheck = 1;
            this.tierRest(tier);
          } if (preceedTierExist == true) {
            this.discountTier.map(data => {
              if (data.tierLevel == tier - 1) {
                if (Number(event.target.value) <= data.tierVolume) {
                  this.RestcallService.statusMessage(417, "Tier " + tier + " should be greater than Tier " + data.tierLevel);
                  condCheck = 2;
                  this.tierRest(tier);
                }
              }
            });
          } if (successorTierExist == true) {
            this.discountTier.map(data => {
              if (data.tierLevel == tier + 1) {
                if (Number(event.target.value) >= data.tierVolume) {
                  this.RestcallService.statusMessage(417, "Tier " + tier + " should be less than Tier " + data.tierLevel);
                  condCheck = 3;
                  this.tierRest(tier);
                }
              }
            });
          }
          if (condCheck == 0) {
            let tierArray = {};
            let changeTier = [];
            const dialogRef = this.dialog.open(TierChange, { width: '300px', data: [{}] });
            dialogRef.afterClosed().subscribe(data => {
              if (data == 'change') {
                this.volumeData.map(tab => {
                  tab['tierIncentives'].map(inc => {
                    if (inc.tierLevel == tier) {
                      changeTier.push({
                        "pviKey": inc.pviKey,
                        "tierInctvAmount": inc.tierInctvAmount,
                        "tierLevel": inc.tierLevel
                      });
                    }
                  })
                });
                tierArray = {
                  "tierIncentives": changeTier,
                  "tierVolume": Number(event.target.value)
                }
                let tierChangeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey + '/' + tier;
                this.RestcallService.ngOnInit();
                this.RestcallService.updateData(tierChangeUrl, JSON.stringify(tierArray)).subscribe(data => this.vehicleVolumeCall());
              } else {
                this.tierRest(tier);
              }

            });
          }
        }
      }
    }
  }

  ondblclick(pvi) {

    if (this.proposalStatus != "NEW" && (this.proposalStatus != "REV" ? true : this.reportLevel == 6 ? false : true) || this.role == "ADM") { }
    else {
      this.dblclickFlag = false;
      this.selectionArray = [];
      let selectDuplicate;
      selectDuplicate = false;
      this.volumeData.map(data => {
        if (data.pvikey == pvi) {
          if (this.selectionArray.length > 0) {
            this.selectionArray.map(arr => {
              if (arr.pvikey == data.pviKey) {
                selectDuplicate = true;
              }
            });
          }
          if (selectDuplicate == false) {

            this.selectionArray.push(data);
            this.deleteAllDisplay = true;
            this.multiEdit();
          }
        }
      });
    }
  }
  multiEdit() {
    this.editArray = [];
    let editDuplicate;
    editDuplicate = false;
    let tierAmount = [];
    if (this.selectionArray.length > 0) {
      this.selectionArray.map(data => {
        tierAmount = [];
        this.editableRow.push(data.pvikey);
        this.volumeData.map(vol => {
          if (vol.pvikey == data.pvikey && vol.bodystylekey == vol.bodystylekey) {
            vol.tierIncentives.map(inc => {
              tierAmount.push({
                "pviKey": vol.pvikey,
                "tierInctvAmount": inc.tierInctvAmount,
                "tierLevel": inc.tierLevel
              });
            });
          }
        });
        if (this.editArray.length > 0) {
          this.editArray.map(dc => {
            if (dc.pvikey == data.pvikey) {
              editDuplicate = true;
            }
          })
        }
        if (editDuplicate == false) {
          this.editArray.push({
            "bodystylekey": data.bodystylekey,
            "pvikey": data.pvikey,
            "repurchaseQty": data.repurchaseQty,
            "tierIncentiveToDealer": data.tierIncentiveToDealer,
            "tierIncentives": tierAmount,
            "vehMlv": data.vehMlv
          });
          this.editArray.map(data => {
            this.multiEditDataMap = new Map(this.multiEditData.map(i => [i.pvikey, i]));
            if (!this.multiEditDataMap.get(data.pvikey)) {
              this.multiEditData.push({
                "bodystylekey": data.bodystylekey,
                "pvikey": data.pvikey,
                "repurchaseQty": data.repurchaseQty,
                "tierIncentiveToDealer": data.tierIncentiveToDealer,
                "tierIncentives": data.tierIncentives,
                "vehMlv": data.vehMlv
              });
            }
          });
        }
      });
    }
  }

  editValueUpdate(edPvi, field, event) {
    this.edittier1Error = false;
    this.edittier2Error = false;
    this.edittier3Error = false;
    this.edittier4Error = false;
    this.edittier5Error = false;
    this.edittier6Error = false;
    this.editmlvError = false;
    this.editrepurError = false;
    if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 5) {
      if (field == 1) {
        this.edittier1Error = true;
      }
      else if (field == 2) {
        this.edittier2Error = true;
      }
      else if (field == 3) {
        this.edittier3Error = true;
      }
      else if (field == 4) {
        this.edittier4Error = true;
      }
      else if (field == 5) {
        this.edittier5Error = true;
      }
      else if (field == 6) {
        this.edittier6Error = true;
      }
      else if (field == 'vehMlv') {
        if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 8) {
          this.editmlvError = true;
        }
      }
      else if (field == 'repurchaseQty') {
        if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 8) {
          this.editrepurError = true;

        }
      }
    }

    else {
      this.vehicleTableAS = true;
      if (field == "vehMlv") {
        this.multiEditData.map(data => {
          if (data.pvikey == edPvi) {
            data['vehMlv'] = Number(event.target.value)
          }
        });
      }
      if (field == "repurchaseQty") {
        this.multiEditData.map(data => {
          if (data.pvikey == edPvi) {
            data['repurchaseQty'] = Number(event.target.value)
          }
        });
      }
      if (field == 1 || field == 2 || field == 3 || field == 4 || field == 5 || field == 6) {
        this.multiEditData.map(data => {
          if (data.pvikey == edPvi) {
            data['tierIncentives'].map(tierInc => {
              if (tierInc.tierLevel == field) {
                tierInc.tierInctvAmount = Number(event.target.value);
              }
            })
          }
        });
      }
    }
  }
  sellingDealerTier() {
    if (this.paymentRouting == 'A') {
      const dialogRef = this.dialog.open(SellingDealer, { width: '300px', data: [{}] });
      dialogRef.afterClosed().subscribe(data => {
        if (data == 'ok') {
          let saveVal = {}
          this.tierSave(saveVal);
        }
        else {
          this.paymentRouting = this.ddPrevState
        }
      });
    } else if (this.paymentRouting == 'B') {
      const dialogRef = this.dialog.open(PaymentSelect, { width: '300px', data: [{}] });
      dialogRef.afterClosed().subscribe(data => {
        if (data == 'ok') {
          let saveVal = {}
          this.tierSave(saveVal);
        }
        else {
          this.paymentRouting = this.ddPrevState
        }
      });

    } else if (this.paymentRouting == 'D') {
      const dialogRef = this.dialog.open(PaymentNone, { width: '300px', data: [{}] });
      dialogRef.afterClosed().subscribe(data => {
        if (data == 'yes') {
          let saveVal = {}
          this.tierSave(saveVal);
        }
        else {
          this.paymentRouting = this.ddPrevState
        }
      });

    } else if (this.paymentRouting == 'C') {
      const dialogRef = this.dialog.open(PaymentSelect, { width: '300px', data: [{}] });
      dialogRef.afterClosed().subscribe(data => {
        if (data == 'ok') {
          this.tierFieldCheck();
        } else {
          this.paymentRouting = this.ddPrevState;
        }
      });
    }

    this.yoySave();
  }

  tierFieldCheck() {
    this.tier1Array = [];
    if (this.paymentRouting == 'C') {
      if (this.ddPrevState == 'A' || this.ddPrevState == 'D') {
        this.volumeData.map(data => {
          this.tier1Array.push({
            "pviKey": data.pvikey,
            "tier1InctvToDlrFlag": "N"
          });
        });
      } else if (this.ddPrevState == 'B') {
        this.volumeData.map(data => {
          this.tier1Array.push({
            "pviKey": data.pvikey,
            "tier1InctvToDlrFlag": "Y"
          });
        });
      } else {
        this.volumeData.map(data => {
          this.tier1Array.push({
            "pviKey": data.pvikey,
            "tier1InctvToDlrFlag": data.tierIncentiveToDealer
          });
        });
      }
    }

  }
  tierValueChange(pvi, event) {
    if (this.paymentRouting == 'C' && this.ddPrevState == null) {
      this.tier1Array = [];
      this.volumeData.map(data => {
        this.tier1Array.push({
          "pviKey": data.pvikey,
          "tier1InctvToDlrFlag": data.tierIncentiveToDealer
        });
      });
    }
    if (this.tier1Array.length > 0) {
      let checkVal = event.srcElement.checked == true ? 'Y' : 'N';
      this.tier1Array.map(val => {
        if (pvi == val.pviKey) {
          val.tier1InctvToDlrFlag = checkVal
        }
      });
    }
    let finalSaveTier = {
      "tier1InctvToDealerDtoList": this.tier1Array
    };
    this.tierSave(finalSaveTier);
  }
  tierSave(finalSaveTier) {
    this.spinnerLoad = true;

    sessionStorage.setItem('paymentRouting', this.paymentRouting);
    let tierFieldUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('pmntRouting', this.paymentRouting);
    this.RestcallService.updateData(tierFieldUrl, JSON.stringify(finalSaveTier)).subscribe(data => this.vehicleVolumeCall(),
    err=> this.spinnerLoad = false);
    this.speSave(); //For Payment Routing and Count-Rental map to A01
  }

  cancelAction() {
    this.spinnerLoad = false
    this.vehicleVolumeCall();
    this.dblclickFlag = true;
  }

  cancel() {
    this.spinnerLoad = false
    this.vehicleVolumeCall();
  }

  cancelActionHide() {
    this.opendialog = false;
  }

  //SaveRow or Update Row
  saveRow() {
    this.spinnerLoad = true;
    let optionDiscountCheck = true;

    let FinalSaveArray = {
      "tierVolumeList": [],
      "vehicleDetailsVos": this.multiEditData
    }
    this.multiEditData.map(checkData => {
        let check = checkData.tierIncentives[0].tierInctvAmount + this.RestcallService.optionDiscountValidationMap.get(String(checkData.pvikey));
        if(isNaN(check) != true && !(check >= 0)) {
          optionDiscountCheck = false;
        }
    });
    if(optionDiscountCheck) {
      let editSaveUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey + '/' + this.proposalYear;
      this.RestcallService.ngOnInit();
      this.RestcallService.createData(editSaveUrl, JSON.stringify(FinalSaveArray)).subscribe(data => this.vehicleVolumeCall(),
      err=> this.spinnerLoad = false
      );
    } else {
      this.RestcallService.statusMessage(417, "Per-unit Incentive Tier1 amount must be greater than , or equal to the absolute value of the corresponding Negative Options VM.");
      this.spinnerLoad = false;
    }

  }

  //Add New
  addNewVehicle() {
    this.opendialog = true;
    this.addOptionDisplay = true;
    let newVehicleUrl = "/fleet-vehicle-line-incentives/vehicle-unit/v1/new-vehicle-info/" + this.proposalKey + '/' + this.proposalYear;
    this.RestcallService.ngOnInit();
    //  let newVehicleUrl = "/modelYearVehLineBdyStlMap";
    this.RestcallService.getData(newVehicleUrl).subscribe(newData => {
      this.newVehicleData = newData.modelYearVehLineBdyStlMap as any;
      this.newmodelYeardropdown = Object.keys(this.newVehicleData);
      this.newModelYearSelected = this.newmodelYeardropdown.includes(this.proposalYear) ? this.proposalYear : this.newmodelYeardropdown[0];
      this.loadVehicleStyle(this.newModelYearSelected);

    });
  }
  //Populate Vehicle style dropdown
  loadVehicleStyle(modelYearSelect) {
    this.vehicleLinePopulate = Object.keys(this.newVehicleData[modelYearSelect + '']);
    this.vehicleLineSelect = 'select'
    this.bodyStyleSelect = [];
    this.bodyStylePopulate = [];
    //this.vehicleLineSelect = 'select';
  }
  //Populate Bodystyle dropdown
  loadBodyStyle(modelYearSelect, vehicleLineSelect) {
    if(this.bodyStylePopulate != 0) {
      this.multiSelectVariable.filterValue = "";
    }
    this.bodyStylePopulate = [];
    this.bodyStyleSelect = [];
    this.bodyStylePopulate = this.newVehicleData[modelYearSelect + ''][vehicleLineSelect];
    this.bodyStylePopulate.map(data => {
      data.bodyStyle = data.bodyStyleDesc + ' - ' + data.bodyStyleCode;
      data.vehicleLine = vehicleLineSelect;
    });
  }

  addNewVehicleLine() {
    let duplicateVehicles;
    duplicateVehicles = false;
    let tierIncDealer;
    this.paymentRouting == 'B' ? tierIncDealer = 'Y' : tierIncDealer = 'N';
    this.bodyStyleSelect.map(data => {
      if (this.newVehicleLine.length > 0) {
        this.bodyStyleKeyMap = new Map(this.newVehicleLine.map(i => [i.bodyStyleKey, i.bodyStyleKey]));
        this.modelYearMap = new Map(this.newVehicleLine.map(i => [i.modelYear, i.modelYear]));
        if (this.bodyStyleKeyMap.get(data['bodyStyleKey']) == null && this.modelYearMap.get(data['modelYear']) == null) {
          this.newVehicleLine.push({
            modelYear: this.newModelYearSelected,
            bodyStyleCode: data.bodyStyleCode,
            bodyStyleDesc: data.bodyStyleDesc,
            bodyStyleKey: data.bodyStyleKey
          });
          this.addnewVehArray.push({
            "bodyStyleDesc": data.bodyStyleDesc,
            "bodyStyleCode": data.bodyStyleCode,
            "vehicleLine": data.vehicleLine,
            "bodystylekey": data.bodyStyleKey,
            "pvikey": 0,
            "repurchaseQty": null,
            "tierIncentiveToDealer": tierIncDealer,
            "tierIncentives": [
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 1
              },
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 2
              },
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 3
              },
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 4
              },
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 5
              },
              {
                "pviKey": 0,
                "tierInctvAmount": null,
                "tierLevel": 6
              }
            ],
            "vehMlv": null
          });
        }
      } else {
        this.newVehicleLine.push({
          modelYear: this.newModelYearSelected,
          bodyStyleCode: data.bodyStyleCode,
          bodyStyleDesc: data.bodyStyleDesc,
          bodyStyleKey: data.bodyStyleKey
        });
        this.addnewVehArray.push({
          "bodyStyleDesc": data.bodyStyleDesc,
          "bodyStyleCode": data.bodyStyleCode,
          "vehicleLine": data.vehicleLine,
          "bodystylekey": data.bodyStyleKey,
          "pvikey": 0,
          "repurchaseQty": null,
          "tierIncentiveToDealer": tierIncDealer,
          "tierIncentives": [
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 1
            },
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 2
            },
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 3
            },
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 4
            },
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 5
            },
            {
              "pviKey": 0,
              "tierInctvAmount": null,
              "tierLevel": 6
            }
          ],
          "vehMlv": null
        });
      }
    });
  }
  newTierVal(bsKey, field, event) {
    this.tier1Error = false;
    this.tier2Error = false;
    this.tier3Error = false;
    this.tier4Error = false;
    this.tier5Error = false;
    this.tier6Error = false;
    this.mlvError = false;
    this.repurError = false;
    if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 5) {
      if (field == 1) {
        this.tier1Error = true;
      }
      else if (field == 2) {
        this.tier2Error = true;
      }
      else if (field == 3) {
        this.tier3Error = true;
      }
      else if (field == 4) {
        this.tier4Error = true;
      }
      else if (field == 5) {
        this.tier5Error = true;
      }
      else if (field == 6) {
        this.tier6Error = true;
      }
      else if (field == 'vehMlv') {
        if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 8) {
          this.mlvError = true;
        }
      }
      else if (field == 'repurchaseQty') {
        if (isNaN(event.target.value) == true || event.target.value < 0 || event.target.value.length > 8) {
          this.repurError = true;
        }
      }

    }
    else if (isNaN(event.target.value) == false) {
      if (isNaN(field) == false) {
        this.addnewVehArray.map(data => {
          if (data.bodystylekey == bsKey) {
            data['tierIncentives'].map(val => {
              if (val.tierLevel == field) {
                val.tierInctvAmount = Number(event.target.value)
              } else if (val.tierLevel == null) {
                val.tierInctvAmount = Number(event.target.value);
                val.tierLevel = field
              }
            })
          }
        })
      }
      else if (field == 'vehMlv') {
        this.addnewVehArray.map(data => {
          if (data.bodystylekey == bsKey) {
            data.vehMlv = Number(event.target.value);
          }
        });
      } else if (field == 'repurchaseQty') {
        this.addnewVehArray.map(data => {
          if (data.bodystylekey == bsKey) {
            data.repurchaseQty = Number(event.target.value);
          }
        });
      }
    }
  }

  paymentTypeChange() {
    if (this.perUnitFormData.get('paymentType').value == 'O') {
      const dialogRef = this.dialog.open(TierVolumePaymentTerm, { width: '300px' });
      dialogRef.afterClosed().subscribe(data => {
        let tier = 1;
        let tierArray = {};
        let changeTier = [];
        this.volumeData.map(tab => {
          tab['tierIncentives'].map(inc => {
            if (inc.tierLevel == tier) {
              changeTier.push({
                "pviKey": inc.pviKey,
                "tierInctvAmount": inc.tierInctvAmount,
                "tierLevel": inc.tierLevel
              });
            }
          })
        });
        tierArray = {
          "tierIncentives": changeTier,
          "tierVolume": Number(tier)
        }

        let tierChangeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/discount-tier/' + this.proposalKey + '/' + tier;
        this.RestcallService.ngOnInit();
        this.RestcallService.updateData(tierChangeUrl, JSON.stringify(tierArray)).subscribe(data => this.vehicleVolumeCall());
      });
    }
  }

  addSave() {
    this.autoEarlyCheck = sessionStorage.getItem("autoEarlycheck");
    this.saveEvent = false;
    this.aeData = [];
    this.addnewVehArray.map(data => {
      this.aeData.push({
        vehicleCode: data.vehicleLine,
        bodyStyleCode: data.bodyStyleCode,
        bodyStyleKey: data.bodystylekey
      });
    });
    let aeUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/model/year';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("modelYr", this.newModelYearSelected);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.spinnerLoad = true;
    this.RestcallService.createData(aeUrl, JSON.stringify(this.aeData)).subscribe(data => {
      let respVehicles = null;
      if (this.RestcallService.copyAEData != null) {
        respVehicles = this.RestcallService.copyAEData
      }

      if (respVehicles.length > 0) {
        let my = +this.newModelYearSelected + +1;
        if (this.autoEarlyCheck == "ON") {
          if (confirm("Multiple Vehicle Lines added have Auto Early vehicle available for model year " + my + ", do you want to add those vehicles as well?")) {
            let addArrayDuplicate = this.addnewVehArray;
            addArrayDuplicate.map(data => {
              respVehicles.map(resp => {
                if (resp.vehicleCode == data.vehicleLine && resp.bodyStyleCode == data.bodyStyleCode) {
                  this.addnewVehArray.push({
                    "bodyStyleDesc": data.bodyStyleDesc,
                    "bodyStyleCode": data.bodyStyleCode,
                    "vehicleLine": data.vehicleLine,
                    "bodystylekey": resp.bodyStyleKey,
                    "pvikey": 0,
                    "repurchaseQty": data.repurchaseQty,
                    "tierIncentiveToDealer": data.tierIncentiveToDealer,
                    "tierIncentives": [
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[0].tierInctvAmount,
                        "tierLevel": 1
                      },
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[1].tierInctvAmount,
                        "tierLevel": 2
                      },
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[2].tierInctvAmount,
                        "tierLevel": 3
                      },
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[3].tierInctvAmount,
                        "tierLevel": 4
                      },
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[4].tierInctvAmount,
                        "tierLevel": 5
                      },
                      {
                        "pviKey": 0,
                        "tierInctvAmount": data.tierIncentives[5].tierInctvAmount,
                        "tierLevel": 6
                      }
                    ],
                    "vehMlv": 0
                  });
                }
              });
            });
          }
        }
      }
      let finaAddArray = {
        "tierVolumeList": [],
        "vehicleDetailsVos": this.addnewVehArray
      }
      let addNewUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey + '/' + this.proposalYear;
      this.spinnerLoad = true;
      this.RestcallService.ngOnInit();
      this.RestcallService.createData(addNewUrl, JSON.stringify(finaAddArray)).subscribe(data => { this.opendialog = false; this.saveEvent = true; }, err=> this.spinnerLoad = false);
    },
      err => {
        let finaAddArray = {
          "tierVolumeList": [],
          "vehicleDetailsVos": this.addnewVehArray
        }
        this.spinnerLoad = true;
        let addNewUrl = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey + '/' + this.proposalYear;
        this.RestcallService.ngOnInit();
        this.RestcallService.createData(addNewUrl, JSON.stringify(finaAddArray)).subscribe(data => { this.opendialog = false; this.saveEvent = true; }, err=> this.spinnerLoad = false);
      });

  }

}
@Component({
  selector: 'vehicle-delete-confirm',
  templateUrl: 'vehicle-delete-confirm.html',
})
export class VehicleDeleteConfirm {
  constructor(
    public dialogRef: MatDialogRef<VehicleDeleteConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}


@Component({
  selector: 'tier-delete',
  templateUrl: 'tier-delete.html',
})
export class TierDelete {
  constructor(
    public dialogRef: MatDialogRef<TierDelete>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}


@Component({
  selector: 'copy-tier',
  templateUrl: 'copy-tier.html',
})
export class CopyTier {
  constructor(
    public dialogRef: MatDialogRef<CopyTier>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('copy');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'tier-change',
  templateUrl: 'tier-change.html',
})
export class TierChange {
  constructor(
    public dialogRef: MatDialogRef<TierChange>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('change');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'sellingDealer',
  templateUrl: 'sellingDealer.html',
})
export class SellingDealer {
  constructor(
    public dialogRef: MatDialogRef<SellingDealer>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'paymentSelect',
  templateUrl: 'paymentSelect.html',
})
export class PaymentSelect {
  constructor(
    public dialogRef: MatDialogRef<PaymentSelect>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'paymentNone',
  templateUrl: 'paymentNone.html',
})
export class PaymentNone {
  constructor(
    public dialogRef: MatDialogRef<PaymentNone>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('yes');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'tier1-volume',
  templateUrl: 'tier1-volume.html',
})
export class Tier1Volume {
  constructor(
    public dialogRef: MatDialogRef<Tier1Volume>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'tier1-volume-value',
  templateUrl: 'tier1-volume-value.html',
})
export class Tier1VolumeValue {
  constructor(
    public dialogRef: MatDialogRef<Tier1VolumeValue>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}

@Component({
  selector: 'tier1-volume-payment-term',
  templateUrl: 'tier1-volume-payment-term.html',
})
export class TierVolumePaymentTerm {
  constructor(
    public dialogRef: MatDialogRef<TierVolumePaymentTerm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
