import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerUnitIncentiveComponent } from './per-unit-incentive.component';

describe('PerUnitIncentiveComponent', () => {
  let component: PerUnitIncentiveComponent;
  let fixture: ComponentFixture<PerUnitIncentiveComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerUnitIncentiveComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerUnitIncentiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
