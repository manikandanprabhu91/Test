import { Component, OnInit, ViewChild, Inject, OnDestroy, AfterViewInit } from '@angular/core';
import { MatAccordion } from '@angular/material/expansion';
import { RestcallService } from '../../services/restcall.service';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PerUnitIncentiveComponent } from './per-unit-incentive/per-unit-incentive.component';
import { IncentivesBonusComponent } from './incentives-bonus/incentives-bonus.component';
import { ProposalCommentsComponent } from './proposal-comments/proposal-comments.component';
import { OptionDiscountsComponent } from './option-discounts/option-discounts.component';
import { CpaletterComponent } from './cpaletter/cpaletter.component';
import { filter } from 'rxjs/operators';
import { PerUnitMexicoComponent } from './per-unit-mexico/per-unit-mexico.component';
import { SummaryandsubmitComponent } from './summaryandsubmit/summaryandsubmit.component';
import { IfStmt } from '@angular/compiler';


@Component({
  selector: 'proposal-landing',
  templateUrl: './proposal-landing.component.html',
  styleUrls: ['../fbmscontainer.component.sass']
})

export class ProposalLandingComponent implements OnInit {

  fleetRating: any;
  nonfinancialEdit: any;
  configUrl: string;
  proposalHeader: any;
  proposalKey: number;
  finKey: number;
  accountName: string;
  finCode: string;
  proposalYear: number;
  version: number;
  autoEarlyFlag: string;
  accountManager: string; 
  segment: string;
  proposalStatus: string;
  statusDate: string;
  aeUpdate: string;
  proposalCreatedUser: string;
  proposalArray: any;
  autoEarlyUpdate: boolean;
  selectedTab: any;
  openDialog: boolean;
  copyComments: string;
  loginId = sessionStorage.getItem('loginId');
  proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
  propCdsId: any;
  previousUrl: string;
  role: any;
  reportLevel: any;
  country: any;
  statusFlag: boolean;
  statusDropdown: any;
  statusComment: any;
  statusSelect: any;
  propHistRedirect: any;
  cpaLetterMod: boolean;
  proposalwarningList: any[];
  proposaldelete:any;
  deletedProposal:any;
  spinnerLoad: boolean;


  @ViewChild(MatAccordion) accordion: MatAccordion;
  @ViewChild(PerUnitIncentiveComponent) proposalInfo: PerUnitIncentiveComponent;
  @ViewChild(PerUnitMexicoComponent) perunitFOM: PerUnitMexicoComponent;
  @ViewChild(IncentivesBonusComponent) incentives: IncentivesBonusComponent;
  @ViewChild(OptionDiscountsComponent) optionDiscount: OptionDiscountsComponent;
  @ViewChild(ProposalCommentsComponent) comments: ProposalCommentsComponent;
  @ViewChild(CpaletterComponent) cpaLetter: CpaletterComponent;
  @ViewChild('tabGroup') tabGroup;  
  @ViewChild(SummaryandsubmitComponent) summaryandsubmitComponent: SummaryandsubmitComponent;


  constructor(private RestcallService: RestcallService, private route: ActivatedRoute, private dialog: MatDialog, private router: Router) { }
  ngOnDestroy() {
  this.deletedProposal = sessionStorage.getItem('deletedProposal');
    if(this.deletedProposal=="No"){
    if ((this.proposalStatus == 'NEW' && this.propCdsId == this.loginId) || (this.proposalStatus == 'REV' && this.reportLevel == 6)) {
      this.onTabChange();
    }
  }
  }
  ngOnInit(): void {
    this.spinnerLoad = false;
    sessionStorage.setItem("deletedProposal", "No");
    sessionStorage.setItem("autoEarlycheck", "");
    //Collapse the left side menu
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.statusComment = '';
    this.copyComments = '';
    this.proposalArray = [];
    this.openDialog = false;
    this.statusFlag = false;
    this.country = sessionStorage.getItem('countryCode');
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    //this.proposalAssignee=sessionStorage.getItem('proposalAssignee')
    this.cpaLetterMod = false;
    //Status Dropdown  
    this.propHistRedirect = null;
    //QueryParam
    const proposal = this.route.snapshot.queryParamMap.get('proposalKey');
    this.propHistRedirect = this.route.snapshot.queryParamMap.get('updStatus')
    this.configUrl = '/fleet-proposal-orchestrator/proposals/v1/proposal/' + proposal;
    this.RestcallService.ngOnInit();
    // this.configUrl = "/propHead";
    this.RestcallService.getData(this.configUrl).subscribe(proposalData => this.mapProposal(proposalData));
  }

  mapProposal(proposalData) {
    this.proposalKey = proposalData.proposalHeaderInfoDTO['proposalSaKey'];
    if (this.country == "MEX") {
      this.fleetRating = proposalData.fleetRating;
    }
    this.nonfinancialEdit = proposalData.proposalHeaderInfoDTO['nonFinancialEditFlag'] == 'N' ? false : true;
    this.finKey = proposalData.proposalHeaderInfoDTO['finMasterSaKey'];
    this.proposalYear = proposalData.proposalHeaderInfoDTO['proposalYear'];
    this.version = proposalData.proposalHeaderInfoDTO['version'];
    this.proposalStatus = proposalData.proposalHeaderInfoDTO['proposalStatus'];
    if (this.role == 'ADM' && this.propHistRedirect != null && this.propHistRedirect == 'upd') {
      this.statusDropdown = [];
      if (this.proposalStatus == 'NEW' || this.proposalStatus == 'REV' || this.proposalStatus == 'APV' || this.proposalStatus == 'SUB' || this.proposalStatus == 'DEC' || this.proposalStatus == 'REJ') {
        this.statusDropdown = ['TRM'];
        this.statusSelect = this.statusDropdown[0];
      } else if (this.proposalStatus == 'EST') {
        this.statusDropdown = ['TRM', 'URV'];
        this.statusSelect = this.statusDropdown[0];
      } else if (this.proposalStatus == 'URV') {
        this.statusDropdown = ['EST', 'TRM'];
        this.statusSelect = this.statusDropdown[0];
      }
    }

    this.statusDate = proposalData.proposalHeaderInfoDTO['statusDate'];
    this.accountName = proposalData.proposalHeaderInfoDTO['accountName'];
    this.finCode = proposalData.proposalHeaderInfoDTO['finCode'];
    this.propCdsId = proposalData.proposalHeaderInfoDTO['cdsId'];
    this.proposalArray = [this.proposalKey, this.finKey, this.proposalYear, this.version, this.proposalStatus, this.nonfinancialEdit, this.propCdsId, this.accountName, this.finCode, this.statusDate];
    if (this.country == "MEX") {
      this.proposalArray.push(this.fleetRating);
    }


    this.autoEarlyFlag = proposalData.proposalHeaderInfoDTO['autoEarlyFlag'];
    this.autoEarlyFlag == 'ON' ? this.autoEarlyUpdate = true : this.autoEarlyUpdate = false;
    this.autoEarlyUpdate == true ? this.autoEarlyFlag = 'ON' : this.autoEarlyFlag = 'OFF';
    sessionStorage.setItem('autoEarlycheck',this.autoEarlyFlag);
    this.accountManager = proposalData.proposalHeaderInfoDTO['firstName'] + ' ' + proposalData.proposalHeaderInfoDTO['lastName'];
    this.segment = proposalData.proposalHeaderInfoDTO['segmentDesc'];


    this.aeUpdate = proposalData.autoEarlyUpdated;
    this.proposalCreatedUser = proposalData.proposalHeaderInfoDTO['origFirstName'] + ' ' + proposalData.proposalHeaderInfoDTO['origLastName'];

    //CPA Letter Modified Test
    let cpaUrl = '/fleet-letters-management/letters/v1/cpa_letter/' + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
    this.RestcallService.getData(cpaUrl).subscribe(data => {
      let letterStatus;
      data != null ? letterStatus = data.customerAcceptanceVo : letterStatus = null;
      if (letterStatus != null) {
        letterStatus.modifiedLetterExist == true ? this.cpaLetterMod = true : this.cpaLetterMod = false;
      }
    });
  }
  autoEarlyCall() {
    this.autoEarlyUpdate == true ? this.autoEarlyFlag = 'ON' : this.autoEarlyFlag = 'OFF';
    const dialogRef = this.dialog.open(AutoEarlyConfirmDialog, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'yes') {
        let saveUrl = '/fleet-fin-management/fin-auto-early/v1/autoearly';
        let saveUpdate = {
          "autoEarlyVos": [
            {
              "assigneeKey": 0,
              "autoEarly": this.autoEarlyUpdate == true ? 'Y' : 'N',
              "finKey": this.finKey
            }]
        };
        this.RestcallService.ngOnInit();
        this.RestcallService.updateData(saveUrl, JSON.stringify(saveUpdate)).subscribe(data => { this.autoEarlyUpdate = this.autoEarlyUpdate });
        sessionStorage.setItem('autoEarlycheck',this.autoEarlyFlag);
      } else {

        this.autoEarlyUpdate = !this.autoEarlyUpdate;
      }
    });  
  }
  globalDelete() {
    this.spinnerLoad = true;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'yes') {
       let deleteUrl = '/fleet-proposal-orchestrator/proposals/v1/proposals';
      this.RestcallService.ngOnInit();
       this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
        //this.RestcallService.deleteData(deleteUrl).subscribe(data => this.router.navigate(['']));
        this.RestcallService.globaldeleteData(deleteUrl).subscribe(data =>{
          data != undefined ? this.proposaldelete= data.body.msgDesc : this.proposaldelete = null;
        if(this.proposaldelete!=null){
        if(this.proposaldelete=='Proposal is successfully deleted.')
        {
          sessionStorage.setItem("deletedProposal", "Yes");
          //sessionStorage.setItem('deletedProposal',null);  
        }
      }
        else{
          sessionStorage.setItem("deletedProposal", "No");
        }
        this.router.navigate(['/accounts-home']);
        //window.location.reload();
      }, err=> this.spinnerLoad = false);  
      }
    });
  }



  copyToNew() {
    this.openDialog = true;
    this.copyComments = '';
  }
  copyToNewCall() {
    this.spinnerLoad = true;
    let copyUrl = '/fleet-proposal-orchestrator/proposals/v1/proposals/copy';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('comments', this.copyComments);
    this.RestcallService.setQueryParams('copyType', 'COPY_NEW_PROPOSAL_VERSION');
    this.RestcallService.setQueryParams('finCd', this.finCode);
    this.RestcallService.setQueryParams('finKey', this.finKey);
    this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
    this.RestcallService.setQueryParams('proposalYrVer', this.version);
    this.RestcallService.setQueryParams('sourceProposalKey', this.proposalKey);
    this.RestcallService.createData(copyUrl, '').subscribe(data => {
      this.copyComments = '';
      this.RestcallService.statusMessage(201, 'Proposal Copied Successfully');
      window.location.href = '/accounts/proposal?proposalKey=' + this.RestcallService.copiedProposalKey;
    }, err => {
      this.openDialog = false;
      this.spinnerLoad = false;
    });
  }
  cancelCopy() {
    if (confirm("Are you sure you want to cancel?")) {
      this.openDialog = false;
      this.statusFlag = false;
      this.copyComments = '';
      this.statusComment = '';
    }
  }
  proposalDownload() {
    let proposalDownloadUrl = '/fleet-proposal-summary/proposals/v1/download';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('finKey', this.finKey);
    this.RestcallService.setQueryParams('isComplete', this.tabGroup.selectedIndex == 4 ? true : false);
    this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
    this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
    this.RestcallService.setQueryParams('proposalYrVer', this.version);
    this.RestcallService.setQueryParams('volumeFinancialDataSource', this.summaryandsubmitComponent.dropdownSelect);
    this.RestcallService.downloadExcel(proposalDownloadUrl, "ProposalReport.xls");
  }
  switchEdit() {
    const dialogRef = this.dialog.open(FinancialEdit, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'yes') {
        if (this.nonfinancialEdit == true) {
          let updateArray = {
            'nonFinancialEditFlag': this.nonfinancialEdit == true ? this.nonfinancialEdit = 'N' : this.nonfinancialEdit = 'Y'
          }
          let switchEditUrl = '/fleet-proposal-orchestrator/proposals/v1/proposals/financial-edit/' + this.proposalKey;
          this.RestcallService.ngOnInit();
          this.RestcallService.updateData(switchEditUrl, JSON.stringify(updateArray)).subscribe(data => this.ngOnInit());
        }
      } else {
        this.nonfinancialEdit = false;
        this.ngOnInit()
      }
    });

  }

  ngAfterViewInit() {
    if (sessionStorage.getItem("warning") == "Warning") {
      this.proposalwarningList = JSON.parse(sessionStorage.getItem("copyWarningsVos"));
      if (this.proposalwarningList != null && this.proposalwarningList.length > 0) {
        sessionStorage.setItem("copyWarningsVos", "");
        sessionStorage.setItem("warning", "");
        document.getElementById("openModalButton").click();
      }
    }
   

    this.route.queryParams.subscribe(params => {
      const selectedTab = params["tab"];
      this.selectedTab = selectedTab;
    });
  }
  statusChange() {
    this.statusFlag = true;
    this.statusComment = '';
  }
  updateStatus() {
    if (confirm('Do you want to change the status to ' + this.statusSelect + '?')) {
      let statusGet = '/fleet-proposal-orchestrator/proposals/v1/proposals/proposal-status';
      let statusArray = {
        "cdsid": this.loginId,
        "inProcess": "N",
        "proposalKey": this.proposalKey,
        "proposalNoteDescription": this.statusComment,
        "statusCd": this.statusSelect
      };
      this.RestcallService.ngOnInit();
      this.RestcallService.updateData(statusGet, statusArray).subscribe(data => {
        window.location.href = '/accounts/history/proposal?proposalKey=' + this.proposalKey;
        // this.router.navigateByUrl('/proposal?proposalKey='+this.proposalKey)    
      }, err => {

      });
    }
  }
  optIncCheck() {
    if (this.tabGroup.selectedIndex == 1 && (this.proposalStatus == 'NEW' && this.propCdsId == this.loginId) || (this.proposalStatus == 'REV' && this.reportLevel == 6)) {
      if (this.incentives.incMlbAdd != this.optionDiscount.mlbCheck()) {
        if (this.optionDiscount.mlbCheck() == false) {
          this.RestcallService.statusMessage(417, 'MLB incentive is added, atleast one vehicle line MLB should be added to save the Incentive');
        }
        if (this.incentives.incMlbAdd == false) {
          this.RestcallService.statusMessage(417, 'MLB option Discount is added, MLB incentive should be added to save the incentive');
        }
      }
    }
  }

  onTabChange() {

    if (this.country == "MEX") {
      //verify
      this.summaryandsubmitComponent.ngOnInit();
      this.cpaLetter.ngOnInit();
      this.comments.ngOnInit();
      //this.perunitFOM.saveForm()
      // this.comments.ngOnInit();
      //this.perunitFOM.ngOnInit();
    } else if (this.country == "USA") {
      this.cpaLetter.ngOnInit();
      this.comments.ngOnInit();
      //this.perunitFOM.ngOnInit();
      //this.summaryandsubmitComponent.financialTable();
      this.summaryandsubmitComponent.ngOnInit();
      this.optionDiscount.ngOnInit(); 
      //this.proposalInfo.saveChanges();
      this.incentives.ngOnInit();
      // this.comments.ngOnInit();
      // this.cpaLetter.ngOnInit();
    } 

    //Proposal Info
    if (this.country == 'USA') {
      this.optIncCheck();
    }

    if (this.country == 'USA') {
      if (this.reportLevel == 8 && (this.proposalStatus == 'SUB' || this.proposalStatus == 'REV' || this.proposalStatus == 'EST' || this.proposalStatus == 'APV')) {
        if (this.incentives.mlbAS == true) {
          this.incentives.mlbAS = false;
          this.incentives.save();
        }
      }


      if ((this.incentives.incMlbAdd == this.optionDiscount.mlbCheck()) && ((this.proposalStatus == 'NEW' && this.propCdsId == this.loginId) || (this.proposalStatus == 'REV' && this.reportLevel == 6))) {

        if (this.proposalInfo.vehicleTableAS == true) {
          this.proposalInfo.vehicleTableAS = false;
          this.proposalInfo.saveRow();
        }
        if (this.proposalInfo.perUnitAS == true || this.proposalInfo.yoyAS == true) {
          this.proposalInfo.perUnitAS = false;
          this.proposalInfo.yoyAS = false;
          this.proposalInfo.saveChanges();
        }


        if (this.proposalInfo.aggAS == true) {
          this.proposalInfo.aggAS = false;
          this.proposalInfo.aggregateSave();
        }
        //Option Discounts
        if (this.optionDiscount.optionDiscountAS == true) {
          this.optionDiscount.optionDiscountAS = false;
          this.optionDiscount.updateItems();
        }

        //MLB
        if (this.incentives.mlbAS == true) {
          this.incentives.mlbAS = false;
          this.incentives.save();
        }
        //Proposal Comments
        if (this.comments.commentNewAs == true) {
          this.comments.commentNewAs = false;
          this.comments.newSave();
        }
        if (this.comments.commentUpdateAs == true) {
          this.comments.commentUpdateAs = false;
          this.comments.updateItem(this.comments.argEditComment, this.comments.argProposalNoteKey);
        }
      }
    }
    if (this.country == 'MEX') {
      if (this.perunitFOM.fomPerunitAS == true) {
        this.perunitFOM.fomPerunitAS = false;
        this.perunitFOM.saveForm();
      }
      if (this.perunitFOM.fomVehicleTableAS == true) {
        this.perunitFOM.fomVehicleTableAS = false;
        this.perunitFOM.saveRow();
      }
      //Proposal Comments
      if (this.comments.commentNewAs == true) {
        this.comments.commentNewAs = false;
        this.comments.newSave();
      }
      if (this.comments.commentUpdateAs == true) {
        this.comments.commentUpdateAs = false;
        this.comments.updateItem(this.comments.argEditComment, this.comments.argProposalNoteKey);
      }
    }
  }
}

@Component({
  selector: 'cpa-letter-type',
  templateUrl: 'cpa-letter-type.html',
})
export class CpaLetterType {
  constructor(
    public dialogRef: MatDialogRef<CpaLetterType>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onExist() {
    this.dialogRef.close('existing');
  }
  onCreate() {
    this.dialogRef.close('create');
  }
  onNoClick(): void {
    this.dialogRef.close('cancel');
  }
}

@Component({
  selector: 'delete-confirm-dialog',
  templateUrl: 'delete-confirm-dialog.html',
})
export class DeleteConfirmDialog {
  constructor(
    public dialogRef: MatDialogRef<DeleteConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onYesClick() {
    this.dialogRef.close('yes');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
@Component({
  selector: 'financial-edit',
  templateUrl: 'financial-edit.html',
})
export class FinancialEdit {
  constructor(
    public dialogRef: MatDialogRef<FinancialEdit>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onYesClick() {
    this.dialogRef.close('yes');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
@Component({
  selector: 'ae-confirm-dialog',
  templateUrl: 'ae-confirm-dialog.html',
})
export class AutoEarlyConfirmDialog {
  constructor(
    public dialogRef: MatDialogRef<AutoEarlyConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onYesClick() {
    this.dialogRef.close('yes');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
//Copy to new Version
@Component({
  selector: 'copy-to-new-version',
  templateUrl: 'copy-to-new-version.html',
})

export class CopyToNewVersion {
  copyComments: any = '';


  constructor(public dialogRef: MatDialogRef<CopyToNewVersion>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onYesClick() {
    this.dialogRef.close(this.copyComments);
  }
  onNoClick(): void {
    this.dialogRef.close('No');
  }
}
