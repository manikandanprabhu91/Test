import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalLandingComponent } from './proposal-landing.component';

describe('ProposalLandingComponent', () => {
  let component: ProposalLandingComponent;
  let fixture: ComponentFixture<ProposalLandingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposalLandingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
