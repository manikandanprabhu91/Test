import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OptionDiscountsComponent } from './option-discounts.component';

describe('OptionDiscountsComponent', () => {
  let component: OptionDiscountsComponent;
  let fixture: ComponentFixture<OptionDiscountsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OptionDiscountsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OptionDiscountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
