import { Component, OnInit, ViewChild, Input, Inject } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { RestcallService } from '../../../services/restcall.service';
import { ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProposalLandingComponent } from '../proposal-landing.component';


@Component({
  selector: 'option-discounts',
  templateUrl: './option-discounts.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class OptionDiscountsComponent implements OnInit {

  opendialog: boolean;
  proposalKey: any;
  codeValues: any;
  addVehicleLine: any;
  addVehicleLineBackUp: any;
  selectedVehiclesToAdd: any;

  codeOption: boolean;
  codeSelect: string;
  commonCode: any;
  voCode: any;
  espEngine: any;
  espTerms: any;
  selectCommonCode: string;
  selectVoCode: any;
  selectEspTerms: string;
  selectEspEngine: string;
  amount: FormControl;
  amountVo: FormControl;
  takeRate: FormControl;
  amountUpdate: any[];
  takeRateUpdate: any[];
  errorAmount: boolean;
  errorTakeRate: boolean;
  loading: boolean;
  isExpanded: boolean = false;
  expandedRows = {};
  selectionArray: any[];
  editable: boolean;
  selectedList: any;
  editInd: any;
  espTermsArray: any;
  commonCodeValidation: any;
  voCodeValidation: any;
  espUpdate: any;
  espAmountError: boolean;
  espTakeRateError: boolean;
  proposalYear: any;
  version: any;
  finKey: any;
  role: any;
  reportLevel: any;
  nonFinancialEdit: any;
  proposalStatus: any;
  optionDiscountAS: boolean;
  loginId = sessionStorage.getItem('loginId');
  propCdsId: any;
  spinnerLoad: boolean;
  @ViewChild('myListbox') myInputVariable;
  @ViewChild('multiSelect') multiSelectVariable;
  optionDiscountValidation: any;

  constructor(private RestcallService: RestcallService, private route: ActivatedRoute, private dialog: MatDialog, private landing: ProposalLandingComponent) { }
  @Input() proposalArray: any;


  ngOnInit(): void {
    this.spinnerLoad = false;
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.optionDiscountAS = false;
    this.espAmountError = false;
    this.espTakeRateError = false;
    this.espUpdate = [];
    this.editable = false;
    this.selectedList = [];
    this.espTermsArray = [];
    this.editInd = null;
    this.isExpanded = false
    this.opendialog = false;
    this.codeSelect = '';
    this.selectedVehiclesToAdd = null;
    this.selectionArray = [];
    this.amountUpdate = [];
    this.takeRateUpdate = [];
    this.loading = true;
    this.selectVoCode = [];

    this.amount = new FormControl(0, [Validators.pattern('^[0-9]*$'), Validators.max(99999), Validators.maxLength(5), Validators.required]);
    this.amountVo = new FormControl(0, [Validators.pattern('^[-,0-9]*$'), Validators.max(99999), Validators.maxLength(5), Validators.required]);
    this.takeRate = new FormControl(0, [Validators.pattern('^[0-9]*$'), Validators.max(100), Validators.maxLength(3), , Validators.required]);
    this.proposalKey = this.proposalArray[0];
    this.proposalYear = this.proposalArray[2];
    this.version = this.proposalArray[3];
    this.finKey = this.proposalArray[1];
    this.proposalStatus = this.proposalArray[4];
    this.nonFinancialEdit = this.proposalArray[5];
    this.propCdsId = this.proposalArray[6];
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('proposalKey', this.proposalKey);
    this.RestcallService.setQueryParams('proposalYr', this.proposalYear);
    this.RestcallService.setQueryParams('finKey', this.finKey);
    this.RestcallService.setQueryParams('proposalYrVer', this.version);
    let configUrl = '/fleet-vehicle-line-incentives/option-discounts/v1/option-incentive';
    // let configUrl = '/optionDiscount';
    this.RestcallService.getData(configUrl).subscribe(data => data != null || data != "" ? this.mapcodeValues(data) : '', err => this.mapcodeValues(null));
  }
  mapcodeValues(respData) {
    this.optionDiscountValidation = [];
    respData != null ? this.codeValues = respData.optionIncentiveSummaryVOList : this.codeValues = null;
    this.codeValues != null ? this.expandAll() : '';
    if (this.codeValues != null) {
      this.codeValues.map(data => {
        if (data.discountDetails.length > 0) {
          let amount = 0;
          let key = data.mainKey;
          let keySubmit = data.vehicleLineDescription + '!' + data.modelYear + '!' + data.bodyStyleCode;
          data.discountDetails.map(discountData => {
            if (discountData.type == "VO") {
              discountData.amount;
              if (amount > discountData.amount) {
                amount = discountData.amount;
              }
            }
          });
          if (amount < 0) {
            this.optionDiscountValidation.push({ 'key': key, 'value': amount,'keySubmit': keySubmit });
          }
        }
      });
    }
    if (this.optionDiscountValidation != []) {
      this.RestcallService.optionDiscountValidationMap = new Map(this.optionDiscountValidation.map(i => [i.key, i.value]));
      this.RestcallService.optionDiscountSubmitMap = new Map(this.optionDiscountValidation.map(i => [i.keySubmit, i.value]));
    } else {
      this.RestcallService.optionDiscountValidationMap = new Map();
      this.RestcallService.optionDiscountSubmitMap = new Map();
    }
    this.loading = false;
  }
  mlbCheck() {
    var optMlbAdded = false;
    this.codeValues.map(data => {
      data.discountDetails.map(dd => {
        if (dd.code == 'MLB') {
          optMlbAdded = true;
        }
      });
    });
    return optMlbAdded;
  }
  expandAll() {
    this.codeValues.forEach(data => {
      this.expandedRows[data.pvisaKey] = true;
    });
  }
  onRowExpand() {
    if (Object.keys(this.expandedRows).length === this.codeValues.length) {
      this.isExpanded = true;
    }
  }
  onRowCollapse() {
    if (Object.keys(this.expandedRows).length === 0) {
      this.isExpanded = false;
    }
  }

  cancel() {
    this.ngOnInit();
  }
  deleteCall() {
    const dialogRef = this.dialog.open(DeleteConfirm, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'delete') {
        var selectionArray = [];
        if (this.selectedList != null && this.selectedList.length > 0) {
          this.selectedList.map(data => {
            selectionArray.push(Number(data.optionIncentiveKey));
          });
        }
        if (selectionArray != [] || selectionArray != null) {
          this.spinnerLoad = true;

          let deleteUrl = "/fleet-vehicle-line-incentives/option-discounts/v1/option-incentive"
          this.RestcallService.ngOnInit();
          this.RestcallService.updateData(deleteUrl, selectionArray).subscribe(data => this.cancel(), err=>     this.spinnerLoad = false          );
        }
      }
    });

  }
  ondblClick(code) {
    if (!this.editInd || this.editInd != code.optionIncentiveKey) {
      this.editInd = code.optionIncentiveKey;
      this.selectedList = [];
      this.selectionArray = [];
      this.selectedList.push(code);
      this.edit();
    }
  }

  edit() {
    this.selectedList != null && this.selectedList.length > 0 ? this.selectedList.map(data => this.selectionArray.includes(data.optionIncentiveKey) ? '' : this.selectionArray.push(data.optionIncentiveKey)) : '';
    this.editable = true;
    this.amountUpdate = [];
    this.takeRateUpdate = [];
  }

  updateAmount(key, event, code) {
    this.errorAmount = false;
    event.target.value == '' ? this.errorAmount = true : this.errorAmount = false;
    if (code == "OTH" || code == "MLB" || code == "ESP") {
      isNaN(event.target.value) ? this.errorAmount = true : event.target.value >= 0 && event.target.value <= 99999 ?
        this.amountUpdate.length > 0 ? this.amountUpdate.some((item) => item.optionIncentiveKey == key) ?
          this.amountUpdate.map(data => {
            data.optionIncentiveKey == key ? data.amount = event.target.value : ''
          }) : this.amountUpdate.push({
            pviKey: Number(key),
            optIncentiveAmount: Number(event.target.value)
          })
          : this.amountUpdate.push({
            pviKey: Number(key),
            optIncentiveAmount: Number(event.target.value)
          })
        : this.errorAmount = true;
    } else {
      if (!isNaN(event.target.value) && event.target.value.length < 6) {
        event.target.value >= -9999 && event.target.value <= 99999 ?
          this.amountUpdate.length > 0 ? this.amountUpdate.some((item) => item.optionIncentiveKey == key) ?
            this.amountUpdate.map(data => {
              data.optionIncentiveKey == key ? data.amount = event.target.value : ''
            }) : this.amountUpdate.push({
              pviKey: Number(key),
              optIncentiveAmount: Number(event.target.value)
            })
            : this.amountUpdate.push({
              pviKey: Number(key),
              optIncentiveAmount: Number(event.target.value)
            })
          : this.errorAmount = true;
      } else {
        this.errorAmount = true;
      }

    }


    if (this.errorAmount == false) {
      this.optionDiscountAS = true;
    } else {
      this.optionDiscountAS = false;
    }
  }
  updateTakeRate(key, event) {
    this.errorTakeRate = false;
    event.target.value == '' ? this.errorTakeRate = true : this.errorTakeRate = false;
    isNaN(event.target.value) ? this.errorTakeRate = true : event.target.value >= 0 && event.target.value <= 100 ?
      this.takeRateUpdate.length > 0 ? this.takeRateUpdate.some((item) => item.optionIncentiveKey == key) ?
        this.takeRateUpdate.map(data => {
          data.optionIncentiveKey == key ? data.takeRate = event.target.value : ''
        }) : this.takeRateUpdate.push({
          pviKey: Number(key),
          optTakeRate: Number(event.target.value)
        })
        : this.takeRateUpdate.push({
          pviKey: Number(key),
          optTakeRate: Number(event.target.value)
        })
      : this.errorTakeRate = true;

    if (this.errorTakeRate == false) {
      this.optionDiscountAS = true;
    } else {
      this.optionDiscountAS = false;
    }
  }

  updateItems() {
    if (this.optionDiscountAS == true) {
      let map = new Map();
      this.amountUpdate.forEach(item => map.set(item.pviKey, item));
      this.takeRateUpdate.forEach(item => map.set(item.pviKey, { ...map.get(item.pviKey), ...item }));
      let mergedArr = Array.from(map.values());
      if (mergedArr.length > 0) {
        mergedArr.map(data => {
          let arrKey = Object.keys(data);
          if (arrKey.length == 2) {
            arrKey.includes('optTakeRate') ? data['optIncentiveAmount'] = null : arrKey.includes('optIncentiveAmount') ? data['optTakeRate'] = null : '';
          }
        });
this.spinnerLoad = true;
        let updateUrl = '/fleet-vehicle-line-incentives/option-discounts/v1/option-discount';
        this.RestcallService.ngOnInit();
        this.RestcallService.updateData(updateUrl, JSON.stringify(mergedArr)).subscribe(data => this.cancel(), err=> this.spinnerLoad = false);
      }
    }
  }


  //Add Code

  codeSelected(val) {
    if (this.codeValues != null) {
      this.selectedVehiclesToAdd = null;
      this.myInputVariable.filterValue = "";
      let vehicleResList = [];
      let vehicleList = [];
      this.takeRate.setValue(0);
      this.amount.setValue(0);
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
      let vehiclesGet = '/fleet-vehicle-line-incentives/option-discounts/v1/common-codes/proposal';
      this.codeValues.map(data => {
        vehicleList.push({
          "bodyStyleDescription": data.bodyStyleDescription,
          "bodyStyle": data.bodyStyleCode,
          "modelYear": Number(data.modelYear),
          "pviSaKey": Number(data.mainKey),
          "bodyStyleSaKey": Number(data.pvisaKey),
          "vehLineSaKey": Number(data.vehicleLineKey),
          "bdyDescriptionStyleModel": data.bodyStyleDescription + ' - ' + data.bodyStyleCode + ' - ' + data.modelYear
        });

        this.addVehicleLine = vehicleList;
        // this.addVehicleLine = respData.optionIncentiveVos;
        this.addVehicleLineBackUp = this.addVehicleLine;
      });
      if (val == 'esp') {
        this.selectEspEngine = 'select';
        this.RestcallService.ngOnInit();
        let espEngineGet = '/fleet-vehicle-line-incentives/option-discounts/v1/extended-service-plan-engine-types';
        // let espEngineGet = '/espEngineType'
        this.RestcallService.getData(espEngineGet).subscribe(data => this.espEngine = data.espFuelTypeList);
      }
    }
    this.opendialog = true;
  }

  newVehicleList() {
    this.selectVoCode = [];
    this.multiSelectVariable.filterValue = "";
    this.voCode = [];
    if (this.selectedVehiclesToAdd.length > 0) {
      if (this.codeSelect == 'common') {
        this.selectCommonCode = 'select';
        this.RestcallService.ngOnInit();
        let commonCodeGet = '/fleet-vehicle-line-incentives/option-discounts/v1/common-codes';
        // let commonCodeGet = '/commonCode';
        this.RestcallService.getData(commonCodeGet).subscribe(data => this.commonCode = data.commonOptionList);
      }
      else if (this.codeSelect == 'vo') {
        let vehicleLineKey = this.selectedVehiclesToAdd[0].vehLineSaKey;
        let addVehSelect = [];
        this.addVehicleLineBackUp.map(data => {
          if (data.vehLineSaKey == vehicleLineKey) {
            addVehSelect.push(data);
          }
        });
        addVehSelect.length > 0 ? this.addVehicleLine = addVehSelect : '';
        let voCodeGet = '/fleet-vehicle-line-incentives/option-discounts/v1/vehicle-option-codes';
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('vehicleLineKey', vehicleLineKey);
        let codeVo = new Map();
        this.RestcallService.getData(voCodeGet).subscribe(data => {
          data.voCodeOptionResponse.map(code => {
            codeVo.set(code.voCodeKey, code.voCodeDescription)
          });
          this.voCode = codeVo;
        });
      }
    }
    else {
      this.selectedVehiclesToAdd = null;
      this.addVehicleLine = this.addVehicleLineBackUp;
    }
  }
  // espLoad(val,vehicleLineKey, modelYear, bsKey){
  espLoad(val) {
    let pviKey = val.data.pviSaKey;
    let bsKey = val.data.bodyStyleSaKey;
    let modelYear = val.data.modelYear;
    let vehicleLineKey = val.data.vehLineSaKey;
    this.RestcallService.ngOnInit();
    let espTermsGet = '/fleet-vehicle-line-incentives/option-discounts/v1/extended-service-plan-terms';
    this.RestcallService.setQueryParams('vehicleLineKey', vehicleLineKey);
    this.RestcallService.setQueryParams('modelYear', modelYear);
    this.RestcallService.setQueryParams('bodyStyleKey', bsKey);
    // let espTermsGet = '/espTerms';
    this.RestcallService.getData(espTermsGet).subscribe(data => {
      data['keyValueVoList'] != [] || data['keyValueVoList'] != null ? this.espTerms = data['keyValueVoList'] : this.espTerms = null;

      if (this.espTerms != null || this.espTerms != '') {
        this.espTermsArray.push({
          pviKey: pviKey,
          bsKey: bsKey,
          modelYear: modelYear,
          vehicleLineKey: vehicleLineKey,
          espTerms: this.espTerms,
          saveVals: {
            pviKey: null,
            espFuelType: '',
            espTerms: 0,
            optIncentiveAmount: 0,
            optTakeRate: 0
          }
        });
      }
    });
  }

  espUnLoad(event) {
    let pviKey = event.data.pviSaKey;
    this.espTermsArray.map((data, index) => {
      if (data.pviKey == event.data.pviSaKey) {
        this.espTermsArray.splice(index, 1);
      }
    });
  }


  takeRateValidator() {
    if (this.codeSelect == 'common' && this.selectCommonCode == 'MLB') {
      this.takeRate.setValue(100);
      this.takeRate.setValidators([Validators.min(100), Validators.max(100), Validators.pattern('^[0-9]*$'), Validators.required, Validators.maxLength(3),]);
      this.takeRate.updateValueAndValidity();
    } else {
      this.takeRate.clearValidators();
      this.takeRate.setValidators([Validators.pattern('^[0-9]*$'), , Validators.required, Validators.maxLength(3), Validators.max(100)]);
      this.takeRate.setValue(0);
      this.takeRate.updateValueAndValidity();
    }
    if (this.selectCommonCode == 'select') {
      this.amount.setValue(0);
      this.takeRate.setValue(0);
    }
  }
  changeVo() {
    if (this.selectVoCode == 'select') {
      this.amount.setValue(0);
      this.takeRate.setValue(0);
    }
  }

  espTermUpdate(pviKey, field, actualValue) {

    this.espTermsArray.map(data => {
      if (data.pviKey == pviKey) {
        data.saveVals.pviKey = pviKey;
        if (field == 'espFuelType') {
          data.saveVals.espFuelType = actualValue.target.value;
        }
        if (field == 'espTerms') {
          data.saveVals.espTerms = Number(actualValue.target.value);
        }
        if (field == 'optIncentiveAmount') {
          actualValue.target.value == '' ? this.espAmountError = true : this.espAmountError = false;
          isNaN(actualValue.target.value) ? this.espAmountError = true : actualValue.target.value < 0 || actualValue.target.value >= 100000 ? this.espAmountError = true :
            this.espAmountError = false; data.saveVals.optIncentiveAmount = Number(actualValue.target.value);
        }
        if (field == 'optTakeRate') {
          actualValue.target.value == '' ? this.espTakeRateError = true : this.espTakeRateError = false;
          isNaN(actualValue.target.value) ? this.espTakeRateError = true : actualValue.target.value < 0 || actualValue.target.value > 100 ? this.espTakeRateError = true :
            this.espTakeRateError = false; data.saveVals.optTakeRate = Number(actualValue.target.value);
        }
      }
    });
  }


  saveCode() {

    if (this.selectedVehiclesToAdd != null || this.selectedVehiclesToAdd != "") {
      if (this.codeSelect == 'common') {
        let pviKey = [];
        this.selectedVehiclesToAdd.map(data => {
          pviKey.push(Number(data.pviSaKey));
        });
        let commonCodeArray = {
          "pviKey": pviKey,
          "commonOptionCode": this.selectCommonCode,
          "optIncentiveAmount": Number(this.amount.value),
          "optTakeRate": Number(this.takeRate.value)
        };
        //Validation
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('pviSaKeylist', pviKey);
        let addCommon = '/fleet-vehicle-line-incentives/option-discounts/v1/common-codes/vehicle-unit';
        this.RestcallService.getData(addCommon).subscribe(data => {
          this.commonCodeValidation = data;
          this.commonCodeValidation = this.commonCodeValidation['pviSaKeyWithCommonCodesMap'];
          if (this.commonCodeValidation != {} || this.commonCodeValidation != null) {
            let ccFails;
            ccFails = false;
            let ccKeys = [];
            ccKeys = Object.keys(this.commonCodeValidation);
            if (ccKeys.length > 0) {
              for (let i = 0; i < ccKeys.length; i++) {
                if (this.commonCodeValidation[ccKeys[i]].includes(this.selectCommonCode) == true) {
                  ccFails = true;
                }
              }
            }
            if (ccFails == true) {
              this.RestcallService.statusMessage(417, "Selected Code already Applied to the Vehicle Line");
            } else {
              this.spinnerLoad = true;

              this.RestcallService.ngOnInit();
              let addCommon = '/fleet-vehicle-line-incentives/option-discounts/v1/common-codes';
              this.RestcallService.createData(addCommon, JSON.stringify(commonCodeArray)).subscribe(data => this.cancel(), err=> this.spinnerLoad = false);
            }
          }
        });
      }

      else if (this.codeSelect == 'vo') {
        let pviKey = [];
        let optionDiscountCheck = false;

        this.selectedVehiclesToAdd.map(data => {
          pviKey.push(Number(data.pviSaKey));
        });
        let voCodeKey = [];
        this.selectVoCode.map(val => {
          voCodeKey.push(Number(val.key));
        });
        let voCodeArray = {
          pviKey: pviKey,
          vehicleOptionCode: voCodeKey,
          optIncentiveAmount: Number(this.amountVo.value),
          optTakeRate: Number(this.takeRate.value)
        };
        if(pviKey != []) {
          pviKey.map(dataValidation => {
            let check = this.RestcallService.vehicleLineDataValidationMap.get(dataValidation) + Number(this.amountVo.value);
            if(isNaN(check) != true && !(check >= 0)) {
              optionDiscountCheck = true;
            }
          });
        }
        //Validation
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams('pviKeylist', pviKey);
        let addCommon = '/fleet-vehicle-line-incentives/option-discounts/v1/vehicle-option-codes/vehicle-unit';
        this.RestcallService.getData(addCommon).subscribe(data => {
          let voFails = false;
          this.voCodeValidation = data['pviSaKeyWithVoCodesMap'];
          let voKeys = voCodeArray['vehicleOptionCode'];
          this.voCodeValidation.map(reponseData => {
            voKeys.map(checkData => {
              if (checkData == reponseData) {
                voFails = true;
              }
            })
          });
          if (voFails) {
            this.RestcallService.statusMessage(417, "Selected Code already Applied to the Vehicle Line");
          } else if(optionDiscountCheck) {
            this.RestcallService.statusMessage(417, "The absolute value of the Negative Options VM must be less than, or equal to, the corresponding Per-unit Incentive Tier1 amount");
          } else {
            this.spinnerLoad = true;

            this.RestcallService.ngOnInit();
            let addVo = '/fleet-vehicle-line-incentives/option-discounts/v1/vehicle-options';
            this.RestcallService.createData(addVo, JSON.stringify(voCodeArray)).subscribe(data => this.cancel(), err => this.spinnerLoad = false);
          }
        });
      }

      else if (this.codeSelect == 'esp') {
        var espFuelTypeFlag = false;
        var espTermsFlag = false;
        var vehicleFlag = false;
        let espSaveArray = [];
        this.espTermsArray.map(data => {
          espSaveArray.push(data.saveVals);
        });
        if (espSaveArray != null || espSaveArray != [] || espSaveArray.length > 0) {
          espSaveArray.map(espData => {
            if (espData.espFuelType == "" || espData.espFuelType == "select") {
              espFuelTypeFlag = true;
            }
            if (espData.espTerms == 0 || isNaN(espData.espTerms)) {
              espTermsFlag = true;
            }
          });
        } else {
          vehicleFlag = true;
        }
        if (vehicleFlag) {
          this.RestcallService.statusMessage(417, "Please Select Atleast One Vehicle");
        } else if (espFuelTypeFlag && espTermsFlag) {
          this.RestcallService.statusMessage(417, "Please Select Engine Type and Esp Terms");
        } else if (espFuelTypeFlag) {
          this.RestcallService.statusMessage(417, "Please Select Engine Type");
        } else if (espTermsFlag) {
          this.RestcallService.statusMessage(417, "Please Select Esp Terms");
        } else {
          this.spinnerLoad = true;
          this.RestcallService.ngOnInit();
          let addEsp = '/fleet-vehicle-line-incentives/option-discounts/v1/extended-service-plan';
          this.RestcallService.createData(addEsp, espSaveArray).subscribe(data => { this.cancel(); }, err=> this.spinnerLoad = false);
        }
      }
    }
  }

}


@Component({
  selector: 'delete-confirm',
  templateUrl: 'delete-confirm.html',
})
export class DeleteConfirm {
  constructor(
    public dialogRef: MatDialogRef<DeleteConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
