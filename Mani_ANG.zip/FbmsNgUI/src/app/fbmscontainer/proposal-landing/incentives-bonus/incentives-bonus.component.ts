import { Component, OnInit, Input, Inject, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProposalLandingComponent } from '../proposal-landing.component';


@Component({
  selector: 'incentives-bonus',
  templateUrl: './incentives-bonus.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class IncentivesBonusComponent implements OnInit {
  mlbEndYear: any;
  mlbEndYearSelected: any;
  mlbStartYear: number;
  mlbToggle: boolean;
  manualBonusToggle: boolean;
  controllerRole: any;
  paymentMadeSelect: any;
  finKey: number;
  proposalKey: number;
  proposalYear: number;
  version: number;
  multiYearBonus: any;
  sourceEffect: any;
  sourceEst: any;
  minVolume: FormControl;
  manualminVolume: FormControl;
  manualaggregate: FormControl;
  microNumber: FormControl;
  approvedDate: FormControl;
  cumulative: FormControl;
  perUnitallocation: number;
  colorendYear: boolean;
  colorbonusFimpsFlag: boolean;
  colorminVolume: boolean;
  colormanualBonusFlag: boolean;
  colorrequiredVolume: boolean;
  colormanualBonusAmount: boolean;
  colorpaymentMadeFlag: boolean;
  colormicroCheckNumber: boolean;
  colormicroCheckDate: boolean;
  colortotalBonusPaidAmount: boolean;
  colorCode: any;
  role: any;
  reportLevel: any;
  status: any;
  nonFinancialEdit: any;
  mlbAS: boolean;
  loginId = sessionStorage.getItem('loginId');
  propCdsId: any;
  incMlbAdd: any;
  readOnlyFlag: boolean;
  spinnerLoad: boolean;

  @Input() proposalArray: any;

  constructor(private RestcallService: RestcallService, private fb: FormBuilder, private dialog: MatDialog, private landing: ProposalLandingComponent) { }

  ngOnInit(): void {
    this.spinnerLoad = false;

    this.mlbAS = false;
    this.controllerRole = sessionStorage.getItem('reportLvlCd');
    this.role = sessionStorage.getItem('roleName');
    this.proposalKey = this.proposalArray[0];
    this.proposalYear = this.proposalArray[2];
    this.version = this.proposalArray[3];
    this.finKey = this.proposalArray[1];
    this.status = this.proposalArray[4];
    this.nonFinancialEdit = this.proposalArray[5];
    this.propCdsId = this.proposalArray[6];
    let configUrl = "/fleet-proposal-bonuses/bonuses/v1/bonus";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("version", this.version);
    this.RestcallService.getData(configUrl).subscribe(respData => this.mapData(respData))
  }

  mapData(respData) {
    this.multiYearBonus = respData;
    if (this.multiYearBonus) {
      this.mlbStartYear = this.multiYearBonus['multiYearTermDto']['startYr'];
      this.mlbEndYearSelected = this.multiYearBonus['multiYearTermDto']['endYr'] == 0 ? 0 : this.multiYearBonus['multiYearTermDto']['endYr'];
      this.mlbEndYear = [0, this.mlbStartYear, this.mlbStartYear + 1, this.mlbStartYear + 2];
      this.mlbToggle = this.multiYearBonus['multiYearTermDto']['bonusFimpsFlag'] == 'N' || null ? false : true;
      this.manualBonusToggle = this.multiYearBonus['multiYearTermDto']['manualBonusFlag'] == 'N' || null ? false : true;
      this.incMlbAdd = this.mlbToggle;
      this.sourceEffect = this.multiYearBonus['sourceVerInEffect'] ? this.multiYearBonus['sourceVerInEffect'] : '';
      this.sourceEst = this.multiYearBonus['sourceVerInEstablishment'] ? this.multiYearBonus['sourceVerInEstablishment'] : '';
      this.minVolume = new FormControl(this.multiYearBonus['multiYearTermDto']['minVolume'], [Validators.pattern("^[0-9]*$"), Validators.max(99999), Validators.maxLength(5)]);
      this.manualminVolume = new FormControl(this.multiYearBonus['multiYearTermDto']['requiredVolume'], [Validators.pattern("^[0-9]*$"), Validators.max(99999), Validators.maxLength(5)]);
      this.manualaggregate = new FormControl(this.multiYearBonus['multiYearTermDto']['manualBonusAmount'], [Validators.pattern("^[0-9]*$"), Validators.max(9999999), Validators.maxLength(7)]);
      this.microNumber = new FormControl(this.multiYearBonus['multiYearTermDto']['microCheckNumber']);
      this.approvedDate = new FormControl(this.multiYearBonus['multiYearTermDto']['microCheckDate']);
      this.cumulative = new FormControl(this.multiYearBonus['multiYearTermDto']['totalBonusPaidAmount'], [Validators.pattern("^[0-9]*$")]);
      this.paymentMadeSelect = this.multiYearBonus['multiYearTermDto']['paymentMadeFlag'];
	  this.readOnlyFlag = this.multiYearBonus['mlbReadOnlyFlag'] == true ? true : false;

	  if( this.multiYearBonus['mlbReadOnlyFlag']){
			this.readOnlyFlag = this.multiYearBonus['mlbReadOnlyFlag'] == true ? true : false;
	  }

	  this.minVolume.valueChanges.subscribe(data => {
        this.minVolume.invalid ? this.mlbAS = false : this.mlbAS = true
      });
      this.manualminVolume.valueChanges.subscribe(data => {
        this.manualminVolume.invalid ? this.mlbAS = false : this.mlbAS = true
      });
      this.microNumber.valueChanges.subscribe(data => {
        this.microNumber.invalid ? this.mlbAS = false : this.mlbAS = true
      });
      this.approvedDate.valueChanges.subscribe(data => {
        this.approvedDate.invalid ? this.mlbAS = false : this.mlbAS = true
      });
      this.cumulative.valueChanges.subscribe(data => {
        this.cumulative.invalid ? this.mlbAS = false : this.mlbAS = true
      });
      this.manualaggregate.valueChanges.subscribe(data => {
        this.manualaggregate.invalid ? this.mlbAS = false : this.mlbAS = true
      });
    }

    // this.perUnitallocation = this.multiYearBonus['multiYearTermDsorto']['manualBonusAmount']>0 || this.multiYearBonus['multiYearTermDto']['requiredVolume'] > 0 ?  this.multiYearBonus['multiYearTermDto']['manualBonusAmount']/this.multiYearBonus['multiYearTermDto']['requiredVolume'] : 0;
    if (this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']) {
      this.colorendYear = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['endYr'];
      this.colorbonusFimpsFlag = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['bonusFimpsFlag'];
      this.colorminVolume = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['minVolume'];
      this.colormanualBonusFlag = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['manualBonusFlag'];
      this.colorrequiredVolume = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['requiredVolume'];
      this.colormanualBonusAmount = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['manualBonusAmount'];
      this.colorpaymentMadeFlag = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['paymentMadeFlag'];
      this.colormicroCheckNumber = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['microCheckNumber'];
      this.colormicroCheckDate = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['microCheckDate'];
      this.colortotalBonusPaidAmount = this.multiYearBonus['multiUnitIncentiveColorDifferenceDTO']['totalBonusPaidAmount'];
    }

    this.perunitcalc();
  }
  perunitcalc() {
    if (this.manualminVolume.value > 0 && this.manualaggregate.value > 0) {
      this.perUnitallocation = Math.round(this.manualaggregate.value / this.manualminVolume.value);
    }
  }
  mlbAssign() {
    if (this.minVolume.invalid || this.manualaggregate.invalid || this.manualminVolume.invalid || this.microNumber.invalid || this.approvedDate.invalid || this.cumulative.invalid) {
      this.mlbAS = false;
    } else {
      this.mlbAS = true;
    }
  }
  setminVolumeValidator() {
    if (this.role == 'ADM' || this.nonFinancialEdit == true || (this.status != 'NEW' ? true : this.propCdsId == this.loginId ? false : true) && (this.status != 'REV' ? true : this.reportLevel == 6 ? false : true)) {

    } else {
      this.mlbAS = true;
      if (this.mlbToggle == false) {
        this.minVolume.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(99999), Validators.maxLength(5)]);
        this.minVolume.value != null && Number(this.minVolume.value) > 0 ? '' : this.minVolume.setValue(1);
        this.minVolume.updateValueAndValidity();
      } else {
        const dialogRef = this.dialog.open(DisableConfirm, { width: '300px' });
        dialogRef.afterClosed().subscribe(data => {
          if (data == 'disable') {
            this.minVolume.setValidators([Validators.pattern("^[0-9]*$"), Validators.max(99999), Validators.maxLength(5)]);
            this.minVolume.setValue(0);
            this.minVolume.updateValueAndValidity();
			this.mlbEndYearSelected = this.manualBonusToggle == false ? 0 : this.mlbEndYearSelected;
            this.mlbToggle = false;
          }
          if (data == 'enable') {
            this.mlbToggle = true;
            this.minVolume.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(99999), Validators.maxLength(5)]);
            this.minVolume.value != null && Number(this.minVolume.value) > 0 ? '' : this.minVolume.setValue(1);
            this.minVolume.updateValueAndValidity();
          }
        });
      }
    }
	//this.incMlbAdd = this.mlbToggle;
  }
  setmanualMinVolumeValidator() {
      if (this.role == 'ADM' || this.nonFinancialEdit == true || (this.status != 'NEW' ? true : this.propCdsId == this.loginId ? false : true) && (this.status != 'REV' ? true : this.reportLevel == 6 ? false : true)) {

    } else {
      this.mlbAS = true;
    if (this.manualBonusToggle == true) {
      this.manualminVolume.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(99999), Validators.maxLength(5)]);
      this.manualaggregate.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(9999999), Validators.maxLength(7)]);
      this.manualminVolume.value != null && Number(this.manualminVolume.value) > 0 ? '' : this.manualminVolume.setValue(1);
      this.manualaggregate.value != null && Number(this.manualaggregate.value) > 0 ? '' : this.manualaggregate.setValue(1);
      this.manualaggregate.updateValueAndValidity();
      this.manualminVolume.updateValueAndValidity();
    } else {
      const dialogRef = this.dialog.open(DisableConfirmManual, { width: '300px' });
      dialogRef.afterClosed().subscribe(data => {
        if (data == 'disable') {
          this.manualminVolume.setValidators([Validators.pattern("^[0-9]*$"), Validators.max(99999), Validators.maxLength(5)]);
          this.manualminVolume.updateValueAndValidity();
          this.manualaggregate.setValidators([Validators.pattern("^[0-9]*$"), Validators.max(9999999), Validators.maxLength(7)]);
          this.manualaggregate.updateValueAndValidity();
          this.manualaggregate.setValue(0);
          this.manualminVolume.setValue(0);
		  this.mlbEndYearSelected = this.mlbToggle == false ? 0 : this.mlbEndYearSelected;
          this.manualBonusToggle = false;
        }
		 if (data == 'enable'){
          this.manualBonusToggle = true;
		        this.manualminVolume.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(99999), Validators.maxLength(5)]);
      this.manualaggregate.setValidators([Validators.required, Validators.pattern("^[0-9]*$"), Validators.min(1), Validators.max(9999999), Validators.maxLength(7)]);
      this.manualminVolume.value != null && Number(this.manualminVolume.value) > 0 ? '' : this.manualminVolume.setValue(1);
      this.manualaggregate.value != null && Number(this.manualaggregate.value) > 0 ? '' : this.manualaggregate.setValue(1);
      this.manualaggregate.updateValueAndValidity();
      this.manualminVolume.updateValueAndValidity();
        }
      });
    }
   // this.incMlbAdd = this.manualBonusToggle;
  }
  }
  cancel() {
    this.mapData(this.multiYearBonus);
  }
  save() {

  this.incMlbAdd = this.mlbToggle == true ? this.mlbToggle : this.manualBonusToggle;
    const dialogRef = this.dialog.open(ControllerApproval, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'ok') {
        if (this.mlbEndYearSelected == 0) {
          this.mlbToggle = false;
		  this.manualBonusToggle = false;
        }
        if (this.mlbToggle == false) {
          this.minVolume.setValue(0);
        }
        if (this.mlbToggle == true) {
          this.minVolume.value != null && Number(this.minVolume.value) > 0 ? '' : this.minVolume.setValue(1);
        }
        if (this.manualBonusToggle == false) {
          this.manualminVolume.setValue(0);
          this.manualaggregate.setValue(0);
          this.paymentMadeSelect = 'N';
        }
        if (this.manualBonusToggle == true) {
          this.manualminVolume.value != null && Number(this.manualminVolume.value) > 0 ? '' : this.manualminVolume.setValue(1);
          this.manualaggregate.value != null && Number(this.manualaggregate.value) > 0 ? '' : this.manualaggregate.setValue(1);
        }
        if (this.paymentMadeSelect == 'N') {
          this.microNumber.setValue('');
          this.approvedDate.setValue('');
          this.cumulative.setValue(0);
        }
        let sendValues = {
          "proposalKey": this.proposalKey,
          "startYr": this.mlbStartYear,
          "endYr": this.mlbEndYearSelected,
          "bonusFimpsFlag": this.mlbToggle == false ? 'N' : 'Y',
          "minVolume": this.minVolume.value,
          "manualBonusFlag": this.manualBonusToggle == false ? 'N' : 'Y',
          "requiredVolume": this.manualminVolume.value,
          "manualBonusAmount": this.manualaggregate.value,
          "paymentMadeFlag": this.paymentMadeSelect,
          "microCheckNumber": this.microNumber.value,
          "microCheckDate": this.approvedDate.value,
          "totalBonusPaidAmount": this.cumulative.value
        }
        this.spinnerLoad = true;

        let updateUrl = "/fleet-proposal-bonuses/bonuses/v1/bonus";
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams("finKey", this.finKey);
        this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
        this.RestcallService.setQueryParams("version", this.version);
        this.RestcallService.updateData(updateUrl, sendValues).subscribe(data => {
          this.ngOnInit();
          this.landing.optIncCheck();
        },
        err=> this.spinnerLoad = false);
      }
    });
  }
}

@Component({
  selector: 'controller-approval',
  templateUrl: 'controller-approval.html',
})
export class ControllerApproval {
  constructor(
    public dialogRef: MatDialogRef<ControllerApproval>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close('cancel');
  }
}

@Component({
  selector: 'disable-confirm',
  templateUrl: 'disable-confirm.html',
})
export class DisableConfirm {
  constructor(
    public dialogRef: MatDialogRef<DisableConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('disable');
  }
  onNoClick(): void {
    this.dialogRef.close('enable');
  }
}

@Component({
  selector: 'disable-confirm-manual',
  templateUrl: 'disable-confirm-manual.html',
})
export class DisableConfirmManual {
  constructor(
    public dialogRef: MatDialogRef<DisableConfirmManual>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('disable');
  }
  onNoClick(): void {
    this.dialogRef.close('enable');
  }
}
