import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncentivesBonusComponent } from './incentives-bonus.component';

describe('IncentivesBonusComponent', () => {
  let component: IncentivesBonusComponent;
  let fixture: ComponentFixture<IncentivesBonusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncentivesBonusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncentivesBonusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
