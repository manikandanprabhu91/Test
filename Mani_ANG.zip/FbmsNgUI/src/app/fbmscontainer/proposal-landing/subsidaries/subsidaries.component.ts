import { Component, Input, OnInit, Inject } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'subsidaries',
  templateUrl: './subsidaries.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class SubsidariesComponent implements OnInit {
  configUrl :any ;
  subfin:FormControl;
  subsidaryTable: any;
  proposalKey:number;
  proposalYear:number;
  proposalVersion:number;
  finKey:number;
  totalCount: number;
  loading: boolean;
  status: any;
  role: any;
  reportLevel: any;
  loginId = sessionStorage.getItem('loginId');
  propCdsId : any;
  spinnerLoad: boolean;
  @Input() proposalArray: any;
  constructor(private RestCallService: RestcallService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.spinnerLoad = false;
    this.subfin=new FormControl('', [Validators.required]);
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.loading = true;
    this.proposalKey = this.proposalArray[0];
    this.finKey = this.proposalArray[1];
    this.proposalYear = this.proposalArray[2];
    this.proposalVersion = this.proposalArray[3];
    this.status = this.proposalArray[4];
    this.propCdsId = this.proposalArray[6];
    this.subsidaryGet();
  }


  subsidaryGet(){
    this.spinnerLoad = false;
        this.subfin.reset();
        this.configUrl ="/fleet-subsidiary-management/subsidiaries/v1/proposal-subfin"
        this.RestCallService.ngOnInit();
        this.RestCallService.setQueryParams('finKey',this.finKey);
        this.RestCallService.setQueryParams('proposalKey',this.proposalKey);
        this.RestCallService.setQueryParams('proposalYr',this.proposalYear);
        this.RestCallService.setQueryParams('proposalYrVer',this.proposalVersion);
        this.RestCallService.getData(this.configUrl).subscribe(respData => this.mapVal(respData), err => this.mapVal(null));

  }
  mapVal(respData){
    respData!= null ? this.subsidaryTable = respData.subsidiariesVOList : this.subsidaryTable =null;
    this.subsidaryTable !=null ? this.totalCount = this.subsidaryTable.length : this.totalCount =0;
    this.loading = false;
  }
  addnew(){
    if(this.subfin.value =='' || this.subfin.value == null){
      this.RestCallService.statusMessage(417, 'Sub-FIN is required');
    }else{
      let sampleRequest = {
        "domainCountryCd": sessionStorage.getItem('countryCode')
      }
      this.spinnerLoad = true;
      this.RestCallService.ngOnInit();
      this.RestCallService.setQueryParams('proposalKey',this.proposalKey);
      this.RestCallService.setQueryParams('subFin',this.subfin.value);
     this.RestCallService.createData(this.configUrl, sampleRequest).subscribe(data => this.subsidaryGet(), err=> this.spinnerLoad = false);
    }

  }
  removeFin(subFinKey){
    const dialogRef = this.dialog.open(DeleteSubsidaryFin, {width: '300px'});
    dialogRef.afterClosed().subscribe(data => {
      if(data == 'delete'){
        this.spinnerLoad = true;
        this.RestCallService.ngOnInit();
        this.RestCallService.setQueryParams('proposalKey',this.proposalKey);
        this.RestCallService.setQueryParams('subFin',subFinKey);
        this.RestCallService.deleteData(this.configUrl).subscribe(data => this.subsidaryGet(), err => this.spinnerLoad = false);
      }
    });
  }

}


@Component({
  selector: 'delete-subsidary-fin',
  templateUrl: 'delete-subsidary-fin.html',
  })
  export class DeleteSubsidaryFin {
  constructor(
  public dialogRef: MatDialogRef<DeleteSubsidaryFin>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
