import { Component, OnInit } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';

@Component({
  selector: 'financial-detailed-view',
  templateUrl: './financial-detailed-view.component.html',
  styleUrls: ['./financial-detailed-view.component.sass']
})
export class FinancialDetailedViewComponent implements OnInit {

  constructor(private Restcallservice: RestcallService, private route: ActivatedRoute) { }
  loadingBig: boolean;
  financialTablevals: any;
  country: any;
  role: any;
  reportLevel;

  ngOnInit(): void {
    alert();
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.country = sessionStorage.getItem('countryCode');
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    let finKey= this.route.snapshot.queryParamMap.get('fk');
    let proposalKey = this.route.snapshot.queryParamMap.get('pk');
    let proposalYear = this.route.snapshot.queryParamMap.get('yr');
    let proposalVersion = this.route.snapshot.queryParamMap.get('ver');
    let dropdownSelect = this.route.snapshot.queryParamMap.get('dds');
    this.loadingBig = true;
    let ftableUrl ='/fleet-proposal-summary/proposals/v1/financial-data';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey", finKey);
    this.Restcallservice.setQueryParams("proposalKey", proposalKey);
    this.Restcallservice.setQueryParams("proposalYr", proposalYear);
    this.Restcallservice.setQueryParams("proposalYrVer", proposalVersion);
    this.Restcallservice.setQueryParams("volumeFinancialDataSource", dropdownSelect);
    this.Restcallservice.getData(ftableUrl).subscribe(data => {
      data!=null ? this.financialTablevals= data.approvalResponseVoList[0].financialDetailedList : this.financialTablevals = null;
      this.loadingBig = false;
      console.log(data);
    },
    err=>{
      this.financialTablevals = null;
      this.loadingBig = false;
    });
  }

}
