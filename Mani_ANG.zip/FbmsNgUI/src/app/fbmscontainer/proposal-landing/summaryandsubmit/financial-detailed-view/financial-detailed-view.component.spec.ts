import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinancialDetailedViewComponent } from './financial-detailed-view.component';

describe('FinancialDetailedViewComponent', () => {
  let component: FinancialDetailedViewComponent;
  let fixture: ComponentFixture<FinancialDetailedViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinancialDetailedViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinancialDetailedViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
