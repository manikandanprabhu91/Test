import { Component, OnInit, Input, ViewChild, Inject } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatHorizontalStepper } from '@angular/material/stepper';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProposalLandingComponent } from '../proposal-landing.component';
import { ActivatedRoute } from 'src/testing/router-stubs';
import { Router } from 'src/testing/router-stubs';



@Component({
  selector: 'summaryandsubmit',
  templateUrl: './summaryandsubmit.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class SummaryandsubmitComponent implements OnInit {
  i:any;
  country: any;
  role: any;  
  reportLevel: any;
  proposalKey: number;
  finKey: number;
  proposalYear: number;
  proposalVersion: number;
  proposalStatus: string;
  nonFinancialEdit: any;
  propCdsId: any;
  dropdownVals: any;
  dropdownSelect: any;
  totAvgVals: any;
  loading: boolean;
  loadingBig: boolean;
  termsData: any;
  commentsData: any;
  commentLoad: any;
  financialTablevals: any;
  financialValsRearrange: any;
  includeText: any;
  approvalVals: any;
  yoyData: any;
  yoyCode: any;
  yoyColor: any;
  mlbData: any;
  valKey:any;
  paymentTerm: any;
  ssPaymentRouting: any;
  myPriceProtect: any;
  volumeData:any;
  openDialog: boolean;
  expandedRows={};
  isExpanded: boolean = true;
  tableFooter: any;
  btnDisplay: any;
  testVal: string;
  selectedVal: any;
  openActionDialog: boolean;
  actionComments: any;
  propAction: any;
  termsColor: any;
  floorPlan: any;
  quotationDate: any;
  propMLV: any;
  dealerInfo: any;
  dealerSelected: any;
  priorityFlag: any;
  fleetRating: any;
  proposalTier: any;
  mlbcolor: any;
fomPerunitAS : any;
   addError: any;
    editError : any;
   saveDisplay : any;
    tempAddVehicle = [];
   newVehicle = [];
   mlvTotal:any;
    selectionArray = [];
    opendialog : any;
   editablePvikey = [];
  editRows = [];
    addCatalogSelect = [];
    addGetVehicleData
    leng:any;
   keyofDefault:any;
  startvalmin:any;
  endvalmin:any;
  yearcon:any;
  bonusformat:any;
  newerProposal:any;
  proposalAssignee:any;
  warningmessage:any;
  buttonname:any;
  deletedProposal:any;
  spinnerLoad: boolean;
  clicked: boolean;
  popupclicked: boolean;


  @Input() proposalArray: any;
  @ViewChild(MatHorizontalStepper) stepper: MatHorizontalStepper;

  constructor(private Restcallservice: RestcallService, private dialog: MatDialog,private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
    this.spinnerLoad = false;
    this.expandAll();
    this.country = sessionStorage.getItem('countryCode');
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.proposalKey = this.proposalArray[0];
    this.finKey = this.proposalArray[1];
    this.proposalYear = this.proposalArray[2];
    this.proposalVersion = this.proposalArray[3];
    this.proposalStatus = this.proposalArray[4];
    this.nonFinancialEdit = this.proposalArray[5];
    this.propCdsId = this.proposalArray[6];
    this.openDialog = false;
    this.openActionDialog = false;
    this.tableFooter = [];
    this.actionComments='';
    this.propAction =null;
    this.fleetRating = 'AAA';
    this.proposalTier = 0;
    this.proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
    this.popupclicked = false;
    this.clicked = false;

    if(this.country =='MEX'){
      this.fleetRating = this.proposalArray[10];
    this.proposalTerms();
    }
    if(this.country =='USA'){
      this.proposalTermsUSA();
      this.mlbVals();
      this.yoyCode = 'FTI';
      this.yoyVals();
      }
    this.proposalComments();
    if(this.proposalStatus != 'NEW'){
      this.approvalProcess();
    }
    this.buttonDisplay();
    this.ddpVals();

  }
//added the below method for Total MLV calculation as per perunit incentive
  volumeTable() {
    this.fomPerunitAS = false;
    this.addError = false;
    this.editError = false;
    this.saveDisplay = false;
    this.tempAddVehicle = [];
    this.newVehicle = [];
    this.loading = true;
    this.selectionArray = [];
    this.opendialog = false;
    this.editablePvikey = [];
    this.editRows = [];
    this.addCatalogSelect = [];
    this.addGetVehicleData = [];
    let tableGet = '/fleet-vehicle-line-incentives/vehicle-unit/v1/proposal-vehicle-lines/' + this.proposalKey;
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(tableGet).subscribe(data => this.mapTableVals(data), err => { this.loading = false; this.volumeData = null });
  }
  mapTableVals(data) {
    if (data != null) {
      this.fomPerunitAS = false;
      this.volumeData = data.vehicleDetailsVos;
      this.editRows = this.volumeData;
      this.mlvTotal = this.volumeData.map(val => Number(val.vehMlv)).reduce((curr, prev) => Number(curr) + Number(prev), 0);
      this.loading = false;
    }
    else {
      this.fomPerunitAS = false;
      this.volumeData = null;
      this.mlvTotal = 0;
      this.loading = false;
    }
  }


  proposalTerms(){
    this. volumeTable();

    let termUrl ='/fleet-proposal-orchestrator/proposals/v1/per-unit-incentive/'+this.proposalKey;
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey",this.finKey);
    this.Restcallservice.setQueryParams("proposalYr",this.proposalYear);
    this.Restcallservice.setQueryParams("proposalYrVer",this.proposalVersion);
    this.Restcallservice.getData(termUrl).subscribe(data => {
      if(data!=null){
        this.termsData = data.proposalExtraInfoDto ;
        this.floorPlan = this.termsData.floorPlanDays;
        this.quotationDate = this.termsData.proposalExpirationDate;

        //this.propMLV = data.proposalDto.proposalMlv;
        //this.propMLV = this.mlvTotal;
        this.termsColor = data.perUnitIncentiveColorDto;
        // this.fleetRating =
      }else{
        this.termsData = null
        this.floorPlan = null;
        this.quotationDate = null;
        this.propMLV = null;
      }
    }, err => {
      this.termsData = null;
      this.floorPlan = null;
      this.quotationDate = null;
      this.propMLV = null;
    });
  }
  proposalTermsUSA(){
    let termUrl ='/fleet-proposal-orchestrator/proposals/v1/terms';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey",this.finKey);
    this.Restcallservice.setQueryParams("proposalKey",this.proposalKey);
    this.Restcallservice.setQueryParams("proposalYr",this.proposalYear);
    this.Restcallservice.setQueryParams("proposalYrVer",this.proposalVersion);
    this.Restcallservice.getData(termUrl).subscribe(data => {
      data!=null ? this.termsData = data : this.termsData = null;
    }, err => {
      this.termsData = null;
    });
  }
  mlbVals(){
    let configUrl = "/fleet-proposal-bonuses/bonuses/v1/bonus";
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey",this.finKey);
    this.Restcallservice.setQueryParams("proposalKey",this.proposalKey);
    this.Restcallservice.setQueryParams("proposalYr",this.proposalYear);
    this.Restcallservice.setQueryParams("version",this.proposalVersion);
    this.Restcallservice.getData(configUrl).subscribe(respData => {
      respData != null ? this.mlbData = respData['multiYearTermDto'] : this.mlbData = null;
      if(this.mlbData!=null)
      {
        this.startvalmin=this.mlbData.startYr;
  this.endvalmin=this.mlbData.endYr;
   this.yearcon="PY-"+this.startvalmin+"-"+this.endvalmin;
    }
      respData != null ? this.mlbcolor = respData['multiUnitIncentiveColorDifferenceDTO'] : this.mlbcolor = null;
    })
  }
  yoyVals(){
    let yoyUrl ='/fleet-proposal-bonuses/bonuses/v1/price-protection-year-over-year';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams('finKey',this.finKey);
    this.Restcallservice.setQueryParams('proposalKey',this.proposalKey);
    this.Restcallservice.setQueryParams('proposalYr',this.proposalYear);
    this.Restcallservice.setQueryParams('version',this.proposalVersion);
    this.Restcallservice.setQueryParams('yoyCode',this.yoyCode);
    this.Restcallservice.getData(yoyUrl).subscribe(data => {
      if(data != null){
        data.yoyResponseList ? this.yoyData = data.yoyResponseList : this.yoyData = null;
        data.yoyColorDifferenceDtoList ? this.yoyColor = data.yoyColorDifferenceDtoList : this.yoyColor = null;
        if(this.yoyData !=null){
        this.yoyData.map(data => {
          data['changeColor']= false;
          if(this.yoyColor != null){
            this.yoyColor.map(col => {
              if(col.modelYear == data.modelYear && col.percentageIncrease == true){
                data['changeColor'] = true;
              }
            });
          }
        });
      }
      }
    },
      err=>{
        this.yoyData = null;
        this.yoyColor = null;
      } );

  }
  proposalComments(){
    this.commentLoad  = true;
    let commentStore;
    this.commentsData = [];
    let configUrl='/fleet-notes-management/notes/v1/proposal-comments';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey", this.finKey);
   this.Restcallservice.getData(configUrl).subscribe(respData => {
     respData != null ? commentStore = respData.proposalNotesRetrival : commentStore =null;
     if(commentStore != null){
      commentStore.map(data => {
        if(data.proposalYear == this.proposalYear){
          this.commentsData.push(data);
        }
      });
     }else{
       this.commentsData = null;
     }
     this.commentLoad = false;
   }, err=>{
    this.commentLoad = false;
    this.commentsData =null;
   });
  }
  approvalProcess(){
    let appUrl ='/fleet-proposal-summary/proposals/v1/approval-chain';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("proposalKey", this.proposalKey);
    this.Restcallservice.getData(appUrl).subscribe(data => {
      data != null ? this.approvalVals = data.approvalResponseVoList[0].approvalChainVOList: this.approvalVals = null;
      if(this.approvalVals != null){
        this.selectedVal = 0;
        let completionCheck = false;
        this.approvalVals.map((data, index) => {
          data['propStatus']=false;
          if(index==0 && data.status == "SUB"){
            data['propStatus'] =true;
          }
          if(index > 0){
            if(data.status == "APV"){
              data['propStatus'] = true;
            }
            if(data.status == "Pending" && this.approvalVals[index-1].status != 'Pending'){
              this.selectedVal=index;
              completionCheck= true;
            }else if(data.status != "Pending" && completionCheck == false){
              data['propStatus'] = true;
            }
          }
        });
      }
    }, err=> this.approvalVals = null);
  }
  buttonDisplay(){
    let btnUrl ='/fleet-proposal-summary/proposals/v1/validate-actions';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams('proposalKey', this.proposalKey);
    this.Restcallservice.getData(btnUrl).subscribe(data => {
      data != null ? this.btnDisplay = data.actionsVO : this.btnDisplay = null;
      if(this.btnDisplay != null){
        this.priorityFlag = this.btnDisplay.highPriorityFlag;
      }else{
        this.priorityFlag = false;
      }
    }, err=>{
      this.btnDisplay = null;
      this.priorityFlag = false;
    });
  }
  ddpVals(){
       //dropdown options
       this.keyofDefault='null';
       let ddUrl = '/fleet-proposal-summary/proposals/v1/volume-financial-options';
       this.Restcallservice.ngOnInit();
       this.Restcallservice.setQueryParams('proposalKey', this.proposalKey);
       this.Restcallservice.getData(ddUrl).subscribe(data => {
         data != null ? this.dropdownVals = data.dropDownMap : this.dropdownVals =null;
         if(this.dropdownVals != null){
           this.leng = Object.keys(this.dropdownVals).length;

           if ( Object.keys(this.dropdownVals).length > 1) {
            
              this.keyofDefault=this.dropdownVals['defaultValue'];
              delete this.dropdownVals.defaultValue;
              this.dropdownSelect = this.keyofDefault;
            
          }
            if ( Object.keys(this.dropdownVals).length ==1)
            {
              let valofdefault= Object.keys(this.dropdownVals)[0];
              let valuenew=Object.values(this.dropdownVals)[0];
              //let valofdefault=this.dropdownVals;
              //this.valKey = Object.keys(this.dropdownVals);
              //let valuenew=Object.values(this.dropdownVals);
              //let verify=Object.values(valofdefault);
              this.dropdownSelect =  valofdefault ;
            }
 }else{
          this.dropdownSelect = null;
         }
         this.totAvgTable();
       });
  
  }


  getNumber(number) {
   this.bonusformat="$"+Math.trunc(number/1000)+ "K";
   return this.bonusformat;    
  }



  



  //Total AVg. Table
  totAvgTable(){
   
    let totAvgUrl = '/fleet-proposal-summary/proposals/v1/totals-avg-financial';
     this.loading = true;
     this.Restcallservice.ngOnInit();
     this.Restcallservice.setQueryParams("fleetRating", this.fleetRating);
     this.Restcallservice.setQueryParams("proposalKey", this.proposalKey);
     this.Restcallservice.setQueryParams("volumeFinancialDataSource", this.dropdownSelect);
     this.Restcallservice.getData(totAvgUrl).subscribe(data => {
      if(this.country =='USA'){
        data != null ? this.totAvgVals = [data.financialSummaryVO] : this.totAvgVals = null;
        data !=null ? this.proposalTier = data.proposalTier : this.proposalTier =0;
      }
      if(this.country =='MEX'){
       data != null ? this.totAvgVals = [data.financialMexSummaryVO] : this.totAvgVals = null;
      }
       this.loading = false;
     }, err => {
       this.loading = false;
       this.totAvgVals = false;
     });
     this.financialTable();
    
  }
  financialTable(){
    //this.deletedProposal = sessionStorage.getItem('deletedProposal');
    //if(this.deletedProposal=="No"){
      
    this.loadingBig = true;
    this.financialValsRearrange = [];
    
    let ftableUrl ='/fleet-proposal-summary/proposals/v1/financial-data';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("fleetRating", this.fleetRating);
    this.Restcallservice.setQueryParams("finKey", this.finKey);  
    this.Restcallservice.setQueryParams("proposalKey", this.proposalKey);
    this.Restcallservice.setQueryParams("proposalYr", this.proposalYear);
    this.Restcallservice.setQueryParams("proposalYrVer", this.proposalVersion);
    this.Restcallservice.setQueryParams("volumeFinancialDataSource", this.dropdownSelect);
    this.Restcallservice.getData(ftableUrl).subscribe(data => {
      if(data !=null){
        if(this.country =='USA'){
        this.financialTablevals = data.approvalResponseVoList[0].financialDetailedList;

        }else if(this.country =='MEX'){
          this.financialTablevals = data.approvalResponseVoList[0].financialDetailedMexList;
        }
        this.financialTablevals.map((data, index) =>{
          data['dataKey'] = index;
          // data['innergrid']=[{
          //   'val1':1,
          //   'val2':2
          // }, {
          //   'val1':3,
          //   'val2':4
          // }];
          if(data.recType =='GrandTotal'){
            this.tableFooter = data;
            let f= this.financialTablevals.splice(index,1).proposalTier;
            let a=this.tableFooter.proposalTier;
            let b=this.tableFooter.totalTier;

          }
          //Table Split based on presentProposal
          if(data.recType !='GrandTotal' && data.presentProposal == true && this.country== 'USA'){
            this.financialValsRearrange.push(data);
            
          }

        });
        ///IF GrandTotal->Rectype retrieve proposal tier and total tier /fleet-proposal-summary/proposals/v1/financial-data
        this.includeText = this.financialValsRearrange.length;
        this.financialTablevals.map(data => {
          if(data.recType !='GrandTotal' && data.presentProposal == false && this.country== 'USA'){
            this.financialValsRearrange.push(data);
            }
        });
        if(this.country == 'USA'){
          this.financialTablevals = this.financialValsRearrange;
        }
        this.expandAll();
      }else{
        this.financialTablevals = null
      }
      this.loadingBig = false;
    },
    err=>{
      this.financialTablevals = null;
      this.loadingBig = false;
    });
  //}
  }
  expandAll() {
    if(!this.isExpanded){
      this.financialTablevals?.forEach(data =>{
        this.expandedRows[data.dataKey] = true;
      })
    } else {
      this.expandedRows={};
    }
    this.isExpanded = !this.isExpanded;
    this.perunitVals();
  }

  presentOPTColor(data) {
    let check = this.Restcallservice.optionDiscountSubmitMap.get(data.vehDesc);
    if(isNaN(check) != true && !(check >= 0)) {
      return '#8face3';
    } else {
      return '';
    }
  }

  onRowExpand() {
    if(Object.keys(this.expandedRows).length === this.financialTablevals.length){
      this.isExpanded = true;
    }
  }
  onRowCollapse() {
    if(Object.keys(this.expandedRows).length === 0){
      this.isExpanded = false;
    }
  }
  detailedView(){
    this.openDialog = true;
  }
  cancel(){
    this.openDialog = false;
  }
  fullPrint(){
    window.print();
  }
  sendMail(){

  }
  perunitVals(){
    if(sessionStorage.getItem('paymentRouting') != null){
      sessionStorage.getItem('paymentRouting') == 'A' ? this.ssPaymentRouting = 'Selling Dealer' :
      sessionStorage.getItem('paymentRouting') == 'B' ? this.ssPaymentRouting = 'Tier-1 All' :
      sessionStorage.getItem('paymentRouting') == 'C' ? this.ssPaymentRouting = 'Tier-1 Partial' :
       this.ssPaymentRouting = 'Tier-1 None'
    }
  }
  proposalAction(propAct){
    this.clicked = true;
    this.buttonname=propAct;
    if(propAct =='SAVE_PROPOSAL'){
      const dialogRef = this.dialog.open(PriorityConfirm, {width: '300px', data:[{}]});
      dialogRef.afterClosed().subscribe(data => {
        if(data == 'ok'){

          this.propAction= propAct;
        this.openActionDialog = false;
        this.actionComments='';
        }else{
          this.priorityFlag = false;
        }
        let saveArray={
          "cdsid": sessionStorage.getItem('loginId'),
          "inProcess": "Y",
          "proposalKey":this.proposalKey,
          "proposalNoteDescription": "",
          "statusCd":  this.proposalStatus
        };
        this.spinnerLoad = true;

        let actUrl ='/fleet-proposal-summary/proposals/v1/submit-actions';
        this.Restcallservice.ngOnInit();
        this.Restcallservice.setQueryParams('action',propAct);
        this.Restcallservice.setQueryParams('proposalKey',this.proposalKey);
        this.Restcallservice.setQueryParams('highPriorityFlag',this.priorityFlag);
        this.Restcallservice.createData(actUrl, JSON.stringify(saveArray)).subscribe(data =>   window.location.reload(),
        err=> this.spinnerLoad = false);
      });
    }else{
      this.propAction= propAct;
      this.openActionDialog = true;
      this.actionComments='';
      this.spinnerLoad = false;

    }

  }

  setFocus() {
    window.setTimeout(function () { 
      document.getElementById('summaryComment').focus(); 
    }, 10);
  }

  saveAction(){
    this.spinnerLoad = true;
    this.openActionDialog = false;
    this.clicked = true;
    let saveArray={
      "cdsid": sessionStorage.getItem('loginId'),
      "inProcess": "Y",
      "proposalKey": this.proposalKey,
      "proposalNoteDescription": this.actionComments,
      "statusCd": this.proposalStatus
    };
  
    let actUrl ='/fleet-proposal-summary/proposals/v1/submit-actions';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams('action',this.propAction);
    this.Restcallservice.setQueryParams('proposalKey',this.proposalKey);
    this.Restcallservice.setQueryParams('highPriorityFlag',this.priorityFlag);
    
    //this.Restcallservice.createData(actUrl, JSON.stringify(saveArray)).subscribe(data => window.location.reload()); Commenting to fix approve next deal
    this.Restcallservice.createData(actUrl, JSON.stringify(saveArray)).subscribe(data =>  {
      data != undefined ? this.newerProposal= data.body.nextProposal : this.newerProposal = null;
      // this.clicked = false;
      // this.popupclicked = false;

      //this.warningmessage=data.body.genericResponse.msgDesc;
     
     if(this.newerProposal!=null && sessionStorage.getItem('countryCode')=='USA'){
       this.router.navigate(['/accounts/proposal'], { queryParams: { proposalAssignee: this.proposalAssignee,proposalKey:this.newerProposal,tab:'4' } })
  .then(() => {
         window.location.reload();
       });
      }
      else{  
        if(this.country=='USA'){ 
          this.router.navigate(['/accounts/proposal'], { queryParams: { proposalAssignee: this.proposalAssignee,proposalKey:this.proposalKey,tab:'4' } })
              .then(() => {
                window.location.reload();
         })
if(this.newerProposal==null && this.country=='USA'){
          sessionStorage.setItem('warning' ,data.body.genericResponse.msgDesc); 
          sessionStorage.setItem('statuscall',data.status); 
          this.router.navigate(['/accounts/proposal'], { queryParams: { proposalAssignee: this.proposalAssignee,proposalKey:this.proposalKey,tab:'4' } })
          .then(() => {
            window.location.reload();
               });
        }
      ;
        }
    if(this.country=='MEX'){
      
      this.router.navigate(['/accounts/proposal'], { queryParams: { proposalAssignee: this.proposalAssignee,proposalKey:this.proposalKey,tab:'2' } })
      .then(() => {
        window.location.reload();
      });
    }
        }    
     
  },
  err=> this.spinnerLoad = false);

}  
  
  cancelAction(){
    if(confirm('Are you sure you want to cancel the Action ?')){
      this.ngOnInit();
    }
  }
}

@Component({
  selector: 'priority-confirm',
  templateUrl: 'priority-confirm.html',
  })
  export class PriorityConfirm {
  constructor(
  public dialogRef: MatDialogRef<PriorityConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick(){
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
