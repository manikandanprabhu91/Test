import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SummaryandsubmitComponent } from './summaryandsubmit.component';

describe('SummaryandsubmitComponent', () => {
  let component: SummaryandsubmitComponent;
  let fixture: ComponentFixture<SummaryandsubmitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SummaryandsubmitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryandsubmitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
