import { Component, OnInit, Input, Inject, ViewChild } from '@angular/core';
import { RestcallService } from 'src/app/services/restcall.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CpaLetterRenderingComponent } from './cpa-letter-rendering/cpa-letter-rendering.component';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';


@Component({
  selector: 'cpaletter',
  templateUrl: './cpaletter.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class CpaletterComponent implements OnInit {

  spinner: boolean;
  role: any;
  reportLevel: any;
  loginId: any;
  proposalKey: any;
  proposalYear: any;
  proposalVersion: any;
  proposalStatus: any;
  finKey: any;
  nonFinancialEdit: any;
  propCdsId: any;
  accountName: any;
  finCode: any;
  cpaLetterType: any;
  myDeal: boolean;
  canadian: boolean;
  econoline: boolean;
  franchisee: boolean;
  repurchase: boolean;
  example: boolean;
  oos: boolean;
  oosCT: boolean;
  eft: boolean;
  py1: boolean;
  py2: boolean;
  py3: boolean;
  selectOpt: any;
  expDays: number;
  typeCheck: boolean;
  fileToUpload: File;
  letterExist: any;
  selectLetterOpt: any;
  selectLetterExist: boolean;
  modLetterExist: boolean;
  currYear: any;
  cpaLetterMod: any;
  templateOptions: any;
  openDialog: boolean;
  cpaComments: any = "";
  cusotmerAction: boolean;
  declaration: any;
  regenerateLetter: any;
  footerSection: any; // -> should be    -> need this in ashok service to get accept/decline on behalf of customer (acceptDecline: any);
  cpaArray: any;
  letterRenderUrl: any;
  xslStylesheet;
 
  myDOM;
  xmlDoc;
  xmlres;
  responseText: any;
  wordXMLViewerText: any;
  wordhtmlText: any;
  commentLoad: boolean;
  selectionMessage: boolean;
  country: any;
  proposalAssignee: any;
  newletterFlag: boolean;
  subject: any;
  fromAddress: any;
  toAddress: any;
  emailText: any;
  openEmailDialog: boolean;
  emailComments: any;
  userDealAuthFlag: boolean;
  approvalInStatus: boolean;
  controlProgram: any;
  cpymy: any;
  spinnerLoad: boolean;
  acceptdeclineenable:boolean;
  @Input() proposalArray: any;
  @ViewChild(CpaLetterRenderingComponent) rendering: CpaLetterRenderingComponent;

  constructor(private http: HttpClient, private RestcallService: RestcallService, private route: ActivatedRoute, private dialog: MatDialog, private router: Router) { }

  ngOnInit(): void {
    this.spinnerLoad = false;

    //To check current proposal year from control program year
    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      if (this.controlProgram != null) {
        this.cpymy = null;
        this.controlProgram.map(val => {
          if (val.currentProposalYearFlag == 'Y') {
            this.cpymy = "" + val.proposalYearCode;
            this.currYear = Number(this.cpymy);
          }
        });  
      }
    }, err => {this.controlProgram = null });
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem("reportLvlCd");
    this.loginId = sessionStorage.getItem("loginId");
    this.country = sessionStorage.getItem('countryCode');
    if(sessionStorage.getItem("approval") == "" && sessionStorage.getItem("CustAcc") == "Yes")
    {
      this.acceptdeclineenable=true;
    }
    else{
      this.acceptdeclineenable=false;
    }
    if (sessionStorage.getItem("CustAcc") == "Yes") {
     
      this.proposalKey = sessionStorage.getItem("proposalKey");
      this.proposalStatus = sessionStorage.getItem("proposalStatus");
      sessionStorage.setItem("CustAcc","");
    } else {
      this.proposalKey = this.proposalArray[0];
      this.proposalStatus = this.proposalArray[4];
    }

    if(sessionStorage.getItem("approval") == "Yes") {
      this.approvalInStatus = true;
      sessionStorage.setItem("approval", "");
    }

    this.proposalYear = this.proposalArray[2];
    this.proposalVersion = this.proposalArray[3];
    this.finKey = this.proposalArray[1];

    this.nonFinancialEdit = this.proposalArray[5];
    this.propCdsId = this.proposalArray[6];
    this.accountName = this.proposalArray[7];
    this.finCode = this.proposalArray[8];
    this.proposalAssignee = this.route.snapshot.queryParamMap.get('proposalAssignee');
    this.expDays = 30;
    this.typeCheck = false;
    this.openDialog = false;
    this.letterStatus();
    this.cpaComments = "";
    this.selectionMessage = true;
    this.userDealAuthFlag = false;
		if (sessionStorage.getItem("dealAuthFlag") == "Y") {
			this.userDealAuthFlag = true;
		}
  }

  ngAfterViewInit() {
    this.route.queryParams.subscribe(params => {
      const viewLetter = params["viewletter"];
     
      if (viewLetter) {
        this.selectLetterOpt = 'existing'
        this.onOptionSelect();
      }
      
    });
  }
  //Get Letter status original modified exist or not
  letterStatus() {
    this.spinnerLoad = false;

    let cpaUrl = '/fleet-letters-management/letters/v1/cpa_letter/' + this.proposalKey;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
    this.RestcallService.getData(cpaUrl).subscribe(data => {
      data != null ? this.cpaLetterMod = data.customerAcceptanceVo : this.cpaLetterMod = null;
      if (this.cpaLetterMod != null) {
        console.log(this.cpaLetterMod);
        this.selectLetterExist = this.cpaLetterMod.originalLetterExist;
        this.modLetterExist = this.cpaLetterMod.modifiedLetterExist;
        this.regenerateLetter = this.cpaLetterMod.regenerateLetter;
        if ((this.country == "MEX" && this.selectLetterExist == true && this.reportLevel == 6) ||
          (this.country == "MEX" && this.selectLetterExist == true && this.reportLevel == 7)) {
          this.selectLetterOpt = 'existing';
          this.selectionMessage = false;
          this.onOptionSelect();
        } else if ((this.country == "USA" && this.selectLetterExist == true && this.role == "ADM" ) || (this.country == "USA" && this.selectLetterExist == true && this.reportLevel == 7)
         ||  (this.country == "USA" && this.selectLetterExist == true && this.reportLevel == 6) ) {
          this.selectLetterOpt = 'existing';
          this.selectionMessage = false;
          this.onOptionSelect();
        } 
      }
    });


    //proposal Status APV
    // if (this.proposalStatus == 'APV') {
    //   if (this.regenerateLetter == false) {
    //     alert('Proposal is Approved, please re-generate CPA letter');
    //   }
    // }
  }
  onOptionSelect() {
    this.fileToUpload = null;
    if (this.selectLetterOpt == 'new') {
      if (this.selectLetterExist == true) {
        const dialogRef = this.dialog.open(CpaLetterNew, { width: '300px' });
        dialogRef.afterClosed().subscribe(data => {
          if (data == 'ok') {
            this.cpaLetterType = 'new';
            this.cpaNewOpts();
          } else {
            this.cpaLetterType = 'existing';
            this.selectLetterOpt = 'existing';
            this.cpaLetterRender();
          }
        });
      }
      else {
        this.cpaLetterType = 'new';
        this.cpaNewOpts();
      }
    } else if (this.selectLetterOpt == 'existing') {
      this.cpaLetterType = 'existing';
      this.cpaLetterRender()
    }

  }

  //CPA Rendering
  cpaLetterRender() {
    this.spinner = true;
    let docType;
    /* if (this.cpaLetterMod.physicalSignExist == true) {
      docType = 'custPhysicalSign';
    } else if (this.cpaLetterMod.physicalSignExist == false && this.cpaLetterMod.digitialSignExist == true) {
      docType = 'custDigitalSign';
    } else if (this.cpaLetterMod.digitialSignExist == false && this.cpaLetterMod.modifiedLetterExist == true) {
      docType = 'cpaLetterModified';
    } else if (this.cpaLetterMod.modifiedLetterExist == false && this.cpaLetterMod.originalLetterExist == true) {
      docType = 'cpaLetterOriginal';
    } else {
      docType = 'cpaLetterOriginal';
    } */
    if (this.cpaLetterMod.modifiedLetterExist == true) {
      docType = 'cpaLetterModified';
    } else {
      docType = 'cpaLetterOriginal';
    }
    this.cpaArray = [this.proposalKey, this.proposalStatus, this.proposalYear, docType]

    let uri = '/fleet-letters-management/s3/buckets/files/view' + '?cdsId=' + sessionStorage.getItem('loginId') + '&countryCd=' + sessionStorage.getItem('countryCode') + '&docType=' + docType + '&proposalKey=' + this.proposalKey + '&proposalStatus=' + this.proposalStatus + '&proposalYr=' + this.proposalYear;
    let endpoint = uri;


    let renderUrl = '/fleet-letters-management/downloads/buckets/files/view';
    let letterServiceUrl = this.RestcallService.orchestratorEndPoint + renderUrl + '?cdsId=' + sessionStorage.getItem('loginId') + '&countryCd=' + sessionStorage.getItem('countryCode') + '&docType=' + docType + '&proposalKey=' + this.proposalKey + '&proposalStatus=' + this.proposalStatus + '&proposalYr=' + this.proposalYear;

    let detsUrl = '/fleet-letters-management/letters/v1/cpa-letter-info';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("docType", docType);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
    this.RestcallService.getData(detsUrl).subscribe(data => {
      console.log(data);
      this.spinner = false;
      this.previewWordDocument(endpoint);
      data != null ? this.footerSection = data : this.footerSection = null;
      if (this.footerSection != null) {
        //letterApprovalStatus

        //Accept/Decline on behalf of customer
      }
      // this.letterStatus();
    });
    
  }

  //preview word document
  // previewWordDocument(endpoint) {
  //   this.commentLoad = true;
  //   this.http.get('../assets/img/WordXMLViewer.xsl', { responseType: 'text' }).subscribe(response => {
  //     let parser = new DOMParser();
  //     let xmlDoc = parser.parseFromString(response, "application/xml");
  //     this.wordXMLViewerText = xmlDoc
     
  //   });
  //   this.http.get('../assets/img/word2html.xsl', { responseType: 'text' }).subscribe(response => {
  //     let parser = new DOMParser();
  //     let xmlDoc = parser.parseFromString(response, "application/xml");
  //     this.wordhtmlText = xmlDoc
  //     this.xsltProcessor.importStylesheet(this.wordhtmlText);

  //   });

  //   this.RestcallService.getWordData(endpoint).subscribe(data => {
  //     this.responseText = data;
  //     let parserValue = new DOMParser();
  //     let xmlDocsValue = parserValue.parseFromString(this.responseText, "application/xml");
  //     this.xmlDoc = xmlDocsValue;
  //     const fragment = this.xsltProcessor.transformToFragment(this.xmlDoc, document);
  //     this.myDOM = fragment;
  //     this.commentLoad = false;
  //     this.selectionMessage = false;
  //     document.getElementById("previewCpaLetter")?.appendChild(fragment);
  //   });
  // }

  previewWordDocument(endpoint) {
  
    let myXMLHTTPRequest = new XMLHttpRequest();
    myXMLHTTPRequest.open("GET", "../assets/img/WordXMLViewer.xsl", false);
    myXMLHTTPRequest.overrideMimeType("text/xml");
    myXMLHTTPRequest.send(null);
    const xsltProcessor = new XSLTProcessor();
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(myXMLHTTPRequest.responseText, "application/xml");
    this.xslStylesheet = xmlDoc;
    // const xsltProcessor = new XSLTProcessor();
    xsltProcessor.importStylesheet(this.xslStylesheet);

    // load the xslt file, example1.xsl
    const myXMLHTTPRequestnew = new XMLHttpRequest();
    myXMLHTTPRequestnew.open("GET", "../assets/img/word2html.xsl", false);
    myXMLHTTPRequestnew.send(null);
    let parsers = new DOMParser();
    let xmlDocs = parsers.parseFromString(myXMLHTTPRequestnew.responseText, "application/xml");

    const xslStylesheetnew = xmlDocs;
    xsltProcessor.importStylesheet(xslStylesheetnew);

    myXMLHTTPRequest = new XMLHttpRequest();
    this.spinner = true;
    this.RestcallService.getWordData(endpoint).subscribe(data => {

      this.responseText = data;
      let parserValue = new DOMParser();
      let xmlDocsValue = parserValue.parseFromString(this.responseText, "application/xml");

      this.xmlDoc = xmlDocsValue;
      const fragment = xsltProcessor.transformToFragment(this.xmlDoc, document);
      this.myDOM = fragment;
      // if(this.newletterFlag == true) {
      //    document.getElementById("previewCpaLetter").innerHTML="";
      //    this.newletterFlag = false;
      // }
      this.spinner = false;
      const previewCpaLetterElement = document.getElementById("previewCpaLetter");
      if (previewCpaLetterElement != null) {
        previewCpaLetterElement.innerHTML="";
        previewCpaLetterElement.appendChild(fragment);
      }
    });



  }


  //Radio Button Options for letter template
  cpaNewOpts() {
    let tempUrl = '/fleet-letters-management/templates/v1/letter-templates';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.getData(tempUrl).subscribe(data => {
      data != null ? this.templateOptions = data.letterTemplateVo : this.templateOptions = null;
    });
  }

  //Expiration days Validation
  checkType() {
    if (isNaN(this.expDays) == true || this.expDays > 90 || this.expDays < 10) {
      this.typeCheck = true;
    } else {
      this.typeCheck = false;
    }
  }
  //Create new CPA letter by giving template code and attachment and Expiration
  generateNewLetter() {
    this.spinnerLoad = true;

    let letterType;
    this.newletterFlag = true;
    let tempSegment;
    if (this.selectOpt == 'TBLL' || this.selectOpt == 'COLL' || this.selectOpt == 'FMQL' || this.selectOpt == 'RELL' || this.selectOpt == 'THLL') {
      letterType = 'L'
    } else if (this.selectOpt == 'TBSL' || this.selectOpt == 'COSL' || this.selectOpt == 'RESL' || this.selectOpt == 'THSL') {
      letterType = 'S'
    }
    if (this.selectOpt == 'COLL' || this.selectOpt == 'COSL' || this.selectOpt == 'FMQL') {
      tempSegment = 'C';
    } else if (this.selectOpt == 'RELL' || this.selectOpt == 'RESL') {
      tempSegment = 'R';
    } else if (this.selectOpt == 'TBLL' || this.selectOpt == 'TBSL') {
      tempSegment = 'B';
    } else if (this.selectOpt == 'THLL' || this.selectOpt == 'THSL') {
      tempSegment = 'H';
    }
    let letterUrl = '/fleet-letters-management/letters/v1/cpa-letter';
    let attached = {
      "canadianFleetSelected": this.canadian,
      "currentProgramYearDefSelected": this.py1,
      "econolineVanSelected": this.econoline,
      "eftAttachment": this.eft,
      "franchiseDistrInstrSelected": this.franchisee,
      "letterOfAssignExampleSelected": this.example,
      "multiYearDealSelected": this.myDeal,
      "orderOutOfStockSelected": this.oos,
      "orderOutOfStockTruckSelected": this.oosCT,
      "previous1ProgramYearDefSelected": this.py2,
      "previous2ProgramYearDefSelected": this.py3,
      "repurchaseProgramExceptionSelected": this.repurchase
    };
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("expireDays", this.expDays);
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("letterType", letterType);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
    this.RestcallService.setQueryParams("templateCd", this.selectOpt);
    this.RestcallService.setQueryParams("templateSegment", tempSegment);
    this.RestcallService.createData(letterUrl, attached).subscribe(data => {
      this.letterStatus();
      this.cpaLetterType = 'existing';
      this.selectLetterOpt = 'existing';
    }, err => {
      this.RestcallService.statusMessage(417, "Letter not generated, please try again");
      this.spinnerLoad = false;
      // this.cpaLetterType = 'existing';
      // this.selectLetterOpt='existing';
      // this.letterStatus();
    });
  }

  //Open Exisitng Letter

  //download to word (type -> customerCopy or word)
  downloadCpaLetter(type) {
    console.log(this.cpaLetterMod);
    let isEditable;
    isEditable = false;
    let fileName = 'ProposalLetter.xml';
    let contentType = 'application/msword';
    if (type == 'word' || type == 'customerCopy') {
      let docType;

      if(type == 'word') {
        isEditable = true;
      }

      if (this.cpaLetterMod.modifiedLetterExist == true) {
        docType = 'cpaLetterModified';
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-Modified.xml'
        contentType = 'application/msword';
      } else if (this.cpaLetterMod.originalLetterExist == true) {
        docType = 'cpaLetterOriginal';
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-SystemGenerated.xml'
        contentType = 'application/msword';
      } else {
        docType = 'cpaLetterOriginal';
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-SystemGenerated.xml'
        contentType = 'application/msword';
      }
      type = docType;
    } else {
      if (type == 'custPhysicalSign') {
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-CustomerSigned.pdf'
        contentType = 'application/pdf';
      } else if (type == 'custDigitalSign') {
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-DigitalSigned.pdf'
        contentType = 'application/pdf';
      } else if (type == 'cpaLetterModified') {
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-Modified.xml'
        contentType = 'application/msword';
      } else {
        fileName = this.finCode + "-" + this.proposalYear + "-" + this.proposalVersion + '-SystemGenerated.xml'
        contentType = 'application/msword';
        isEditable = true;
      }
    }
    let downloadUrl = '/fleet-letters-management/s3/buckets/files/download';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("docType", type);
    this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
    this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
    this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
    this.RestcallService.setQueryParams("isEditable", isEditable);
    this.RestcallService.downloadCpaLetter(downloadUrl, contentType, fileName);
  }
  printComponent(divName) {
    const printContents = document.getElementById(divName).innerHTML;
    const WindowPrt = window.open('', '', 'left=0,top=0,width=900,height=900,toolbar=0,scrollbars=0,status=0');
    WindowPrt.document.write(printContents);
    WindowPrt.document.close();
    WindowPrt.focus();
    WindowPrt.print();
    WindowPrt.close();
    this.ngOnInit();
  }
  preview(letterType) {
    let previewUrl = '/fleet-administrations/letter-templates/v1/download';
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("tempCd", letterType);
    this.RestcallService.setQueryParams("tempId", 0);
    this.RestcallService.downloadCpaLetter(previewUrl, "application/msword", letterType + '.xml');
  }
  //Cancel
  closeDialog() {
    if (confirm('Cancelling will undo you action, do you want to continue?')) {
      this.openDialog = false;
      this.fileToUpload = null;
      this.cusotmerAction = false;
      this.cpaComments = "";
    }
  }

  //File Upload
  handleFileInput(files: FileList) {
    this.fileToUpload = files.item(0);
    console.log(this.fileToUpload)
  }
  //Upload comments
  uploadFileToActivity() {
    this.openDialog = true;
    this.cusotmerAction = false;
    this.cpaComments = "";
  }

  //Accept/Decline in customer behalf comments
  customerAction() {
    this.openDialog = true;
    this.cusotmerAction = true;
    this.cpaComments = "";

  }
  //Accept/Decline in customer behalf backend action -> accept/decline or Approver accept/decline -> user-'Approver or 'Customer'
  actionComment(user, action) {
    let docType;
    if (this.cpaLetterMod.modifiedLetterExist == true) {
      docType = 'cpaLetterModified';
    } else {
      docType = 'cpaLetterOriginal';
    }
    if (user == 'Approver') {
      let updateArray = {
        "apprAcceptComment": this.cpaComments,
        "apprStatus": action == 'Accept' ? 1 : 3,
        "proposalKey": this.proposalKey
      };
      let actionUrl = '/fleet-letters-management/approvals/v1/approver-accept-reject-comment';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("status", action);
      this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
      this.RestcallService.setQueryParams("docType", docType);
      this.RestcallService.updateData(actionUrl, JSON.stringify(updateArray)).subscribe(data => {
        this.selectLetterOpt = 'existing';
        this.onOptionSelect();
        this.openDialog = false;
        if (this.country == "USA") {
          window.location.href = '/accounts/proposal?proposalKey='+this.proposalKey+'&tab=6'+'&viewletter=true'
        } else {
          window.location.href = '/accounts/proposal?proposalKey='+this.proposalKey+'&tab=6'+'&viewletter=true'
        }

      });
    } else if (user == 'Customer') {
      let updateData = {
        "comment": this.cpaComments,
        "proposalKey": this.proposalKey
      }
      let actionUrl = '/fleet-letters-management/approvals/v1/customer-accept-decline';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("status", action);
      this.RestcallService.updateData(actionUrl, JSON.stringify(updateData)).subscribe(data => {
        this.selectLetterOpt = 'existing';
        this.onOptionSelect();
        this.openDialog = false;
        window.location.href = '/accounts/proposal?proposalKey='+this.proposalKey+'&tab=6'+'&viewletter=true'
        /*if (this.country == "USA") {
          window.location.href = '/accounts/proposal?proposalAssignee=' + this.proposalAssignee + '&proposalKey=' + this.proposalKey;
        } else {
          window.location.href = '/accounts/proposal?proposalAssignee=' + this.proposalAssignee + '&proposalKey=' + this.proposalKey;
        }*/
      });
    }
   

  }
  //Approver accept/decline comments after customer accept
  approverAction() {
    this.openDialog = true;
    this.cusotmerAction = true;
    this.cpaComments = "";
  }
  uploadLetter() {
    let docType;
    if(this.proposalStatus == "EST" && this.fileToUpload.type != "application/pdf") {
      this.RestcallService.statusMessage("417", "Invalid file type");
    } else if(this.proposalStatus == "APV" && this.fileToUpload.type != "text/xml") {
      this.RestcallService.statusMessage("417", "Invalid file type");
    } else {
      if (this.proposalStatus == "EST") {
        this.spinner = true;
        docType = 'custPhysicalSign';
      } else if (this.proposalStatus == "APV") {
        this.spinner = true;
        docType = 'cpaLetterModified';
      }
      if (this.cpaComments == "") {
        this.cpaComments = null;
      }
      let uploadUrl = '/fleet-letters-management/s3/buckets/files/upload';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("comments", this.cpaComments);
      this.RestcallService.setQueryParams("docType", docType);
      this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
      this.RestcallService.setQueryParams("proposalStatus", this.proposalStatus);
      this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
      this.RestcallService.setQueryParams("proposalYrVer", this.proposalVersion);
      this.RestcallService.setQueryParams("finCd", this.finCode);
      this.RestcallService.uploadFile(uploadUrl, this.fileToUpload, 'file', '').subscribe(data => {
        this.RestcallService.statusMessage(200, 'CPA letter upload success');
        this.newletterFlag = true;
        this.selectLetterOpt = 'existing';
        this.letterStatus();
        this.openDialog = false;
        this.cpaComments = "";
        this.spinner = false;
      }, err => {
        this.openDialog = false;
        this.RestcallService.statusMessage(417, 'CPA letter upload failed, try again after sometime');
        console.log(err);
      });
    }
  }

  deleteUpload() {

    // this.spinner = true;
    const dialogRef = this.dialog.open(CpaDeleteUpload, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'ok') {
        let deleteUrl = '/fleet-letters-management/s3/buckets/files';
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams("docType", 'cpaLetterModified');
        this.RestcallService.setQueryParams("proposalKey", this.proposalKey);
        this.RestcallService.setQueryParams("proposalYr", this.proposalYear);
        this.RestcallService.deleteData(deleteUrl).subscribe(data => {
          this.selectLetterOpt = 'existing';
          this.newletterFlag = true;
          this.letterStatus();
          // this.spinner = false;
        });
      }
    });
  }

  loadSendEmailModel() {
    let emailUrl = '/fleet-letters-management/letters/v1/submit' + '?cdsId=' +
    sessionStorage.getItem('loginId') + '&countryCd=' + sessionStorage.getItem('countryCode') +
    '&finCd=' + this.finCode + '&finKey=' + this.finKey + '&proposalKey=' + this.proposalKey + '&proposalYr=' + this.proposalYear +
    '&proposalYrVer=' + this.proposalVersion;
    this.RestcallService.getWordData(emailUrl).subscribe(data => {
      let response = JSON.parse(data);
      this.fromAddress = response.emailRequestVo.sender;
      this.toAddress = response.emailRequestVo.to;
      this.subject = response.emailRequestVo.subject;
      this.emailText = response.emailRequestVo.content.replace('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN"><HTML><HEAD><META http-equiv=Content-Type content="text/html; charset=utf-8"></HEAD><BODY>', '').replace('</BODY></HTML>', '').replace("<p align='left'>null</p>","");
     this.openEmailDialog = true;
    });
  }

  closeModeWindow() {
    this.openEmailDialog = false;
  }

  setFocus() {
    document.getElementById('popupHidden').focus();
  }

  sendEmail() {
    // this.spinner = true;
    let emailUrl = '/fleet-letters-management/letters/v1/email' + '?cdsId=' +
      sessionStorage.getItem('loginId') + '&countryCd=' + sessionStorage.getItem('countryCode') +
      '&finCd=' + this.finCode + '&finKey=' + this.finKey + '&from=' + this.fromAddress +
      '&proposalKey=' + this.proposalKey + '&proposalYr=' + this.proposalYear + '&proposalYrVer=' + this.proposalVersion + '&subject=' + this.subject + '&to=' + this.toAddress;
      let reqBody = {
        "comments": this.emailComments
      }

      this.RestcallService.createEmailData(emailUrl, JSON.stringify(reqBody)).subscribe(data => {
        this.openEmailDialog = false;
        this.RestcallService.statusMessage('201', "Email has been sent successfully.")
        this.spinner = false;
      });

  }

}



@Component({
  selector: 'cpa-letter-new',
  templateUrl: 'cpa-letter-new.html',
})
export class CpaLetterNew {
  constructor(
    public dialogRef: MatDialogRef<CpaLetterNew>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close('cancel');
  }
}

@Component({
  selector: 'cpa-delete-upload',
  templateUrl: 'cpa-delete-upload.html',
})
export class CpaDeleteUpload {
  constructor(
    public dialogRef: MatDialogRef<CpaDeleteUpload>, @Inject(MAT_DIALOG_DATA) public data: any) {
  }
  onYesClick() {
    this.dialogRef.close('ok');
  }
  onNoClick(): void {
    this.dialogRef.close('cancel');
  }
}