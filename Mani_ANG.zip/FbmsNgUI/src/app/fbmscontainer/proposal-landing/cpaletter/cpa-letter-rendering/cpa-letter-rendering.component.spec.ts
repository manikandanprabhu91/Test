import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CpaLetterRenderingComponent } from './cpa-letter-rendering.component';

describe('CpaLetterRenderingComponent', () => {
  let component: CpaLetterRenderingComponent;
  let fixture: ComponentFixture<CpaLetterRenderingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CpaLetterRenderingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CpaLetterRenderingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
