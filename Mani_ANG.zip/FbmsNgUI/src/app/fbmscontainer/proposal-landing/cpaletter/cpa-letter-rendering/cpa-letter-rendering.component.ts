import { Component, OnInit, Input } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { RestcallService } from 'src/app/services/restcall.service';


@Component({
  selector: 'cpa-letter-rendering',
  templateUrl: './cpa-letter-rendering.component.html',
  styleUrls: ['./cpa-letter-rendering.component.sass']
})

export class CpaLetterRenderingComponent implements OnInit {
  letterRenderUrl: any;
  letterData: any;
  @Input() cpaArray: any;
  constructor(private RestcallService: RestcallService, private sanitizer: DomSanitizer) { }
  
  ngOnInit(): void {
    
  }
}
