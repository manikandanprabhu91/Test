import { Component, OnInit, Input, Inject, ViewChild } from '@angular/core';
import { RestcallService } from '../../../services/restcall.service';
import { FormControl, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Table } from 'primeng/table';
import { ExportsService } from 'src/app/services/exports.service';

@Component({
  selector: 'proposal-comments',
  templateUrl: './proposal-comments.component.html',
  styleUrls: ['../../fbmscontainer.component.sass']
})
export class ProposalCommentsComponent implements OnInit {
  public isReadMore: boolean = true;
  show: any[];
  expand: boolean = true;
  configUrl: string;
  commentsData: any = [];
  yearDropdown: any;
  versionDropdown: any;
  commentedbyDropdown: any;
  proposalYearSelect: any;
  proposalVersionSelect: any;
  commentedBySelect: any;
  commentTableValues: any;
  editComment: any;
  addnewrow: boolean;
  newcommentedBy: any;
  newproposalYear: number;
  newproposalVersion: number;
  newDate: any;
  newproposalComments: FormControl;
  totalCount: number;
  parentProposalYear: number;
  parentFinkey: number;
  parentProposalVersion: number;
  parentProposalkey: number;
  parentProposalStatus: any;
  loading: boolean;
  cdsId: string;
  propCdsId: any;
  role: any;
  reportLevel: any;
  commentNewAs: boolean;
  commentUpdateAs: boolean;
  commentChangeCheck: any;
  argProposalNoteKey: any;
  argEditComment: any;
  showExpand: boolean = false;
  // accountName:any;
  accountName: string;
  finCode: string;
  status: string;
  inprogressFlag: boolean;

  @Input() proposalArray: number;
  @ViewChild(Table) templateRight: Table;
  constructor(private RestCallService: RestcallService, private datePipe: DatePipe, private snackBar: MatSnackBar, private dialog: MatDialog, private exportExcel: ExportsService) { }

  ngOnInit(): void {
    this.commentNewAs = false;
    this.commentUpdateAs = false;
    this.loading = true;
    this.role = sessionStorage.getItem('roleName');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.parentFinkey = this.proposalArray[1];
    this.parentProposalkey = this.proposalArray[0];
    this.parentProposalYear = this.proposalArray[2];
    this.parentProposalVersion = this.proposalArray[3];
    this.parentProposalStatus = this.proposalArray[4];
    this.propCdsId = this.proposalArray[6];
    this.accountName = this.proposalArray[7];
    this.finCode = this.proposalArray[8];
    this.status = this.proposalArray[9];
    this.cdsId = sessionStorage.getItem('loginId');

    this.newcommentedBy = sessionStorage.getItem('loginId');
    this.newproposalVersion = this.parentProposalVersion;
    this.newproposalYear = this.parentProposalYear;
    this.newDate = new Date;
    this.newDate = this.datePipe.transform(this.newDate, 'MM/dd/yyyy');
    this.newproposalComments = new FormControl('', [Validators.required, Validators.maxLength(2000)]);
    this.newproposalComments.valueChanges.subscribe(data => this.commentNewAs = true);
    this.proposalVersionSelect = 0;
    this.proposalYearSelect = 0;
    this.commentedBySelect = 0;
    this.configUrl = '/fleet-notes-management/notes/v1/proposal-comments';
    this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("finKey", this.parentFinkey);
    this.RestCallService.getData(this.configUrl).subscribe(respData => respData != null ? this.mapDropdown(respData.proposalNotesRetrival) : this.loading = false, err => this.mapDropdown(null));
  }

  mapDropdown(respData) {
    if (respData[0].inProcess) {
      this.commentsData = respData;
      this.commentsData.map(data => {
        if (data.inProcess == 'Y' && (this.parentProposalStatus == 'NEW' || 'REV') && this.newcommentedBy == data.commentedBy) {
          this.editComment = data.proposalComments;
          this.commentChangeCheck = data.proposalComments;
        }
      });
      this.yearDropdown = (this.commentsData.map(data => data['proposalYear']).filter((value, index, self) => self.indexOf(value) === index)).sort((a, b) => a - b);
      this.yearDropdown = this.yearDropdown.reverse();
      this.versionDropdown = (this.commentsData.map(data => data['proposalVersion']).filter((value, index, self) => self.indexOf(value) === index)).sort((a, b) => a - b);
      this.versionDropdown = this.versionDropdown.reverse();
      this.commentedbyDropdown = (this.commentsData.map(data => data['commentedBy']).filter((value, index, self) => self.indexOf(value) === index)).sort();
      this.commentedbyDropdown = this.commentedbyDropdown.reverse();
      this.searchValues();
    }
    else {
      this.commentsData = null;
    }
  }
  commentEditCheck(argEditComment, argProposalNoteKey) {
    if (this.commentChangeCheck != this.editComment) {
      this.argEditComment = argEditComment;
      this.argProposalNoteKey = argProposalNoteKey;
      this.commentUpdateAs = true;
    }
  }
  changeDropdownVals(changedLabel, changedVal) {
    if (changedLabel == 'proposalYearSelect') {
      let versionValues = [];
      let commentedbyValues = [];
      this.commentsData.map(data => {
        if (data['proposalYear'] == changedVal || changedVal == 0) {
          versionValues.push(data['proposalVersion']);

        }
      });
      this.versionDropdown = versionValues.filter((value, index, self) => self.indexOf(value) === index).sort((a, b) => a - b).reverse();
      this.proposalVersionSelect = this.versionDropdown[0];
      if (changedVal != 0) {
        this.commentsData.map(data => {
          if (data['proposalYear'] == changedVal) {
            commentedbyValues.push(data['commentedBy']);
          }
        });
        this.commentedbyDropdown = commentedbyValues.filter((value, index, self) => self.indexOf(value) === index).sort().reverse();
      } else {
        this.commentedbyDropdown = (this.commentsData.map(data => data['commentedBy']).filter((value, index, self) => self.indexOf(value) === index)).sort();
        this.commentedbyDropdown = this.commentedbyDropdown.reverse();
      }

      this.commentedBySelect = 0;
      this.proposalVersionSelect = 0;
    } else if (changedLabel == 'proposalVersionSelect') {
      let commentedbyValues = [];
      this.commentsData.map(data => {
        if ((changedVal == 0 ? this.proposalYearSelect == 0 ? changedVal == 0 : (changedVal == 0 && this.proposalYearSelect == data.proposalYear) : this.proposalYearSelect == 0 ? data['proposalVersion'] == changedVal : (data['proposalYear'] == 0 ? data['proposalVersion'] == changedVal : data['proposalVersion'] == changedVal && data['proposalYear'] == this.proposalYearSelect))) {
          commentedbyValues.push(data['commentedBy']);
        }
      });
      this.commentedbyDropdown = commentedbyValues.filter((value, index, self) => self.indexOf(value) === index).sort().reverse();
      this.commentedBySelect = 0;
    }

  }
  searchValues() {
    this.templateRight.reset();

    this.loading = true;
    this.commentTableValues = [];
    let isInprogress = false;
    if (this.proposalYearSelect == 0 && this.proposalVersionSelect == 0 && this.commentedBySelect == 0) {
      this.commentsData.map(data => {
        if (this.parentProposalYear == data.proposalYear && 
          this.parentProposalVersion == data.proposalVersion) {
            if(isInprogress == false) {
              if ((this.parentProposalStatus == "NEW" && data.status == "NEW") ||
              (this.parentProposalStatus == "REV" && data.status == "REV")) {
                data.inProcess = "Y";
                this.editComment = data.proposalComments;
                isInprogress = true;
              } else {
                data.inProcess = "N";
              }
             
              // this.editComment = data.proposalComments;
            }else {
              // this.editComment = data.proposalComments;
              // this.commentChangeCheck = data.proposalComments;
              data.inProcess = "N";
            }
           
          } else {
            if(isInprogress == false) {
              this.editComment = "";
            } 
            data.inProcess = "N";
        }

        this.commentTableValues.push({
          "proposalNoteKey": data.proposalNoteKey,
          "proposalYear": data.proposalYear,
          "proposalVersion": data.proposalVersion,
          "commentedBy": data.commentedBy,
          "dateSubmitted": data.dateSubmitted,
          "proposalComments": data.proposalComments,
          "inProcess": data.inProcess
        })
      });
      this.commentTableValues = this.commentsData.sort((a, b)=> b.inProcess.localeCompare(a.inProcess));
    
    } else {
      this.commentTableValues = [];
      this.commentsData.map(data => {
        if (data.proposalYear == this.proposalYearSelect && data.proposalVersion == this.proposalVersionSelect && data.commentedBy == this.commentedBySelect) {
          if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
            if (isInprogress) {
              data.inProcess = "Y";
              isInprogress = false;
            } else {
              data.inProcess = "N";
            }
  
          } else {
            if(data.dummy == 0) {
              data.inProcess = "Y";
              isInprogress = false;
            }
            if(isInprogress) {
              this.editComment = "";
            }
            data.inProcess = "N";
          }
          this.commentTableValues.push({
            "proposalNoteKey": data.proposalNoteKey,
            "proposalYear": data.proposalYear,
            "proposalVersion": data.proposalVersion,
            "commentedBy": data.commentedBy,
            "dateSubmitted": data.dateSubmitted,
            "proposalComments": data.proposalComments,
            "inProcess": data.inProcess
          });
        } else if (this.proposalYearSelect == 0 || this.proposalVersionSelect == 0 || this.commentedBySelect == 0) {
          if (this.proposalYearSelect == 0) {
            if (this.proposalVersionSelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;

              this.commentsData.map(data => {
                if (data.commentedBy == this.commentedBySelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else if (this.commentedBySelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;

              this.commentsData.map(data => {
                if (data.proposalVersion == this.proposalVersionSelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else {
              this.commentTableValues = [];
              let isInprogress = true;
              this.commentsData.map(data => {
                if (data.proposalVersion == this.proposalVersionSelect && data.commentedBy == this.commentedBySelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {

                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            }
          }
          else if (this.proposalVersionSelect == 0) {
            if (this.proposalYearSelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;
              this.commentsData.map(data => {
                if (data.commentedBy == this.commentedBySelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else if (this.commentedBySelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;
              this.commentsData.map(data => {
                if (data.proposalYear == this.proposalYearSelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else {
              this.commentTableValues = [];
              let isInprogress = true;
              this.commentsData.map(data => {
                if (data.proposalYear == this.proposalYearSelect && data.commentedBy == this.commentedBySelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            }
          }
          else if (this.commentedBySelect == 0) {
            if (this.proposalYearSelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;
              this.commentsData.map(data => {
                if (data.proposalVersion == this.proposalVersionSelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else if (this.proposalVersionSelect == 0) {
              this.commentTableValues = [];
              let isInprogress = true;

              this.commentsData.map(data => {
                if (data.proposalYear == this.proposalYearSelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }

                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            } else {
              this.commentTableValues = [];
              let isInprogress = true;

              this.commentsData.map(data => {
                if (data.proposalVersion == this.proposalVersionSelect && data.proposalYear == this.proposalYearSelect) {
                  if (this.parentProposalYear == data.proposalYear && this.parentProposalVersion == data.proposalVersion) {
                    if (isInprogress) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    } else {
                      data.inProcess = "N";
                    }
          
                  } else {
                    if(data.dummy == 0) {
                      data.inProcess = "Y";
                      isInprogress = false;
                    }
                    
                    if(isInprogress) {
                      this.editComment = "";
                    }
                    data.inProcess = "N";
                  }
                  this.commentTableValues.push({
                    "proposalNoteKey": data.proposalNoteKey,
                    "proposalYear": data.proposalYear,
                    "proposalVersion": data.proposalVersion,
                    "commentedBy": data.commentedBy,
                    "dateSubmitted": data.dateSubmitted,
                    "proposalComments": data.proposalComments,
                    "inProcess": data.inProcess
                  });
                }
              });
            }
          }
        }
      });
    }

     for (let val of this.commentTableValues) {
      if (val.proposalComments.length > 180) {
        this.showExpand = true;
        break;
      }
    }
    this.totalCount = this.commentTableValues.length;
    this.loading = false;
    this.show = new Array(this.totalCount);
    this.expand = true;
    for (let i = 0; i < this.show.length; i++) {
      this.show[i] = !this.expand;

    }

  }
  expandAll() {
    for (let i = 0; i < this.show.length; i++) {
      this.show[i] = this.expand;
    }
    this.expand = !this.expand;
  }

  addnew() {
    this.addnewrow = true;
  }

  cancel() {
    const dialogRef = this.dialog.open(CancelConfirmDialog, { width: '300px' });
    dialogRef.afterClosed().subscribe(data => {
      if (data == 'cancel') {
        this.commentNewAs = false;
        this.commentUpdateAs = false;
        this.addnewrow = false;
        this.editComment = '';
        this.newproposalComments = new FormControl('', [Validators.required, Validators.maxLength(2000)]);
        this.commentsData.map(data => data.inProcess == 'Y' ? this.editComment : '');
        this.ngOnInit();
      }
    });
  }

  newSave() {
    let saveArray = {
      "cdsid": this.newcommentedBy,
      "inProcess": 'Y',
      "proposalKey": this.parentProposalkey,
      "proposalNoteDescription": this.newproposalComments.value,
      "statusCd": "NEW"
    };
    let saveUrl = "/fleet-notes-management/notes/v1/proposal-comments";
    this.RestCallService.ngOnInit();
    this.RestCallService.createData(saveUrl, JSON.stringify(saveArray)).subscribe(data => {
       this.addnewrow = false; 
       this.ngOnInit()
       });
  }

  updateItem(editComment, proposalNoteKey) {
    let updateArray = {
      "cdsid": this.newcommentedBy,
      "inProcess": 'Y',
      "proposalNoteDescription": editComment,
      "proposalNoteKey": proposalNoteKey,
      "proposalstatus": this.parentProposalStatus,
    }
    let updateUrl = '/fleet-notes-management/notes/v1/proposal-comments';
    this.RestCallService.ngOnInit();
    this.RestCallService.updateData(updateUrl, JSON.stringify(updateArray)).subscribe(data => {
       this.addnewrow = false;
       this.ngOnInit(); 
      });
  }

  excelDownload() {
    let downloadData = [];
    let topheader = [];
    let headers = [];
    let title = [];

    headers.push({
      '': 'Program Year',
      ' ': 'Version', '  ': 'CDSID', '   ': 'Date Submitted', '    ': 'Comments'
    });

    this.commentTableValues.map(data => {
      downloadData.push({
        "Program Year": data.proposalYear,
        "Version": data.proposalVersion,
        "CDSID": data.commentedBy,
        "Date Submitted": data.dateSubmitted,
        "Comments": data.proposalComments,
      });
    });

    const year = this.proposalYearSelect == 0 ? 'ALL' : this.proposalYearSelect;
    const version = this.proposalVersionSelect == 0 ? 'ALL' : this.proposalVersionSelect;
    const pyVersion = this.parentProposalYear + '-' + this.parentProposalVersion;
    const statusValue = this.parentProposalStatus + ' on ' + this.status;
    this.exportExcel.exportAsExcelFile(downloadData, 'ProposalComments', topheader,
      headers, title, this.accountName, this.finCode, pyVersion, statusValue, year, version);
  }

}


@Component({
  selector: 'cancel-confirm-dialog',
  templateUrl: 'cancel-confirm-dialog.html',
})
export class CancelConfirmDialog {
  constructor(
    public dialogRef: MatDialogRef<CancelConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  onYesClick() {
    this.dialogRef.close('cancel');
  }
  onNoClick(): void {
    this.dialogRef.close();
  }
}
