import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'actiondialog',
  templateUrl: './actiondialog.component.html',
  styleUrls: ['./actiondialog.component.sass']
})
export class ActiondialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
