import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatMenuTrigger } from '@angular/material/menu';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RestcallService } from '../services/restcall.service';
import { ActiondialogComponent } from './actiondialog/actiondialog.component';
import { DatePipe } from '@angular/common';
import { ExportsService } from '../services/exports.service';
import { ActivatedRoute } from 'src/testing/router-stubs';


@Component({
  selector: 'fbmscontainer',
  templateUrl: './fbmscontainer.component.html',
  styleUrls: ['./fbmscontainer.component.sass']
})
export class FbmscontainerComponent {
  @ViewChild('menuTrigger') menuTrigger: MatMenuTrigger;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  //Starts
  configUrl: string;
  dropdownValues: [];
  operationalValue: [];
  programYear: [];
  accountStatus: [];
  opvSelected: any;
  dpdSelected: any;
  dpdText: any;
  // subSegmentSelected: any;
  // subSegmentDisplay: boolean = true;
  pySelected: any;
  statusSelected: any;
  includeProposal = false;
  includeSubfin = false;
  dependentdropdown: any;
  textBox = false;
  accountTableValues: any[];
  totalCount: number;
  today: any;
  loading: boolean;
  subfinMod: any;
  loginId: any;
  roleName: any;
  reportLevel: any;
  country: any;
  searchOpt: any;
  searchFinVal: any;
  searchAccountVal: any;
  controlProgram: any;
  cpymy: any;
  proposalAssignee:any;
  //dataSource: MatTableDataSource<any>;
  //displayedColumns: string[] = ["action","accountName", "fin", "programYear", "autoEarly","version","subfin", "status", "proposal", "metrics", "contactinfo"];

  constructor(private RestcallService: RestcallService, private route: ActivatedRoute, public dialog: MatDialog, private datePipe: DatePipe, private exportExcel: ExportsService) {
  }

  ngOnInit(): void {
    //Remove sidebar-collapse
    document.body.className = document.body.className.replace('sidebar-collapse', '');
    //Routersnapshot
    
    this.searchOpt = this.route.snapshot.queryParamMap.get('option');
    this.searchAccountVal = this.route.snapshot.queryParamMap.get('account');
    this.searchFinVal = this.route.snapshot.queryParamMap.get('fin');
    this.loading = true;
    this.loginId = sessionStorage.getItem('loginId');
    this.roleName = sessionStorage.getItem('roleName');
    this.country = sessionStorage.getItem('countryCode');
    this.reportLevel = sessionStorage.getItem('reportLvlCd');
    this.proposalAssignee=sessionStorage.getItem("proposalAssignee");	  
    this.cpymy = null;
    //clearing history session
    if(sessionStorage.getItem("history") == "History"){
			sessionStorage.setItem("proposalKey", "");
			sessionStorage.setItem("finKey", "");
			sessionStorage.setItem("proposalYear", "");
      sessionStorage.setItem("accountName", "");
      sessionStorage.setItem("history", "") ;
    
			sessionStorage.setItem("vernumR", "");	
			sessionStorage.setItem("finCd", "");
    }
    //To check current proposal year from control program year
    let controlUrl = '/fleet-administrations/program-years/v1/control-proposal-year';
    this.RestcallService.ngOnInit();
    this.RestcallService.getData(controlUrl).subscribe(data => {
      data == null || data == "" ? this.controlProgram = null : this.controlProgram = data.controlProposalYearDtoList;
      this.loading = false;
      if (this.controlProgram != null) {
        this.cpymy = null;
        this.controlProgram.map(val => {
          if (val.currentProposalYearFlag == 'Y') {
            this.cpymy = "" + val.proposalYearCode;
          }
        });
      }
    }, err => { this.loading = false; this.controlProgram = null });
    this.configUrl = "/fleet-lookups/proposal-lookups/v1/operational-view-data";
    this.RestcallService.ngOnInit();
    // this.configUrl = "/operationalViewData";
    this.RestcallService.getData(this.configUrl).subscribe(dataSet => this.mapDropdownValues(dataSet));

  }
  //mapping the values to dropdown
  mapDropdownValues(dataSet) {
    this.today = new Date;
    this.today = this.datePipe.transform(this.today, 'yyyy');
    this.dropdownValues = dataSet;
    this.operationalValue = this.dropdownValues['operationalViewList'];
    this.programYear = this.dropdownValues['programYear'];
    this.accountStatus = this.dropdownValues['proposalStatusList'];
    this.searchOpt == 'account' ? this.opvSelected = this.dropdownValues['operationalViewList'][4] :
      this.searchOpt == 'fin' ? this.opvSelected = this.dropdownValues['operationalViewList'][0] :
        this.opvSelected = this.dropdownValues['operationalViewList'][1];
    if (this.cpymy != null) {
      this.dropdownValues['programYear'].includes(this.cpymy) == true ? this.pySelected = this.cpymy : this.pySelected = this.dropdownValues['programYear'][1]
    } else {
      this.dropdownValues['programYear'].includes(this.today) == true ? this.pySelected = this.today : this.pySelected = this.dropdownValues['programYear'][0]
    }

    this.statusSelected = this.dropdownValues['proposalStatusList'][0];
    this.dpdvalueSet(this.opvSelected);
    if(this.searchOpt == null){
     if (Object.keys(this.RestcallService.accountFilter).length > 0) {
      this.opvSelected = this.RestcallService.accountFilter.opvSelected;
      this.dpdvalueSet(this.opvSelected);
      this.dpdSelected = this.RestcallService.accountFilter.dpdSelected;
      this.pySelected = this.RestcallService.accountFilter.pySelected;
      this.statusSelected = this.RestcallService.accountFilter.statusSelected;
      this.includeProposal = this.RestcallService.accountFilter.includeProposal;
      this.includeSubfin = this.RestcallService.accountFilter.includeSubfin;
     }
    }
    this.ddSearch(this.opvSelected, this.dpdSelected, this.pySelected, this.statusSelected, this.includeProposal, this.includeSubfin);
  }
  dpdvalueSet(opvSelected) {
    this.textBox = false;
    if(opvSelected=='Segment'){
      this.statusSelected = this.dropdownValues['proposalStatusList'][1];
    }else{
      this.statusSelected = this.dropdownValues['proposalStatusList'][0];
    }
    if (this.cpymy != null) {
      this.dropdownValues['programYear'].includes(this.cpymy) == true ? this.pySelected = this.cpymy : this.pySelected = this.dropdownValues['programYear'][1]
    } else {
      this.dropdownValues['programYear'].includes(this.today) == true ? this.pySelected = this.today : this.pySelected = this.dropdownValues['programYear'][0]
    }
    opvSelected == 'Account Manager' ? (this.dependentdropdown = this.dropdownValues['accountManagerList']) && (this.dpdSelected = this.dropdownValues['accountManagerList'].includes(sessionStorage.getItem('loginId')) == true ? sessionStorage.getItem('loginId') : this.dropdownValues['accountManagerList'][0] || this.dropdownValues['accountManagerList'][0]) :
      opvSelected == 'Region' ? (this.dependentdropdown = this.dropdownValues['regionMangerList']) && (this.dpdSelected = this.dropdownValues['regionMangerList'][0]) :
        opvSelected == 'Segment' ? (this.dependentdropdown = this.dropdownValues['segmentGroupTypeList']) && (this.dpdSelected = this.dropdownValues['segmentGroupTypeList'][0].segmentGroupTypeCode) :
          opvSelected == 'Account Name' || opvSelected == 'FIN' ? (this.textBox = true) && (this.dpdSelected = '') : '';
    opvSelected == 'FIN' ? this.pySelected = this.dropdownValues['programYear'][0] : '';
    opvSelected == 'Account Name' ? this.pySelected = this.dropdownValues['programYear'][0] : '';

    if (this.searchOpt != null) {
      this.searchOpt == 'account' ? this.dpdSelected = this.searchAccountVal : this.searchOpt == 'fin' ? this.dpdSelected = this.searchFinVal : '';
    }
  }
  ddSearch(opv, dpd, py, stat, prop, subfin) {
    this.loading = true;
    if(sessionStorage.getItem("optionsel") == "Option") {
      opv = sessionStorage.getItem("opvSelectedSel");
      dpd = sessionStorage.getItem("dpdSelectedSel");
      py = sessionStorage.getItem("pySelectedSel");
      stat = sessionStorage.getItem("statusSelectedSel");
      // prop = sessionStorage.getItem("propSelectedSel");
      // subfin = sessionStorage.getItem("subfinSelectedSel");
      this.dpdSelected = dpd;
      this.pySelected = py;
      this.statusSelected = stat;
      // this.includeSubfin = subfin;
      sessionStorage.setItem("optionsel", "");
    } else {
      sessionStorage.setItem("dpdSelectedSel", dpd);
      sessionStorage.setItem("pySelectedSel", py);
      sessionStorage.setItem("statusSelectedSel", stat);
      sessionStorage.setItem("opvSelectedSel", opv);
      // sessionStorage.setItem("propSelectedSel", prop);
      // sessionStorage.setItem("subfinSelectedSel", subfin);
    }
    let accountconfigUrl = "/fleet-lookups/proposal-lookups/v1/proposals";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('includeAssignedAccounts', prop);
    this.RestcallService.setQueryParams('includeSubFins', subfin);
    this.RestcallService.setQueryParams('operationalViewType', opv);
    this.RestcallService.setQueryParams('operationalViewTypeValue', dpd);
    this.RestcallService.setQueryParams('proposalStatus', stat);
    this.RestcallService.setQueryParams('proposalYear', py);

    // let accountconfigUrl = '/accountView';
    this.RestcallService.accountFilter.opvSelected = opv;
    this.RestcallService.accountFilter.dpdSelected = dpd;
    this.RestcallService.accountFilter.pySelected = py;
    this.RestcallService.accountFilter.statusSelected = stat;
    this.RestcallService.accountFilter.includeProposal = prop;
    this.RestcallService.accountFilter.includeSubfin = subfin;
    this.RestcallService.getData(accountconfigUrl).subscribe(tableData => {
      this.accountTableValues = tableData as any;
      tableData != null && tableData != {} ? this.accountTableValues = this.accountTableValues['accountView'] : this.accountTableValues = null;
      if (this.accountTableValues != null) {
        this.accountTableValues.forEach(data => {
          data.subfinMod = data.subFinExists == 1 ? 'Y' : data.subFinExists == 0 ? 'N' : null;
        })
      }
      this.loading = false;

      //this.dataSource = new MatTableDataSource(this.accountTableValues);
      //this.dataSource.paginator = this.paginator;
      // this.dataSource.sort = this.sort;
    }, err => {
      this.accountTableValues = null;
      this.loading = false;
    });
  }

  //Dialog box
  openDialog() {
    const dialogRef = this.dialog.open(ActiondialogComponent, { panelClass: 'myapp-no-padding-dialog', width: '150px', restoreFocus: false, disableClose: false });
    // Manually restore focus to the menu trigger since the element that
    // opens the dialog won't be in the DOM any more when the dialog closes.
    dialogRef.afterClosed().subscribe(() => this.menuTrigger.focus());
  }

  downloadExcel() {
    let downloadData = [];
    let topheader = [];
    let headers = [];
    let title = [];

    topheader.push({
      '': 'Proposal Year',
      ' ': this.pySelected,
      '  ': 'Status',
      '   ': this.statusSelected,
      '    ': 'Account Manager',
      '      ': sessionStorage.getItem('loginId')
    });


    this.accountTableValues.map(data => {

      downloadData.push(Object.values({
        "Action": '',
        "Account Name": data.acctName,
        "FIN": data.finCode,
        "Proposal Year": data.proposalYear,
        "Version": data.vernumR,
        "Sub-Fin Included": data.subfinMod,
        "Status": data.proposalStatus,
        "Proposal Assignee": data.cdsidProposal,
        "Metrics Assignee": data.cdsidMetrics,
        "Contact Info Assignee": data.cdsidContact
      }));
    });
    headers.push({
      '': 'Action',
      ' ': 'Account Name', '  ': 'FIN', '   ': 'Proposal Year', '    ': 'Version',
      '     ': 'Sub-Fin Included', '      ': 'Status', '       ': 'Proposal Assignee',
      '        ': 'Metrics Assignee', '         ': 'Contact Info Assignee'
    });
    // headers.push(header);
    // let finalDownload = [];

    // finalDownload = [{
    //   "Proposal Year : ": this.pySelected,
    //   "Status : ": this.statusSelected,
    //   "Account Manager : ": sessionStorage.getItem('loginId'),
    //   "Serch Values": downloadData
    //   }
    // ]
    this.exportExcel.exportAsExcelFile(downloadData, 'AccountsHome', topheader, headers, title, '',
		'', '', '', '', '');
  }


}
