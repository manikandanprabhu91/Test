import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'multiselectdropdown',
  templateUrl: './multiselectdropdown.component.html',
  styleUrls: ['./multiselectdropdown.component.scss']
})
export class MultiselectdropdownComponent {
 
  @Input() list!:any[]; 
  @Input() checkedList!:any[]; 

    
  @Output() shareCheckedList = new EventEmitter();
  @Output() shareIndividualCheckedList = new EventEmitter();
  
  //checkedList: any[];
  currentSelected! : {};
  showDropDown:boolean = true;
  
  constructor(){
     // this.checkedList = ['fff','rrr','vvv']
  }
  getSelectedValue(status:Boolean,value:String){
      if(status){
        this.checkedList.push(value);  
      }else{
          var index = this.checkedList.indexOf(value);
          this.checkedList.splice(index,1);
      }
      
      this.currentSelected = {flag : status,indicatorname:value};

      //share checked list
      this.shareCheckedlist();
      
      //share individual selected item
      this.shareIndividualStatus();
  }
  shareCheckedlist(){
       this.shareCheckedList.emit(this.checkedList);
  }
  shareIndividualStatus(){
      this.shareIndividualCheckedList.emit(this.currentSelected);
  }
}
