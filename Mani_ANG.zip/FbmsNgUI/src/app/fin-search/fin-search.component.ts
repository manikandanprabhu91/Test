import { Component, OnInit } from '@angular/core';
import { RestcallService } from '../services/restcall.service';

@Component({
  selector: 'fin-search',
  templateUrl: './fin-search.component.html',
  styleUrls: ['./fin-search.component.sass']
})
export class FinSearchComponent implements OnInit {

  searchVal: any;
  selectOption : any;
  searchGet: any;
  programYearVals: any;
  programYearSelected: any;
  country: any;
  role: any;
  reportLevel: any;
  loading: boolean;
  opendialog: boolean;
  parentFin: any;
  parentData: any;
  finMaster: any;
  spinner: boolean = false;

  constructor(private Restcallservice: RestcallService) { }

  ngOnInit(): void {
    this.searchVal ='';
    this.country= sessionStorage.getItem('countryCode');
    this.role= sessionStorage.getItem('roleName');
    this.reportLevel= sessionStorage.getItem('reportLvlCd');
    this.selectOption = 'fin';
    this.opendialog = false;
    this.pydpd();

  }
  onSearch(){
    this.loading = true;
    this.searchGet=null;
    this.spinner = true;
    let searchUrl = '/fleet-lookups/proposal-lookups/v1/fin-search';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finFlag", this.selectOption);
    this.Restcallservice.setQueryParams("finAccountName", this.searchVal);
    this.Restcallservice.getData(searchUrl).subscribe(data => {
      data != null ? this.searchGet = data.finSearchViewDtoList : this.searchGet = null;
      this.loading = false;
      this.spinner = false
    }, err => {this.loading = false;this.searchGet = null;
      this.spinner = false;});
  }
  pydpd(){
    let configUrl = "/fleet-lookups/proposal-lookups/v1/operational-view-data";
    this.Restcallservice.ngOnInit();
    this.Restcallservice.getData(configUrl).subscribe(dataSet =>{
      this.programYearVals = dataSet['programYear'];
      this.programYearSelected = this.programYearVals[0];

    });

  }
  opd(finCode, finMaster){
    this.parentFin = finCode;
    this.finMaster = finMaster;
    this.opendialog = true;
  }
  searchParent(){
    this.loading= true;
    this.parentData=[];
    let childVals=[];
    let parentVals=[];
    let searchParentUrl = '/fleet-lookups/proposal-lookups/v1/sub-fin-search';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("finKey", this.finMaster );
    this.Restcallservice.setQueryParams("finCd", this.parentFin );
    this.Restcallservice.setQueryParams("proposalYear", this.programYearSelected );
    this.Restcallservice.getData(searchParentUrl).subscribe(data => {
      data != null ? parentVals = data.parentFinSearchList : parentVals = [];
      data != null ? childVals = data.childFinSearchList : childVals = [];
      if(parentVals){
        this.parentData=parentVals;
      }
      if(childVals){
        this.parentData= this.parentData.concat(childVals);
      }
      this.loading = false;
    }, err => {
      this.loading = false;
      this.parentData = null;
    });
  }
  opdClose(){
    this.opendialog = false;
    this.parentData=null;
    this.programYearSelected = this.programYearVals[0];
  }

}
