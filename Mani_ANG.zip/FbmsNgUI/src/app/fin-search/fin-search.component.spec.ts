import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinSearchComponent } from './fin-search.component';

describe('FinSearchComponent', () => {
  let component: FinSearchComponent;
  let fixture: ComponentFixture<FinSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
