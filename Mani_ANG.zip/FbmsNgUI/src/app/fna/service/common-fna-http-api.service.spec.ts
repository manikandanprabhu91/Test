import { TestBed } from '@angular/core/testing';

import { CommonFnaHttpApiService } from './common-fna-http-api.service';

describe('CommonFnaHttpApiService', () => {
  let service: CommonFnaHttpApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CommonFnaHttpApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
