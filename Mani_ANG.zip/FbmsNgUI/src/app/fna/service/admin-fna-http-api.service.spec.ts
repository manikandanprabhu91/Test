import { TestBed } from '@angular/core/testing';

import { AdminFnaHttpApiService } from './admin-fna-http-api.service';

describe('AdminFnaHttpApiService', () => {
  let service: AdminFnaHttpApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminFnaHttpApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
