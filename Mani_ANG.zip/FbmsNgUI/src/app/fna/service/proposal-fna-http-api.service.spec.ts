import { TestBed } from '@angular/core/testing';

import { ProposalFnaHttpApiService } from './proposal-fna-http-api.service';

describe('ProposalFnaHttpApiService', () => {
  let service: ProposalFnaHttpApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProposalFnaHttpApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
