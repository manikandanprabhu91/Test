import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { FbmsHttpApiService } from '../../services/fbms-http-api.service';
import { DOCUMENT } from '@angular/common';
import { RestcallService } from '../../services/restcall.service';

@Injectable({
  providedIn: 'root'
})
export class CommonFnaHttpApiService extends FbmsHttpApiService {
  // static ROUTE_PATH: string = 'common-fna'
  static ROUTE_PATH: string = 'user-management'

  constructor(http: HttpClient, @Inject(DOCUMENT) document, RestcallService: RestcallService) {
    super(http, CommonFnaHttpApiService.ROUTE_PATH, document, RestcallService);
  }
}
