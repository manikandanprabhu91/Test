import { Component, OnInit, HostListener } from '@angular/core';
import { AccountFilter } from '../fbmscontainer/accountfilter';
import { RestcallService } from '../services/restcall.service';

@Component({
  selector: 'fbmsmenu',
  templateUrl: './fbmsmenu.component.html',
  styleUrls: ['./fbmsmenu.component.sass']
})
export class FbmsmenuComponent implements OnInit {
  // @HostListener('window:resize', ['$event']) onResize(event?) {
	// 	this.getContentSize(event)
	// }
  country: any;
  showleftnav = false;
  invaliddata =false;
  constructor(private Restcallservice: RestcallService) { }

 
  // getContentSize(event) {
    
	// 	console.log("width"+event.target.innerWidth);
		

	// }

  ngOnInit(): void {
  
          console.log("inner width"+ window.innerWidth);
    if(window.innerWidth <= 620 || window.innerWidth <=840) 
     {
     
      this.showleftnav=true;
		console.log("sidenav"+this.showleftnav)
		}
    else
    {
      this.showleftnav=false;
      console.log("sidenav"+this.showleftnav)
    }
    this.country = sessionStorage.getItem("countryCode");
  }
 
  guide(type) {
    let docUrl = '/fleet-letters-management/s3/buckets/files/download/user-guide';
    this.Restcallservice.ngOnInit();
    this.Restcallservice.setQueryParams("fileType", type);
    this.Restcallservice.downloadCpaLetter(docUrl, "application/msword", type + ".doc");
  }
  resetFilter() {
    this.Restcallservice.accountFilter = new AccountFilter();
  }
}
