import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmsmenuComponent } from './fbmsmenu.component';

describe('FbmsmenuComponent', () => {
  let component: FbmsmenuComponent;
  let fixture: ComponentFixture<FbmsmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmsmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmsmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
