import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'fbmsfooter',
  templateUrl: './fbmsfooter.component.html',
  styleUrls: ['./fbmsfooter.component.sass']
})
export class FbmsfooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
