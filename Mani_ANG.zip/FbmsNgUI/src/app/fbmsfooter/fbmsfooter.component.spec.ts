import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmsfooterComponent } from './fbmsfooter.component';

describe('FbmsfooterComponent', () => {
  let component: FbmsfooterComponent;
  let fixture: ComponentFixture<FbmsfooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmsfooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmsfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
