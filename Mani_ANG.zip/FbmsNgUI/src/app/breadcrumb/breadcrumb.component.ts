import { Component, OnInit, HostListener} from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.sass']
})
export class BreadcrumbComponent implements OnInit {
  showleftnav = false;
  public breadcrumbs: Breadcrumb[];
  
  constructor(private router: Router, private route: ActivatedRoute) {
    this.breadcrumbs = this.buildBreadCrumb(this.route.root);
   }


  ngOnInit(): void {
    

    // this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(event => {
    //   //set breadcrumbs
    //   let root: ActivatedRoute = this.route.root;
    //   this.breadcrumbs = this.getBreadcrumbs(root);
    //    this.breadcrumbs = [breadcrumb, ...this.breadcrumbs];
       
    // }); 
    this.router.events.pipe(
      filter(event=> event instanceof NavigationEnd),
      distinctUntilChanged(),
    ).subscribe(() => {
      this.breadcrumbs = this.buildBreadCrumb(this.route.root);
    })
  }

//   private getBreadcrumbs(route: ActivatedRoute, url: string = "", breadcrumbs: Breadcrumb[] = []): Breadcrumb[] {
//     const ROUTE_DATA_BREADCRUMB = 'title';
// debugger
//     //get the child routes
//     let children: ActivatedRoute[] = route.children;
//     console.log(route);
//     console.log(route.children);

//     //return if there are no more children
//     if (children.length === 0) {
//       return breadcrumbs;
//     }

//     //iterate over each children
//     for (let child of children) {
//       //verify primary route
//       if (child.outlet !== PRIMARY_OUTLET || child.snapshot.url.length==0) {
//         continue;
//       }

//       //verify the custom data property "breadcrumb" is specified on the route
//       if (!child.snapshot.data.hasOwnProperty(ROUTE_DATA_BREADCRUMB)) {
//         return this.getBreadcrumbs(child, url, breadcrumbs);
//       }

//       //get the route's URL segment
//       let routeURL: string = child.snapshot.url.map(segment => segment.path).join("/");
  
//       //append route URL to URL
//       url += `/${routeURL}`;

//       //add breadcrumb
//       let breadcrumb: Breadcrumb = {
//         label: child.snapshot.data[ROUTE_DATA_BREADCRUMB],
//         url: url
//       };
//       breadcrumbs.push(breadcrumb);

//       //recursive
//       return this.getBreadcrumbs(child, url, breadcrumbs);
//     }
//     return breadcrumbs;
//   }

buildBreadCrumb(route: ActivatedRoute, url: string = '', breadcrumbs: Breadcrumb[] = []): Breadcrumb[] {
  //If no routeConfig is avalailable we are on the root path
  let label = route.routeConfig && route.routeConfig.data ? route.routeConfig.data.breadcrumb : '';
  let isClickable = route.routeConfig && route.routeConfig.data && route.routeConfig.data.isClickable;
  let path = route.routeConfig && route.routeConfig.data ? route.routeConfig.path : '';

  // If the route is dynamic route such as ':id', remove it
  const lastRoutePart = path.split('/').pop();
  const isDynamicRoute = lastRoutePart.startsWith(':');
  if(isDynamicRoute && !!route.snapshot) {
    const paramName = lastRoutePart.split(':')[1];
    path = path.replace(lastRoutePart, route.snapshot.params[paramName]);
    label = route.snapshot.params[paramName];
  }

  //In the routeConfig the complete path is not available,
  //so we rebuild it each time
  const nextUrl = path ? `${url}/${path}` : url;

  const breadcrumb: Breadcrumb = {
      label: label,
      url: nextUrl,
  };
  // Only adding route with non-empty label
  const newBreadcrumbs = breadcrumb.label ? [ ...breadcrumbs, breadcrumb ] : [ ...breadcrumbs];
  if (route.firstChild) {
      //If we are not on our current path yet,
      //there will be more children to look after, to build our breadcumb
      return this.buildBreadCrumb(route.firstChild, nextUrl, newBreadcrumbs);
  }
  return newBreadcrumbs;
}

}

export interface Breadcrumb{
  label: string;
    url: string;
}