import { Component, OnInit } from '@angular/core';
import { Router } from 'src/testing/router-stubs';
//import {UserIdService} from '../services/user-id.service';
//import {Observable} from 'rxjs';
@Component({
  selector: 'fbmsheader',
  templateUrl: './fbmsheader.component.html',
  styleUrls: ['./fbmsheader.component.sass']
})
export class FbmsheaderComponent implements OnInit {
  fleetPersonCdsid: string;
  countryCode: string;
  roleName: string;
  firstName: string;
  lastName: string;
  flagEnable: boolean;
  defaultFlag: any;
  invalidUser:any; 
  constructor(private router: Router) { }

  ngOnInit(): void {
    this.fleetPersonCdsid = sessionStorage.getItem('loginId');
    this.countryCode = sessionStorage.getItem('countryCode');
    this.roleName = sessionStorage.getItem('roleName');
    this.firstName = sessionStorage.getItem('loginFirstName');
    this.lastName = sessionStorage.getItem('loginLastName');
    
  }

  countryChangeClick() {
    var path = this.router.url ;
    if((path == '/accounts-home' || path == '/admin-home') && this.countryCode == 'USA' || this.countryCode == 'CAN') {
      this.flagEnable = true;
      this.defaultFlag = this.countryCode;
    }
  }

  selectionFlagChange() {
    this.flagEnable = false;
    this.countryCode = this.defaultFlag;
    sessionStorage.setItem("countryCode", this.defaultFlag);
    window.location.reload();
  }

}
