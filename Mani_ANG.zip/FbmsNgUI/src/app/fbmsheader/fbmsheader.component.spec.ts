import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmsheaderComponent } from './fbmsheader.component';

describe('FbmsheaderComponent', () => {
  let component: FbmsheaderComponent;
  let fixture: ComponentFixture<FbmsheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmsheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmsheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
