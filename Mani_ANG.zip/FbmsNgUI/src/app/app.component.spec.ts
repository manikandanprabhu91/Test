import {
	async,
	TestBed
} from '@angular/core/testing';

import {AppComponent} from './app.component';
import {
	RouterLinkStubDirective,
	RouterOutletStubDirective,
	RouterStub
} from '../testing/router-stubs';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {By} from '@angular/platform-browser';
import {environment} from '../environments/environment';
import {configureTestSuite} from '../testing/performance/test-bed-helper';
import {
	NavigationEnd,
	Router
} from '@angular/router';
import {of} from 'rxjs';

describe('AppComponent', () => {
	let fixture, appComponent, compiled;
	const routerStub = new RouterStub();

	configureTestSuite(() => {
		TestBed.configureTestingModule({
			declarations: [
				AppComponent,
				//for routing we have to use some router stubs. these aren't given by angular.
				//but, the /testing/router-stubs.ts file, from google, provides the necessary mocks
				RouterLinkStubDirective,
				RouterOutletStubDirective
			],
			providers: [
				{provide: Router, useValue: routerStub}
			],
			schemas: [NO_ERRORS_SCHEMA]
		}).compileComponents();

		fixture = TestBed.createComponent(AppComponent);
		fixture.detectChanges();
		appComponent = fixture.debugElement.componentInstance;
		compiled = fixture.debugElement.nativeElement;
	});

	it('should create the app', async(() => {
		expect(appComponent).toBeTruthy();
	}));

	describe('ngOnInit(): ', () => {
		it('should leverage the router events to dynamically construct the skip url', () => {
			spyOn(appComponent, 'setSkipLinkUrl');
			routerStub.events = of(new NavigationEnd(2, 'test', 'test-after-redirect'));
			appComponent.ngOnInit();
			expect(appComponent.setSkipLinkUrl).toHaveBeenCalledWith('test-after-redirect');
		});
	});

	describe('setSkipLinkUrl(): ', () => {
		it('should use the passed in url to appropriately set the skip url', () => {
			appComponent.skipToMain = 'someurl';
			appComponent.setSkipLinkUrl('test#app-content');
			expect(appComponent.skipToMain).toEqual('someurl');
			appComponent.setSkipLinkUrl('test');
			expect(appComponent.skipToMain).toEqual('test#app-content');
		});
	});

	describe('template tests: ', () => {
		it('should include a header, main content section and footer', () => {
			expect(compiled.querySelector('#app-header').tagName).toEqual('HEADER');
			expect(compiled.querySelector('#app-header h1').textContent).toEqual('Ford Starter WebApp');
			expect(compiled.querySelector('#app-content').tagName).toEqual('MAIN');
			expect(compiled.querySelector('#app-footer').tagName).toEqual('FOOTER');
		});

		it('should have the toast component included and properly configured', () => {
			expect(fixture.debugElement.query(By.css('p-toast')).nativeElement.tagName).toEqual('P-TOAST');
		});

		it('should include the nav component in the header', () => {
			//equiv to fixture.debugElement.query(By.css('#app-header app-nav'))
			expect(compiled.querySelector('#app-header app-nav')).toBeDefined();
		});

		it('should include a skip to main link before other items in the header', () => {
			expect(compiled.querySelector('#app-header').firstChild.tagName).toEqual('A');
			expect(compiled.querySelector('#app-header .skip-link').textContent).toEqual('Skip to Content');
			expect(compiled.querySelector('#app-header .skip-link').href)
				.toEqual('http://localhost:9876/testurl-after-redirect#app-content');
		});

		it('should get the currently used angular version from the framework', () => {
			expect(appComponent.version).toEqual('9.1.12');
		});

		it('should include and display environment items', () => {
			expect(appComponent.envProd).toEqual(environment.production);
			expect(fixture.debugElement.queryAll(By.css('#app-footer p'))[2].nativeNode.textContent)
				.toContain(appComponent.envProd ? 'Production' : 'Development');
		});

		it('should put the angular version being used in the footer', () => {
			expect(compiled.querySelector('#app-footer p').textContent).toContain(appComponent.version);
		});
	});
});
