import { TestBed } from '@angular/core/testing';

import { FbmsHttpApiService } from './fbms-http-api.service';

describe('FbmsHttpApiService', () => {
  let service: FbmsHttpApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FbmsHttpApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
