import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpParams, HttpHeaders } from '@angular/common/http';
// import 'rxjs/add/observable/of';
// import 'rxjs/add/operator/toPromise';
import { catchError, tap } from 'rxjs/internal/operators';
import { Observable } from 'rxjs';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { CATCH_ERROR_VAR } from '@angular/compiler/src/output/output_ast';
import { of } from 'rxjs';
import { environment } from '../../environments/environment';
import { CommonFnaHttpApiService } from '../fna/service/common-fna-http-api.service';

@Injectable({
  providedIn: 'root'
})
export class UserauthcheckService {
  public PARENT_PATH = 'api/v1/fbmssbmw';
  public CHILD_PATH = '/validate/user-role';

  constructor(private http: HttpClient, private commonApiService: CommonFnaHttpApiService) { }
  
  getUserStatus(loggedInUser: string, entityName: string): Observable<any> {
    let url = this.PARENT_PATH + this.CHILD_PATH + '?loggedUser=' + loggedInUser + '&entityName=' + entityName;
    return this.commonApiService.get(url)
  }

}
