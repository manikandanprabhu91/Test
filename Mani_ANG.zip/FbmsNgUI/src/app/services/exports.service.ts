import { Injectable } from '@angular/core';
import { PatternValidator } from '@angular/forms';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
@Injectable({
  providedIn: 'root'
})
export class ExportsService {
  storeData: any;
  worksheet: any;
  jsonData: any;

  constructor() { }

  public exportAsExcelFile(json: any[], excelFileName: string, topheader: any, header: any[], title: any, accountName: string,
    finCode: string, pyVersion: string, status: string, progreamyears: string, proposalVersion: string) {

    let assignTitle = [];
    let proposalComments = [];
    let accountname = [];
    let programYear = [];
    let fin = [];

    let worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(title);

    if(excelFileName=='PurgeProgramYearData' || excelFileName=='VehicleLineByDefinition') {
      XLSX.utils.sheet_add_json(worksheet, topheader, { skipHeader: true, origin: "A1" });

      XLSX.utils.sheet_add_json(worksheet, header, { skipHeader: true, origin: "A1" });
      XLSX.utils.sheet_add_json(worksheet, json, { skipHeader: true, origin: "A2" });
    } else if( excelFileName=='ProposalComments') {
      // XLSX.utils.sheet_add_json(worksheet, topheader, { skipHeader: true, origin: "A1" });
      proposalComments.push({'':'Proposal Comments Download'});
      XLSX.utils.sheet_add_json(worksheet, proposalComments, { skipHeader: true, origin: "A1" });
      accountname.push({ '': 'Account Name', ' ': accountName, '  ': 'PY-Ver', '   ': pyVersion});
      XLSX.utils.sheet_add_json(worksheet, accountname, { skipHeader: true, origin: "A2" });
      fin.push({'': 'FIN', ' ': finCode, '  ': 'Status', '   ':status});
      XLSX.utils.sheet_add_json(worksheet, fin, { skipHeader: true, origin: "A3" });
      programYear.push({'': 'Program Year', ' ': progreamyears, '  ': 'Proposal Version', '   ': proposalVersion});
      XLSX.utils.sheet_add_json(worksheet, programYear, { skipHeader: true, origin: "A4" });
      
     
      XLSX.utils.sheet_add_json(worksheet, header, { skipHeader: true, origin: "A5" });
      XLSX.utils.sheet_add_json(worksheet, json, { skipHeader: true, origin: "A6" });
    } else {
      XLSX.utils.sheet_add_json(worksheet, topheader, { skipHeader: true, origin: "A3" });
      if(excelFileName=='AssignmentofProceeds') {
        assignTitle.push({'':'', 
        ' ':'', '  ':'', '   ':'', '    ':'Letter of Assignment of Proceeds', '     ':'', '      ':'Selling Dealer Assignment CPA Funds'});
        XLSX.utils.sheet_add_json(worksheet, assignTitle, { skipHeader: true, origin: "A5" });
      }
      XLSX.utils.sheet_add_json(worksheet, header, { skipHeader: true, origin: "A6" });
      XLSX.utils.sheet_add_json(worksheet, json, { skipHeader: true, origin: "A7" });
  
    } 
    
    const wscols = [
      { wch: 15 },
      { wch: 40 },
      { wch: 20 },
      { wch: 15 },
      { wch: 15 },
      { wch: 15 },
      { wch: 10 },
      { wch: 30 },
      { wch: 20 },
      { wch: 20 }
    ];
    
    worksheet['!cols'] = wscols;
    // worksheet['A6'] = wscol
    // worksheet['!merges']=mergesV;
    // worksheet['!cols'].fill.prototype = wscolrs;
    
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };

    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }




  private saveAsExcelFile(buffer: any, fileName: string): void {
    const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
    FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  }

  // readExcel(fileUploaded) {  
  //   let readFile = new FileReader();  
  //   readFile.onload = (e) => {  
  //     this.storeData = readFile.result;  
  //     var data = new Uint8Array(this.storeData);  
  //     var arr = new Array();  
  //     for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);  
  //     var bstr = arr.join("");  
  //     var workbook = XLSX.read(bstr, { type: "binary" });  
  //     var first_sheet_name = workbook.SheetNames[0];  
  //     this.worksheet = workbook.Sheets[first_sheet_name];  
  //   }  
  //   readFile.readAsArrayBuffer(fileUploaded);  
  // } 
  // readAsJson() {  
  //   this.jsonData = XLSX.utils.sheet_to_json(this.worksheet, { raw: false });  
  //   this.jsonData = JSON.stringify(this.jsonData);  
  //   const data: Blob = new Blob([this.jsonData], { type: "application/json" });  
  //   FileSaver.saveAs(data, "JsonFile" + new Date().getTime() + '.json');  
  // }
}
