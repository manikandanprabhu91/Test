import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'numberCheck'})

export class NumberCheckPipe implements PipeTransform {
    transform(value: number): String { 
      if(value >= 0) {
        return 'green';
      } else {
        return 'red';
      }
    }
}