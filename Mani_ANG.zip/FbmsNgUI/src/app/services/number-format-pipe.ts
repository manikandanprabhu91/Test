import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'negativeNumber'})

export class NumberFormatPipe implements PipeTransform {
    transform(value: number): String { 
      if(value >= 0) {
        return value.toString();
      } else {
        return ('('+ value * -1 + ')').toString();
      }
    }
}