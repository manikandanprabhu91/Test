import {DOCUMENT} from '@angular/common';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from 'src/environments/environment';
import { RestcallService } from '../services/restcall.service';

export class FbmsHttpApiService {

	public url = environment.gatwayUrl;

	constructor(private http: HttpClient, private routePath: string, @Inject(DOCUMENT) private document, private RestcallService: RestcallService) {
	}

	constructURL(apiPath: string): string {
		return this.url + apiPath;
	}
	get(path: string): Observable<any> {
		return this.http.get(this.constructURL(path), this.getHeaders());
	}

	post(path: string, bodyObject: any): Observable<any> {
		return this.http.post(this.constructURL(path), bodyObject, this.getHeaders());
	}

	put(path: string, bodyObject: any): Observable<any> {
		return this.http.put(this.constructURL(path), bodyObject, this.getHeaders());
	}

	delete(path: string): Observable<any> {
		return this.http.delete(this.constructURL(path), this.getHeaders());
	}

	getHeaders(): any {
		this.RestcallService.refreshApicToken();
		const header = new HttpHeaders({
			Authorization: 'Bearer ' + sessionStorage['gateway_access_token']
		});
		return {headers: header};
	}
}
