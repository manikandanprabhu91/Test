import { Injectable, OnInit } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry, map } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material/snack-bar';
import { environment } from 'src/environments/environment';
import { DomSanitizer } from '@angular/platform-browser';
import { AccountFilter } from '../fbmscontainer/accountfilter';
import { OauthTokenService } from '../services/oauth-token.service';

@Injectable({
	providedIn: 'root'
})
export class RestcallService implements OnInit {
	accountFilter: AccountFilter = new AccountFilter();
	queryParams: any;
	optionsWithParams: any;
	// tslint:disable-next-line:max-line-length
	orchestratorEndPoint = environment.gatwayUrl;
	directEndPoint = environment.directUrl;
	copyAEData: any;
	copiedProposalKey: any;
	vehicleLineTable: any;
	newerProposal:any;
	vehicleLineDataValidationMap: any;
	optionDiscountValidationMap: any;
	optionDiscountSubmitMap: any;
	constructor(private http: HttpClient, private statusBar: MatSnackBar, private sanitizer: DomSanitizer, private oauthService: OauthTokenService) { }

	// tslint:disable-next-line:contextual-lifecycle
	ngOnInit() {
		this.queryParams = new HttpParams().set('cdsId', sessionStorage.getItem('loginId'));
		this.queryParams = this.queryParams.append('countryCd', sessionStorage.getItem('countryCode'));
		this.queryParams = this.queryParams.append('role', sessionStorage.getItem('roleName'));
		// this.queryParams = this.queryParams.append('reportLvlCd', sessionStorage.getItem('reportLvlCd'));
		this.setOptionParam();
	}

	//Setting headers
	setOptionParam() {
		this.optionsWithParams = this.queryParams;
	}

	getHeaders(): any {
		this.refreshApicToken();
		const header = new HttpHeaders({
			'Content-Type': 'application/json',
			'Authorization': 'Bearer ' + sessionStorage['gateway_access_token']
		});
		return header;
	}

	refreshApicToken() {
		if (environment.isApicEnabled && (new Date().getTime()) - sessionStorage['apic_token_time_start'] > environment.apicTokenRefreshTime) {
			this.oauthService.getApicToken().subscribe(data => {
				sessionStorage['gateway_access_token'] = data['access_token'];
				sessionStorage['apic_token_time_start'] = new Date().getTime();
			}, err => {
				this.statusMessage(500, "Error getting access token");
			})
		}
	}

	getMultipartHeaders(): any {
		//this.refreshApicToken();
		const header = new HttpHeaders({
			//'Content-Type':  'multipart/form-data',
			// 'Accept': 'application/json',
			'Authorization': 'Bearer ' + sessionStorage['directUrl_access_token']
		});
		return header;
	}

	//set the query params
	setQueryParams(extraParamKey, extraParamsValue) {
		this.queryParams = this.queryParams.append(extraParamKey, extraParamsValue);
		this.setOptionParam();
	}

	//Function to initiate restcall and get the value
	getData(configUrl) {
		return this.http.get<any>(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			params: this.optionsWithParams
		}).pipe(
			retry(1),
			catchError(this.handleError.bind(this)));
	}

	getWordHeaders(): any {
		this.refreshApicToken();
		const header = new HttpHeaders({
			'Content-Type': 'text/plain',
			'Authorization': 'Bearer ' + sessionStorage['gateway_access_token']
		});
		return header;
	}
	//rest calll for preview document
	getWordData(configUrl) {
		return this.http.get<any>(this.orchestratorEndPoint + configUrl, {
			headers: this.getWordHeaders(), responseType: "text" as "json"

		}).pipe(
			retry(1),
			catchError(this.handleError.bind(this)));
	}

	//create new data --> post
	createData(configUrl, newValue) {
		return this.http.post<any>(this.orchestratorEndPoint + configUrl, newValue, {
			headers: this.getHeaders(),
			observe: 'response' as 'body',
			params: this.optionsWithParams
		}).pipe(
			map(responseData => {
				console.log(responseData);
				if (responseData.body.modelYrData) {
					this.copyAEData = responseData.body.modelYrData;
				}
				if (responseData.body.proposalDto) {
					if (responseData.body.proposalDto.proposalKey) {
						this.copiedProposalKey = responseData.body.proposalDto.proposalKey;
					}
				}
				if (responseData.body.vehicleResponseVo) {
					this.vehicleLineTable = responseData.body.vehicleResponseVo.vehicles;
					return this.vehicleLineTable;

				}
				if (responseData.body.nextProposal) {
					return responseData;
					//return this.newerProposal;

				}
				if (responseData.body.msgDesc != null) {
					this.statusMessage(responseData.status, responseData.body.msgDesc);
				} else if (responseData.body.letterApprovalStatus == "Generated") {
					this.statusMessage(responseData.status, "CPALetter has been Successfully Generated.");
				} else if(responseData.body.copyWarningsVos != null || responseData.body.copyWarningsVos == null) {
					return responseData;
				} else {
					this.statusMessage(responseData.status, responseData);
				}
			}),
			retry(1),
			catchError(this.handleError.bind(this)));
	}

		//Submit to Dealer email send
	createEmailData(configUrl, emailReqBody) {
		return this.http.post<any>(this.orchestratorEndPoint + configUrl, emailReqBody, {
			headers: this.getHeaders(),
			observe: 'response' as 'body'
		}).pipe(
			map(responseData => {
				return responseData;
			}),
			retry(1),
			catchError(this.handleError.bind(this)));
	}


	//Update the existing value--> put
	updateData(configUrl, editVal) {
		return this.http.put<any>(this.orchestratorEndPoint + configUrl, editVal, {
			headers: this.getHeaders(),
			observe: 'response' as 'body',
			params: this.optionsWithParams
		}).pipe(
			map(responseData => {
				console.log(responseData);
				this.statusMessage(responseData.status, responseData.body.msgDesc)
			}),
			retry(1),
			catchError(this.handleError.bind(this)));
	}

	//deleting the row item
	deleteData(configUrl) {
		return this.http.delete<any>(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			observe: 'response' as 'body',
			params: this.optionsWithParams
		}).pipe(
			map(responseData => {
				this.statusMessage(responseData.status, responseData.body.msgDesc);
				
			}),
			retry(1),
			catchError(this.handleError.bind(this)));  
	}



    //deleting the row item
	globaldeleteData(configUrl) {
		return this.http.delete<any>(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			observe: 'response' as 'body',
			params: this.optionsWithParams
		}).pipe(
			map(responseData => {
				this.statusMessage(responseData.status, responseData.body.msgDesc);
				return responseData;
			}),
			retry(1),
			catchError(this.handleError.bind(this)));
	}





	//create new data --> post with get retrieval
	createDealer(configUrl, newValue) {
		return this.http.post<any>(this.orchestratorEndPoint + configUrl, newValue, {
			headers: this.getHeaders(),
			params: this.optionsWithParams
		}).pipe(
			retry(1),
			catchError(this.handleError.bind(this)));
	}

	//downloading the proposal word document
	downloadProposalLetter(configUrl, fileName) {
		this.statusMessage(201, 'Please wait.. we are preparing your document');
		return this.http.get(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			responseType: 'blob',
			params: this.optionsWithParams,
		}).subscribe(response => this.downLoadFile(response, "application/msword", fileName),
			err => {
				alert('Please disable your Pop-up blocker and try again.');
			});
	}


	downloadExcel(configUrl, fileName) {
		return this.http.get(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			responseType: 'blob',
			params: this.optionsWithParams,
		}).subscribe(response => this.downLoadFile(response, "application/octet-stream", fileName),
			err => {
				alert('Please disable your Pop-up blocker and try again.');
			});
	}

	downLoadFile(data: any, type: string, fileName) {

		let blob = new Blob([data], { type: type });
		if (window.navigator && window.navigator.msSaveOrOpenBlob) {
			window.navigator.msSaveOrOpenBlob(blob, fileName);
		} else {
			let url = window.URL.createObjectURL(blob);
			// let pwa = window.open(url);
			let anchor = document.createElement("a");
			anchor.download = fileName;
			anchor.href = url;
			anchor.click();
		}

		// if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
		//     alert( 'Please disable your Pop-up blocker and try again.');
		// }
		// var link = document.createElement('a');
		// link.href = window.URL.createObjectURL(data);
		// link.download = 'test.xlsx';
		// link.click();
		// const blob = new Blob([data], { type: 'application/octet-stream' });
		// 	fs.saveAs(blob, 'test' + '.xlsx');
	}

	previewDocument(configUrl, fileName) {
		this.statusMessage(201, 'Please wait.. we are preparing your document');
		return this.http.get(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			responseType: 'blob',
			params: this.optionsWithParams,
		}).subscribe(response => {
			let blob = new Blob([response], { type: 'application/octet-stream' });
			let url = window.URL.createObjectURL(blob);
			// alert(url);
			let pwa = window.open(url, '_blank');
			// let anchor = document.createElement("a");
			// anchor.download = fileName;
			// anchor.href = url;
			// 		// let linkText = document.createTextNode("View File");
			// 		// anchor.target = "_blank";
			// 		// anchor.appendChild(linkText);
			// 		// anchor.href = url;
		},
			err => {
				alert('Please disable your Pop-up blocker and try again.');
			}
		);
	}

	uploadFile(configUrl: string, fileToUpload: File, fileName: string, inputData: string): Observable<boolean> {
		let formData = new FormData();
		formData.append(fileName, fileToUpload, fileToUpload.name);
		if (inputData == 'uploadA1') {
			return this.http.post(this.directEndPoint + configUrl, formData, {
				headers: this.getMultipartHeaders(),
				params: this.optionsWithParams
			}).pipe(
				retry(1),
				catchError(this.handleError.bind(this))
			);
		} else {
			return this.http.post(this.directEndPoint + configUrl, formData, {
				headers: this.getMultipartHeaders(),
				params: this.optionsWithParams
			}).pipe(
				map(responseData => {
					this.statusMessage(200, 'File Uploaded Successfully');
				}),
				catchError(this.handleError.bind(this))
			);
		}
	}

	//Error handling during API call
	handleError(error: HttpErrorResponse) {
		let errorMessage = 'Unknown error!';
		// this.statusMessage(200, 'File Upload Success');
		this.statusMessage(error.status, error.error.msgDesc);
		console.log(error);
		if (error.error instanceof ErrorEvent) {
			// Client-side errors
			errorMessage = `Error: ${error.error.message}`;
			// this.statusMessage(error.error.message, error.error.message);
		} else {
			// Server-side errors
			errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

		}
		return throwError(errorMessage);
	}

	//Handle the Response Messages
	statusMessage(statusCode, statusText) {
		//To display the user action message
		if (statusText != null) {
			statusCode < 300 ? this.openSuccessSnackBar(statusCode, statusText) : this.openFailureSnackBar(statusCode, statusText);
		}
	}

	//Mesagebar
	openSuccessSnackBar(statusCode, statusText) {
		this.statusBar.open(statusText, 'x', {
			duration: 15000,
			verticalPosition: 'top',
			horizontalPosition: 'center',
			panelClass: ['green-snackbar', 'login-snackbar'],
		});
	}

	//Snackbar that opens with failure background
	openFailureSnackBar(statusCode, statusText) {
		// alert(statusCode);
		// if(statusCode == 500){
		// 	let original = statusText;
		// 	statusText = 'Some services have downtime, please try again after sometime. If you still face the issue, please contact Technical Experts';
		// }

		this.statusBar.open(statusText, 'x', {
			duration: 180000,
			verticalPosition: 'top',
			horizontalPosition: 'center',
			panelClass: ['red-snackbar', 'login-snackbar'],
		});
	}


	//Get blob
	previewBlob(configUrl) {
		return this.http.get(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			responseType: 'blob',
			params: this.optionsWithParams,
		}).pipe(
			retry(1),
			catchError(this.handleError.bind(this)));
	}

	// 	//downloading the cpa letter
	downloadCpaLetter(configUrl, contentType, fileName) {
		this.statusMessage(201, 'Please wait.. we are preparing your document');
		return this.http.get(this.orchestratorEndPoint + configUrl, {
			headers: this.getHeaders(),
			responseType: 'blob',
			params: this.optionsWithParams,
		}).subscribe(response => this.downLoadFile(response, contentType, fileName),
			err => {
				alert('Please disable your Pop-up blocker and try again.');
			});
	}

	validatedate(dateString) {
		let dateformat = /^(0?[1-9]|1[0-2])[\/](0?[1-9]|[1-2][0-9]|3[01])[\/]\d{4}$/;
		let pdatepart = '';
		// Match the date format through regular expression      
		if (dateString?.match(dateformat)) {
			let operator = dateString.split('/');

			// Extract the string into month, date and year      
			let datepart = [];
			if (operator.length > 1) {
				pdatepart = dateString.split('/');
			}
			let month = parseInt(datepart[0]);
			let day = parseInt(datepart[1]);
			let year = parseInt(datepart[2]);
			if (year > 9999 || year < 1000) {
				return false;
			}
			// Create list of days of a month      
			let ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
			if (month == 1 || month > 2) {
				if (day > ListofDays[month - 1]) {
					///This check is for Confirming that the date is not out of its range      
					return false;
				}
			} else if (month == 2) {
				let leapYear = false;
				if ((!(year % 4) && year % 100) || !(year % 400)) {
					leapYear = true;
				}
				if ((leapYear == false) && (day >= 29)) {
					return false;
				} else
					if ((leapYear == true) && (day > 29)) {
						// console.log('Invalid date format!');      
						return false;
					}
			}
		} else {
			// console.log("Invalid date format!");      
			return false;
		}
		return true;
	}
}
