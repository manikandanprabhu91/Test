import {HttpClient, HttpHeaders, HttpParams, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from 'src/environments/environment';

@Injectable({
	providedIn: 'root'
})
export class OauthTokenService {

	constructor(private http: HttpClient) {
	}

	getApicToken(): Observable<any> {
		const body = new URLSearchParams({
			scope: environment.apicScope,
			client_id: environment.apicClientId,
			client_secret: environment.apicClientSecret,
			grant_type: 'client_credentials'
		});

		const header = new HttpHeaders({
			'Content-Type': 'application/x-www-form-urlencoded'
		});
		return this.http.post(environment.apicTokenUrl, body.toString(), {headers: header})
	}

	// getApiModuleToken(resourceId: string): Observable<any> {
	// 	const body = new URLSearchParams({
	// 		resource: resourceId,
	// 		client_id: '59b7c387-6658-b870-26f0-d915af4fd643',
	// 		client_secret: 'dLa1om9FpmZcLMT3cyaeIXzSwPj0DCIxgREq9Fgf',
	// 		grant_type: 'client_credentials'
	// 	});

	// 	const header = new HttpHeaders({
	// 		'Content-Type': 'application/x-www-form-urlencoded'
	// 	});

	// 	return this.http.post(`adfs/oauth2/token`, body.toString(), {headers: header})
	// }
}
