import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'SelfFin' })

export class SelfFinPipe implements PipeTransform {
    constructor(private datePipe: DatePipe) { }

    transform(value: String, selectProposalYear: number): boolean {
        if (value.charAt(0) == "C" || value.charAt(0) == "P") {
            return false;
        } else {
            return value.substring(value.length - 4, value.length) == String(selectProposalYear) ? false : true;
        }
    }
}