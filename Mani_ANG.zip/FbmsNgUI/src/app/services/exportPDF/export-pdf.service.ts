import {Injectable} from '@angular/core';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

/** This class wraps some functionality of the jspdf package in an easy to use service. See the below example:
 *
 * -Dependency Inject the ExportPdfService into component
 * 	constructor(private exportPdfService: ExportPdfService) {}
 *
 * -Create an array to hold the content of the export
 * 	const tableContent = [];
 *
 * - Have the column headings as 'cols'
 * cols = [
 * 			{field: 'confirmationNumber', header: 'Confirmation Number'},
 * 			{field: 'customerName', header: 'Customer Name'},
 * 			{field: 'adventureName', header: 'Adventure'},
 * 			{field: 'startDate', header: 'Start Date'},
 * 			{field: 'endDate', header: 'End Date'}
 * 			];
 *
 * -Push the body contents
 * 	bookings.forEach((booking) => {
 * 		tableContent.push([booking.confirmationNumber, booking.customerName, booking.adventureName, booking.startDate, booking.endDate]);
 * 	});
 *
 * -Call the service with the content and desired file name
 * 		this.exportPdfService.exportPdf(cols, tableContent, 'bookings.pdf');
 */
@Injectable({
	providedIn: 'root'
})
export class ExportPdfService {
	/** exports table data to a PDF file
	 * @param cols is the column headings of the table
	 * @param tableContent is the contents of the table, which is an array of any object
	 * @param fileName is the name for the file that the data will be exported to
	 */
	exportPDF(cols: any[], tableContent: any[], fileName: string): void {
		const pdf = this.createJsPdfInstance();
		this.callAutoTableWithPDFAndOptions(pdf, cols, tableContent);
		pdf.save(fileName);
	}

	/**
	 * Pass-through method for creation of our jsPDF instance
	 */
	/* istanbul ignore next */
	createJsPdfInstance() {
		return new jsPDF();
	}

	/**
	 * Pass-through method for creation of our autoTable instance
	 */
	/* istanbul ignore next */
	callAutoTableWithPDFAndOptions(pdfInstance: jsPDF, cols, tableContent) {
		return autoTable(pdfInstance, {
			columns: cols,
			body: tableContent
		});
	}
}
