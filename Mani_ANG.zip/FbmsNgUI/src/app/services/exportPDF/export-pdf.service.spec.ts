import {
	inject,
	TestBed
} from '@angular/core/testing';

import {ExportPdfService} from './export-pdf.service';

describe('ExportPdfService', () => {
	let service;
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [ExportPdfService]
		});
	});
	const agentTestData = [
		{
			uuid: '1',
			firstName: 'test',
			lastName: 'user',
			region: 'North America',
			birthYear: 1980
		},
		{
			uuid: '2',
			firstName: 'test1',
			lastName: 'user1',
			region: 'North America',
			birthYear: 1980
		},
		{
			uuid: '3',
			firstName: 'test',
			lastName: 'user',
			region: 'North America',
			birthYear: 1980
		}];

	it('should be created', inject([ExportPdfService], (subject: ExportPdfService) => {
		expect(subject).toBeTruthy();
	}));

	describe('Tests: ', () => {
		describe('exportPdf(): ', () => {
			beforeEach(inject([ExportPdfService], (exportPDFService) => {
				service = exportPDFService;
			}));

			it('should call exportPdf()', () => {
				spyOn(service, 'exportPDF');
				service.exportPDF();
				expect(service.exportPDF).toHaveBeenCalled();
			});

			it('should call pdf.autoTable & pdf.save', () => {
				const tableContent: any[][] = [];
				const fileName = 'test.pdf';

				const jsPdfMock = {
					save: jasmine.createSpy('save')
				};

				const cols = [
					{field: 'fullName', header: 'Name', filterMatchMode: 'contains'},
					{field: 'region', header: 'Region', filterMatchMode: 'contains'},
					{field: 'birthYear', header: 'Birth Year'},
					{field: 'mostRecentCertificationYear', header: 'Most Recent Certification Year'}
				];

				// push the table headings
				agentTestData.forEach((agent) => {
					const row = [];
					cols.forEach((col) => {
						if (agent[col.field]) {
							row.push(agent[col.field]);
						} else {
							row.push('');
						}
					});
					tableContent.push(row);
				});

				spyOn(service, 'createJsPdfInstance').and.returnValue(jsPdfMock);
				spyOn(service, 'callAutoTableWithPDFAndOptions');
				service.exportPDF(cols, tableContent, fileName);
				expect(service.createJsPdfInstance).toHaveBeenCalled();
				expect(service.callAutoTableWithPDFAndOptions).toHaveBeenCalledWith(jsPdfMock, cols, tableContent);
				expect(jsPdfMock.save).toHaveBeenCalledWith(fileName);
			});
		});
	});
});
