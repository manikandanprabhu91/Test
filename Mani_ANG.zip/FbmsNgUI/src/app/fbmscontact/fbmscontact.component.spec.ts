import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FbmscontactComponent } from './fbmscontact.component';

describe('FbmscontactComponent', () => {
  let component: FbmscontactComponent;
  let fixture: ComponentFixture<FbmscontactComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FbmscontactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FbmscontactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
