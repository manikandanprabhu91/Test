import { Component, Inject } from '@angular/core';
import {RestcallService} from '../../services/restcall.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'accountpref',
  templateUrl: './accountpref.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})
export class AccountprefComponent {
  configUrl: string = "";
  preferenceList : any[];
  saveIcon = false;
  ouVal;
  orgVal;
  assignee : any[];
  editDisabled = false;
  loading: boolean;

  constructor(private RestCallService: RestcallService,private dialog: MatDialog, private fb:FormBuilder) { }

  accountPrefInvoke(ouVal,orgVal, assignee){
    this.saveIcon = false;
    this.orgVal = orgVal;
    this.ouVal = ouVal;
    this.assignee = assignee;
    this.preferenceList == null || this.preferenceList == [] ? this.loading = true : this.loading = false;
    this.assignee.map(checkAssignee => {
      checkAssignee.cdsId == sessionStorage.getItem('loginId') ? this.editDisabled = true : '';
    });
    this.configUrl = "/fleet-fin-preferences/account-preferences/v1/account-pref"
    this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("orgCd", this.orgVal);
    this.RestCallService.setQueryParams("ouKey", this.ouVal);
    // this.configUrl="/accountPref";
    this.RestCallService.getData(this.configUrl).subscribe(report => this.mapVals(report),err => {
                                                                                      this.mapVals(null);
                                                                                    });
  }
  mapVals(report){
      this.preferenceList = report;
      this.preferenceList !=null ? this.preferenceList = this.preferenceList['accountPreference'] : this.preferenceList= null;
      this.loading = false;
  }

  clickIn(ind){
    this.preferenceList[ind].statusFlag == 'I' ?
                                                this.preferenceList[ind].statusFlag = 'A' :
                                                this.preferenceList[ind].statusFlag == 'A' ?
                                                this.preferenceList[ind].statusFlag = 'I' : '';
    this.saveIcon = true;
  }
  cancel(){
    const dialogRef = this.dialog.open(CancelConfirmDialog, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
      if(data == 'cancel'){
    this.accountPrefInvoke(this.ouVal,this.orgVal, this.assignee)
      }
    });
  }
  saveData(){
    let sendPrefList = {
      "finOpUnitMasterSaKey": this.ouVal,
      "fordOrgCode": this.orgVal,
      "assignee": this.assignee.map(data => data.cdsId),
      "acccountPrefVoList": this.preferenceList
      };
    let saveUrl = '/fleet-fin-preferences/account-preferences/v1/account-pref';
    this.RestCallService.ngOnInit();
    this.RestCallService.updateData(saveUrl, sendPrefList).subscribe(data => this.accountPrefInvoke(this.ouVal,this.orgVal,this.assignee));
  }

}

@Component({
  selector: 'cancel-confirm-dialog',
  templateUrl: 'cancel-confirm-dialog.html',
  })
  export class CancelConfirmDialog {
  constructor(
  public dialogRef: MatDialogRef<CancelConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onYesClick(){
    this.dialogRef.close('cancel');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
