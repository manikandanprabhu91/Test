import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountprefComponent } from './accountpref.component';

describe('AccountprefComponent', () => {
  let component: AccountprefComponent;
  let fixture: ComponentFixture<AccountprefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountprefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountprefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
