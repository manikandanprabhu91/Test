import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountnotesComponent } from './accountnotes.component';

describe('AccountnotesComponent', () => {
  let component: AccountnotesComponent;
  let fixture: ComponentFixture<AccountnotesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountnotesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountnotesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
