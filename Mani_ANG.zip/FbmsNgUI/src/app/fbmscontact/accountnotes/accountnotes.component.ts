import {Component, Inject} from '@angular/core';
import {RestcallService} from '../../services/restcall.service';
import { DatePipe } from '@angular/common';
import {MatSnackBar} from '@angular/material/snack-bar';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'accountnotes',
  templateUrl: './accountnotes.component.html',
  styleUrls: ['../fbmscontact.component.sass'],
})

export class AccountnotesComponent {
  //Rest service Url
  configUrl: string = "";
  noteList: any[] = [];

  addnewrow: boolean = false;
  accountNote: any;
  addHide = false;
  ouVal;
  orgVal;
  assignee;
  addressValue: any[];
  tableDate;
  tableCdsid;
  tableNote;
  cdsid;
  today:any;
  totalCount:number = 0;
  loading: boolean;

  constructor(private RestCallService: RestcallService,private dialog: MatDialog, private datePipe: DatePipe, private snackBar: MatSnackBar) {
  }
  ngOnInit() { }

  accounNotesInvoke(ouVal, orgVal, assignee){
    this.addnewrow = false;
    this.accountNote= '';
    this.loading = true;
    //Table data thru rest call
    this.cdsid = sessionStorage.getItem('loginId');
    //current date
    this.today = new Date;
    this.today = this.datePipe.transform(this.today, 'MM/dd/yyyy');

    this.ouVal = ouVal;
    this.orgVal = orgVal;
    this.assignee = assignee;
    this.configUrl = "/fleet-notes-management/notes/v1/account-notes";
    this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("orgCd", this.orgVal);
    this.RestCallService.setQueryParams("ouKey", this.ouVal);
    // this.configUrl  = "/accountNoteListDummy";
    this.RestCallService.getData(this.configUrl).subscribe(report => this.mapNoteValues(report));
  }

  mapNoteValues(report){
    this.assignee.map(checkAssignee => {
      //this.addHide = checkAssignee.cdsId.includes(sessionStorage.getItem('loginId'));
      checkAssignee.cdsId == sessionStorage.getItem('loginId') ? this.addHide = true : '';
    });
    report!=null ? this.addressValue = report.accountNotes : this.addressValue= null;
    this.addressValue !=null ? this.totalCount = this.addressValue.length: this.totalCount = 0;
    this.loading = false;
  }

  addnew(){
    this.addnewrow = true;
  }
  //Adding new Row
  addItem(){
    let saveUrl = '/fleet-notes-management/notes/v1/account-notes';
    this.RestCallService.ngOnInit();
    let postAccountNote = {
      "ouKey": this.ouVal,
      "orgCd": this.orgVal,
      "accountNote": this.accountNote,
      "assignees": this.assignee.map(data=> data.cdsId)
    }
    this.RestCallService.createData(saveUrl, postAccountNote).subscribe(data =>  {
    this.addnewrow = false;
    this.accountNote= '';
    this.accounNotesInvoke(this.ouVal, this.orgVal, this.assignee)
    });
  }
  //Reset/Cancel
  cancel(){
    if(this.accountNote != null && this.accountNote != '' ){
      const dialogRef = this.dialog.open(CancelConfirmDialog, {width: '300px'});
      dialogRef.afterClosed().subscribe(data => {
      if(data == 'cancel'){
        this.addnewrow = false;
        this.accountNote= '';
      }
      });
    }else{
      this.addnewrow = false;
        this.accountNote= '';
    }

  }
}


@Component({
  selector: 'cancel-confirm-dialog',
  templateUrl: 'cancel-confirm-dialog.html',
  })
  export class CancelConfirmDialog {
  constructor(
  public dialogRef: MatDialogRef<CancelConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  onYesClick(){
    this.dialogRef.close('cancel');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
