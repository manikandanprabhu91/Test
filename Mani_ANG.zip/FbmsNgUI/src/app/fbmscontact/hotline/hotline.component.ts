import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RestcallService } from 'src/app/services/restcall.service';
import { ActivatedRoute } from 'src/testing/router-stubs';

@Component({
  selector: 'hotline',
  templateUrl: './hotline.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})
export class HotlineComponent implements OnInit {

  accountName: String;
  accountStatus: string;
  statusData: any[];
  countryCode = sessionStorage.getItem('countryCode');
  configUrl: string = "";
  taxId: string = "";
  fleetRating: string = "";
  ouKey;
  ouCode;
  hotlineForm: FormGroup;
  reason: any;
  hotlineArray: any;
  oudba: any;
  finKey: any;
  fleetPersonCdsid = sessionStorage.getItem('loginId');
  fbmsEmailId: string;
  spinner: boolean = false;

  constructor(public dialogRef: MatDialogRef<HotlineComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder,
    private RestcallService: RestcallService, private route: ActivatedRoute) {
    dialogRef.disableClose = true;
    this.hotlineForm = this.fb.group({
      streetOnePhysical: [''],
      streetTwoPhysical: [''],
      cityPhysical: [''],
      statePhysical: [''],
      postalPhysical: [''],
      poBoxMailing: [''],
      cityMailing: [''],
      StateMailing: [''],
      PostalMailing: [''],
      ExtMailing: [''],
      firstNameContact: [''],
      middleNameContact: [''],
      lastNameContact: [''],
      titleContact: [''],
      phoneContact: [''],
      phoneExtnContact: [''],
      faxContact: [''],
      eMailContact: ['']
    });
  }

  ngOnInit(): void {
    this.ouKey = this.data.ouKey;
    this.oudba = this.data.oudba;
    for (var val of this.oudba) {
      if (val.ouKey == this.ouKey) {
        this.ouCode = val.ouCd;
        this.accountName = val.accountName;
        this.accountStatus = val.finStatus;
      }
    }
    this.finKey = this.route.snapshot.queryParamMap.get('fin');
    this.addressDataFetch();
    this.contactDataFetch();
    this.statusData = [
      { label: 'Active', value: 'A' },
      { label: 'Deactivated', value: 'D' },
      { label: 'Inactive', value: 'I' }
    ];
    if (this.countryCode == 'MEX') {
      this.configUrl = "/fleet-corporate-management/information/v1/fleet-corporate-info";
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("ouKey", this.ouKey);
      this.RestcallService.getData(this.configUrl).subscribe(data => {
        this.taxId = data['taxId'];
        this.fleetRating = data['fleetRating'];
      });
    }
  }

  addressDataFetch() {
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('orgCd', this.data.orgselectedValue)
    this.configUrl = "/fleet-fin-orchestrator/fin-operating-unit/v1/ou/" + this.ouKey + "/address";
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      if (data.addresses[0] != null) {
        this.hotlineForm.controls['streetOnePhysical'].setValue(data.addresses[0].addressLine1);
        this.hotlineForm.controls['streetTwoPhysical'].setValue(data.addresses[0].addressLine2);
        this.hotlineForm.controls['cityPhysical'].setValue(data.addresses[0].city);
        this.hotlineForm.controls['statePhysical'].setValue(data.addresses[0].state);
        this.hotlineForm.controls['postalPhysical'].setValue(data.addresses[0].zipCode);
      }
      if (data.addresses[1] != null) {
        this.hotlineForm.controls['poBoxMailing'].setValue(data.addresses[1].addressLine1);
        this.hotlineForm.controls['cityMailing'].setValue(data.addresses[1].city);
        this.hotlineForm.controls['StateMailing'].setValue(data.addresses[1].state);
        this.hotlineForm.controls['PostalMailing'].setValue(data.addresses[1].zipCode);
        this.hotlineForm.controls['ExtMailing'].setValue(data.addresses[1].addressLine2);
      }
    });
  }

  contactDataFetch() {
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("orgCd", this.data.orgselectedValue);
    this.RestcallService.setQueryParams("ouKey", this.ouKey);
    this.configUrl = "/fleet-customer-management/fleet-persons/v1/fleet-person";
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      if (data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.finContactCd == 'Y') {
        this.hotlineForm.controls['firstNameContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.fname);
        this.hotlineForm.controls['middleNameContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.mname);
        this.hotlineForm.controls['lastNameContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.lname);
        this.hotlineForm.controls['titleContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.title);
        this.hotlineForm.controls['phoneContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.phone);
        this.hotlineForm.controls['phoneExtnContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.extension);
        this.hotlineForm.controls['faxContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.fax);
        this.hotlineForm.controls['eMailContact'].setValue(data.fleetPersonAssignmentDtos[0].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.email);
      }
    });
  }

  onHotlineSave() {
    this.spinner = true;
    this.hotlineForm.disable();
    this.fbmsEmailId = this.fleetPersonCdsid + '@ford.com';
    this.RestcallService.ngOnInit();
    this.configUrl = "/fleet-fin-orchestrator/fin-operating-unit/v1/fin-hotline";
    let accountStatus;
    if (this.accountStatus == 'Active') {
      accountStatus = 'A';
    } else if (this.accountStatus == 'Deactivated') {
      accountStatus = 'D';
    } else if (this.accountStatus == 'Inactive') {
      accountStatus = 'I';
    } else {
      accountStatus = '';
    }
    this.hotlineArray = {
      "accountName": this.accountName,
      "changeReason": this.reason == null ? '' : this.reason,
      "city": this.hotlineForm.get('cityPhysical').value == null ? '' : this.hotlineForm.get('cityPhysical').value,
      "contactTitle": this.hotlineForm.get('titleContact').value == null ? '' : this.hotlineForm.get('titleContact').value,
      "countryCd": this.countryCode == null ? '' : this.countryCode,
      "email": this.hotlineForm.get('eMailContact').value == null ? '' : this.hotlineForm.get('eMailContact').value,
      "fax": this.hotlineForm.get('faxContact').value == null ? '' : this.hotlineForm.get('faxContact').value,
      "fbmsEmailId": this.fbmsEmailId == null ? '' : this.fbmsEmailId,
      "finCd": this.data.finCode == null ? '' : this.data.finCode,
      "finKey": this.finKey == null ? null : Number(this.finKey),
      "firstName": this.hotlineForm.get('firstNameContact').value == null ? '' : this.hotlineForm.get('firstNameContact').value,
      "fleetRating": this.fleetRating == null ? '' : this.fleetRating,
      "lastName": this.hotlineForm.get('lastNameContact').value == null ? '' : this.hotlineForm.get('lastNameContact').value,
      "mailingCityName": this.hotlineForm.get('cityMailing').value == null ? '' : this.hotlineForm.get('cityMailing').value,
      "mailingPoBox": this.hotlineForm.get('poBoxMailing').value == null ? '' : this.hotlineForm.get('poBoxMailing').value,
      "mailingStateName": this.hotlineForm.get('StateMailing').value == null ? '' : this.hotlineForm.get('StateMailing').value,
      "mailingZip": this.hotlineForm.get('PostalMailing').value == null ? '' : this.hotlineForm.get('PostalMailing').value,
      "mailingZipExt": this.hotlineForm.get('ExtMailing').value == null ? '' : this.hotlineForm.get('ExtMailing').value,
      "middleName": this.hotlineForm.get('middleNameContact').value == null ? '' : this.hotlineForm.get('middleNameContact').value,
      "ouCode": this.ouCode == null ? '' : this.ouCode,
      "ouKey": this.ouKey == null ? null : Number(this.ouKey) ,
      "phone": this.hotlineForm.get('phoneContact').value == null ? '' : this.hotlineForm.get('phoneContact').value,
      "phoneExt": this.hotlineForm.get('phoneExtnContact').value == null ? '' : this.hotlineForm.get('phoneExtnContact').value,
      "postalCode": this.hotlineForm.get('postalPhysical').value == null ? '' : this.hotlineForm.get('postalPhysical').value,
      "state": this.hotlineForm.get('statePhysical').value == null ? '' : this.hotlineForm.get('statePhysical').value,
      "status": accountStatus,
      "streetAddress1": this.hotlineForm.get('streetOnePhysical').value == null ? '' : this.hotlineForm.get('streetOnePhysical').value,
      "streetAddress2": this.hotlineForm.get('streetTwoPhysical').value == null ? '' : this.hotlineForm.get('streetTwoPhysical').value,
      "taxId": this.taxId == null ? '' : this.taxId
    }
    this.RestcallService.updateData(this.configUrl, this.hotlineArray).subscribe(data => {
      this.dialogRef.close('ok');
      this.spinner = false;
    }, err => {
      this.dialogRef.close('ok');
      this.spinner = false;
    });
  }

  onHotlineCancel() {
    this.dialogRef.close();
  }
}
