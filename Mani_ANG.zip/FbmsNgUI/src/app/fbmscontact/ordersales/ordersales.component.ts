import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from 'src/testing/router-stubs';
import {RestcallService} from '../../services/restcall.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'ordersales',
  templateUrl: './ordersales.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})
export class OrdersalesComponent implements OnInit {

  configUrl : string;
  parentFin: string;
  programYear: number;
  selectedYear: number;
  includeSubsidaries: boolean = false;
  finKey: any;
  ordersTableData: [];
  ordersTotal: any;
  tableLoadConfigUrl: any;
  totalRecords: number = 0;
  loading: boolean;
  finalTotal: number;
  finalTotalScheduled: number;
  finalTotalSold: number;
  finalTotalmlv: number;
  finalTotalunscheduled: number;
  today:any;


  constructor(private RestcallService: RestcallService, private route: ActivatedRoute, private datePipe: DatePipe) { }

  ngOnInit(): void { }
  orderSalesInvoke(finCode){
  //current date
  this.today = new Date;
  this.today = Number(this.datePipe.transform(this.today, 'yyyy'));
    this.loading = true;
    this.finKey= this.route.snapshot.queryParamMap.get('fin');
    this.parentFin = finCode;
    this.configUrl = "/fleet-orders-sales/order-sales-lookups/v1/program-years";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finCd", this.parentFin);
    // this.configUrl = "/ordersAndSalesPopulate";
    this.RestcallService.getData(this.configUrl).subscribe((respData) => {
      this.programYear = respData.proposalYearDefinitionResponse['programYear'];
      this.selectedYear = respData.proposalYearDefinitionResponse['programYear'].includes(this.today) ? this.today : respData.proposalYearDefinitionResponse['programYear'][0];
      this.ordersTablePopulate(this.selectedYear,this.includeSubsidaries);
    });
  }
  ordersInvoke(selectedYear, includeSubsidaries){
    if(selectedYear != "" && selectedYear != null) {
      this.loading = true;
      this.ordersTablePopulate(selectedYear,includeSubsidaries);
    } else {
      this.RestcallService.statusMessage(417, "Proposal Year not selected, Please select it");
    }
  }
  ordersTablePopulate(selectedYear, includeSubsidaries){
    this.loading = true;
    this.tableLoadConfigUrl = "/fleet-orders-sales/order-sales-lookups/v1/orders-and-sales";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finKey",this.finKey);
    this.RestcallService.setQueryParams("finCd", this.parentFin);
     this.RestcallService.setQueryParams("includeSubsidiaries",includeSubsidaries);
     this.RestcallService.setQueryParams("programYearCd",selectedYear);
    // this.tableLoadConfigUrl = "/ordersAndSalesList";
     this.RestcallService.getData(this.tableLoadConfigUrl).subscribe((respData) => {
      respData != null ? this.ordersTableData = respData.orderAndSalesResponse as any : this.ordersTableData = null;
     respData !=null ?  this.ordersTotal = respData.orderAndSalesResponse['totalOrdersAndSales'] : this.ordersTotal =0;
     this.ordersTableData !=null ?  this.ordersTableData = this.ordersTableData['ordersAndSales'] : this.ordersTableData =null;
     this.ordersTableData !=null ?  this.totalRecords = this.ordersTableData.length : this.totalRecords =0;
     if(this.ordersTotal != 0){
      this.finalTotal = this.ordersTotal.finalTotal;
      this.finalTotalScheduled = this.ordersTotal.finalTotalScheduled;
      this.finalTotalSold = this.ordersTotal.finalTotalSold;
      this.finalTotalmlv = this.ordersTotal.finalTotalMlv;
      this.finalTotalunscheduled = this.ordersTotal.finalTotalUnScheduled;
     }
     this.loading = false;
    //  this.ordersTableData !=null ? this.totalRecords = this.ordersTableData.length : this.totalRecords = 0;
     }, err => {  this.loading = false; this.ordersTableData= null });
  }

}
