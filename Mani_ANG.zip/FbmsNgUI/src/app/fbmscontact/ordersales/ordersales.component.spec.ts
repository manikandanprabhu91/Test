import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdersalesComponent } from './ordersales.component';

describe('OrdersalesComponent', () => {
  let component: OrdersalesComponent;
  let fixture: ComponentFixture<OrdersalesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrdersalesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
