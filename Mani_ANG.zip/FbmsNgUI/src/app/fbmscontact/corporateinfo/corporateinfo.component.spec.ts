import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateinfoComponent } from './corporateinfo.component';

describe('CorporateinfoComponent', () => {
  let component: CorporateinfoComponent;
  let fixture: ComponentFixture<CorporateinfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CorporateinfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CorporateinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
