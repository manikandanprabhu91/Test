import { Component, OnInit } from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup, FormArray} from '@angular/forms';
import { find, map } from 'rxjs/operators';
import {RestcallService} from '../../services/restcall.service';
import {MatSnackBar} from '@angular/material/snack-bar';
@Component({
  selector: 'corporateinfo',
  templateUrl: './corporateinfo.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})


export class CorporateinfoComponent implements OnInit {

  configUrl: string ="";

  corporateform: FormGroup;
  coporateFormValues : any;
  isReadOnly: boolean = false;
  enableFoot = 0;
  //For check box
  list = [];
  checkedList = [];
  addedList = [];
  languageOptions = [];
  viewClass = 0;
  viewStatusCode: number;
  viewStatusMessage: string;
  ouVal;
  orgVal;
  assignee;
  vatValue;
  fleetRating;
  enableSubmit: boolean;
  country = sessionStorage.getItem('countryCode');
  spinnerLoad: boolean;
  editDisabled = false;

  constructor(private cpbuild: FormBuilder, private RestcallService: RestcallService, private snackBar: MatSnackBar) {
    //Specifying the form group
    this.corporateform = cpbuild.group({
      stock : ['', [Validators.maxLength(500)]],
      website : ['', [Validators.maxLength(500)]],
      cpsc : ['', [Validators.maxLength(500)]],
      sicc : ['', [Validators.maxLength(500)]],
      companies : this.cpbuild.array([
        this.cpbuild.group({
          compName: [''],
          compSelect:[false]
        })
      ]),
      vendor : ['',[Validators.maxLength(500)]],
      uiocv : ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]],
      uiocar : ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]],
      forduio : ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]],
      totuio : ['', [Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]],
      lang : [''],
      hidden: ['']
    })
   }

  ngOnInit(): void {
   }

   corporateInfoInvoke(ouVal,orgVal, assignee){
    this.spinnerLoad = false;
    this.enableSubmit = false;
    this.enableFoot = 0;
    this.isReadOnly = false;
    this.corporateform.reset();

      this.assignee = assignee;
      this.ouVal = ouVal;
      this.orgVal = orgVal;
      this.assignee.map(checkAssignee => {
        checkAssignee.cdsId == sessionStorage.getItem('loginId') ? this.editDisabled = true : '';
      });
  this.configUrl ="/fleet-corporate-management/information/v1/fleet-corporate-info";
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("ouKey",this.ouVal );
    // this.configUrl = "/corporateForm";
    this.RestcallService.getData(this.configUrl).subscribe(data => {
      this.coporateFormValues = data;
      this.dropdownValueSet();
      //this.languageOptions = this.coporateFormValues[0].lang;
      this.setFormValues();
    });
  }

  //Dropdown
  shareCheckedList(item:any[]){
    this.enableSubmit = true;
    this.addedList = item;
    this.hiddenfunc();
  }
  shareIndividualCheckedList(item:any[]){
  }
  dropdownValueSet(){
    this.list=[];
    this.coporateFormValues['leasingCompanyList'].map(compList =>{
      this.list.push(
        { indicatorname: compList.compName, flag: compList.compSelect }
        );
    });
    this.checkListValueSet();
  }

  checkListValueSet(){
    this.checkedList =[];
    this.list.map(data=> {
      if(data.flag){
        this.checkedList.push(data.indicatorname);
      }
    });
  }
  setFormValues(){
  //  this.languageOptions.map(langVal => {
  //     if(langVal.langSelect){
  //       this.corporateform.patchValue({lang: langVal.langname});
  //     }
  //   });
    //let stockValue = this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='002' ? data.accountInfoValue : console.log(data.accountInfoValue));
    let stockValue;
    this.coporateFormValues['corporateInfoList'].map(val => {
      val.accountInfoType=='002'? stockValue = val.accountInfoValue : null
    });
    let cpscValue ;
    this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='003' ? cpscValue = data.accountInfoValue : null);
    let websiteValue;
    this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='004' ? websiteValue = data.accountInfoValue : null);
    let siccValue = this.coporateFormValues['stdIndustrialDesc'];
    let vendorValue ;
    this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='018' ? vendorValue=data.accountInfoValue : null);
    let uiocvValue;
     this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='039' ? uiocvValue=data.accountInfoValue : null);
    let uiocarValue;
         this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='040' ? uiocarValue=data.accountInfoValue : null);
    let forduioValue;
     this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='017' ? forduioValue=data.accountInfoValue : null);
    let totuioValue;
    this.coporateFormValues['corporateInfoList'].map(data =>  data.accountInfoType =='006' ? totuioValue=data.accountInfoValue : null);
    
      this.vatValue = this.coporateFormValues['taxId'];
      this.fleetRating = this.coporateFormValues['fleetRating'];
      
 

  this.corporateform.patchValue({
    stock: stockValue,
    cpsc: cpscValue,
    website: websiteValue,
    sicc: siccValue,
    vendor: vendorValue,
    uiocv: uiocvValue,
    uiocar: uiocarValue,
    forduio:forduioValue,
    totuio: totuioValue,
  });
  if(uiocvValue || uiocarValue){
    this.uiocv();
  }

}

  //set validators
  uiocv(){
    if((!this.corporateform.get('uiocv').errors && this.corporateform.get('uiocv').value) || (!this.corporateform.get('uiocar').errors && this.corporateform.get('uiocar').value)){
      //shold check the value of totuio
      let forduio = +this.corporateform.get('uiocv').value + +this.corporateform.get('uiocar').value;
      this.corporateform.patchValue({
        forduio : forduio
      });
      this.isReadOnly = true;
      this.enableFoot = 1;
      this.corporateform.get('totuio').setValidators([Validators.pattern("^[0-9]*$"), Validators.min(forduio), Validators.maxLength(500)]);
      this.corporateform.get('totuio').updateValueAndValidity();
      this.corporateform.get('forduio').setValidators([Validators.pattern("^[0-9]*$"), Validators.min(forduio), Validators.max(forduio), Validators.maxLength(500)]);
      this.corporateform.get('forduio').updateValueAndValidity();
    }
    else{
      this.isReadOnly = false;
      this.enableFoot = 0;
      this.corporateform.get['totuio'].clearValidators();
      this.corporateform.get('totuio').setValidators([Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]);
      this.corporateform.get('totuio').updateValueAndValidity();
      this.corporateform.get['forduio'].clearValidators();
      this.corporateform.get('forduio').setValidators([Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]);
      this.corporateform.get('forduio').updateValueAndValidity();
     }
  }
  forduioValueChange(){
    if(!this.corporateform.get('forduio').errors && this.corporateform.get('forduio').value){
      this.corporateform.get('forduio').clearValidators();
      this.corporateform.get('forduio').setValidators([Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]);
      this.corporateform.get('forduio').updateValueAndValidity();
      let minVal = +this.corporateform.get('forduio').value;
      this.corporateform.get('totuio').setValidators([Validators.pattern("^[0-9]*$"), Validators.min(minVal), Validators.maxLength(500)]);
      this.corporateform.get('totuio').updateValueAndValidity();
    }
    else{
      this.corporateform.get('totuio').clearValidators();
      this.corporateform.get('totuio').setValidators([Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]);
      this.corporateform.get('totuio').updateValueAndValidity();
    }
  }
  totuioValueChange(){
    if(!this.corporateform.get('totuio').errors && this.corporateform.get('totuio').value){
      this.corporateform.get('totuio').clearValidators();
      this.corporateform.get('totuio').setValidators([Validators.pattern("^[0-9]*$"), Validators.maxLength(500)]);
      let maxVal = this.corporateform.get('totuio').value;
      this.corporateform.get('forduio').setValidators([Validators.pattern("^[0-9]*$"), Validators.max(maxVal), Validators.maxLength(500)]);
      this.corporateform.get('forduio').updateValueAndValidity();
    }
  }
  hiddenfunc(){
    if(!this.addedList.length || this.addedList.length > 3 ){
      this.corporateform.patchValue({
        hidden: 0
      })
      this.corporateform.get('hidden').setValidators([Validators.min(1)]);
      this.corporateform.get('hidden').updateValueAndValidity();
      this.viewClass = 1;
    }
    else{
      this.viewClass = 0;
      this.corporateform.patchValue({
        hidden: 1
      })
      this.corporateform.get['hidden'].clearValidators();
      this.corporateform.get('hidden').updateValueAndValidity();
    }
  }

  //On Submitting the form
  postform(){

    if(!this.addedList.length){
      if(!this.checkedList.length){
        this.hiddenfunc();
      }
      else{
        this.addedList = this.checkedList;
        this.postform();
      }
    }

    else{
    let chosen = this.corporateform.get('lang').value;
    // this.languageOptions.map(mapVal => {
    //   if(mapVal.langname == chosen){
    //     mapVal.langSelect = true;
    //   }else{
    //     mapVal.langSelect = false;
    //   }
    // })
    // this.corporateform.patchValue({lang: this.languageOptions})

    this.corporateform.value.companies = [];
    this.list.map(addSelect => {
      let testVal = this.addedList.includes(addSelect.indicatorname);
      if(testVal){
        this.corporateform.value.companies.push({compName: addSelect.indicatorname, compSelect: true})
      }else{
        this.corporateform.value.companies.push({compName: addSelect.indicatorname, compSelect: false})
      }
    });
      let saveArray = {
        "corporateInfoList": [
          {
          "accountInfoType": "002",
          "accountInfoValue": this.corporateform.value.stock
          },
          {
            "accountInfoType": "003",
            "accountInfoValue": this.corporateform.value.cpsc
          },
          {
            "accountInfoType": "004",
            "accountInfoValue": this.corporateform.value.website
          },
          {
            "accountInfoType": "006",
            "accountInfoValue": this.corporateform.value.totuio
          },
          {
            "accountInfoType": "017",
            "accountInfoValue": this.corporateform.value.forduio
          },
          {
            "accountInfoType": "018",
            "accountInfoValue": this.corporateform.value.vendor
          },
          {
            "accountInfoType": "039",
            "accountInfoValue": this.corporateform.value.uiocv
          },
          {
            "accountInfoType": "040",
            "accountInfoValue": this.corporateform.value.uiocar
          }
        ],
        "leasingCompanyList": this.corporateform.value.companies
      }
      this.spinnerLoad = true;
      let saveUrl = '/fleet-corporate-management/information/v1/fleet-corporate-info';
      this.RestcallService.ngOnInit();
      this.RestcallService.setQueryParams("ouKey",this.ouVal );
      this.RestcallService.updateData(saveUrl, saveArray).subscribe(data=> this.corporateInfoInvoke(this.ouVal,this.orgVal,this.assignee),
      err => this.spinnerLoad = false)
  }
}
}
