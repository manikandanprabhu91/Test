import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddressComponent } from './address/address.component';
import { RestcallService } from '../services/restcall.service';
import { AccountnotesComponent } from './accountnotes/accountnotes.component';
import { AccountprefComponent } from './accountpref/accountpref.component';
import { ActivatedRoute } from '@angular/router';
import { PersonalprefComponent } from './personalpref/personalpref.component';
import { CorporateinfoComponent } from './corporateinfo/corporateinfo.component';
import { OrdersalesComponent } from './ordersales/ordersales.component';
import { HotlineComponent } from './hotline/hotline.component';

@Component({
  selector: 'fbmscontact',
  templateUrl: './fbmscontact.component.html',
  styleUrls: ['./fbmscontact.component.sass']
})
export class FbmscontactComponent implements OnInit {
  configUrl: string;
  searchValues: any[];
  country = sessionStorage.getItem('countryCode');
  finName: string;
  finCode: any;
  assignee: any[];
  segment: string;
  status: string;
  region: string;
  oudba: any[];
  organization: any[];
  ouselectedValue: string;
  orgselectedValue: string;
  originalOrg: string;
  ouTooltip: any;
  orgTooltip: any;
  finKey: any;
  programYear: any;

  @ViewChild(AddressComponent) Address: AddressComponent;
  @ViewChild(AccountnotesComponent) AccountNotes: AccountnotesComponent;
  @ViewChild(AccountprefComponent) AccountPreference: AccountprefComponent;
  @ViewChild(PersonalprefComponent) PersonalPref: PersonalprefComponent;
  @ViewChild(OrdersalesComponent) OrderSales: OrdersalesComponent;
  @ViewChild(CorporateinfoComponent) CorporateInfo: CorporateinfoComponent;



  constructor(public dialog: MatDialog, private RestcallService: RestcallService, private route: ActivatedRoute) { }

  ngOnInit(): void {
    //Collapse side navigation
    const body = document.getElementsByTagName('body')[0];
    body.classList.add('sidebar-collapse');
    this.finKey = this.route.snapshot.queryParamMap.get('fin');
    this.programYear = this.route.snapshot.queryParamMap.get('py');
    this.RestcallService.ngOnInit();
    this.configUrl = "/fleet-fin-orchestrator/fin-operating-unit/v1/fin/" + this.finKey + "/ou-org";
    // this.configUrl = "/ou-org";
    this.dialog.closeAll();
    this.RestcallService.getData(this.configUrl).subscribe((respData) => {
      this.mapSearchValues(respData);
    })
  }
  //Assign dynamic values
  mapSearchValues(respData) {
    this.searchValues = respData;
    this.originalOrg = this.searchValues['personOrg'];
    this.country = sessionStorage.getItem('countryCode');
    this.finCode = this.searchValues['finMasterDto'].finCode;
    this.finName = this.searchValues['finOpUnitMasterDtoList'][0].accountName;
    this.segment = this.searchValues['segmentDesc'];
    this.region = this.searchValues['region'];
    this.assignee = this.searchValues['accountAssignmentDtoList'];
    this.oudba = this.searchValues['finOpUnitMasterDtoList'];
    this.organization = this.searchValues['fordOrganizationDtoList'];
    this.ouselectedValue = this.searchValues['finOpUnitMasterDtoList'][0].ouKey;
    this.ouTooltip = this.searchValues['finOpUnitMasterDtoList'][0].accountName;
    this.orgselectedValue = this.searchValues['personOrg'];
    this.organization.map(data => {
      if (data.fordOrgCode == this.orgselectedValue) {
        this.orgTooltip = data.fordOrgDescription;
      }
    });
    this.valuetoSend(this.ouselectedValue, this.orgselectedValue);
  }
  ouDropdown(ouSelect){
  
    this.oudba.map(data =>{
      if(data.ouKey == ouSelect){
        this.ouTooltip = data.accountName;
      }
    });
  }
  orgDropdown(orgSelect){
    this.organization.map(data =>{
      if(data.fordOrgCode == orgSelect){
        this.orgTooltip = data.fordOrgDescription;
      }
    });
  }
  //Call to Invoke corresponsing services
  valuetoSend(ouVal, orgVal) {
    //Change status based on OU
    this.searchValues['finOpUnitMasterDtoList'].map(mapVal => {
      mapVal.ouKey == ouVal ? this.status = mapVal.finStatus : ''
    });
    //Child component call
    this.Address.addressInvoke(ouVal, orgVal, this.assignee);
    this.AccountNotes.accounNotesInvoke(ouVal, orgVal, this.assignee);
    this.AccountPreference.accountPrefInvoke(ouVal, orgVal, this.assignee);
    this.PersonalPref.personalPrefInvoke(ouVal, orgVal, this.assignee, this.originalOrg);
    if(this.country != 'CAN') {
      this.OrderSales.orderSalesInvoke(this.finCode);
    }
    this.CorporateInfo.corporateInfoInvoke(ouVal, orgVal, this.assignee);
  }

  openDialog() {
    const dialogRef = this.dialog.open(HotlineComponent, {
      panelClass: 'myapp-no-padding-dialog',
      height: '550px',
      minWidth:'90vw',
      restoreFocus: false,
      disableClose: false,
      data: {
        finCode: this.finCode,
        ouKey: this.ouselectedValue,
        orgselectedValue: this.orgselectedValue,
        oudba: this.oudba
      }
    });
  }
  reportDownload(){
    let reportUrl = '/fleet-fin-orchestrator/fin-operating-unit/v1/ou/' + this.ouselectedValue + '/download-contact-report';
    let includeSubsidiaries = this.OrderSales.includeSubsidaries;
    let programYearCd = this.OrderSales.selectedYear;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams("finCd", this.finCode);
    this.RestcallService.setQueryParams("finKey", this.finKey);
    this.RestcallService.setQueryParams("orgCd", this.orgselectedValue);
    this.RestcallService.setQueryParams("ouKey", this.ouselectedValue);
    this.RestcallService.setQueryParams("includeSubsidiaries", includeSubsidiaries);
    this.RestcallService.setQueryParams("programYearCd", programYearCd);
    this.RestcallService.downloadExcel(reportUrl, "ContactReport.xls");
  }
}
