import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalprefComponent } from './personalpref.component';

describe('PersonalprefComponent', () => {
  let component: PersonalprefComponent;
  let fixture: ComponentFixture<PersonalprefComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalprefComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalprefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
