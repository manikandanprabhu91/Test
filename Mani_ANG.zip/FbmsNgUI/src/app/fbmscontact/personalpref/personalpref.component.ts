import { Component, OnInit, Inject } from '@angular/core';
import {RestcallService} from '../../services/restcall.service';
import { Form, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'personalpref',
  templateUrl: './personalpref.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})
export class PersonalprefComponent implements OnInit {
  configUrl: string ="";
  personList: any[];
  addnewPerson = false;
  createPersonArray : any;
  createPerson: FormGroup;
  addDropdown: any;

  editRow: number;
  editDropdown: any;

  addHide = false;
  ouVal: number;
  orgVal: string;
  assignee;
  originalOrg: string;
  fleetPersonId: number;
  loading: boolean;


  constructor(private RestCallService: RestcallService, private fb:FormBuilder, private route: ActivatedRoute, private dialog: MatDialog){
    this.createPerson = this.fb.group({
      salutation: [''],
      firstName: ['', ([Validators.required, Validators.maxLength(30)])],
      middleName: ['', ([Validators.maxLength(1)])],
      lastName: ['', ([Validators.required,  Validators.maxLength(50)])],
      title: ['', ([Validators.required,  Validators.maxLength(50)])],
      phone: ['', ([Validators.required, Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      extension: ['', ([Validators.maxLength(5),Validators.pattern("^[0-9]*$")])],
      cell: ['', ([Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      email: ['', ([Validators.email,  Validators.maxLength(60)])],
      fax: ['', ([Validators.minLength(10), Validators.maxLength(18), Validators.pattern('[- +0-9]+')])],
      wslx: ['',([Validators.maxLength(8)])],
      address1: [''],
      address2: [''],
      city: [''],
      state: [''],
      zipCode: ['', ([Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")])],
      indicator: ['']
    });
   }

  ngOnInit(): void { }


  personalPrefInvoke(ouVal, orgVal, assignee, originalOrg){
    this.loading = true;
    this.editRow = null;
    this.addnewPerson = false;
    this.createPerson.reset();

    this.assignee = assignee;
    this.ouVal = ouVal;
    this.orgVal = orgVal;
    this.originalOrg = originalOrg;
    this.assignee.map(checkAssignee => {
      checkAssignee.cdsId == sessionStorage.getItem('loginId') ? this.addHide = true : '';
    });

    this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("orgCd",this.orgVal);
    this.RestCallService.setQueryParams("ouKey",this.ouVal);
    this.configUrl= "/fleet-customer-management/fleet-persons/v1/fleet-person";
    // this.configUrl= "/personnelprefDto";
    this.RestCallService.getData(this.configUrl).subscribe((personData) => {
    this.mapPersonData(personData);
    },  err => this.mapPersonData(null));
  }

  //Map Data to table
  mapPersonData(personData){
    personData!=null ?  this.personList = personData['fleetPersonAssignmentDtos'] : this.personList = null;
    this.loading = false;
  }
  //Add New Row icon click
  addnew(){
    this.RestCallService.ngOnInit();
    let addFetchUrl = "/fleet-customer-management/fleet-persons/v1/fleet-person-info";
    this.RestCallService.setQueryParams("orgCd",this.orgVal);
    // let addFetchUrl = "/personalprefAdd";
    this.createPerson.reset();
    this.RestCallService.getData(addFetchUrl).subscribe(data => this.mapAddDropdown(data));
    this.addnewPerson = true;
  }
  mapAddDropdown(data){
    this.addDropdown = data;
  }
  //Setting Custom Validation
  address1Change(){
    if(!this.createPerson.get('address1').errors && this.createPerson.get('address1').value.length > 0){
      this.createPerson.get('address2').setValidators(Validators.required);
      this.updateValue('address2');
      this.createPerson.get('city').setValidators(Validators.required);
      this.updateValue('city');
      this.createPerson.get('state').setValidators(Validators.required);
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.required, Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
    else if(!this.createPerson.get('address1').errors && this.createPerson.get('address1').value.length == 0){
      this.createPerson.get('address2').clearValidators();
      this.updateValue('address2');
      this.createPerson.get('city').clearValidators();
      this.updateValue('city');
      this.createPerson.get('state').clearValidators();
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
  }
  address2Change(){
    if(!this.createPerson.get('address2').errors && this.createPerson.get('address2').value.length > 0){
      this.createPerson.get('address1').setValidators(Validators.required);
      this.updateValue('address1');
      this.createPerson.get('city').setValidators(Validators.required);
      this.updateValue('city');
      this.createPerson.get('state').setValidators(Validators.required);
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.required, Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
    else if(!this.createPerson.get('address2').errors && this.createPerson.get('address2').value.length > 0){
      this.createPerson.get('address1').clearValidators();
      this.updateValue('address1');
      this.createPerson.get('city').clearValidators();
      this.updateValue('city');
      this.createPerson.get('state').clearValidators();
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
  }
  cityChange(){
    if(!this.createPerson.get('city').errors && this.createPerson.get('city').value.length > 0){
      this.createPerson.get('address1').setValidators(Validators.required);
      this.updateValue('address1');
      this.createPerson.get('address2').setValidators(Validators.required);
      this.updateValue('address2');
      this.createPerson.get('state').setValidators(Validators.required);
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.required, Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
    else if(!this.createPerson.get('city').errors && this.createPerson.get('city').value.length == 0){
      this.createPerson.get('address1').clearValidators();
      this.updateValue('address1');
      this.createPerson.get('address2').clearValidators();
      this.updateValue('address2');
      this.createPerson.get('state').clearValidators();
      this.updateValue('state');
      this.createPerson.get('zipCode').setValidators([Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
    }
  }
  zipCodeChange(){
    if(!this.createPerson.get('zipCode').errors && this.createPerson.get('zipCode').value.length > 0){
      this.createPerson.get('address1').setValidators(Validators.required);
      this.updateValue('address1');
      this.createPerson.get('address2').setValidators(Validators.required);
      this.updateValue('address2');
      this.createPerson.get('state').setValidators(Validators.required);
      this.updateValue('state');
      this.createPerson.get('city').setValidators(Validators.required);
      this.updateValue('city');
    }
    else if(!this.createPerson.get('zipCode').errors && this.createPerson.get('zipCode').value.length == 0){
      this.createPerson.get('address1').clearValidators();
      this.updateValue('address1');
      this.createPerson.get('address2').clearValidators();
      this.updateValue('address2');
      this.createPerson.get('state').clearValidators();
      this.updateValue('state');
      this.createPerson.get('city').clearValidators();
      this.updateValue('city');
    }
  }
  stateChange(){
    if(!this.createPerson.get('state').errors && this.createPerson.get('state').value.length > 0 && this.createPerson.get('state').value != 0){
      this.createPerson.get('address1').setValidators(Validators.required);
      this.updateValue('address1');
      this.createPerson.get('address2').setValidators(Validators.required);
      this.updateValue('address2');
      this.createPerson.get('zipCode').setValidators([Validators.required, Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
      this.createPerson.get('city').setValidators(Validators.required);
      this.updateValue('city');
    }
    else if(!this.createPerson.get('state').errors && (this.createPerson.get('state').value.length == 0 || this.createPerson.get('state').value==0)){
      this.createPerson.get('address1').clearValidators();
      this.updateValue('address1');
      this.createPerson.get('address2').clearValidators();
      this.updateValue('address2');
      this.createPerson.get('zipCode').setValidators([Validators.minLength(5), Validators.maxLength(5),Validators.pattern("^[0-9]*$")]);
      this.updateValue('zipCode');
      this.createPerson.get('city').clearValidators();
      this.updateValue('city');
    }
  }
  // wslx(){
  //   if(this.createPerson.get('indicator').value != null && this.createPerson.get('indicator').value.includes(6)){
  //     this.createPerson.get('wslx').setValidators(Validators.required);
  //     this.updateValue('wslx');
  //   }else if(this.createPerson.get('indicator').value == null || (this.createPerson.get('indicator').value != null &&  !this.createPerson.get('indicator').value.includes(6))){
  //     this.createPerson.get('wslx').clearValidators();
  //     this.updateValue('wslx');
  //   }
  // }
  updateValue(fieldUpdate){
    this.createPerson.get(fieldUpdate).updateValueAndValidity();
  }
  //Cancel
  cancel(){
    this.addnewPerson = false;
    this.createPerson.get('address1').clearValidators();
    this.updateValue('address1');
    this.createPerson.get('address2').clearValidators();
    this.updateValue('address2');
    this.createPerson.get('zipCode').clearValidators();
    this.updateValue('zipCode');
    this.createPerson.get('state').clearValidators();
    this.updateValue('state');
    this.createPerson.get('city').clearValidators();
    this.updateValue('city');

    this.createPerson.reset();

 }
  //Create new contact
  createContact(){
   let prefList = null;
   if(this.createPerson.get('indicator').value){
    prefList = [];
   this.createPerson.get('indicator').value.map(prefId => {
    this.addDropdown['personPreferenceTypeDtoList'].map(codeVal => {
      if(codeVal.id == prefId ){
        prefList.push({
          "personPreferenceId": {
            "personPreferenceId": prefId
          },
          "personPreferenceTypeDto": {
            "id": prefId, 
            "code": codeVal.code
          }
        });
      }
    });

   });
  }

  let addressDataset;
  this.createPerson.get('address1').value == null || this.createPerson.get('address1').value == "" ? addressDataset = null :
                                                    addressDataset = {
                                                      "addressLine1": this.createPerson.get('address1').value,
                                                      "addressLine2": this.createPerson.get('address2').value,
                                                      "city": this.createPerson.get('city').value,
                                                      "state": this.createPerson.get('state').value,
                                                      "zipCode": this.createPerson.get('zipCode').value,
                                                      "addressType": "FLP"
                                                    }
    let createSalutation;
    this.createPerson.get('salutation').value == '' || this.createPerson.get('salutation').value == null  ? createSalutation = null : createSalutation= {'code' :  this.createPerson.get('salutation').value }


    this.createPersonArray = {
      "fordOrgCd": this.orgVal,
      "title": this.createPerson.get('title').value ,
      "wslXid": this.createPerson.get('wslx').value,
      "delFlag": null,
      "finContactCd": null,
      "fleetPersonContactDto": null,
      "fname": this.createPerson.get('firstName').value,
      "lname": this.createPerson.get('lastName').value,
      "mname": this.createPerson.get('middleName').value,
      "addressDto": addressDataset,
      "fleetPersonContact": {
        "phone": this.createPerson.get('phone').value,
        "extension": this.createPerson.get('extension').value,
        "cell": this.createPerson.get('cell').value,
        "fax": this.createPerson.get('fax').value,
        "email": this.createPerson.get('email').value,
      },
      "personPreferenceDtoList": prefList,
      "salutationDto": createSalutation
    };
     let createUrl = '/fleet-customer-management/fleet-persons/v1/fleet-person';
     this.RestCallService.ngOnInit();
     this.RestCallService.setQueryParams("createType",'CREATE_PERSONNEL_PREF');
    this.RestCallService.setQueryParams("fleetPersonId",0);
     this.RestCallService.setQueryParams("orgCd",this.orgVal);
    this.RestCallService.setQueryParams("ouKey",this.ouVal);

    this.RestCallService.createData(createUrl, JSON.stringify(this.createPersonArray)).subscribe(data => this.personalPrefInvoke(this.ouVal, this.orgVal, this.assignee, this.originalOrg));
  }
  //Edit and Update the person
  editEnable(ind){
  //this.personList[ind].fleetPersonAssignmentId.fleetPersonId.finContactCd == "Y" ?  this.editRow = null : this.editRow=ind;
  if(this.editRow == ind){

  }else{
    this.editRow=ind;
    this.addnew();
    this.addnewPerson = false;
    this.mapEdit();
  }

  }
  mapEdit(){
    if(this.editRow != null){
    this.createPerson.patchValue({
      salutation: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.salutationDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.salutationDto.code : '',
      firstName: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fname,
      middleName: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.mname,
      lastName: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.lname,
      title: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.title,
      phone: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.phone : '',
      extension: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.extension : '',
      cell: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.cell : '',
      email: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.email : '',
      fax: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.fax : '',
      wslx: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.wslXid : '',
      address1: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto.addressLine1 : '',
      address2:  this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto.addressLine2 : '',
      city:  this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto.city: '',
      state:  this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto.state: '',
      zipCode:  this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto ? this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.addressDto.zipCode: '',
      indicator: this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.personPreferenceDtoList ?
      this.personList[this.editRow].fleetPersonAssignmentId.fleetPersonId.personPreferenceDtoList .map(data => data.personPreferenceId.personPreferenceId) : ''

    });
  }

  }
  updateCancel(){
    this.editRow = null;
    this.createPerson.reset();
  }

  updateContact(ind){
    let personId = this.personList[ind].fleetPersonAssignmentId.fleetPersonId.id;
    let updatePrefList = null;
    if(this.createPerson.get('indicator').value){
      updatePrefList = [];
    this.createPerson.get('indicator').value.map(prefId => {
      this.addDropdown['personPreferenceTypeDtoList'].map(codeVal => {
        if(codeVal.id == prefId ){
          updatePrefList.push({
            "personPreferenceId": {
              "personPreferenceId": prefId
            },
            "personPreferenceTypeDto": {
              "id": prefId,
              "code": codeVal.code
            }
          });
        }
      });

     });
    }
    let editAddressDataset;
    this.createPerson.get('address1').value == null || this.createPerson.get('address1').value == "" ? editAddressDataset = null :
                                editAddressDataset = {
                                                  "addressLine1": this.createPerson.get('address1').value,
                                                  "addressLine2": this.createPerson.get('address2').value,
                                                  "city": this.createPerson.get('city').value,
                                                  "state": this.createPerson.get('state').value,
                                                  "zipCode": this.createPerson.get('zipCode').value,
                                                  "addressType": "FLP"
                                                  }
    let updateSalutation;
    this.createPerson.get('salutation').value == '' || this.createPerson.get('salutation').value == null  ? updateSalutation = null : updateSalutation= {'code' :  this.createPerson.get('salutation').value }

    let updatePersonArray = {
      "fordOrgCd": this.orgVal,
      "title": this.createPerson.get('title').value ,
      "wslXid": this.createPerson.get('wslx').value,
      "delFlag": null,
      "finContactCd": null,
      "fname": this.createPerson.get('firstName').value,
      "lname": this.createPerson.get('lastName').value,
      "mname": this.createPerson.get('middleName').value,
      "addressDto": editAddressDataset,
      "salutationDto": updateSalutation,
      "fleetPersonContact": {
        "phone": this.createPerson.get('phone').value,
        "extension": this.createPerson.get('extension').value,
        "cell": this.createPerson.get('cell').value,
        "fax": this.createPerson.get('fax').value,
        "email": this.createPerson.get('email').value,
      },
       "personPreferenceDtoList": updatePrefList
};


    let updateUrl = '/fleet-customer-management/fleet-persons/v1/fleet-person';
    this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("createType",'EDIT_PERSONNEL_PREF');
    this.RestCallService.setQueryParams("fleetPersonId",personId);
    this.RestCallService.setQueryParams("orgCd",this.orgVal);
    this.RestCallService.setQueryParams("ouKey",this.ouVal);
    this.RestCallService.updateData(updateUrl,JSON.stringify(updatePersonArray)).subscribe(data => this.personalPrefInvoke(this.ouVal, this.orgVal, this.assignee, this.originalOrg));
  }
  deletePerson(personId){
    const dialogRef = this.dialog.open(DeleteConfirm, {width: '300px'});
    dialogRef.afterClosed().subscribe(data => {
    if(data == 'delete'){
      let fleetPersonId = this.personList[personId].fleetPersonAssignmentId.fleetPersonId.id;
    let deleteUrl = '/fleet-customer-management/fleet-persons/v1/fleet-person';
     this.RestCallService.ngOnInit();
    this.RestCallService.setQueryParams("fleetPersonId",fleetPersonId);
    this.RestCallService.deleteData(deleteUrl).subscribe(data => this.personalPrefInvoke(this.ouVal, this.orgVal, this.assignee, this.originalOrg));
    }
    });
  }

  copyPerson(personId){
    this.addnew();
    this.addnewPerson = false;
    let fleetPersonId = this.personList[personId].fleetPersonAssignmentId.fleetPersonId.id;
    let copyPrefList = null;
    if(this.personList[personId].fleetPersonAssignmentId.fleetPersonId.personPreferenceDtoList){
      copyPrefList = [];
      if(this.addDropdown){

      this.personList[personId].fleetPersonAssignmentId.fleetPersonId.personPreferenceDtoList.map(prefId => {
      this.addDropdown['personPreferenceTypeDtoList'].map(codeVal => {
        if(codeVal.id == prefId ){
          copyPrefList.push({
            "personPreferenceId": {
              "fleetPersonId": fleetPersonId,
              "personPreferenceId": prefId
            },
            "personPreferenceTypeDto": {
              "id": prefId,
              "code": codeVal.code
            }
          });
        }
      });

     });
    }
  }
    let copyAddressDataset;
    this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto == null || this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto == "" ? copyAddressDataset = null :
                                                      copyAddressDataset = {
                                                    "addressLine1": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto.addressLine1,
                                                    "addressLine2": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto.addressLine2,
                                                    "city": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto.city,
                                                    "state": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto.state,
                                                    "zipCode": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.addressDto.zipCode ,
                                                    "addressType": "FLP"
                                                    }
    let salutation;
    this.personList[personId].fleetPersonAssignmentId.fleetPersonId.salutationDto == null || this.personList[personId].fleetPersonAssignmentId.fleetPersonId.salutationDto == ""  ? salutation = null : salutation= {'code' :  this.personList[personId].fleetPersonAssignmentId.fleetPersonId.salutationDto.code }
    let copyPersonArray = {
      "fordOrgCd": this.orgVal,
      "title": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.title ,
      "wslXid": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.wslXid,
      "delFlag": null,
      "finContactCd": null,
      "fname": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fname,
      "lname": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.lname,
      "mname": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.mname,
      "addressDto": copyAddressDataset,
      "salutationDto": salutation,
      "fleetPersonContact": {
        "phone": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.phone,
        "extension": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.extension,
        "cell": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.cell,
        "fax": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.fax,
        "email": this.personList[personId].fleetPersonAssignmentId.fleetPersonId.fleetPersonContact.email,
      },
       "personPreferenceDtoList": copyPrefList
};

    let copyUrl = '/fleet-customer-management/fleet-persons/v1/fleet-person';
    this.RestCallService.ngOnInit();
     this.RestCallService.setQueryParams("createType",'COPY_TO_ORG');
    this.RestCallService.setQueryParams("fleetPersonId",fleetPersonId);
     this.RestCallService.setQueryParams("orgCd",this.originalOrg);
    this.RestCallService.setQueryParams("ouKey",this.ouVal);
    this.RestCallService.createData(copyUrl, JSON.stringify(copyPersonArray)).subscribe(data => this.personalPrefInvoke(this.ouVal, this.orgVal, this.assignee, this.originalOrg));
   }

}


@Component({
  selector: 'delete-confirm',
  templateUrl: 'delete-confirm.html',
  })
  export class DeleteConfirm {
  constructor(
  public dialogRef: MatDialogRef<DeleteConfirm>, @Inject(MAT_DIALOG_DATA) public data: any) {

  }
  onYesClick(){
    this.dialogRef.close('delete');
  }
  onNoClick(): void {
  this.dialogRef.close();
  }
}
