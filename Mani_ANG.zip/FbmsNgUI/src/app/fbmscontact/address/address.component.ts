import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {RestcallService} from '../../services/restcall.service';

@Component({
  selector: 'address',
  templateUrl: './address.component.html',
  styleUrls: ['../fbmscontact.component.sass']
})
export class AddressComponent implements OnInit {

  addressConfig: string;
  physicalAddress: string;
  mailingAddress: string;
  directionValue: string;
  ActualdirectionValue: string;
  EditdirectionValue: string;
  ouVal: number;
  orgVal: string;
  assignee: any;
  editDisabled : boolean = false;

  @Output() myEvent = new EventEmitter();

  constructor(private RestcallService: RestcallService) { }

  ngOnInit(): void {}

  addressInvoke(ouVal, orgVal, assignee){

    this.ouVal = ouVal;
    this.orgVal = orgVal;
    this.assignee= assignee;
    this.RestcallService.ngOnInit();
    this.RestcallService.setQueryParams('orgCd', this.orgVal)
    this.addressConfig = "/fleet-fin-orchestrator/fin-operating-unit/v1/ou/"+this.ouVal+"/address";
    // this.addressConfig = "/address";
    this.assignee.map(checkAssignee => {
      checkAssignee.cdsId == sessionStorage.getItem('loginId') ? this.editDisabled = true : '';
    });
    this.RestcallService.getData(this.addressConfig).subscribe((respData) => {this.mapAddress(respData) });
    //Mapping to respective variables
  }
  //Set the Address values on selection
  mapAddress(AddressValue){
    this.mailingAddress = '';
    this.physicalAddress = '';
    this.directionValue = '';
    AddressValue.addresses.map(mapData => {
      mapData.addressType == 'FLL' ? this.physicalAddress = (mapData.addressLine1 == null || mapData.addressLine1 == 'Unknown' ? '' : mapData.addressLine1+',  ')+(mapData.addressLine2 == null || mapData.addressLine2 == 'Unknown' ? '' : mapData.addressLine2+',  ')+(mapData.city == null || mapData.city=='Unknown' ? '' : mapData.city+', ')+(mapData.state == null || mapData.state == 'XX' ? '' : mapData.state+', ')+(mapData.zipCode == null ? '' : mapData.zipCode) :
                                     mapData.addressType == 'FLM' ? this.mailingAddress = (mapData.addressLine1 == null || mapData.addressLine1 == 'Unknown' ? '' : mapData.addressLine1+',  ')+(mapData.addressLine2 == null || mapData.addressLine2 == 'Unknown' ? '' : mapData.addressLine2+',  ')+(mapData.city == null || mapData.city=='Unknown' ? '' : mapData.city+', ')+(mapData.state == null || mapData.state == 'XX' ? '' : mapData.state+', ')+(mapData.zipCode == null ? '' :  mapData.zipCode):'';
    });
    this.directionValue = (AddressValue.direction != null ? AddressValue.direction.direction : '');
    this.ActualdirectionValue = this.directionValue;
    }
    // clickedIn(ActualdirectionValue){
    //   alert(ActualdirectionValue);
    //   this.ActualdirectionValue = ActualdirectionValue;
    // }
    clickedOut(EditdirectionValue){
      this.EditdirectionValue = EditdirectionValue;
      if(this.EditdirectionValue != this.ActualdirectionValue && this.EditdirectionValue.length <=500){
        //Send the Direction data to backend
        let directionUpdate = {
          "direction": this.EditdirectionValue
        };
        //Rest call to update the direction
        let updateUrl = "/fleet-address-management/addresses/v1/address/direction";
        this.RestcallService.ngOnInit();
        this.RestcallService.setQueryParams("orgCd", this.orgVal);
        this.RestcallService.setQueryParams("ouKey", this.ouVal);
        this.RestcallService.createData(updateUrl, directionUpdate).subscribe((respData) => {
          this.addressInvoke(this.ouVal, this.orgVal, this.assignee)
        });
      }
    }
}
