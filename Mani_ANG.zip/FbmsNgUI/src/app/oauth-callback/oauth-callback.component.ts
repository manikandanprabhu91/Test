import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {environment} from 'src/environments/environment';
import {CommonFnaHttpApiService} from '../fna/service/common-fna-http-api.service';
import {OauthTokenService} from '../services/oauth-token.service';
import {HttpClient} from '@angular/common/http';

@Component({
	selector: 'oauth-callback',
	templateUrl: './oauth-callback.component.html',
	styleUrls: ['./oauth-callback.component.scss']
})
export class OAuthCallbackComponent implements OnInit {

	constructor(private router: Router, private commonApiService: CommonFnaHttpApiService, private oauthService: OauthTokenService,
				private http: HttpClient) {
	}
	public static FNA_ENTITY_NAME_CODE = 'GBR'
	public static supportedCountryCodes: string[] = ['AUT', 'BEL', 'CHE', 'CZE', 'DEU', 'DNK', 'ESP', 'FIN', 'FRA', 'GBR', 'GEO', 'GRC', 'HUN', 'IRL', 'ITA', 'LUX', 'NLD', 'NOR', 'POL', 'PRT', 'SWE', 'UKR'];
	public userAuthData: any = {};

	ngOnInit() {
		const callbackResponse = (document.URL).split('#')[1];
		//console.log(callbackResponse);
		const responseParameters = (callbackResponse).split('&');
		const parameterMap: any = {};
		responseParameters.forEach(eachParam => {
			const key = eachParam.split('=')[0];
			const value = eachParam.split('=')[1];
			parameterMap[key] = value;
		});

		sessionStorage['directUrl_access_token'] = parameterMap['access_token'];
		if (environment.isApicEnabled) {
			if (parameterMap) {
				this.oauthService.getApicToken().subscribe(data => {
					 sessionStorage['gateway_access_token'] = data['access_token'];
					 sessionStorage['apic_token_time_start'] = new Date().getTime();
					this.processBuildLoggedInUserData(parameterMap);
				}, err => {
					//sessionStorage.setItem("invalidUser", "Yes");
					window.location.href = window.location.href + '/invalid-access';
				})
			}
		} else {
			sessionStorage['gateway_access_token'] = parameterMap['access_token'];
			this.processBuildLoggedInUserData(parameterMap);
		}
	}

	processBuildLoggedInUserData(parameterMap: any): void {
		const accessToken = parameterMap['access_token'];
		//console.log(accessToken);
		const tokenInfo = this.getTokenInfo(accessToken);
		const userId = tokenInfo.sub;
		//const entityName = !(this.countryFnaCode.indexOf(countryCode) > -1) ? OAuthCallbackComponent.FNA_ENTITY_NAME_CODE : '';

		//let path = 'api/v1/fbmssbmw/validate/user-role?loggedUser=' + userId + '&entityName=' + entityName;
		const path = '/fleet-user-management/fleet-users/v1/user/role?cdsId=' + userId + '&countryCd=' + OAuthCallbackComponent.FNA_ENTITY_NAME_CODE;
		// const path = '/fleet-user-management/fleet-users/v1/user/role?cdsId=' + userId + '&countryCd=' + countryCode;
		this.commonApiService.get(path).subscribe(data => {
			this.userAuthData = data;
			let redirectURL = '/invalid-access';
			// if (this.userAuthData.roleName) {
			//  switch (this.userAuthData.roleName) {
			//      case 'NAMNAC':
			//          redirectURL = '/';
			//          break;
			//      case 'ADMNAC':
			//          redirectURL = '/admin-fna';
			//          break;
			//      case 'RSMNAC':
			//          redirectURL = '/proposals-approval-fna';
			//          break;
			//  }
			if (OAuthCallbackComponent.supportedCountryCodes.indexOf(this.userAuthData.countryCd) == -1) {
				sessionStorage['activeContent'] = true;
				//sessionStorage.setItem("invalidUser", "Yes");
				window.location.href = window.location.protocol + '//' + window.location.host + '/invalid-access';
			}
			if (this.userAuthData.titleCd) {
				// switch (this.userAuthData.titleCd) {
				// 	case 'NAM':
				// 		redirectURL = '/';
				// 		break;
				// 	case 'ADM':
				// 		redirectURL = '/';
				// 		break;
				// 	case 'RSM':
				// 		redirectURL = '/';
				// 		break;
				// }
				if(this.userAuthData.reportLvlCd==7 || this.userAuthData.reportLvlCd==91 || this.userAuthData.titleCd == 'ITS'){
					redirectURL = '/accounts-home';
				}else if(this.userAuthData.reportLvlCd!=7 && this.userAuthData.reportLvlCd!=90){
					redirectURL = '/approvals';
				}else if(this.userAuthData.titleCd == 'ADM'){
					redirectURL = '/admin-home';
				}
				sessionStorage['activeContent'] = true;
				sessionStorage['countryCode'] = this.userAuthData.countryCd;
				sessionStorage.setItem('loginId', userId.toUpperCase());
				sessionStorage.setItem('loginEmail', tokenInfo.subjectid);
				sessionStorage.setItem('loginFirstName', this.userAuthData.firstName);
				sessionStorage.setItem('loginLastName', this.userAuthData.lastName);
				sessionStorage.setItem('tokenExpTime', tokenInfo.exp);
				//sessionStorage.setItem('roleName', this.userAuthData.roleName);
				sessionStorage.setItem('roleName', this.userAuthData.titleCd);
				sessionStorage.setItem('orgCode', this.userAuthData.fordOrgCd);
				sessionStorage.setItem('reportLvlCd', this.userAuthData.reportLvlCd);
				sessionStorage.setItem('dealAuthFlag', this.userAuthData.unassignedFinsFlag);
				//sessionStorage.setItem("invalidUser", ""); 
				//sessionStorage.setItem('access_token', accessToken);
				//sessionStorage['gateway_access_token'] = accessToken;
				//console.log(sessionStorage['gateway_access_token']);
			}
			window.location.href = window.location.protocol + '//' + window.location.host + redirectURL;
		}, err => {
			sessionStorage['activeContent'] = true;
			//sessionStorage.setItem("invalidUser", "Yes");
			window.location.href = window.location.protocol + '//' + window.location.host + '/invalid-access';
		});
	}

	getTokenInfo(token: string): any {
		return JSON.parse(atob(token.split('.')[1]));
	}
}

