import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { environment } from 'src/environments/environment';
import { LoginService } from '../login/login.service';

@Injectable()
export class AuthGuardService implements CanActivate {

	constructor(private router: Router, private loginService: LoginService, @Inject(DOCUMENT) private document) { }

	canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
		sessionStorage['activeContent'] = false;
		if (sessionStorage.length > 0 && this.loginService.isValidLogin()) {
			sessionStorage['activeContent'] = true;
			return true;
		}
		document.location.href = environment.webTokenUrl +
			'/adfs/oauth2/authorize/wia?response_type=token+id_token&client_id=' + environment.webClientId + '&resource=' + environment.webResourceId + '&' +
			'redirect_uri=' + window.location.protocol + '//' + window.location.host + '/oauth-callback';
	}
}