import { Injectable } from '@angular/core';
import {
  CanActivate, Router,
  ActivatedRouteSnapshot, RouterStateSnapshot
} from '@angular/router';

@Injectable()
export class LoginService {
  public tokenExp: number;

  constructor(private router: Router) { }

  parseSessionStorage() {
    if (sessionStorage.length > 0) {
      this.tokenExp = sessionStorage['tokenExpTime'];
    }
  }

  isTokenExpired(): boolean {
    const epoch = Math.trunc(new Date().getTime() / 1000);
    // console.log("Current Epoch ====  >>>>   " + epoch);
    // console.log("Token Exp Epoch ====  >>>>   " + this.tokenExp);
    // console.log("===== >>> isExpired Token    " + (epoch > this.tokenExp));
    if (this.tokenExp == undefined) {
      return true;
    }
    return (epoch > this.tokenExp) ? true : false;
  }

  isValidLogin(): boolean {
    this.parseSessionStorage();
    if (this.isTokenExpired()) {
      sessionStorage.clear();
      console.log("Token Failed");
      return false;
    }
    return true;
  }
}
