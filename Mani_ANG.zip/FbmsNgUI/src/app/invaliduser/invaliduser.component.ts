import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'invaliduser',
  templateUrl: './invaliduser.component.html',
  styleUrls: ['./invaliduser.component.sass']
})
export class InvaliduserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
