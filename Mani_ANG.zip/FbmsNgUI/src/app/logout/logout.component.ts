import { DOCUMENT } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.sass']
})
export class LogoutComponent implements OnInit {

  //public hostUrl = environment.hostUrl;

  constructor(@Inject(DOCUMENT) private document) { }

  ngOnInit() {
    localStorage.clear();
    sessionStorage.clear();
    document.location.href = environment.logoutUrl+'logout?back='+ window.location.protocol + '//' + window.location.host;
    // if (this.document.location.hostname == 'localhost') {
    //   document.location.href = 'http://localhost:4001/';
    // } else {
    // }
  }
}
