import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
//import {HttpClientInMemoryWebApiModule} from 'angular-in-memory-web-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { AppComponent } from './app.component';
import { NavComponent } from './nav/nav.component';
import { ButtonModule } from 'primeng/button';
import { MenubarModule } from 'primeng/menubar';
import { PanelMenuModule } from 'primeng/panelmenu';
import { SidebarModule } from 'primeng/sidebar';
import { AppRoutingModule } from './app-routing.module';
import { ExamplePageComponent } from './example-page/example-page.component';
import { ToastModule } from 'primeng/toast';
import { NotFoundComponent } from './not-found/not-found.component';
import { MessageService } from 'primeng/api';
import { MaterialmodModule } from './materialmod/materialmod.module';
import { FbmsheaderComponent } from './fbmsheader/fbmsheader.component';
import { FbmsfooterComponent } from './fbmsfooter/fbmsfooter.component';
import { FbmscontactComponent } from './fbmscontact/fbmscontact.component';
import { FbmscontainerComponent } from './fbmscontainer/fbmscontainer.component';
import { FbmsmenuComponent } from './fbmsmenu/fbmsmenu.component';
import { FbmstoolbarComponent } from './fbmstoolbar/fbmstoolbar.component';
import { MultiselectdropdownComponent } from './multiselectdropdown/multiselectdropdown.component';
import { RestcallService } from './services/restcall.service';
import { AccountnotesComponent } from './fbmscontact/accountnotes/accountnotes.component';
import { AccountprefComponent } from './fbmscontact/accountpref/accountpref.component';
import { ActiondialogComponent } from './fbmscontainer/actiondialog/actiondialog.component';
import { AddressComponent } from './fbmscontact/address/address.component';
import { CorporateinfoComponent } from './fbmscontact/corporateinfo/corporateinfo.component';
import { HotlineComponent } from './fbmscontact/hotline/hotline.component';
import { OrdersalesComponent } from './fbmscontact/ordersales/ordersales.component';
import { PersonalprefComponent } from './fbmscontact/personalpref/personalpref.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { OAuthCallbackComponent } from './oauth-callback/oauth-callback.component';
import { InvaliduserComponent } from './invaliduser/invaliduser.component';
import { AuthGuardService } from './oauth-callback/auth-guard.service';
import { LoginService } from './login/login.service';
import { OauthTokenService } from './services/oauth-token.service';
import { UserauthcheckService } from './services/userauthcheck.service';
import { ProposalLandingComponent } from './fbmscontainer/proposal-landing/proposal-landing.component';
import { PerUnitIncentiveComponent } from './fbmscontainer/proposal-landing/per-unit-incentive/per-unit-incentive.component';
import { ProposalCommentsComponent } from './fbmscontainer/proposal-landing/proposal-comments/proposal-comments.component';
import { SubsidariesComponent } from './fbmscontainer/proposal-landing/subsidaries/subsidaries.component';
import { OptionDiscountsComponent } from './fbmscontainer/proposal-landing/option-discounts/option-discounts.component';
import { IncentivesBonusComponent } from './fbmscontainer/proposal-landing/incentives-bonus/incentives-bonus.component';
import { SummaryandsubmitComponent } from './fbmscontainer/proposal-landing/summaryandsubmit/summaryandsubmit.component';
import { ProposalHistoryComponent } from './fbmscontainer/proposal-history/proposal-history.component';
import { FinAssignmentApprovalComponent } from './approvals/fin-assignment-approval/fin-assignment-approval.component';
import { ApprovalsComponent } from './approvals/approvals.component';
import { LettersInApprovalComponent } from './approvals/letters-in-approval/letters-in-approval.component';
import { ProposalsInApprovalComponent } from './approvals/proposals-in-approval/proposals-in-approval.component';
import { CpaletterComponent } from './fbmscontainer/proposal-landing/cpaletter/cpaletter.component';
import { VehicleLineProposalYearComponent } from './fbmsadmin/vehicle-line-proposal-year/vehicle-line-proposal-year.component';
import { FinancialInformationComponent } from './fbmsadmin/financial-information/financial-information.component';
import { ControlProgramYearComponent } from './fbmsadmin/control-program-year/control-program-year.component';
import { FbmsadminComponent } from './fbmsadmin/fbmsadmin.component';
import { UserMaintenanceComponent } from './fbmsadmin/user-maintenance/user-maintenance.component';
import { FinAssignmentComponent } from './fbmsadmin/fin-assignment/fin-assignment.component';
import { FinancialApprovalRangeComponent } from './fbmsadmin/financial-approval-range/financial-approval-range.component';
import { ControllerRoutingThresholdComponent } from './fbmsadmin/controller-routing-threshold/controller-routing-threshold.component';
import { ProposallettertemplateComponent } from './fbmsadmin/proposallettertemplate/proposallettertemplate.component';
import { GovernmentFinComponent } from './fbmsadmin/government-fin/government-fin.component';
import { CustomerAcceptanceViewComponent } from './fbmscontainer/customer-acceptance-view/customer-acceptance-view.component';
import { MaintainVehicleLineComponent } from './fbmsadmin/maintain-vehicle-line/maintain-vehicle-line.component';
import { PerUnitMexicoComponent } from './fbmscontainer/proposal-landing/per-unit-mexico/per-unit-mexico.component';
import { MaintainFinAutoearlyComponent } from './fbmsadmin/maintain-fin-autoearly/maintain-fin-autoearly.component';
import { MaintainEspDiscountsComponent } from './fbmsadmin/maintain-esp-discounts/maintain-esp-discounts.component';
import { AssignmentOfProceedsComponent } from './fbmsadmin/assignment-of-proceeds/assignment-of-proceeds.component';
import { NumberFormatPipe } from './services/number-format-pipe';
import { NumberCheckPipe } from './services/number-check-pipe';
import { FinSearchComponent } from './fin-search/fin-search.component';
import { FieldErrorDisplayComponent } from './fbmsadmin/maintain-esp-discounts/field-error-display/field-error-display.component';
import { CpaLetterRenderingComponent } from './fbmscontainer/proposal-landing/cpaletter/cpa-letter-rendering/cpa-letter-rendering.component';
import { MetricsObjectivesComponent } from './fbmsadmin/metrics-objectives/metrics-objectives.component';
import { DealerStockReplacementComponent } from './fbmsadmin/dealer-stock-replacement/dealer-stock-replacement.component';
import { FinancialDetailedViewComponent } from './fbmscontainer/proposal-landing/summaryandsubmit/financial-detailed-view/financial-detailed-view.component';
import { SelfFinPipe } from './services/self-fin-pipe';
import { SafePipe } from './safe.pipe';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { BnNgIdleService } from 'bn-ng-idle';
import { HelppageComponent } from './helppage/helppage.component';
import { FoeFinAssignmentComponent } from './fbmsadmin/foe-fin-assignment/foe-fin-assignment.component';
import { MaintainModelCostComponent } from './fbmsadmin/maintain-model-cost/maintain-model-cost.component';
import { SalestypeAccountProfileComponent } from './fbmsadmin/maintain-model-cost/salestype-account-profile/salestype-account-profile.component';
import { EwCostDataComponent } from './fbmsadmin/maintain-model-cost/ew-cost-data/ew-cost-data.component';
import { ExchangeRateComponent } from './fbmsadmin/maintain-model-cost/exchange-rate/exchange-rate.component';

//import { FbmsHttpApiService } from './services/fbms-http-api.service';

@NgModule({
	declarations: [
		AppComponent,
		NavComponent,
		ExamplePageComponent,
		NotFoundComponent,
		FbmsheaderComponent,
		FbmsfooterComponent,
		FbmscontactComponent,
		FbmscontainerComponent,
		FbmsmenuComponent,
		FbmstoolbarComponent,
		AccountnotesComponent,
		AccountprefComponent,
		ActiondialogComponent,
		AddressComponent,
		CorporateinfoComponent,
		HotlineComponent,
		OrdersalesComponent,
		PersonalprefComponent,
		MultiselectdropdownComponent,
		LoginComponent,
		LogoutComponent,
		OAuthCallbackComponent,
		InvaliduserComponent,
		ProposalLandingComponent,
		PerUnitIncentiveComponent,
		ProposalCommentsComponent,
		SubsidariesComponent,
		OptionDiscountsComponent,
		IncentivesBonusComponent,
		SummaryandsubmitComponent,
		ProposalHistoryComponent,
		FinAssignmentApprovalComponent,
		ApprovalsComponent,
		LettersInApprovalComponent,
		ProposalsInApprovalComponent,
		CpaletterComponent,
		VehicleLineProposalYearComponent,
		FinancialInformationComponent,
		ControlProgramYearComponent,
		FbmsadminComponent,
		UserMaintenanceComponent,
		FinAssignmentComponent,
		FinancialApprovalRangeComponent,
		ControllerRoutingThresholdComponent,
		FinAssignmentComponent,
		ProposallettertemplateComponent,
		GovernmentFinComponent,
		CustomerAcceptanceViewComponent,
		MaintainVehicleLineComponent,
		PerUnitMexicoComponent,
		MaintainFinAutoearlyComponent,
		AssignmentOfProceedsComponent,
		NumberFormatPipe,
		NumberCheckPipe,
		SelfFinPipe,
		MaintainEspDiscountsComponent,
		AssignmentOfProceedsComponent,
		FinSearchComponent,
		FieldErrorDisplayComponent,
		CpaLetterRenderingComponent,
		DealerStockReplacementComponent,
		MetricsObjectivesComponent,
		FinancialDetailedViewComponent,
		BreadcrumbComponent,
		SafePipe,
		HelppageComponent,
		FoeFinAssignmentComponent,
		MaintainModelCostComponent,
		ExchangeRateComponent,
		SalestypeAccountProfileComponent,
		EwCostDataComponent

	],
	imports: [
		BrowserModule,
		BrowserAnimationsModule,
		RouterModule,
		HttpClientModule,
		AppRoutingModule,
		ButtonModule,
		MenubarModule,
		PanelMenuModule,
		SidebarModule,
		ToastModule,
		FormsModule,
		ReactiveFormsModule,
		MaterialmodModule,
		MatAutocompleteModule,
		ProgressSpinnerModule
	],
	providers: [
		MessageService,
		DatePipe,
		LoginService, AuthGuardService,
		RestcallService,
		UserauthcheckService,
		OauthTokenService,
		SafePipe,
		BnNgIdleService
	],
	bootstrap: [AppComponent]
})
export class AppModule {
}
