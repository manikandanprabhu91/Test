import {
	Component,
	OnInit,
	VERSION,
	HostListener
} from '@angular/core';
import { environment } from '../environments/environment';
import {
	NavigationEnd,
	Router
} from '@angular/router';
import { filter } from 'rxjs/operators';
import { BnNgIdleService } from 'bn-ng-idle';
import { MatSnackBar } from '@angular/material/snack-bar';
import {interval, Subscription} from 'rxjs/index';
import { OauthTokenService } from './services/oauth-token.service';
import { RestcallService } from 'src/app/services/restcall.service';

/** Class for the app component that is bootstrapped to run the application
 */
@Component({
	selector: 'body',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

	public activeContent: boolean = false;

	public apicTokenRefresh : any;

	/** string used to hold the url for the skipToMain link */
	skipToMain: string;
	/** the Angular version */
	version = VERSION.full;
	/** whether we are production or not */
	envProd = environment.production;
	/** constructor for setting up DI in this component */
	// @HostListener('window:resize', ['$event']) onResize(event?) {
	// 	this.getContentSize(event)
	// }
  

	constructor(private readonly router: Router, private bnIdle: BnNgIdleService, private statusBar: MatSnackBar, private oauthService: OauthTokenService, private restcallservice: RestcallService) { 
		
	}

	// getContentSize(eent) {
	// 	console.log(event.target.innerWidth);
		

	// }
	/** this class requires this method to implement the OnInit interface */
	ngOnInit() {
		if(window.innerWidth <= 620 || window.innerWidth <=840)  {
			
			const body = document.getElementsByTagName('body')[0];
    		body.classList.add('sidebar-collapse');
			console.log("ineer width"+window.innerWidth)
		}
		this.activeContent = sessionStorage['activeContent'] == 'true' ? true : false;
		this.router.events.pipe(filter(event => event instanceof NavigationEnd))
			.subscribe((event: NavigationEnd) => {
				this.setSkipLinkUrl(event.urlAfterRedirects);
			});

		this.bnIdle.startWatching(environment.sessionTimeoutDuration).subscribe((isTimedOut: boolean) => {
			localStorage.clear();
			sessionStorage.clear();
			alert("Session Timed Out!");
			document.location.href = environment.logoutUrl + 'logout?back=' + window.location.protocol + '//' + window.location.host;
		});

		//To unscribe - Call Below
		//this.appComponent.apicTokenRefresh.unsubscribe();
		if (environment.isApicEnabled) {
			this.apicTokenRefresh = interval(environment.apicTokenRefreshTime).subscribe(n => {
				if (sessionStorage['gateway_access_token']) {
					this.refreshApicToken();			
				}
			});
		}
	}

	/**
	 * setSkipLinkUrl takes in a url string and processes whether
	 * the skipToMain link should be updated to use the new value
	 * @param currentUrl the new url to refer to
	 */
	private setSkipLinkUrl(currentUrl: string) {
		if (!currentUrl.endsWith('#app-content')) {
			this.skipToMain = `${currentUrl}#app-content`;
		}
	}
	
	refreshApicToken() {
		this.oauthService.getApicToken().subscribe(data => {
			sessionStorage['gateway_access_token'] = data['access_token'];
			sessionStorage['apic_token_time_start'] = new Date().getTime();
	   }, err => {
			this.restcallservice.statusMessage(500, "Error getting access token");
	   })
	}
}