# Building and Testing

This document describes how to set up your development environment to build and test FRF.
It also explains the basic mechanics of using `git`, `node`, and `npm`.

* [Prerequisite Software](#prerequisite-software)
* [Getting the Sources](#getting-the-sources)
* [Installing NPM Modules](#installing-npm-modules)
* [Building](#building)
* [Running Tests Locally](#running-tests-locally)

## Prerequisite Software

Before you can build and test, you must install and configure the
following products on your development machine:

* Git - [GitHub's Guide to Installing
  Git](https://help.github.com/articles/set-up-git) is a good source of information. For internal Ford resources, see the docs the SDE team provides [here](http://wiki.ford.com/display/SDE/GitHub)

* Node.js - this is used to run tooling, tests, and generate distributable files. Node 12.x or higher is required, and can be found in [Nexus](http://www.nexus.ford.com/#browse/browse:wamcoe_raw_private_repository:nodejs)

* An IDE - WaME recommends WebStorm. Installers and directions can be found in [Nexus](http://www.nexus.ford.com/#browse/browse:wamcoe_raw_private_repository:WebStorm). WebStorm is not required, though an IDE that is TypeScript aware is highly recommended.

## Getting the Sources

Note that we track two main branches in the frf-starter repo - *master* and *dev*. *master* should never be touched directly - treat it as our production code. Releases will be tagged from this branch. 

*dev* is our working branch for development efforts, but again, don't check code directly into this branch. Instead, we use a feature branching strategy, where each bit of work will be done in a branch off of *dev*, and will then be merged into *dev* with a pull request. Typically, these branches will be named to reflect the GitHub issue and the item being worked on. For instance, if you're working on issue #123, you'd create a branch named *123-feature*.

Clone down the frf-starter repository:

1. Login to Ford's GitHub [here](https://github.ford.com). If you don't have access, follow the instructions [here](http://wiki.ford.com/display/SDE/Get+Started+in+GitHub)
2. Visit the [frf-starter](https://github.ford.com/WaMCOE/frf-starter) repository
3. Clone the repo somewhere locally. (note that code snippets here should be performed in GitBash on Windows)
```shell
cd <your local project directory>
git clone git@github.ford.com:WaMCOE/frf-starter.git
```

Set up your local workspace
1. Change into the project directory and set up local branches
```shell
#change into the project
cd frf-starter

#checkout the dev branch
git checkout dev

#create a new local branch from dev
git checkout -b <name of branch here>
```

## Installing NPM Modules

Next, install the JavaScript modules needed to build and test Angular:

```shell
npm ci
```

Note that this runs an npm clean install, which ensures your installation will match as closely as possible to the packages that we ship in this project. Additionally, this installation process relies on configuration in the project's `.npmrc` file. This configuration is set up to properly leverage Ford's internal dependency repo, Nexus. Nexus is pre-loaded with all of the necessary dependencies for this project, so the npm install should not have to reach out to the public internet. If you see errors during the installation that refer to unavailable hosts, or other seemingly network related issues, ensure your proxy configs are correct using `npm config ls -l` and/or `set` (Windows) or `env` (Unix).

## Building

To build frf-starter for dev, run:

```shell
npm run build-dev
```

Similarly, to run a prod build, use:

```shell
npm run build-prod
```

Results are put in the dist folder.

## Serving content locally

You have two options for serving your built content locally. Which one you choose depends on personal preference. They are:
1. `npm run build-dev` + a standalone WebServer (like WebStorm's), running on port 9500. If using this strategy, a build will need to be manually triggered whenever a set of code changes has been completed. The `npm run build-dev` command will build the application and put the output into the `dist` folder. Contents of this file should then be served by the WebServer of your choice.
2. `npm run start-dev`. If using this strategy, a watcher will start up that will build the project whenever a file is saved. Builds will run in memory, and the files will be served by angular-cli's integrated development WebServer, which is configured to run on port 9500.

Because of this, you cannot use both of these options at the same time - your workstation only has a single port 9500.

## Running Tests Locally

To run tests:

```shell
# unit tests
npm run test

# e2e tests
npm run e2e-local
```

You should execute both test suites before committing any code and pushing to GitHub.

All the tests are executed on our Continuous Integration (Jenkins) infrastructure, and will currently run when code attempts to be integrated with the *dev* branch. The CI process will fail if your tests fail.

## Code style and formatting:

The frf-starter project is set up with a `.editorconfig` file that defines our desired style and formatting conventions. Editors/IDEs like WebStorm will obey this config and provide guidance on how to format your code. Also, editors can perform auto-formatting using a hotkey combination - for instance, to reformat the current file in WebStorm, press `CTRL`+`ALT`+`L` on Windows.

## Linting/verifying your source code

The project is set up with both *tslint* and *codelyzer* for static code analysis. These tools will run automatically inside of editors like WebStorm. If you prefer to see this output on the command line, you can trigger *tslint* by running:

``` shell
npm run lint
```

## Pushing/Pulling code

When your work is complete, you'll want to push your code to the remote for your feature branch:

```shell
git push
```

If it is the first time you're pushing code, you'll need to set your upstream branch:

```shell
git push --set-upstream origin <my branch>
```

Once your code is in the remote repo, you'll want to create a pull request to pull your changes into *dev*. In the comments, make sure to reference the issue you were working on using the [closing keyword syntax](https://help.github.com/articles/closing-issues-using-keywords/). An example of this would be:
```shell
This PR closes #123.
```
