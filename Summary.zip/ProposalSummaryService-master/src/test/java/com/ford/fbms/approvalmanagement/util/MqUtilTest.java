package com.ford.fbms.approvalmanagement.util;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.fbms.approvalmanagement.transport.EmailRequest;

/**
 * @author VSHANMU8
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MqUtilTest {

	@InjectMocks
	private MqUtil mqUtil;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private RabbitTemplate rabbitTemplate;
	
	@Test
	public void testSendWithNullValues() {
		mqUtil.send(null, null);
	}
	
	@Test
	public void testSend() {
		mqUtil.send(MqDetails.EMAIL, new Message(null, null));
	}
	
	@Test
	public void testPutEmailInMqWithException() {
		assertFalse(mqUtil.putEmailInMq(new EmailRequest()));
	}
	
	@Test
	public void testPutEmailInMqWithJsonProcessingException() throws JsonProcessingException {
		when(objectMapper.writeValueAsString(Mockito.any(EmailRequest.class))).thenThrow(JsonProcessingException.class);
		assertFalse(mqUtil.putEmailInMq(new EmailRequest()));
	}
	
	@Test
	public void testPutEmailInMq() throws JsonProcessingException {
		when(objectMapper.writeValueAsString(Mockito.any(EmailRequest.class))).thenReturn("Data");
		assertTrue(mqUtil.putEmailInMq(new EmailRequest()));
	}

}
