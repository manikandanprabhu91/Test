package com.ford.fbms.approvalmanagement.util;



import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.MessageLangDto;
import com.ford.fbms.approvalmanagement.repository.MessageLangRepository;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CacheUtilTest {

    @Spy
    @InjectMocks
    private CacheUtil cacheUtil;
    @Mock
    private MessageLangRepository messageLangRepository;

    @Test
    public void testGetMsgDesc() {
        MessageLangDto messageLangDto = new MessageLangDto();
        messageLangDto.setMessageDesc("Success");
        messageLangDto.setMessageCode("202");
        MessageLangDto messageLangDto1 = new MessageLangDto();
        messageLangDto1.setMessageDesc(messageLangDto.getMessageDesc());
        messageLangDto1.setMessageCode(messageLangDto.getMessageCode());
        Mockito.when(messageLangRepository.findById(Mockito.any())).thenReturn(Optional.of(messageLangDto));
        Assert.assertEquals("Success",cacheUtil.getMsgDesc(Mockito.anyString()));

    }

}