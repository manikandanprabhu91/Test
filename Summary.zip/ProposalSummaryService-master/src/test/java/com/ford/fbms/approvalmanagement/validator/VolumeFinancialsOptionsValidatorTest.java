package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.AccountSaleSummaryPK;
import com.ford.fbms.approvalmanagement.domain.AccountSalesSummaryDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.VoulmeFinancialsOptionsValidator;


@RunWith(MockitoJUnitRunner.Silent.class)
public class VolumeFinancialsOptionsValidatorTest {
	
	@InjectMocks
	
	private VoulmeFinancialsOptionsValidator validator;
	
	@Mock
	private MasterRuleEngine ruleEngine;
	@Mock
	 private ProposalRepository proposalRepository;
	@Mock
	private AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Mock
	private ResponseBuilder responseBuilder;
	@Mock
	protected FordPersonRepository fordPersonRepository;
	@Test
	public void testValidateAndConstructSuccess() {
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		ProposalDto dto = new ProposalDto();
		AccountSalesSummaryDto salesSummaryDto = setSalesSuumary();
		FordPersonDto fordPerson = new FordPersonDto();
		ReportLevelDto reportLvlDto = new ReportLevelDto();
		reportLvlDto.setTitleCode("RSM");
		fordPerson.setReportLevel(reportLvlDto);
		dto.setPyDefinition(new PyDefinitionDto());
		FinMasterDto finMasterDto= new FinMasterDto();
		finMasterDto.setFinMasterKey(1L);
		dto.setFinMasterKey(finMasterDto);
		Optional<ProposalDto> proposal = Optional.of(dto);
		Optional<FordPersonDto> fordPrOpt = Optional.of(fordPerson);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
		when(proposalRepository.
				getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(Mockito.anyLong(), Mockito.anyLong()))
		.thenReturn(proposal);
		 
		 
		when(accountSalesSummaryRepository.
				queryCalculatedOtdStdSummaryByProposal(Mockito.anyLong())).thenReturn(Collections.singletonList(salesSummaryDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(fordPrOpt);
		ApiParams apiParams = new ApiParams();
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
        apiParams.setCountryCd("USA");
		assertNotNull(validator.validateAndConstruct(apiParams, null, ruleEngine,httpServletRequest));
	}

	private AccountSalesSummaryDto setSalesSuumary() {
		AccountSalesSummaryDto salesSummaryDto = new AccountSalesSummaryDto();
		salesSummaryDto.setVehiclesSoldMonthToDate(2);
		salesSummaryDto.setBucketed(null);
		salesSummaryDto.setId(null);
		salesSummaryDto.setIncentiveType(null);
		salesSummaryDto.setOther(null);
		salesSummaryDto.setProduced(null);
		salesSummaryDto.setReleased(null);
		salesSummaryDto.setScheduledVehiclesMonthToDate(null);
		salesSummaryDto.setStocked(null);
		salesSummaryDto.setUnscheduledVehiclesMonthToDate(null);
		salesSummaryDto.setVehicleOrdersSubmittedMonthToDate(null);
		salesSummaryDto.setVehiclesCancelledMonthToDate(null);
		salesSummaryDto.setVehiclesOrderedMonthToDate(null);
		salesSummaryDto.getVehiclesSoldMonthToDate();
		salesSummaryDto.getBucketed();
		salesSummaryDto.getId();
		salesSummaryDto.getIncentiveType();
		salesSummaryDto.getOther();
		salesSummaryDto.getProduced();
		salesSummaryDto.getReleased();
		salesSummaryDto.getScheduledVehiclesMonthToDate();
		salesSummaryDto.getStocked();
		salesSummaryDto.getUnscheduledVehiclesMonthToDate();
		salesSummaryDto.getVehicleOrdersSubmittedMonthToDate();
		salesSummaryDto.getVehiclesCancelledMonthToDate();
		salesSummaryDto.getVehiclesOrderedMonthToDate();
		AccountSaleSummaryPK accountSaleSummaryPK = new AccountSaleSummaryPK();
		accountSaleSummaryPK.setBodyStyle(null);
		accountSaleSummaryPK.setFinMaster(null);
		accountSaleSummaryPK.setPyDefinition(0);
		accountSaleSummaryPK.setSegment(null);
		accountSaleSummaryPK.getBodyStyle();
		accountSaleSummaryPK.getFinMaster();
		accountSaleSummaryPK.getPyDefinition();
		accountSaleSummaryPK.getSegment();
		salesSummaryDto.setId(accountSaleSummaryPK);
		return salesSummaryDto;
	}
	
	@Test
	public void testValidateAndConstructFailure() {
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

		Optional<ProposalDto> proposal = Optional.empty();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
		ApiParams apiParams = new ApiParams();
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
        apiParams.setCountryCd("USA");
		assertNotNull(validator.validateAndConstruct(apiParams, null, ruleEngine,httpServletRequest));
	}
	

}
