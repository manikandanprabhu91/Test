package com.ford.fbms.approvalmanagement.validator;

import static com.ford.fbms.approvalmanagement.util.Constants.BLANK;
import static org.junit.Assert.assertNotNull;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.VehicleLineOptionDiscountVo;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.VechileLineManager;

/**
 * Test class for VehicleLineManagerTest class.
 *
 * @author SJAGATJO on 6/1/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class VehicleLineManagerTest {

  @Spy
  @InjectMocks
  private VechileLineManager vechileLineManager;
  @Mock
  private RestService restService;
  @Mock
  private HttpServletRequest httpRequest;

  @Test
  public void testValidateAndConstruct() throws ExecutionException, InterruptedException {
    ApiParams apiParams = new ApiParams();
    apiParams.setUserId("FBMSTID1");
    apiParams.setCountryCd("USA");
    List<VehicleLineOptionDiscountVo> vehicleLineOptionDiscountVos= Arrays.asList(getVehicleLineVo(), getVehicleLineVo());
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setVehicleLineOptionDiscountVos(vehicleLineOptionDiscountVos);
    Mockito.when(restService.getVehicleIncentiveOptionsData(apiParams, httpRequest)).thenReturn(responseWrapper);
    assertNotNull(vechileLineManager
        .validateAndConstruct(apiParams, null, null,httpRequest).get().getVehicleLineOptionDiscountVos());
  }

  private VehicleLineOptionDiscountVo getVehicleLineVo() {
    VehicleLineOptionDiscountVo vehicleLineOptionDiscountVo = new VehicleLineOptionDiscountVo();
    vehicleLineOptionDiscountVo.setVehicleLineDesc(BLANK);
    vehicleLineOptionDiscountVo.setBodyStyle(BLANK);
    vehicleLineOptionDiscountVo.setModelYr(null);
    vehicleLineOptionDiscountVo.setMlv(null);
    vehicleLineOptionDiscountVo.setTier1(BLANK);
    vehicleLineOptionDiscountVo.setTier1Amt(1000L);
    vehicleLineOptionDiscountVo.setTier2Amt(1000L);
    vehicleLineOptionDiscountVo.setTier3Amt(1000L);
    vehicleLineOptionDiscountVo.setTier4Amt(1000L);
    vehicleLineOptionDiscountVo.setTier5Amt(1000L);
    vehicleLineOptionDiscountVo.setTier6Amt(1000L);
    return vehicleLineOptionDiscountVo;
  }
}