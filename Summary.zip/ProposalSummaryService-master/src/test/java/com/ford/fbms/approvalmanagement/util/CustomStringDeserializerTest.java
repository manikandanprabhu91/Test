package com.ford.fbms.approvalmanagement.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidTypeIdException;

/**
 * this test class is to perform unit test on the CustomStringDeserializer
 *
 * @author APARAMA2.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomStringDeserializerTest {

    @Spy
    JsonParser jsonParser;
    @Mock
    DeserializationContext deserializationContext;
    ObjectMapper mapper = new ObjectMapper();
    CustomStringDeserializer deserializer = new CustomStringDeserializer();

    /**
     * The method is used to test the CustomDeserializer object is not null.
     */
    @Test
    public void testCustomStringDeserializer() throws IOException {
        CustomStringDeserializer customStringDeserializer =
            new CustomStringDeserializer();
        Assert.assertNotNull(customStringDeserializer);
        JsonFactory jsonFactory = new JsonFactory();
        String json = "{\"appName\":\"12345\"}";
        jsonParser = jsonFactory.createParser(json);
        //jsonParser.setCurrentValue("123");
        customStringDeserializer.deserialize(jsonParser, deserializationContext);
    }

    @Test(expected = InvalidTypeIdException.class)
    public void intInvalid() throws IOException {
        String json = String.format("%d", 93);
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = mapper.getFactory().createParser(stream);
        DeserializationContext ctxt = mapper.getDeserializationContext();
        parser.nextToken();
        deserializer.deserialize(parser, ctxt);
    }

    @Test(expected = InvalidTypeIdException.class)
    public void floatInvalid() throws IOException {
        String json = String.format("%f", 1.1);
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = mapper.getFactory().createParser(stream);
        DeserializationContext ctxt = mapper.getDeserializationContext();
        parser.nextToken();
        deserializer.deserialize(parser, ctxt);
    }

    @Test(expected = InvalidTypeIdException.class)
    public void booleanTrueInvalid() throws IOException {
        String json = String.format("%s", true);
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = mapper.getFactory().createParser(stream);
        DeserializationContext ctxt = mapper.getDeserializationContext();
        parser.nextToken();
        deserializer.deserialize(parser, ctxt);
    }

    @Test(expected = InvalidTypeIdException.class)
    public void booleanFalseInvalid() throws IOException {
        String json = String.format("%s", false);
        InputStream stream = new ByteArrayInputStream(json.getBytes(StandardCharsets.UTF_8));
        JsonParser parser = mapper.getFactory().createParser(stream);
        DeserializationContext ctxt = mapper.getDeserializationContext();
        parser.nextToken();
        deserializer.deserialize(parser, ctxt);
    }


}