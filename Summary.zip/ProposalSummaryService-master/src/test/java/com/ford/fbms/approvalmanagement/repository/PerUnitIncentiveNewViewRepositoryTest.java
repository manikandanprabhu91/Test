package com.ford.fbms.approvalmanagement.repository;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.domain.PerUnitIncentiveNewViewDto;

/**
 * @author VSHANMU8
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class PerUnitIncentiveNewViewRepositoryTest {

	@InjectMocks
	private PerUnitIncentiveNewViewRepository repository;
	@Mock
	private EntityManager entityManager;
	@Mock
	private ConfigProperties configProperties;

	@Test
	public void testMaintainFinancialData() {
		StoredProcedureQuery query = mock(StoredProcedureQuery.class);
		when(configProperties.getSchema()).thenReturn("FBMS");
		when(entityManager.createStoredProcedureQuery(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(query);
		List<PerUnitIncentiveNewViewDto> data = repository.findPerUnitNewViewByProposal(1l);
		assertNotNull(data);
		assertTrue(data.isEmpty());;
	}

}
