package com.ford.fbms.approvalmanagement.validator;

import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalVo;
import com.ford.fbms.approvalmanagement.validators.PerUnitIncentiveManager;
import java.util.concurrent.ExecutionException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import static org.junit.Assert.assertNotNull;

/**
 * Test class for PerUnitIncentiveManagerTest class.
 *
 * @author SJAGATJO on 6/1/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class PerUnitIncentiveManagerTest {

  @Spy
  @InjectMocks
  private PerUnitIncentiveManager perUnitIncentiveManager;
  @Mock
  private RestService restService;
  @Mock
  private HttpServletRequest httpRequest;

  @Test
  public void testValidateAndConstruct() throws ExecutionException, InterruptedException {
    ApiParams apiParams = new ApiParams();
    apiParams.setUserId("FBMSTID1");
    apiParams.setCountryCd("USA");
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    Mockito.when(restService.getPerUnitIncentiveDetails(apiParams, httpRequest)).thenReturn(responseWrapper);
    assertNotNull(perUnitIncentiveManager
        .validateAndConstruct(apiParams, null, null,httpRequest).get().getProposalVo());
  }
}