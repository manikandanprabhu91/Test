package com.ford.fbms.approvalmanagement.ruleengines;

import static com.ford.fbms.approvalmanagement.util.Constants.BLANK;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.AccountAssignmentDto;
import com.ford.fbms.approvalmanagement.domain.AccountNote;
import com.ford.fbms.approvalmanagement.domain.AcctSourceType;
import com.ford.fbms.approvalmanagement.domain.Address;
import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ApprovalViewDto;
import com.ford.fbms.approvalmanagement.domain.AssignmentTypeDto;
import com.ford.fbms.approvalmanagement.domain.CountryDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FinOpUnitMaster;
import com.ford.fbms.approvalmanagement.domain.FinStatus;
import com.ford.fbms.approvalmanagement.domain.FordOrganization;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.VehicleLineOptionDiscountVo;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalViewRepository;
import com.ford.fbms.approvalmanagement.repository.FinOpUnitMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO.rowType;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalCommentsVo;
import com.ford.fbms.approvalmanagement.transport.ProposalVo;
import com.ford.fbms.approvalmanagement.transport.SubsidiariesVo;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.MqUtil;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

/**
 * Test class for MasterRuleEngine class.
 *
 * @author NACHUTHA on 3/12/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MasterRuleEngineTest {

  @Spy
  @InjectMocks
  private NaRuleEngine masterRuleEngine;
  @Mock
  private ResponseBuilder responseBuilder;
  @Mock
  private RestService restService;
  @Mock
  protected ProposalRepository proposalRepository;
  @Mock
  private MqUtil mqUtil;
  @Mock
  protected ProposalStatusRepository proposalStatusRepo;
  @Mock
  protected FinOpUnitMasterRepository finOpUnitMasterRepository;
  @Mock
  protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
  @Mock
  protected ApprovalProcessRepository approvalProcessRepository;
  @Mock
  protected FordPersonRepository fordPersonRepo;
  @Mock
  protected ProcedureRepository procedureRepository;
  @Mock
  protected ReportLevelRepository reportLevelRepo;
  @Mock
  protected ApprovalViewRepository approvalViewRepo;
  
  protected HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
  protected HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
  
  protected ApiParams apiParams = new ApiParams();
  protected FordPersonDto fordPersonDto = new FordPersonDto();
  protected ProposalDto proposalDto = new ProposalDto();
  protected FinMasterDto finMasterDto = new FinMasterDto();
  protected FinOpUnitMaster finOpUnitMaster = new FinOpUnitMaster();
  protected PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
  protected CreateProposalRequest createProposalRequest =  new CreateProposalRequest();
  protected ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
  protected ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
  protected ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
  protected FinancialDetailedVO financialDetailedVO = new FinancialDetailedVO();
  protected FinancialMexDetailedVO financialMexDetailedVO = new FinancialMexDetailedVO();
  
  protected void loadProposalDto() {
		fordPersonDto.setCdsid("FBMSTID1");
		proposalDto.setFordPerson(fordPersonDto);
		pyDefinitionDto.setProposalYearCode(2021);
		proposalDto.setPyDefinition(pyDefinitionDto);
		proposalDto.setCntlReqdFlag(true);
		finMasterDto.setFinMasterKey(1L);
		proposalDto.setProposalSaKey(1l);
		proposalDto.setFinMasterKey(finMasterDto);
		proposalDto.setProposalMlv(new BigDecimal(25));
		proposalDto.setLetterMinQty(BigDecimal.ONE);
		proposalDto.setCntlReqdFlag(true);
		proposalDto.setLongTermDemoR(new BigDecimal(2));
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryIso3Code("USA");
		finMasterDto.setCountry(countryDto);
		proposalDto.setProposalStatus(proposalStatusDto);
	}
  
  
	@Test
	public void testGetApprovalChainWithEmptyChainList() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(Collections.emptyList());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.getApprovalChain(genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetApprovalChain() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(Arrays.asList(new ApprovalChainVO(BLANK, BLANK, BLANK)));
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setHttpStatus(HttpStatus.OK);
		GenericResponse actualGenericResponse = masterRuleEngine.getApprovalChain(genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	
	@Test
	public void testCreateProposalCommentsWithEmptyDesc() {
		CreateProposalRequest createProposalRequest =  new CreateProposalRequest();
		createProposalRequest.setProposalNoteDescription(BLANK);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setHttpStatus(HttpStatus.OK);
		GenericResponse actualGenericResponse = masterRuleEngine.createProposalComments(apiParams, createProposalRequest, httpServletRequest, genericResponse);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testCreateProposalComments() {
		createProposalRequest.setProposalNoteDescription("Note Desc");
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setHttpStatus(HttpStatus.OK);
		when(restService.createProposalComments(apiParams, createProposalRequest, httpServletRequest)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.createProposalComments(apiParams, createProposalRequest, httpServletRequest, genericResponse);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testSaveProposalWithEmptyProposal() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.saveProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSaveProposalWithEmptyProposalSamePriority() {
		apiParams.setHighPriority(false);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(new ProposalDto());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.saveProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSaveProposal() {
		apiParams.setHighPriority(true);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(new ProposalDto());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0002");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_CREATE)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.saveProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0002", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetTotalAvgFinancials() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testPopulateFinancialListWithEmptyFinancialDetailVo() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setFinancialDetailedVOList(Collections.emptyList());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.populateFinancialList(genericResponseWrapper);
		assertEquals("MSG-MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testPopulateFinancialListWithEmptyFinancialDetailMexVo() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setFinancialDetailedMexVOList(Collections.emptyList());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.populateFinancialList(genericResponseWrapper);
		assertEquals("MSG-MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testPopulateFinancialListWithFinancialDetailMexVo() {
		financialMexDetailedVO.setRecType(FinancialMexDetailedVO.rowType.LineTotal);
		financialMexDetailedVO.setVehicleLineCode("CODE");
		financialMexDetailedVO.setBodyStyle("BodyStyle");
		financialMexDetailedVO.setModelYear(2021);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setFinancialDetailedMexVOList(Arrays.asList(financialMexDetailedVO));
		GenericResponse actualGenericResponse = masterRuleEngine.populateFinancialList(genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testPopulateFinancialListWithFinancialDetailVo() {
		financialDetailedVO.setRecType(rowType.LineTotal);
		financialDetailedVO.setVehicleLineCode("CODE");
		financialDetailedVO.setBodyStyle("BodyStyle");
		financialDetailedVO.setModelYear(2021l);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setFinancialDetailedVOList(Arrays.asList(financialDetailedVO));
		GenericResponse actualGenericResponse = masterRuleEngine.populateFinancialList(genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithEmptyFinancialDetailVo() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedVOList(Collections.emptyList());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithEmptyFinancialDetailMexVo() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedMexVOList(Collections.emptyList());
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailMexVo() {
		financialMexDetailedVO.setRecType(FinancialMexDetailedVO.rowType.LineTotal);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedMexVOList(Arrays.asList(financialMexDetailedVO));
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailMexVoAndGrandTotal() {
		financialMexDetailedVO.setRecType(FinancialMexDetailedVO.rowType.GrandTotal);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedMexVOList(Arrays.asList(financialMexDetailedVO));
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailMexVoAndGrandTotalAndVmAndCM() {
		financialMexDetailedVO.setRecType(FinancialMexDetailedVO.rowType.GrandTotal);
		financialMexDetailedVO.setPresentVM(1);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedMexVOList(Arrays.asList(financialMexDetailedVO));
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailVo() {
		financialDetailedVO.setRecType(rowType.LineTotal);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedVOList(Arrays.asList(financialDetailedVO));
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailVoAndGrandTotal() {
		financialDetailedVO.setRecType(rowType.GrandTotal);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedVOList(Arrays.asList(financialDetailedVO));
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testGetTotalAvgFinancialsWithFinancialDetailVoAndGrandTotalAndVmAndCM() {
		financialDetailedVO.setRecType(rowType.GrandTotal);
		financialDetailedVO.setPresentVM(1);
		financialDetailedVO.setPriorPYVM(1);
		financialDetailedVO.setPriorVol(1);
		financialDetailedVO.setPresentCM(1);
		financialDetailedVO.setPrevVerVM(1);
		financialDetailedVO.setPriorPYCM(2);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFinancialDetailedVOList(Arrays.asList(financialDetailedVO));
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.getTotalAvgFinancials(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testReviseProposal() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0274");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REVISED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = masterRuleEngine.reviseProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0274", actualGenericResponse.getMsgId());
	}
	
	
	@Test
	public void testRecallProposal() {
		loadProposalDto();
		approvalResponseVo.setAccountManagerFlag(false);
		approvalResponseVo.setReportlevel(6);
		approvalResponseVo.setApprovalChain(Arrays.asList(approvalProcessDto));
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setUpdateRecalledQueue(approvalProcessDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0232");
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_RECALLED_SUCCESSFULLY)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0232", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testRecallProposalWithReportLevel5() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		proposalStatusDto.setProposalStatusCode("SUB");
		proposalDto.setCntlReqdFlag(true);
		loadProposalDto();
		approvalResponseVo.setAccountManagerFlag(true);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testRecallProposalWithReportLevel4() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(4);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		proposalStatusDto.setProposalStatusCode("SUB");
		proposalDto.setCntlReqdFlag(true);
		loadProposalDto();
		approvalResponseVo.setAccountManagerFlag(true);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testRecallProposalWithReportLevel2() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(2);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		proposalStatusDto.setProposalStatusCode("SUB");
		proposalDto.setCntlReqdFlag(true);
		loadProposalDto();
		approvalResponseVo.setAccountManagerFlag(true);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetVolumeFinancials() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-MSG-0005");
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.getVolumeFinancials(genericResponseWrapper);
		assertEquals("MSG-MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testGetVolumeFinancialsWithDropDownMap() {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setDropDownMap(Collections.emptyMap());
		GenericResponse actualGenericResponse = masterRuleEngine.getVolumeFinancials(genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testRecallProposalWithEmptyProposal() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0232");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_RECALLED_SUCCESSFULLY)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0232", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testFindNextDeal() {
		loadProposalDto();
		approvalResponseVo.setPresentReportLevelTitle(ApprovalConstants.CTL);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		GenericResponse actualGenericResponse = masterRuleEngine.findNextDeal(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testFindNextDealWithNonCtlReportLevel() {
		loadProposalDto();
		approvalResponseVo.setPresentReportLevelTitle(ApprovalConstants.ADM);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		GenericResponse actualGenericResponse = masterRuleEngine.findNextDeal(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testFindNextDealWithApprovalViewAndNonCtlReportLevel() {
		loadProposalDto();
		apiParams.setCountryCd("USA");
		apiParams.setUserId("FBMSTID1");
		approvalResponseVo.setPresentReportLevelTitle(ApprovalConstants.ADM);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		when(approvalViewRepo.queryApprovalNextDealUSAByCountryCodeCdsidCode("USA", "FBMSTID1")).thenReturn(new ApprovalViewDto());
		GenericResponse actualGenericResponse = masterRuleEngine.findNextDeal(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testFindNextDealWithApprovalView() {
		loadProposalDto();
		apiParams.setCountryCd("USA");
		approvalResponseVo.setPresentReportLevelTitle(ApprovalConstants.CTL);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		ApprovalViewDto approvalViewDto = setApprovalView();
		when(approvalViewRepo.queryApprovalNextDealUSACTLByCountryCodeTitleCode("USA", ApprovalConstants.CTL)).thenReturn(approvalViewDto);
		GenericResponse actualGenericResponse = masterRuleEngine.findNextDeal(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}


	private ApprovalViewDto setApprovalView() {
		ApprovalViewDto approvalViewDto = new ApprovalViewDto();
		approvalViewDto.setAccountName(BLANK);
		approvalViewDto.setCdsid(BLANK);
		approvalViewDto.setControllerRequiredFlag(false);
		approvalViewDto.setFin(BLANK);
		approvalViewDto.setFinMasterSaKey(null);
		approvalViewDto.setHttpStatus(null);
		approvalViewDto.setMaxReportLevelCode(0);
		approvalViewDto.setMaxReportLevelKey(0);
		approvalViewDto.setMaxReportLevelTitle(BLANK);
		approvalViewDto.setMsgDesc(BLANK);
		approvalViewDto.setMsgId(BLANK);
		approvalViewDto.setProposalMlv(0);
		approvalViewDto.setProposalSaKey(null);
		approvalViewDto.setProposalStatus(BLANK);
		approvalViewDto.setProposalSubmittedDate(null);
		approvalViewDto.setProposalYear(0);
		approvalViewDto.setQueueReportLevelCode(0);
		approvalViewDto.setSegmentGroupType(BLANK);
		approvalViewDto.setStatusDate(null);
		approvalViewDto.setTimeStamp(null);
		approvalViewDto.setSubmittedDate(null);
		approvalViewDto.setVersion(0);
		
		approvalViewDto.getAccountName();
		approvalViewDto.getCdsid();
		approvalViewDto.isControllerRequiredFlag();
		approvalViewDto.getFin();
		approvalViewDto.getFinMasterSaKey();
		approvalViewDto.getHttpStatus();
		approvalViewDto.getMaxReportLevelCode();
		approvalViewDto.getMaxReportLevelKey();
		approvalViewDto.getMaxReportLevelTitle();
		approvalViewDto.getMsgDesc();
		approvalViewDto.getMsgId();
		approvalViewDto.getProposalMlv();
		approvalViewDto.getProposalSaKey();
		approvalViewDto.getProposalStatus();
		approvalViewDto.getProposalSubmittedDate();
		approvalViewDto.getProposalYear();
		approvalViewDto.getQueueReportLevelCode();
		approvalViewDto.getSegmentGroupType();
		approvalViewDto.getStatusDate();
		approvalViewDto.getTimeStamp();
		approvalViewDto.getSubmittedDate();
		approvalViewDto.getVersion();
		return approvalViewDto;
	}
	
	@Test
	public void testRecallProposalWithUnExpectedBehavior() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0013");
		when(responseBuilder.generateResponse(ResponseCodes.UNEXPECTED_BEHAVIOR)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = masterRuleEngine.recallProposal(apiParams, genericResponseWrapper);
		assertEquals("MSG-0013", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSendBackProposal() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);   
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0258");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, null);
		assertEquals("MSG-0258", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testApproveProposal() {
		approvalResponseVo.setControllerApprovalRequired(true);
		approvalResponseVo.setControllerApprovalYear(new Date());
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(6);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		loadProposalDto();
		proposalDto.setReportLevel(reportLevel);
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0260");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(reportLevel));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0260", actualGenericResponse.getMsgId());
	}
	
	/*@Test
	public void testApproveProposalWithProposalApproved() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("NEW");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0233");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(reportLevel));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0233", actualGenericResponse.getMsgId());
		
	}*/
	
	@Test
	public void testApproveProposalWithProposalInRevise() {
		approvalResponseVo.setProposalInRevise(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0233");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(reportLevel));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0233", actualGenericResponse.getMsgId());
	}
	@Test
	public void testApproveProposalWithProposalInReviseCntrlReq() {
		approvalResponseVo.setProposalInRevise(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		approvalResponseVo.setMaxReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		approvalResponseVo.setControllerApproved(true);
		approvalResponseVo.setControllerApprovalYear(new Date());
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0233");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(reportLevel));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0233", actualGenericResponse.getMsgId());
	}
	@Test
	public void testApproveProposalWithApprovedStatus() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setProposalApproved(true);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("APV");
		accountAssignmentDto.setFordPerson(fordPersonDto);
		AssignmentTypeDto assignmentTypeDto = new AssignmentTypeDto();
		assignmentTypeDto.setAssignmentTypeCode("test");
		assignmentTypeDto.setAssignmentTypeDesc("test");
		accountAssignmentDto.setAssignmentType(assignmentTypeDto);
		accountAssignmentDto.setFinMaster(new FinMasterDto());
		accountAssignmentDto.setStatusCode(BLANK);
		accountAssignmentDto.setCreatedProcess(BLANK);
		accountAssignmentDto.setCreatedTimeStamp(null);
		accountAssignmentDto.setCreatedUser(BLANK);
		accountAssignmentDto.setLastUpdatedProcess(BLANK);
		accountAssignmentDto.setLastUpdatedTimeStamp(null);
		accountAssignmentDto.setSaKey(0);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);   
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0266");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_FULLY)).thenReturn(genericResponse);
		when(approvalProcessRepository.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(approvalProcessDto));
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0266", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testApproveProposalWithReportLevel5() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		proposalDto.setReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_LL5CONTROLLER_APPROVAL)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testApproveProposalWithReportLevel4() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(4);
		proposalDto.setReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testApproveProposalWithReportLevel2() {
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(2);
		proposalDto.setReportLevel(reportLevel);
		loadProposalDto();
		apiParams.setProposalKey(1l);
		approvalResponseVo.setNextApproverCdsid("FBMSTID1");
		proposalStatusDto.setProposalStatusCode("SUB");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0237");
		when(responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_GLOBALCONTROLLER_APPROVAL)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		GenericResponse actualGenericResponse = masterRuleEngine.approveProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0237", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testRejectProposal() {
		apiParams.setUserId("FBMSTID1");
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);
		createProposalRequest.setProposalNoteDescription("ProposalNote");
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0234");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REJECTED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		GenericResponse actualGenericResponse = masterRuleEngine.rejectProposal(apiParams, genericResponseWrapper, RequestMode.REJECT_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0234", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSendBackProposalWithApprovalRequest() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);   
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Arrays.asList(new ApprovalProcessDto()));
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0238");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new ProposalStatusDto()));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, null);
		assertEquals("MSG-0238", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSendBackProposalWithRejectProposal() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0238");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new ProposalStatusDto()));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.REJECT_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0238", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testMailWithSendProposal() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);   
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0238");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new ProposalStatusDto()));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.SENDBACK_PROPOSAL, httpServletRequest, httpServletResponse, createProposalRequest);
		assertEquals("MSG-0238", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testSendBackProposalWithAccountName() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);
		setFinOptUnitMaster();
		
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0238");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new ProposalStatusDto()));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		when(mqUtil.putEmailInMq(Mockito.any())).thenReturn(true);
		when(finOpUnitMasterRepository.findByFinMasterFinOpUnit(Mockito.anyLong(), Mockito.anyString())).thenReturn(Optional.of(finOpUnitMaster));
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, null);
		assertEquals("MSG-0238", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testTriggerPostDbProcesses() {
		masterRuleEngine.triggerPostDbProcesses(apiParams);
	}

	private void setFinOptUnitMaster() {
		finOpUnitMaster.setAccountName("AccoutName");
		AccountNote accountNote = new AccountNote();
		accountNote.setAccountNoteDescription(BLANK);
		accountNote.setAccountNoteSaKey(0);
		accountNote.setAccountNoteTS(null);
		accountNote.setCreatedProcess(BLANK);
		accountNote.setCreatedTimeStamp(null);
		accountNote.setCreatedUser(BLANK);
		accountNote.setFordOrganization(new FordOrganization());
		accountNote.setFordPerson(fordPersonDto);
		accountNote.setLastUpdatedProcess(BLANK);
		accountNote.setLastUpdatedTimeStamp(null);
		accountNote.setLastUpdatedUser(BLANK);
		accountNote.getAccountNoteDescription();
		accountNote.getAccountNoteSaKey();
		accountNote.getAccountNoteTS();
		accountNote.getCreatedProcess();
		accountNote.getCreatedTimeStamp();
		accountNote.getCreatedUser();
		accountNote.getFordOrganization();
		accountNote.getFordPerson();
		accountNote.getLastUpdatedProcess();
		accountNote.getLastUpdatedTimeStamp();
		accountNote.getLastUpdatedUser();
		finOpUnitMaster.setAccountNotes(Arrays.asList(accountNote));
		AcctSourceType acctSourceType = setAcctSourceType();
		finOpUnitMaster.setAccountSourceType(acctSourceType);
		finOpUnitMaster.setCreatedProcess(BLANK);
		finOpUnitMaster.setCreatedTimeStamp(null);
		finOpUnitMaster.setCreatedUser(BLANK);
		finOpUnitMaster.setCupid(null);
		finOpUnitMaster.setEnrollDate(null);
		finOpUnitMaster.setFinMasterDto(finMasterDto);
		finOpUnitMaster.setFinOpUnitMasterSaKey(0);
		finOpUnitMaster.setFinStatus(new FinStatus());
		finOpUnitMaster.setFleetClassCode(BLANK);
		finOpUnitMaster.setFleetTypeCode(BLANK);
		finOpUnitMaster.setLastUpdatedProcess(BLANK);
		finOpUnitMaster.setLastUpdatedTimeStamp(null);
		finOpUnitMaster.setLastUpdatedUser(BLANK);
		Address address = setMailingAddress();
		finOpUnitMaster.setMailingAddress(address);
		finOpUnitMaster.setOperationUnitCode(BLANK);
		finOpUnitMaster.setPhysicalAddress(null);
		finOpUnitMaster.setRestrictedFinStatus(BLANK);
		finOpUnitMaster.getAccountNotes();
		finOpUnitMaster.getAccountSourceType();
		finOpUnitMaster.getCreatedProcess();
		finOpUnitMaster.getCreatedTimeStamp();
		finOpUnitMaster.getCreatedUser();
		finOpUnitMaster.getCupid();
		finOpUnitMaster.getEnrollDate();
		finOpUnitMaster.getFinMasterDto();
		finOpUnitMaster.getFinOpUnitMasterSaKey();
		finOpUnitMaster.getFinStatus();
		finOpUnitMaster.getFleetClassCode();
		finOpUnitMaster.getFleetTypeCode();
		finOpUnitMaster.getLastUpdatedProcess();
		finOpUnitMaster.getLastUpdatedTimeStamp();
		finOpUnitMaster.getLastUpdatedUser();
		finOpUnitMaster.getMailingAddress();
		finOpUnitMaster.getOperationUnitCode();
		finOpUnitMaster.getPhysicalAddress();
		finOpUnitMaster.getRestrictedFinStatus();
	}


	private Address setMailingAddress() {
		Address address = new Address();
		address.setAddress1PoboxDescription(BLANK);
		address.setAddress2Description(BLANK);
		address.setAddress3Description(BLANK);
		address.setAddress4Description(BLANK);
		address.setAddressSaKey(0);
		address.setAddressType(null);
		address.setCityDescription(BLANK);
		address.setCountry(null);
		address.setCreatedProcess(BLANK);
		address.setCreatedTimeStamp(null);
		address.setCreatedUser(BLANK);
		address.setLastUpdatedProcess(BLANK);
		address.setLastUpdatedTimeStamp(null);
		address.setLastUpdatedUser(BLANK);
		address.setPostalDescription(BLANK);
		address.setPostalSuffixDescription(BLANK);
		address.setProvinceN(BLANK);
		address.getAddress1PoboxDescription();
		address.getAddress2Description();
		address.getAddress3Description();
		address.getAddress4Description();
		address.getAddressSaKey();
		address.getAddressType();
		address.getCityDescription();
		address.getCountry();
		address.getCreatedProcess();
		address.getCreatedTimeStamp();
		address.getCreatedUser();
		address.getLastUpdatedProcess();
		address.getLastUpdatedTimeStamp();
		address.getLastUpdatedUser();
		address.getPostalDescription();
		address.getPostalSuffixDescription();
		address.getProvinceN();
		return address;
	}


	private AcctSourceType setAcctSourceType() {
		AcctSourceType acctSourceType = new AcctSourceType();
		acctSourceType.setAcctSourceC(BLANK);
		acctSourceType.setAcctSourceDescription(BLANK);
		acctSourceType.setCreatedProcess(BLANK);
		acctSourceType.setCreatedTimeStamp(null);
		acctSourceType.setCreatedUser(BLANK);
		acctSourceType.setLastUpdatedProcess(BLANK);
		acctSourceType.setLastUpdatedTimeStamp(null);
		acctSourceType.setLastUpdatedUser(BLANK);
		acctSourceType.getAcctSourceC();
		acctSourceType.getAcctSourceDescription();
		acctSourceType.getCreatedProcess();
		acctSourceType.getCreatedTimeStamp();
		acctSourceType.getCreatedUser();
		acctSourceType.getLastUpdatedProcess();
		acctSourceType.getLastUpdatedTimeStamp();
		acctSourceType.getLastUpdatedUser();
		return acctSourceType;
	}
	
	@Test
	public void testSendBackProposalMsgFailed() {
		ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
		AccountAssignmentDto accountAssignmentDto = new AccountAssignmentDto();
		loadProposalDto();
		accountAssignmentDto.setFordPerson(fordPersonDto);
		proposalAssignAttributeDto.setAccountAssignment(accountAssignmentDto);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalProcessDtoList(Collections.emptyList());
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0238");
		genericResponse.setMsgDesc("test");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new ProposalStatusDto()));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(Arrays.asList(proposalAssignAttributeDto)));
		GenericResponse actualGenericResponse = masterRuleEngine.sendBackProposal(apiParams, genericResponseWrapper, RequestMode.APPROVE_PROPOSAL, httpServletRequest, httpServletResponse, null);
		assertEquals("MSG-0238", actualGenericResponse.getMsgId());
	}
	

  @Test
  public void testDownloadProposalInfoValid() {
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    ApiParams apiParams = getApiParams();
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    assertEquals(HttpStatus.OK, masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier6Valid() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier5Valid() {
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTie4Valid() {
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier3Valid() {
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier2Valid() {
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume3(0L);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier1Valid() {
    Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume3(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume2(0L);
    ApiParams apiParams = getApiParams();
    assertNotNull(masterRuleEngine.downloadProposal(apiParams, genericResponseWrapperList.get(0)).getHttpStatus());
  }

  private List<GenericResponseWrapper> constructGenericResponseWrapperList() {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    genericResponseWrapper.setGenericResponse(genericResponse);
    genericResponseWrapper.setProposalCommentsVos(getProposalComments());
    genericResponseWrapper.setProposalVo(getProposaData());
    genericResponseWrapper.setSubsidiariesVos(getSubsidiaryData());
    genericResponseWrapper.setVehicleLineOptionDiscountVos(getVehicleData());
    genericResponseWrapper.setFinancialDetailedVOList(getFinanceDetails());
    return Collections.singletonList(genericResponseWrapper);
  }

  private List<VehicleLineOptionDiscountVo> getVehicleData() {
    VehicleLineOptionDiscountVo vehicleLineOptionDiscountVo = new VehicleLineOptionDiscountVo();
    vehicleLineOptionDiscountVo.setVehicleLineDesc(BLANK);
    vehicleLineOptionDiscountVo.setBodyStyle(BLANK);
    vehicleLineOptionDiscountVo.setModelYr(null);
    vehicleLineOptionDiscountVo.setMlv(null);
    vehicleLineOptionDiscountVo.setTier1(BLANK);
    vehicleLineOptionDiscountVo.setTier1Amt(1000L);
    vehicleLineOptionDiscountVo.setTier2Amt(1000L);
    vehicleLineOptionDiscountVo.setTier3Amt(1000L);
    vehicleLineOptionDiscountVo.setTier4Amt(1000L);
    vehicleLineOptionDiscountVo.setTier5Amt(1000L);
    vehicleLineOptionDiscountVo.setTier6Amt(1000L);
    return Collections.singletonList(vehicleLineOptionDiscountVo);
  }

  private List<SubsidiariesVo> getSubsidiaryData() {
    SubsidiariesVo viewDto = new SubsidiariesVo();
    viewDto.setFin("1743");
    viewDto.setAccountName("Hertz Corp");
    viewDto.setStateCode("FL");
    viewDto.setCity("Brandon");
    return Collections.singletonList(viewDto);
  }


  private ProposalVo getProposaData() {
    ProposalVo proposalVo = new ProposalVo();
    proposalVo.setProposalYr(2020);
    proposalVo.setAccountName("Hertz");
    proposalVo.setAddress1("addr 1");
    proposalVo.setTierVolume1(100L);
    proposalVo.setTierVolume2(200L);
    proposalVo.setTierVolume3(300L);
    proposalVo.setTierVolume4(400L);
    proposalVo.setTierVolume5(500L);
    proposalVo.setTierVolume6(600L);
    proposalVo.setFinKey(12345L);
    proposalVo.setAggregateIncentiveCd1(100L);
    proposalVo.setAggregateIncentiveCd2(200L);
    proposalVo.setAggregateIncentiveDesc1("desc 1");
    proposalVo.setAggregateIncentiveDesc2("desc 2");
    proposalVo.setVersion(5);
    proposalVo.setYoyCd("yoy1");
    proposalVo.setYoyDesc("yoy desc");
    proposalVo.setAddress2("addr 2");
    proposalVo.setLetterMinQty(666L);
    proposalVo.setStatusYear(new Date());
    proposalVo.setMultiYearStart(2020L);
    proposalVo.setMultiYearEnd(2022L);
    proposalVo.setPaymentType("Monthly");
    proposalVo.setCity("Tampa");
    proposalVo.setFinCd("BU452");
    proposalVo.setState("NY");
    proposalVo.setZipcode("23565");
    return proposalVo;
  }

  private List<ProposalCommentsVo> getProposalComments() {
    ProposalCommentsVo viewDto = new ProposalCommentsVo();
    viewDto.setProposalVersion("2");
    viewDto.setProposalComments("added comments");
    viewDto.setProposalYear("2020");
    viewDto.setDateSubmitted(new Date());
    viewDto.setCommentedBy("FBMSTID1");
    return Collections.singletonList(viewDto);
  }

  private List<FinancialDetailedVO> getFinanceDetails() {
    List<FinancialDetailedVO> financialDetailedVOList = new ArrayList<>();
    FinancialDetailedVO financialDetailedVo = new FinancialDetailedVO();
    financialDetailedVo.setBodyStyle("ALL");
    financialDetailedVo.setBwPrevVerCM(1000);
    financialDetailedVo.setBwPrevVerNR(1000);
    financialDetailedVo.setVehicleLine("ALL");
    financialDetailedVo.setModelYear(2022L);
    financialDetailedVo.setPresentVol(1000);
    financialDetailedVo.setPriorVol(1000);
    financialDetailedVo.setBwVol(1000);
    financialDetailedVo.setPresentCPA(1000);
    financialDetailedVo.setPresentESP(1000);
    financialDetailedVo.setPresentOPT(1000);
    financialDetailedVo.setPresentAGG(1000);
    financialDetailedVo.setPresentVM(1000);
    financialDetailedVo.setBwPriorPYVM(1000);
    financialDetailedVo.setBwPrevVerVM(1000);
    financialDetailedVo.setBwTargetVM(1000);
    financialDetailedVo.setPresentNR(1000);
    financialDetailedVo.setBwPriorPYNR(1000);
    financialDetailedVo.setPresentCM(1000);
    financialDetailedVo.setBwPriorPYCM(1000);
    financialDetailedVo.setBwTargetCM(1000);
    financialDetailedVo.setRecType(FinancialDetailedVO.rowType.GrandTotal);
    financialDetailedVOList.add(financialDetailedVo);
    /*financialDetailedVOList = new ArrayList<>();
    financialDetailedVo = new FinancialDetailedVO();
    financialDetailedVo.setBodyStyle("ALL");
    financialDetailedVo.setBwPrevVerCM(1000);
    financialDetailedVo.setBwPrevVerNR(1000);
    financialDetailedVo.setVehicleLine("ALL");
    financialDetailedVo.setModelYear(2022L);
    financialDetailedVo.setPresentVol(1000);
    financialDetailedVo.setPriorVol(1000);
    financialDetailedVo.setBwVol(1000);
    financialDetailedVo.setPresentCPA(1000);
    financialDetailedVo.setPresentESP(1000);
    financialDetailedVo.setPresentOPT(1000);
    financialDetailedVo.setPresentAGG(1000);
    financialDetailedVo.setPresentVM(1000);
    financialDetailedVo.setBwPriorPYVM(1000);
    financialDetailedVo.setBwPrevVerVM(1000);
    financialDetailedVo.setBwTargetVM(1000);
    financialDetailedVo.setPresentNR(1000);
    financialDetailedVo.setBwPriorPYNR(1000);
    financialDetailedVo.setPresentCM(1000);
    financialDetailedVo.setBwPriorPYCM(1000);
    financialDetailedVo.setBwTargetCM(1000);
    financialDetailedVo.setRecType(FinancialDetailedVO.rowType.LineTotal);
    financialDetailedVOList.add(financialDetailedVo);
    financialDetailedVOList = new ArrayList<>();
    financialDetailedVo = new FinancialDetailedVO();
    financialDetailedVo.setBodyStyle("ALL");
    financialDetailedVo.setBwPrevVerCM(1000);
    financialDetailedVo.setBwPrevVerNR(1000);
    financialDetailedVo.setVehicleLine("ALL");
    financialDetailedVo.setModelYear(2022L);
    financialDetailedVo.setPresentVol(1000);
    financialDetailedVo.setPriorVol(1000);
    financialDetailedVo.setBwVol(1000);
    financialDetailedVo.setPresentCPA(1000);
    financialDetailedVo.setPresentESP(1000);
    financialDetailedVo.setPresentOPT(1000);
    financialDetailedVo.setPresentAGG(1000);
    financialDetailedVo.setPresentVM(1000);
    financialDetailedVo.setBwPriorPYVM(1000);
    financialDetailedVo.setBwPrevVerVM(1000);
    financialDetailedVo.setBwTargetVM(1000);
    financialDetailedVo.setPresentNR(1000);
    financialDetailedVo.setBwPriorPYNR(1000);
    financialDetailedVo.setPresentCM(1000);
    financialDetailedVo.setBwPriorPYCM(1000);
    financialDetailedVo.setBwTargetCM(1000);
    financialDetailedVo.setRecType(FinancialDetailedVO.rowType.VehicleLine);*/
    financialDetailedVOList.add(financialDetailedVo);
    return financialDetailedVOList;
  }

  private ApiParams getApiParams() {
    ApiParams apiParams = new ApiParams();
    apiParams.setCountryCd("NA");
    apiParams.setUserId("fbmstid1");
    apiParams.setProposalKey(5222L);
    apiParams.setProposalYr(2020);
    apiParams.setProposalYrVer(5);
    apiParams.setFinKey(10000L);
    apiParams.setComplete(true);
    apiParams.setVolumeFinancialDataSource("5_pact_svm_vs_cfct_mvm");
    return apiParams;
  }
}