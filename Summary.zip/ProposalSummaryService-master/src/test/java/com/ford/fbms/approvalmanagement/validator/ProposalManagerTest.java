package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.AccountSalesSummaryDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermViewDto;
import com.ford.fbms.approvalmanagement.domain.NewBodyStylePKDto;
import com.ford.fbms.approvalmanagement.domain.NewBodyStyleViewDtO;
import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumePk;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ProposalManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ProposalManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private ProposalManager validator;

	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		AccountSalesSummaryDto accountSalesSummaryDto = new AccountSalesSummaryDto();
		accountSalesSummaryDto.setVehiclesSoldMonthToDate(2);
		TierVolumeDto tierDto = new TierVolumeDto();
		TierVolumePk tierVolumePk = new TierVolumePk();
		tierVolumePk.setTierLevel(1);
		tierDto.setTierVolumePk(tierVolumePk);
		tierDto.setTierVolume(2l);
		MultiYearTermViewDto multiYearTermDto = new MultiYearTermViewDto();
		multiYearTermDto.setProposalKey(1l);
		multiYearTermDto.setEndYr(2022l);
		multiYearTermDto.setStartYr(2021l);
		multiYearTermDto.setRequiredVolume(1l);
		multiYearTermDto.setManualBonusAmount(10l);
		perUnitOptViewDto.setBodyGroupIndicator("Y");
		ProposalSummaryViewDto value = new ProposalSummaryViewDto();
		value.setTotalTiers(3);
		when(proposalSummaryViewRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(value));
		this.apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE);
		when(tierVolumeRepository.findAllByProposalKey(Mockito.anyLong())).thenReturn(Collections.singletonList(tierDto));
		when(multiYearBonusRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(multiYearTermDto));
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(accountSalesSummaryRepository.queryCalculatedOtdStdSummaryByProposal(Mockito.anyLong())).thenReturn(Collections.singletonList(accountSalesSummaryDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
		tierVolumePk.setTierLevel(2);
		proposalBodyFinancialViewDtos.get(0).setCurrentYrContributionCost(1l);
		proposalBodyFinancialViewDtos.get(0).setCurrentYrRevenue(2l);
		Future<GenericResponseWrapper> wrapper1 = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse1 = wrapper1.get();
		assertNotNull(actualGenericResponse1);
		tierVolumePk.setTierLevel(3);
		Future<GenericResponseWrapper> wrapper2 = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse2 = wrapper2.get();
		assertNotNull(actualGenericResponse2);
		tierVolumePk.setTierLevel(4);
		Future<GenericResponseWrapper> wrapper3 = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse3 = wrapper3.get();
		assertNotNull(actualGenericResponse3);
		tierVolumePk.setTierLevel(5);
		Future<GenericResponseWrapper> wrapper4 = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse4 = wrapper4.get();
		assertNotNull(actualGenericResponse4);
		tierVolumePk.setTierLevel(6);
		NewBodyStyleViewDtO newBodyStyleViewDtO = new NewBodyStyleViewDtO();
		newBodyStyleViewDtO.setNewBodyStylePK(new NewBodyStylePKDto(1l, 2l));
		when(newBodyStyleRepo.findNewBodystyleByOldBodyStyle(Mockito.anyLong())).thenReturn((newBodyStyleViewDtO));
		
		Future<GenericResponseWrapper> wrapper5 = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse5 = wrapper5.get();
		assertNotNull(actualGenericResponse5);
	}
	
	@Test
	public void testValidateAndConstructWithDifferentBodyStyle() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIdenticalPeriorProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.proposalByFinMasterProposalYearVersion(Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(proposalDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIdenticalPeriorPYProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIdenticalPeriorPYProposalAndFinanceList() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIdenticalPeriorPYProposalAndFinanceListAndBodyStyle() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto(2l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithAggregateIncentive() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		loadAggregateIncentiveViewDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(aggregateIncentiveViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(aggregateIncentiveViewDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithFVAData() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		loadFVADataDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(fvaDataRepo.findFVADataByFinBdyStylePropYr(Mockito.anyLong(), Mockito.anyLong(), Mockito.anyInt())).thenReturn(fVADataDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		targetBandDto.setBand1R(BigDecimal.ZERO);
		targetBandDto.setBand2R(BigDecimal.ONE);
		proposalDto.setProposalMlv(BigDecimal.ZERO);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(targetBandRepo.findTargetBandBySegEffDt(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(targetBandDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand2R() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		targetBandDto.setBand1R(BigDecimal.ZERO);
		targetBandDto.setBand2R(BigDecimal.ZERO);
		proposalDto.setProposalMlv(BigDecimal.ZERO);
		targetBandDto.setBand3R(BigDecimal.ONE);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(targetBandRepo.findTargetBandBySegEffDt(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(targetBandDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand3R() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		targetBandDto.setBand1R(BigDecimal.ZERO);
		targetBandDto.setBand2R(BigDecimal.ZERO);
		proposalDto.setProposalMlv(BigDecimal.ZERO);
		targetBandDto.setBand3R(BigDecimal.ZERO);
		targetBandDto.setBand4R(BigDecimal.ONE);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(targetBandRepo.findTargetBandBySegEffDt(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(targetBandDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand4R() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		targetBandDto.setBand1R(BigDecimal.ZERO);
		targetBandDto.setBand2R(BigDecimal.ZERO);
		proposalDto.setProposalMlv(BigDecimal.ZERO);
		targetBandDto.setBand3R(BigDecimal.ZERO);
		targetBandDto.setBand4R(BigDecimal.ZERO);
		targetBandDto.setBand5R(BigDecimal.ONE);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(targetBandRepo.findTargetBandBySegEffDt(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(targetBandDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand5R() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalBodyFinancialViewDto();
		loadPerUnitOptViewDto(2l);
		loadPerUnitNewViewDto();
		targetBandDto.setBand1R(BigDecimal.ZERO);
		targetBandDto.setBand2R(BigDecimal.ZERO);
		proposalDto.setProposalMlv(BigDecimal.ZERO);
		targetBandDto.setBand3R(BigDecimal.ZERO);
		targetBandDto.setBand4R(BigDecimal.ZERO);
		targetBandDto.setBand5R(BigDecimal.ZERO);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalBodyFinancialViewRepo.findProposalBodyFinancials(Mockito.anyLong())).thenReturn(proposalBodyFinancialViewDtos);
		when(perUnitOptViewRepository.findByProposalKey(Mockito.anyLong())).thenReturn(perUnitOptViewDtos);
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2020, 1l)).thenReturn(Optional.of(proposalDto));
		when(perUnitNewViewRepo.findListPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitNewViewDtos);
		when(targetBandRepo.findTargetBandBySegEffDt(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(targetBandDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	
	
}
