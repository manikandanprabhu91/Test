/*
package com.ford.fbms.approvalmanagement.service;

import com.ford.fbms.approvalmanagement.domain.VehicleLineOptionDiscountVo;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.ruleengines.NaRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalCommentsVo;
import com.ford.fbms.approvalmanagement.transport.ProposalVo;
import com.ford.fbms.approvalmanagement.transport.SubsidiariesVo;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import javax.servlet.http.HttpServletRequest;
import static com.ford.fbms.approvalmanagement.util.Constants.BLANK;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

*/
/**
 * Test class for ApprovalManagementService class.
 *
 * @author NACHUTHA on 3/08/2021.
 *//*

@RunWith(MockitoJUnitRunner.Silent.class)
public class DownloadProposalServiceTest {

  @Spy
  @InjectMocks
  private DownloadProposalService proposalService;

  @Mock
  private NaRuleEngine naRuleEngine;

  @Mock
  private ResponseBuilder responseBuilder;

  @Mock
  private MasterRuleEngine masterRuleEngine;


  */
/**
   * This test is for buildApiParams.
   *//*

  @Test
  public void test_buildApiParams() {
    ApiParams apiParams = proposalService.buildApiParams("Fbmstid1", "USA", 12L, 2020, 5, 123L, true);
    Assert.assertNotNull(apiParams);
  }

  @Test
  public void testDownloadProposalInfoInValid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertEquals(HttpStatus.OK, proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfo_InValid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(false);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL));
  }
  @Test
  public void testDownloadProposalInfoTier6Valid() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier5Valid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTie4Valid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier3Valid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier2Valid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume3(0L);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  @Test
  public void testDownloadProposalInfoTier1Valid() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    List<GenericResponseWrapper> genericResponseWrapperList = constructGenericResponseWrapperList();
    genericResponseWrapperList.get(0).setGenericResponse(null);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume6(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume5(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume4(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume3(0L);
    genericResponseWrapperList.get(0).getProposalVo().setTierVolume2(0L);
    Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(genericResponseWrapperList);
    ApiParams apiParams = getApiParams();
    assertNotNull(proposalService.downloadProposalInfo(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL).getHttpStatus());
  }

  private List<GenericResponseWrapper> constructGenericResponseWrapperList() {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    genericResponseWrapper.setGenericResponse(genericResponse);
    genericResponseWrapper.setProposalCommentsVos(getProposalComments());
    genericResponseWrapper.setProposalVo(getProposaData());
    genericResponseWrapper.setSubsidiariesVos(getSubsidiaryData());
    genericResponseWrapper.setVehicleLineOptionDiscountVos(getVehicleData());
    return Collections.singletonList(genericResponseWrapper);
  }

  private List<VehicleLineOptionDiscountVo> getVehicleData() {
    VehicleLineOptionDiscountVo vehicleLineOptionDiscountVo = new VehicleLineOptionDiscountVo();
    vehicleLineOptionDiscountVo.setVehicleLineDesc(BLANK);
    vehicleLineOptionDiscountVo.setBodyStyle(BLANK);
    vehicleLineOptionDiscountVo.setModelYr(null);
    vehicleLineOptionDiscountVo.setMlv(null);
    vehicleLineOptionDiscountVo.setTier1(BLANK);
    vehicleLineOptionDiscountVo.setTier1Amt(1000L);
    vehicleLineOptionDiscountVo.setTier2Amt(1000L);
    vehicleLineOptionDiscountVo.setTier3Amt(1000L);
    vehicleLineOptionDiscountVo.setTier4Amt(1000L);
    vehicleLineOptionDiscountVo.setTier5Amt(1000L);
    vehicleLineOptionDiscountVo.setTier6Amt(1000L);
    return Collections.singletonList(vehicleLineOptionDiscountVo);
  }

  private List<SubsidiariesVo> getSubsidiaryData() {
    SubsidiariesVo viewDto = new SubsidiariesVo();
    viewDto.setFin("1743");
    viewDto.setAccountName("Hertz Corp");
    viewDto.setStateCode("FL");
    viewDto.setCity("Brandon");
    return Collections.singletonList(viewDto);
  }

  private ProposalVo getProposaData() {
    ProposalVo proposalVo = new ProposalVo();
    proposalVo.setProposalYr(2020);
    proposalVo.setAccountName("Hertz");
    proposalVo.setAddress1("addr 1");
    proposalVo.setTierVolume1(100L);
    proposalVo.setTierVolume2(200L);
    proposalVo.setTierVolume3(300L);
    proposalVo.setTierVolume4(400L);
    proposalVo.setTierVolume5(500L);
    proposalVo.setTierVolume6(600L);
    proposalVo.setFinKey(12345L);
    proposalVo.setAggregateIncentiveCd1(100L);
    proposalVo.setAggregateIncentiveCd2(200L);
    proposalVo.setAggregateIncentiveDesc1("desc 1");
    proposalVo.setAggregateIncentiveDesc2("desc 2");
    proposalVo.setVersion(5);
    proposalVo.setYoyCd("yoy1");
    proposalVo.setYoyDesc("yoy desc");
    proposalVo.setAddress2("addr 2");
    proposalVo.setLetterMinQty(666L);
    proposalVo.setStatusYear(new Date());
    proposalVo.setMultiYearStart(2020L);
    proposalVo.setMultiYearEnd(2022L);
    proposalVo.setPaymentType("Monthly");
    proposalVo.setCity("Tampa");
    proposalVo.setFinCd("BU452");
    proposalVo.setState("NY");
    proposalVo.setZipcode("23565");
    return proposalVo;
  }

  private List<ProposalCommentsVo> getProposalComments() {
    ProposalCommentsVo viewDto = new ProposalCommentsVo();
    viewDto.setProposalVersion("2");
    viewDto.setProposalComments("added comments");
    viewDto.setProposalYear("2020");
    viewDto.setDateSubmitted(new Date());
    viewDto.setCommentedBy("FBMSTID1");
    return Collections.singletonList(viewDto);
  }

  private ApiParams getApiParams() {
    ApiParams apiParams = new ApiParams();
    apiParams.setCountryCd("NA");
    apiParams.setUserId("fbmstid1");
    apiParams.setProposalKey(5222L);
    apiParams.setProposalYr(2020);
    apiParams.setProposalYrVer(5);
    apiParams.setFinKey(10000L);
    apiParams.setComplete(true);
    return apiParams;
  }

}*/
