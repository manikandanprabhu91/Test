package com.ford.fbms.approvalmanagement.config;

import java.util.List;
import java.util.Map;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.oauth2.jwt.JwtValidationException;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;

/*
* This test class is written to perform unit testing for AdfsPermissionEvaluator class.
*
* @author SJAGATJO on 2/9/2021.
*/
@RunWith(MockitoJUnitRunner.Silent.class)
public class AdfsPermissionEvaluatorTest {

  /*
  *This method is used to test the positive case for hasPermission Method.
  *
  */
  @Test
  public void testHasPermissionWithValidInput() throws Exception {
    JwtAuthenticationToken auth = Mockito.mock(JwtAuthenticationToken.class);
    ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
    Map<String, List<String>> resourcePermissions = Map.of("Adfs", List.of("allow"));
    configProperties.setResourcePermissions(resourcePermissions);
    AdfsPermissionEvaluator adfsPermissionEvaluator = new AdfsPermissionEvaluator(configProperties);
    Mockito.when(configProperties.getResourcePermissions()).thenReturn(resourcePermissions);
    Mockito.when(((JwtAuthenticationToken) auth).getTokenAttributes()).thenReturn(Map.of("Adfs", List.of("allow")));
    Assert.assertTrue(adfsPermissionEvaluator.hasPermission(auth, "Adfs", "Adfs"));
  }

  /*
   * This method is used to test the negative case for hasPermission Method.
   *
   */
  @Test(expected = JwtValidationException.class)
  public void testHasPermissionWithInValidInput() throws Exception {
    JwtAuthenticationToken auth = Mockito.mock(JwtAuthenticationToken.class);
    ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
    Map<String, List<String>> resourcePermissions = Map.of("Adfs", List.of("allow"));
    configProperties.setResourcePermissions(resourcePermissions);
    AdfsPermissionEvaluator adfsPermissionEvaluator = new AdfsPermissionEvaluator(configProperties);
    Mockito.when(configProperties.getResourcePermissions()).thenReturn(resourcePermissions);
    Mockito.when(((JwtAuthenticationToken) auth).getTokenAttributes()).thenReturn(Map.of("Adfs", "allow"));
    adfsPermissionEvaluator.hasPermission(auth, "", "Adfs","Adfs");
  }
}
