/**
 * 
 */
package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.MexApprovalChainValidator;

/**
 * @author vvm
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MexApprovalChainValidatorTest {
	
	@InjectMocks
	private  MexApprovalChainValidator mexApprovalChainValidator;
	@Mock
	private ProposalRepository proposalRepository;
	@Mock
	private ResponseBuilder responseBuilder;
	@Mock
	private ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;
	@Mock
	private PviExtraInfoRepository pviExtraInfoRepository;
	@Mock
	private FordPersonRepository fordPersonRepo;
	@Mock
	private ApprovalProcessRepository approvalProcessRepository;
	
	private ApiParams apiParams = new ApiParams();
	private ProposalDto proposalDto = new ProposalDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	private FordPersonDto personDto = new FordPersonDto();
	
	@Before
	public void setup() {
		
		apiParams = this.getApiParams();
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
	}
	
	public ApiParams getApiParams() {
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("MEX");
		return apiParams;
	}
	
	@Test
	public void testValidconstructApprovalChainNotExists() throws InterruptedException, ExecutionException {
		GenericResponse response = new GenericResponse();
		response.setMsgId("MSG-0006");
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.NEW);
		this.proposalDto.setProposalStatus(statusDto);
		Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(response);
		assertEquals(ResponseCodes.APPROVAL_CHAIN_NOT_EXISTS.getMsgId(), this.mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get().getGenericResponse().getMsgId());
	}
	
	@Test
	public void test_validateAndConstruct_failure() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		
		assertEquals("MSG-0064",mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get().getGenericResponse().getMsgId());
	}
	
	@Test
	public void test_validateAndConstruct_ApprovalChainError() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.CEO);
		setBussinessCase(false);
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(null);
		ApprovalChainVO approvalChainVO = mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get().getApprovalChainList().get(0);
		assertEquals("Not Applicable",approvalChainVO.getStatus());
	}
	
	@Test
	public void test_validateAndConstructSubmit_Success() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.CEO);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.CEO);
		rptlvl.setCode(11);
		dto.setReportLevel(rptlvl);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}
	
	@Test
	public void test_validateAndConstruct_Approve() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.APPROVED,ApprovalConstants.CEO);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.APPROVED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.CEO);
		rptlvl.setCode(11);
		dto.setReportLevel(rptlvl);
		dto.setSubmittedById(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		dto.setSubmittedToId(personDto);
		dto.setApprovedById(personDto);
		dto.setApprovedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setSubmittedToId(personDto);
		nextQueue.setSubmittedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}


	@Test
	public void test_validateAndConstruct_ApproveWithOutBussinesscase() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.APPROVED,ApprovalConstants.CEO);
		setBussinessCase(false);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.APPROVED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.CEO);
		rptlvl.setCode(11);
		dto.setReportLevel(rptlvl);
		dto.setSubmittedById(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		dto.setSubmittedToId(personDto);
		dto.setApprovedById(personDto);
		dto.setApprovedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setSubmittedToId(personDto);
		nextQueue.setSubmittedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}

	
	@Test
	public void test_validateAndConstructSubmit_SuccessNotCEO() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.FNM);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.FNM);
		rptlvl.setCode(10);
		dto.setReportLevel(rptlvl);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}
	
	@Test
	public void test_validateAndConstructSubmit_SuccessDFO() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.FNM);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.FNM);
		rptlvl.setCode(10);
		dto.setReportLevel(rptlvl);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.DFO);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}
	

	@Test
	public void test_validateAndConstructSubmit_SuccessCTL() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.CTL);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.CTL);
		rptlvl.setCode(10);
		dto.setReportLevel(rptlvl);
		this.personDto.setCdsid(ApprovalConstants.DEFAULT_CONTROLLER_MEX);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		List<FordPersonDto> fordpersList = new ArrayList<>();
		FordPersonDto person = new FordPersonDto();
		person.setCdsid("TestUser");
		person.setCountryCode(ApprovalConstants.MEX);
		person.setSprcdsidDescription("testSuper");
		fordpersList.add(person);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(fordPersonRepo.queryEligibleFordPersonAsController()).thenReturn(fordpersList);
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}

	
	@Test
	public void test_validateAndConstructSubmit_SuccessCEO() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.CTL);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.CEO);
		rptlvl.setCode(10);
		dto.setReportLevel(rptlvl);
		this.personDto.setReportLevel(rptlvl);
		this.personDto.setCdsid(ApprovalConstants.DEFAULT_CONTROLLER_MEX);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		List<FordPersonDto> fordpersList = new ArrayList<>();
		FordPersonDto person = new FordPersonDto();
		person.setCdsid("TestUser");
		person.setCountryCode(ApprovalConstants.MEX);
		person.setSprcdsidDescription("testSuper");
		fordpersList.add(person);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(fordPersonRepo.queryEligibleFordPersonAsController()).thenReturn(fordpersList);
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}

	
	@Test
	public void test_validateAndConstructSubmit_SuccessFSM() throws InterruptedException, ExecutionException {
		
		setDetails(ApprovalConstants.SUBMITTED,ApprovalConstants.CTL);
		setBussinessCase(true);
		List<ApprovalProcessDto> firstApprovalQueue = new ArrayList<>();
		ApprovalProcessDto dto = new ApprovalProcessDto();
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(statusDto);
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(ApprovalConstants.FSM);
		rptlvl.setCode(5);
		dto.setReportLevel(rptlvl);
		this.personDto.setReportLevel(rptlvl);
		this.personDto.setCdsid(ApprovalConstants.DEFAULT_CONTROLLER_MEX);
		dto.setSubmittedById(personDto);
		dto.setSubmittedToId(personDto);
		dto.setSubmittedTime(Calendar.getInstance().getTime());
		firstApprovalQueue.add(dto);
		ApprovalProcessDto nextQueue = new ApprovalProcessDto();
		ProposalStatusDto statusDto1 = new ProposalStatusDto();
		statusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		nextQueue.setProposalStatus(statusDto1);
		nextQueue.setReportLevel(rptlvl);
		nextQueue.setApprovedById(personDto);
		nextQueue.setApprovedTime(Calendar.getInstance().getTime());
		List<FordPersonDto> fordpersList = new ArrayList<>();
		FordPersonDto person = new FordPersonDto();
		person.setCdsid("TestUser");
		person.setCountryCode(ApprovalConstants.MEX);
		person.setSprcdsidDescription("testSuper");
		fordpersList.add(person);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.anyLong(),Mockito.anyString())).thenReturn(nextQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.anyLong(),Mockito.anyString(),Mockito.anyInt())).thenReturn(firstApprovalQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(fordPersonRepo.queryEligibleFordPersonAsController()).thenReturn(fordpersList);
		assertNotNull(mexApprovalChainValidator.validateAndConstruct(apiParams, null, null, null).get());
	}


	

	private void setDetails(String statusCode,String titleCode) {
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(statusCode);
		this.proposalDto.setProposalStatus(statusDto);
		this.personDto.setCdsid("TestUser");
		this.personDto.setSprcdsidDescription("TestSuperUser");
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setTitleCode(titleCode);
		rptlvl.setCode(11);
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setFordPerson(personDto);
	}

	private void setBussinessCase(boolean exists) {
		ProposalVehicleLineIncentiveDto dto = new ProposalVehicleLineIncentiveDto();
		List<ProposalVehicleLineIncentiveDto> incentiveDtos = new ArrayList<>();
		incentiveDtos.add(dto);
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		Mockito.when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(incentiveDtos));
		if(exists) {
		Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		}else {
			Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		}
	}
	


}
