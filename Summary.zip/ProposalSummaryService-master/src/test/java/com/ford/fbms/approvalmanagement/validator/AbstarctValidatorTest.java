/**
 * 
 */
package com.ford.fbms.approvalmanagement.validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.mockito.Mock;
import org.mockito.Mockito;

import com.ford.fbms.approvalmanagement.domain.ActualSalesFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.ActualSalesFinancialViewPk;
import com.ford.fbms.approvalmanagement.domain.AggregateIncentiveViewDto;
import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.AutoearlyBodystyle;
import com.ford.fbms.approvalmanagement.domain.BodyFinancialDto;
import com.ford.fbms.approvalmanagement.domain.BodyFinancialPKDto;
import com.ford.fbms.approvalmanagement.domain.BodyGroupAssignment;
import com.ford.fbms.approvalmanagement.domain.BodyGroupAssignmentPK;
import com.ford.fbms.approvalmanagement.domain.BodyStyleDto;
import com.ford.fbms.approvalmanagement.domain.ControllerThresholdDto;
import com.ford.fbms.approvalmanagement.domain.CountryDto;
import com.ford.fbms.approvalmanagement.domain.EspOptionDto;
import com.ford.fbms.approvalmanagement.domain.ExpandedBodyFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.ExpandedBodyFinancialViewPK;
import com.ford.fbms.approvalmanagement.domain.FVADataDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FinProfileDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.OptionIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PaymentTypeDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitExpandedViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitExpandedViewPK;
import com.ford.fbms.approvalmanagement.domain.PerUnitIncentiveNewViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitIncentiveNewViewPK;
import com.ford.fbms.approvalmanagement.domain.PerUnitNewViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitNewViewPK;
import com.ford.fbms.approvalmanagement.domain.PerUnitOptViewDto;
import com.ford.fbms.approvalmanagement.domain.PriceProtectionLevelYearOverYearDto;
import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalBodyFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryPK;
import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.PyVehicleDefinition;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.SegmentDto;
import com.ford.fbms.approvalmanagement.domain.TargetBandDto;
import com.ford.fbms.approvalmanagement.domain.TierIncentive;
import com.ford.fbms.approvalmanagement.domain.TierIncentivePK;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.domain.UscOptionDto;
import com.ford.fbms.approvalmanagement.domain.UscOptionPK;
import com.ford.fbms.approvalmanagement.domain.VehicleLineDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.ActualSalesFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.AutoearlyBodystyleRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyStyleViewRepository;
import com.ford.fbms.approvalmanagement.repository.FVADataRepository;
import com.ford.fbms.approvalmanagement.repository.FinMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearTermViewRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.OptionIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitExpandedViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PyCountryDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.PyVehicleDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.repository.VehicleLineRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO.rowType;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.validators.ActualsManager;
import com.ford.fbms.approvalmanagement.validators.ProposalManager;

/**
 * @author VSHANMU8
 *
 */
public class AbstarctValidatorTest {
	@Mock
	protected MasterRuleEngine ruleEngine;
	@Mock
	protected ResponseBuilder responseBuilder;
	@Mock
	protected FordPersonRepository fordPersonRepository;
	@Mock
	protected ProposalSummaryViewRepository proposalSummaryViewRepo;
	@Mock
	protected ProposalRepository proposalRepository;
	@Mock
	protected TierVolumeRepository tierVolumeRepository;
	@Mock
	protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
	@Mock
	protected ProposalSubsidiaryRepository proposalSubsidiaryRepository;
	@Mock
	protected FinMasterRepository finMasterRepository;
	@Mock
	protected TierVolumeRepository tierVolumeRepo;
	@Mock
	protected TierIncentiveRepository tierIncentiveRepo;
	@Mock
	protected ProposalVehicleLineIncentiveRepository propsalVlRepo;
	@Mock
	protected OptionIncentiveRepository optionIncentiveRepository;
	@Mock
	protected PyVehicleDefinitionRepository pyVehicleDfnRepo;
	@Mock
	protected AutoearlyBodystyleRepository autoEarlyRepo;
	@Mock
	protected ProposalManager proposalManager;
	@Mock
	protected FinProfileRepository finProfileRepo;
	@Mock
	protected ControllerThresholdRepository controllerThresholdRepo;
	@Mock
	protected ReportLevelRepository reportLevelRepo;
	@Mock
	protected ProposalSummaryViewRepository proposalSummaryViewRepository;
	@Mock
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineRepo;
	@Mock
	protected ApprovalProcessRepository approvalProcessRepository;
	@Mock
	protected ProposalBodyFinancialViewRepository proposalBodyFinancialViewRepo;
	@Mock
	protected AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Mock
	protected TargetBandRepository targetBandRepo;
	@Mock
	protected PerUnitOptViewRepository perUnitOptViewRepository;
	@Mock
	protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
	@Mock
	protected MultiYearTermViewRepository multiYearBonusRepository;
	@Mock
	protected FVADataRepository fvaDataRepo;
	@Mock
	protected NewBodyStyleRepository newBodyStyleRepo;
	@Mock
	protected PerUnitNewViewRepository perUnitNewViewRepo;
	@Mock
	protected BodyFinancialRepository bodyFinancialRepo;
	@Mock
	protected ExpandedBodyFinancialViewRepository expandedBodyFinancialViewRepo;
	@Mock
	protected PerUnitExpandedViewRepository perUnitExpandedViewRepo;
	@Mock
	protected ActualSalesFinancialViewRepository actualSalesFinancialViewRepo;
	@Mock
	protected PerUnitIncentiveNewViewRepository perUnitIncNewViewRepo;
	@Mock
	protected VehicleLineRepository vehLineRepo;
	@Mock
	protected ActualsManager actualManager;
	@Mock
	protected PyCountryDefinitionRepository pyCountryDefinitionRepository;
	@Mock
	protected ExpandedBodyStyleViewRepository expandedBodyStyleViewRepo;

	protected HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

	protected ApiParams apiParams = new ApiParams();
	protected FordPersonDto fordPersonDto = new FordPersonDto();
	protected ProposalDto proposalDto = new ProposalDto();
	protected FinMasterDto finMasterDto = new FinMasterDto();
	protected ProposalAssignAttributeDto proposalAssignAttributeDto = new ProposalAssignAttributeDto();
	protected List<ProposalAssignAttributeDto> proposalAssignAttributeDtos = new ArrayList<>();
	protected ProposalSummaryViewDto proposalSummaryViewDto = new ProposalSummaryViewDto();
	protected List<TierVolumeDto> tierVolumes = new ArrayList<>();
	protected List<ProposalVehicleLineIncentiveDto> pviDtos = new ArrayList<>();
	protected ProposalVehicleLineIncentiveDto pviDto = new ProposalVehicleLineIncentiveDto();
	protected ProposalSubsidiaryDto proposalSubsidiaryDto = new ProposalSubsidiaryDto();
	protected List<ProposalSubsidiaryDto> proposalSubsidiaryDtos = new ArrayList<>();
	protected List<TierIncentive> tierIncentives = new ArrayList<>();
	protected List<OptionIncentiveDto> optionIncentives = new ArrayList<>();
	protected OptionIncentiveDto optionIncentiveDto = new OptionIncentiveDto();
	protected PyVehicleDefinition pyVehicleDefinition = new PyVehicleDefinition();
	protected AutoearlyBodystyle autoearlyBodystyle = new AutoearlyBodystyle();
	protected FinancialDetailedVO financialDetailedVO = new FinancialDetailedVO();
	protected List<FinancialDetailedVO> financialDetailedVOs = new ArrayList<>();
	protected PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
	protected SegmentDto segmentDto = new SegmentDto();
	protected ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
	protected PriceProtectionLevelYearOverYearDto priceProtectionLevelYearOverYearDto;
	protected FinProfileDto FinProfileDto =  new FinProfileDto();
	protected ReportLevelDto reportLevelDto = new ReportLevelDto();
	protected ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
	protected ProposalBodyFinancialViewDto proposalBodyFinancialViewDto = new ProposalBodyFinancialViewDto();
	protected List<ProposalBodyFinancialViewDto> proposalBodyFinancialViewDtos = new ArrayList<>();
	protected PerUnitOptViewDto perUnitOptViewDto = new PerUnitOptViewDto();
	protected List<PerUnitOptViewDto> perUnitOptViewDtos = new ArrayList<>();
	protected PerUnitNewViewDto perUnitNewViewDto = new PerUnitNewViewDto();
	protected List<PerUnitNewViewDto> perUnitNewViewDtos = new ArrayList<>();
	protected AggregateIncentiveViewDto aggregateIncentiveViewDto = new AggregateIncentiveViewDto();
	protected FVADataDto fVADataDto = new  FVADataDto();
	protected List<FVADataDto> fVADataDtos = new ArrayList<>();
	protected TargetBandDto targetBandDto = new TargetBandDto();
	protected PerUnitExpandedViewDto perUnitExpandedViewDto = new PerUnitExpandedViewDto();
	protected List<PerUnitExpandedViewDto> perUnitExpandedViewDtos =  new ArrayList<>();
	protected ExpandedBodyFinancialViewDto expandedBodyFinancialViewDto = new ExpandedBodyFinancialViewDto();
	protected List<ExpandedBodyFinancialViewDto> expandedBodyFinancialViewDtos = new ArrayList<>();
	protected ActualSalesFinancialViewDto actualSalesFinancialViewDto = new ActualSalesFinancialViewDto();
	protected List<ActualSalesFinancialViewDto> actualSalesFinancialViewDtos = new ArrayList<>();
	protected List<PerUnitIncentiveNewViewDto> perUnitIncentiveNewViewDtos =  new ArrayList<>();
	protected PerUnitIncentiveNewViewDto perUnitIncentiveNewViewDto = new PerUnitIncentiveNewViewDto();
	protected ProposalFinancialVO proposalFinancialVO;
	protected List<ProposalFinancialVO> proposalFinancialVOs = new ArrayList<>();
	protected List<VehicleLineDto> vehicleLineDtos =  new ArrayList<>();
	protected VehicleLineDto vehicleLineDto = new VehicleLineDto();
	
	protected void loadVehicleLineDto() {
		vehicleLineDtos.add(vehicleLineDto);
	}
	
	protected void loadProposalFinancialVO() {
		proposalFinancialVO = new ProposalFinancialVO(0l);
		proposalFinancialVO.setVehicleLineDescription("DESC");
		proposalFinancialVO.setVolume(2l);
		proposalFinancialVO.setPriorYearVolume(2l);
		proposalFinancialVO.setPriorVerVolume(2l);
		proposalFinancialVO.setPerUnit(1l);
		proposalFinancialVO.setPriorVerPerUnit(1l);
		proposalFinancialVO.setPriorYearPerUnit(1l);
		
		proposalFinancialVO.setActCC(0);
		proposalFinancialVO.setActNR(0);
		proposalFinancialVO.setActRevenue(0);
		proposalFinancialVO.setAGG(0);
		proposalFinancialVO.setBodyGroup(false);
		proposalFinancialVO.setCPA(0);
		proposalFinancialVO.setEstCC(0);
		proposalFinancialVO.setEndDate("");
		proposalFinancialVO.setESP(0);
		proposalFinancialVO.setEstRevenue(0);
		proposalFinancialVO.setmLBIncentive(0l);
		proposalFinancialVO.setNegativeVOIncentiveFlag(false);
		proposalFinancialVO.setYoyTargetVM(0);
		proposalFinancialVO.setPerUnitDescription("");
		proposalFinancialVO.setPresentTier1("");
		proposalFinancialVO.setPresentTier2("");
		proposalFinancialVO.setPresentTier3("");
		proposalFinancialVO.setPresentTier4("");
		proposalFinancialVO.setPresentTier5("");
		proposalFinancialVO.setPresentTier6("");
		proposalFinancialVO.setPresentVehicleLine(false);
		proposalFinancialVO.setPriorVerActCC(0);
		proposalFinancialVO.setPriorVerActRevenue(0);
		proposalFinancialVO.setPriorVerAGG(0);
		proposalFinancialVO.setPriorVerCPA(0);
		proposalFinancialVO.setVehLineCode("");
		proposalFinancialVO.setVL(0);
		proposalFinancialVO.setVM(0);
		proposalFinancialVO.setTotalTier(0);
		proposalFinancialVOs.add(proposalFinancialVO);
	}
	
	protected void loadPerUnitIncentiveNewViewDto(long bodyStyleKey) {
		PerUnitIncentiveNewViewPK perUnitIncentiveNewViewPK = new PerUnitIncentiveNewViewPK();
		perUnitIncentiveNewViewPK.setBodyStyleKey2(bodyStyleKey);
		perUnitIncentiveNewViewDto.setId(perUnitIncentiveNewViewPK);
		perUnitIncentiveNewViewDto.setBodyStyleCode_2("Code");
		perUnitIncentiveNewViewDtos.add(perUnitIncentiveNewViewDto);
	}
	
	protected void loadActualSalesFinancialViewDto() {
		ActualSalesFinancialViewPk actualSalesFinancialViewPk  = new  ActualSalesFinancialViewPk();
		actualSalesFinancialViewPk.setBodyStyle(0l);
		actualSalesFinancialViewDto.setId(actualSalesFinancialViewPk);
		actualSalesFinancialViewDto.setContributionCost(1l);
		actualSalesFinancialViewDto.setRevenue(1l);
		actualSalesFinancialViewDto.setSoldToDate(2);
		
		actualSalesFinancialViewDtos.add(actualSalesFinancialViewDto);
	}
	
	protected void loadActualSalesFinancialViewDto1() {
		ActualSalesFinancialViewPk actualSalesFinancialViewPk  = new  ActualSalesFinancialViewPk();
		actualSalesFinancialViewPk.setBodyStyle(1l);
		actualSalesFinancialViewDto.setId(actualSalesFinancialViewPk);
		actualSalesFinancialViewDto.setContributionCost(1l);
		actualSalesFinancialViewDto.setRevenue(1l);
		actualSalesFinancialViewDto.setSoldToDate(2);
		
		ActualSalesFinancialViewPk actualSalesFinancialViewPk1  = new  ActualSalesFinancialViewPk();
		ActualSalesFinancialViewDto actualSalesFinancialViewDto1 = new ActualSalesFinancialViewDto();
		actualSalesFinancialViewPk1.setBodyStyle(0l);
		actualSalesFinancialViewDto1.setId(actualSalesFinancialViewPk1);
		actualSalesFinancialViewDto1.setContributionCost(1l);
		actualSalesFinancialViewDto1.setRevenue(1l);
		actualSalesFinancialViewDto1.setSoldToDate(2);
		actualSalesFinancialViewDtos.add(actualSalesFinancialViewDto);
		actualSalesFinancialViewDtos.add(actualSalesFinancialViewDto1);
	}
	
	protected void loadExpandedBodyFinancialViewDto(long bodyStyleKey) {
		ExpandedBodyFinancialViewPK expandedBodyFinancialViewPK = new ExpandedBodyFinancialViewPK();
		expandedBodyFinancialViewPK.setExpandedBodyStyle(bodyStyleKey);
		expandedBodyFinancialViewDto.setId(expandedBodyFinancialViewPK);
		expandedBodyFinancialViewDtos.add(expandedBodyFinancialViewDto);
	}
	
	protected void loadPerUnitExpandedViewDto(long bodyStyleKey) {
		
		PerUnitExpandedViewPK perUnitExpandedViewPK = new PerUnitExpandedViewPK();
		perUnitExpandedViewPK.setBodyStyleSaKey(0l);
		perUnitExpandedViewDto.setId(perUnitExpandedViewPK);
		perUnitExpandedViewDto.setVehicleLineDesc("Desc");
		
		perUnitExpandedViewDtos.add(perUnitExpandedViewDto);
	}
	protected void loadPerUnitExpandedViewDto1(long bodyStyleKey) {
		
		PerUnitExpandedViewPK perUnitExpandedViewPK = new PerUnitExpandedViewPK();
		perUnitExpandedViewPK.setBodyStyleSaKey(3l);
		perUnitExpandedViewDto.setId(perUnitExpandedViewPK);
		perUnitExpandedViewDto.setVehicleLineDesc("Desc");
		perUnitExpandedViewDto.setMlv(10);
		perUnitExpandedViewPK.setExpandedBodyStyleSaKey(3l);
		PerUnitExpandedViewDto perUnitExpandedViewDto1 = new PerUnitExpandedViewDto();
		PerUnitExpandedViewPK perUnitExpandedViewPK1 = new PerUnitExpandedViewPK();
		perUnitExpandedViewPK1.setBodyStyleSaKey(1l);
		perUnitExpandedViewDto1.setId(perUnitExpandedViewPK1);
		perUnitExpandedViewDto1.setVehicleLineDesc("Desc1");
		perUnitExpandedViewDto.setMlv(11);
		perUnitExpandedViewPK.setExpandedBodyStyleSaKey(1l);
		perUnitExpandedViewDtos.add(perUnitExpandedViewDto);
		perUnitExpandedViewDtos.add(perUnitExpandedViewDto1);
	}
	
	protected void loadFVADataDto() {
		fVADataDto.setAverageContributionCost(2l);
		fVADataDtos.add(fVADataDto);
	}
	
	protected void loadAggregateIncentiveViewDto() {
		aggregateIncentiveViewDto.setIncentive(1l);
	}
	
	protected void loadPerUnitNewViewDto() {
		PerUnitNewViewPK perUnitNewViewPK = new PerUnitNewViewPK();
		perUnitNewViewPK.setBodyStyleKey(1l);
		perUnitNewViewDto.setId(perUnitNewViewPK);
		perUnitNewViewDto.setVehicleLineDesc("Desc");
		perUnitNewViewDtos.add(perUnitNewViewDto);
	}
	
	protected void loadPerUnitNewViewDto(long bodyStyleKey) {
		PerUnitNewViewPK perUnitNewViewPK = new PerUnitNewViewPK();
		perUnitNewViewPK.setBodyStyleKey(1l);
		perUnitNewViewDto.setId(perUnitNewViewPK);
		perUnitNewViewDto.setVehicleLineDesc("Desc");
		perUnitNewViewDto.setNewBodyStyleKey(bodyStyleKey);
		perUnitNewViewDtos.add(perUnitNewViewDto);
	}
	
	protected void loadPerUnitOptViewDto(long bodyStyleKey) {
		perUnitOptViewDto.setBodyStyleKey(bodyStyleKey);
		perUnitOptViewDto.setModelYear(2021);
		perUnitOptViewDto.setVehicleLineDesc("Desc");
		perUnitOptViewDtos.add(perUnitOptViewDto);
	}
	
	
	protected void loadProposalBodyFinancialViewDto() {
		proposalBodyFinancialViewDto.setBodyStyle(2l);
		proposalBodyFinancialViewDto.setContributionCost(2l);
		proposalBodyFinancialViewDto.setRevenue(2l);
		proposalBodyFinancialViewDtos.add(proposalBodyFinancialViewDto);
		BodyFinancialDto body = new BodyFinancialDto();
		BodyFinancialPKDto bodyFinancialPKDto = new BodyFinancialPKDto();
		body.setId(bodyFinancialPKDto);
		body.setBaseIncentiveR(null);
		body.setBodyStylThrshldP(null);
		body.setContributionCostR(null);
		body.setCreatedProcess(null);
		body.setCreatedTimeStamp(null);
		body.setCreatedUser(null);
		body.setEmailTrgrF(null);
		body.setEstCurtYrContbCstA(null);
		body.setEstCurtYrContbCstA(null);
		body.setEstCurtYrRevnChngA(null);
		body.setLastUpdatedProcess(null);
		body.setLastUpdatedTimeStamp(null);
		body.setLastUpdatedUser(null);
		body.setMyOverMyTargetR(null);
		body.setRevenueR(null);
		body.setTier1TargetR(null);
		body.setTier2TargetR(null);
		body.setTier3TargetR(null);
		body.setTier4TargetR(null);
		body.setTier5TargetR(null);
		body.getId();
		body.getBaseIncentiveR();
		body.getBodyStylThrshldP();
		body.getContributionCostR();
		body.getCreatedProcess();
		body.getCreatedTimeStamp();
		body.getCreatedUser();
		body.getEmailTrgrF();
		body.getEstCurtYrContbCstA();
		body.getEstCurtYrContbCstA();
		body.getEstCurtYrRevnChngA();
		body.getLastUpdatedProcess();
		body.getLastUpdatedTimeStamp();
		body.getLastUpdatedUser();
		body.getMyOverMyTargetR();
		body.getRevenueR();
		body.getTier1TargetR();
		body.getTier2TargetR();
		body.getTier3TargetR();
		body.getTier4TargetR();
		body.getTier5TargetR();
	}
	
	protected void loadPriceProtectionLevelYearOverYearDtoData(String code, String desc) {
		priceProtectionLevelYearOverYearDto = PriceProtectionLevelYearOverYearDto.builder().priceProLevYrOverYearCode(code).priceProLevYrOverYearDesc(desc).build();
		proposalDto.setPplYoy(priceProtectionLevelYearOverYearDto);
	}

	protected void loadFinancialDetailedVO(boolean presentProFlag, rowType type, long presentKey, long periorPYVM) {
		financialDetailedVO.setPresentProposal(presentProFlag);
		financialDetailedVO.setRecType(type);
		financialDetailedVO.setPresentKey(presentKey);
		financialDetailedVO.setPriorPYVM(periorPYVM);
		financialDetailedVOs.add(financialDetailedVO);
	}
	
	protected void loadVM() {
		financialDetailedVO.setPresentVM(3);
		financialDetailedVO.setYoyTarget(1);
		financialDetailedVO.setMatrixTargetVM(1);
	}

	protected void loadOptionIncentiveDto(String statusFlag) {
		if (statusFlag != null) {
			EspOptionDto espOptionDto = new EspOptionDto();
			espOptionDto.setEspStatusFlag(statusFlag);
			espOptionDto.setBodyStyle(null);
			espOptionDto.setCreatedProcess("");
			espOptionDto.setCreatedTimeStamp(null);
			espOptionDto.setCreatedUser("");
			espOptionDto.setEspContractType(null);
			espOptionDto.setEspCostA(null);
			espOptionDto.setEspDeductibleA(null);
			espOptionDto.setEspDurationR(null);
			espOptionDto.setEspInactiveTS(null);
			espOptionDto.setEspMilesR(null);
			espOptionDto.setEspOptionSaKey(0);
			espOptionDto.setEspStatusFlag("");
			espOptionDto.setLastUpdatedProcess("");
			espOptionDto.setLastUpdatedTimeStamp(null);
			espOptionDto.setLastUpdatedUser("");
			optionIncentiveDto.setEspOption(espOptionDto);
			UscOptionDto uscOptionDto = new UscOptionDto();
			uscOptionDto.setCreatedProcess("");
			uscOptionDto.setCreatedTimeStamp(null);
			uscOptionDto.setCreatedUser("");
			uscOptionDto.setDartsVersionR(null);
			uscOptionDto.setDealerFlag(statusFlag);
			uscOptionDto.setDisplayFlag(statusFlag);
			uscOptionDto.setKeystrokeCode("");
			uscOptionDto.setKeystrokesMaximumT(null);
			uscOptionDto.setKeystrokesMinimumT(null);
			uscOptionDto.setLastUpdatedProcess("");
			uscOptionDto.setLastUpdatedTimeStamp(null);
			uscOptionDto.setLastUpdatedUser("");
			uscOptionDto.setOptionTypeCode("");
			uscOptionDto.setUscStatus(null);
			uscOptionDto.setUscN("");
			uscOptionDto.setUscDesc("");
			uscOptionDto.setTableTypeDesc("");
			uscOptionDto.setTableTypeDesc("");
			uscOptionDto.setTableTypeCode("");
			uscOptionDto.setTableNextCode("");
			uscOptionDto.setTableCode("");
			uscOptionDto.setSalesFlag(statusFlag);
			
			UscOptionPK uscOptionPK = new  UscOptionPK();
			uscOptionPK.setModelCode("");
			uscOptionPK.setUscCode("");
			uscOptionPK.setPdMarket(null);
			uscOptionDto.setUscOptionPK(uscOptionPK);
			optionIncentiveDto.setUscOption(uscOptionDto);
		}
		optionIncentives.add(optionIncentiveDto);
	}

	protected void loadTierIncentive(long tierValue, long tierTwoValue, int tierAmount, int tierTwoAmount) {
		TierIncentive tIOne = new TierIncentive();
		tIOne.setTierIncentivePK(getTierIncePK(tierValue));
		tIOne.setTierInctvAmount(new BigDecimal(tierAmount));
		tierIncentives.add(tIOne);
		TierIncentive tITwo = new TierIncentive();
		tITwo.setTierIncentivePK(getTierIncePK(tierTwoValue));
		tITwo.setTierInctvAmount(new BigDecimal(tierTwoAmount));
		tierIncentives.add(tITwo);
	}

	private TierIncentivePK getTierIncePK(long tierValue) {
		TierIncentivePK pk = new TierIncentivePK();
		pk.setTierLevel(tierValue);
		return pk;
	}

	protected void loadProposalVehicleLineIncentiveDto(long pviKey) {
		BodyStyleDto bodyStyleDto = new BodyStyleDto();
		bodyStyleDto.setBodyStyleSaKey(1l);;
		pviDto.setPviSaKey(pviKey);
		pviDto.setTier1InctvToDlrFlag("N");
		pviDto.setBodyStyle(bodyStyleDto);;
		pviDtos.add(pviDto);
	}

	protected void loadProposalVehicleLineIncentiveDto(long pviKey, String bodyGroupFlag, boolean groupAssignmentListFlag) {
		BodyStyleDto bodyStyleDto = new BodyStyleDto();
		VehicleLineDto vehicleLineDto = new VehicleLineDto();
		vehicleLineDto.setVehlnSaKey(1l);
		vehicleLineDto.setModelYear(2021l);
		vehicleLineDto.setVehlnDesc("Desc");
		bodyStyleDto.setVehicleLine(vehicleLineDto);
		bodyStyleDto.setBodyGroupIndFlag(bodyGroupFlag);
		if (groupAssignmentListFlag) {
			BodyGroupAssignmentPK pk = new BodyGroupAssignmentPK();
			pk.setMfbme03BodyStyle(bodyStyleDto);
			BodyGroupAssignment bodyGroupAssignment = new BodyGroupAssignment();
			bodyGroupAssignment.setId(pk);
			bodyStyleDto.setBodyGroupAssignemnts(Arrays.asList(bodyGroupAssignment));
		}
		pviDto.setBodyStyle(bodyStyleDto);
		pviDto.setPviSaKey(pviKey);
		pviDtos.add(pviDto);
	}

	protected void loadProposalSummaryViewDto(String paymentRouting) {
		proposalSummaryViewDto.setPaymentRouting(paymentRouting);
	}

	protected void loadTierVolume(long tiervalue1, long tierValue2) {
		TierVolumeDto t1 = new TierVolumeDto();
		t1.setTierVolume(tiervalue1);
		tierVolumes.add(t1);
		TierVolumeDto t2 = new TierVolumeDto();
		t2.setTierVolume(tierValue2);
		tierVolumes.add(t2);
	}

	protected void loadProposalSubsidiaryDto() {
		finMasterDto.setFinMasterKey(1L);
		ProposalSubsidiaryPK proposalSubsidiaryPK = new ProposalSubsidiaryPK();
		proposalSubsidiaryPK.setSubFinMaster(finMasterDto);
		proposalSubsidiaryDto.setProposalSubsidiaryPK(proposalSubsidiaryPK);
		proposalSubsidiaryDtos.add(proposalSubsidiaryDto);
		proposalDto.setProposalSubsidiaryList(proposalSubsidiaryDtos);
	}

	protected void loadProposalDto() {
		fordPersonDto.setCdsid("FBMSTID1");
		proposalDto.setFordPerson(fordPersonDto);
		pyDefinitionDto.setProposalYearCode(2021);
		proposalDto.setPyDefinition(pyDefinitionDto);
		proposalDto.setCntlReqdFlag(true);
		finMasterDto.setFinMasterKey(1L);
		segmentDto.setSegmentCode("SegmentCode");
		finMasterDto.setSegment(segmentDto);
		proposalDto.setProposalSaKey(1l);
		proposalDto.setFinMasterKey(finMasterDto);
		proposalDto.setProposalMlv(new BigDecimal(25));
		proposalDto.setLetterMinQty(BigDecimal.ONE);
		proposalDto.setCntlReqdFlag(true);
		proposalDto.setLongTermDemoR(new BigDecimal(2));
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryIso3Code("GBR");
		finMasterDto.setCountry(countryDto);
	}
	
	public void loadProposalStatus(String status) {
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(status);
		proposalDto.setProposalStatus(statusDto);
	}
	
	protected void loadSourceProposal(long sourceProposalKey, String sourceProposalCode) {
		proposalDto.setSourceProposalCode(sourceProposalKey);
		if(sourceProposalCode != null) {
			ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
			proposalStatusDto.setProposalStatusCode(sourceProposalCode);
			proposalDto.setSourceProposalStatusCode(proposalStatusDto);
		}
	}
	
	protected void loadPaymentType() {
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		proposalDto.setPaymentType(paymentTypeDto);
	}

	protected void loadNonFinancialFlag(boolean flag) {
		proposalDto.setNonFinancialFlag(flag);
	}

	protected void loadSegment(String segmentCode) {
		segmentDto.setSegmentCode(segmentCode);
	}

	protected void loadProposalAssignAttributeDto(String flag) {
		proposalAssignAttributeDto.setSellingDlrAsgnFlag(flag);
		proposalAssignAttributeDtos.add(proposalAssignAttributeDto);
	}

	protected ApiParams getApiParams() {
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(1l);
		return apiParams;
	}

	protected void loadFordPersion(String cdsid) {
		fordPersonDto.setCdsid(cdsid);
		fordPersonDto.setSprcdsidDescription(cdsid);
	}
	protected void loadFordPersion(String cdsid, String flag) {
		fordPersonDto.setCdsid(cdsid);
		fordPersonDto.setSprcdsidDescription(cdsid);
		fordPersonDto.setUnassignedFinsFlag(flag);
	}

	protected void loadReportLevel(int code) {
		reportLevelDto.setSaKey(1l);
		reportLevelDto.setCode(code);
		reportLevelDto.setTitleCode("");
		proposalDto.setReportLevel(reportLevelDto);
		fordPersonDto.setReportLevel(reportLevelDto);
	}
	
}
