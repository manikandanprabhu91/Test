/**
 * 
 */
package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ApprovalProcessMexValidator;

/**
 * @author vvm
 *
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalProcessMexValidatorTest {
	
	@InjectMocks
	private ApprovalProcessMexValidator appProcessValidator;
	@Mock
	private ProposalRepository proposalRepository;
	@Mock
	private ApprovalProcessRepository approvalProcessRepository;
	@Mock
	private FordPersonRepository fordPersonRepo;
	@Mock
	private ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;
	@Mock
	private PviExtraInfoRepository pviExtraInfoRepository;
	@Mock
	private ReportLevelRepository reportLevelRepo;
	@Mock
	private ResponseBuilder responseBuilder;
	
	private ApiParams apiParams = new ApiParams();
	private ProposalDto proposalDto = new ProposalDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	private FordPersonDto personDto = new FordPersonDto();
	
	@Before
	public void setup() {
		
		apiParams = this.getApiParams();
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
	}
	
	public ApiParams getApiParams() {
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("MEX");
		return apiParams;
	}

	@Test
	public void test_validateAndConstructSuccess() {
		
		ApprovalProcessDto presentQueue = new ApprovalProcessDto();
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		ProposalStatusDto status = new ProposalStatusDto();
		status.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(status);
		this.proposalDto.setCntlReqdFlag(true);
		ReportLevelDto rptLvl = new ReportLevelDto();
		rptLvl.setTitleCode(ApprovalConstants.FNA);
		rptLvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE_MEX);
		this.personDto.setReportLevel(rptLvl);
		this.personDto.setSprcdsidDescription("TestSuperCDSID");
		this.proposalDto.setReportLevel(rptLvl);
		presentQueue.setReportLevel(rptLvl);
		pviExtraInfoDto.setFleetIncentive(5L);
		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto rptLvl1 = new ReportLevelDto();
		rptLvl1.setTitleCode(ApprovalConstants.RSM);
		reportLevelList.add(rptLvl1);
		
		ProposalVehicleLineIncentiveDto lineIncentiveDto = new ProposalVehicleLineIncentiveDto();
		lineIncentiveDto.setMlv(2L);
		List<ProposalVehicleLineIncentiveDto> vehInctList = new ArrayList<>();
		vehInctList.add(lineIncentiveDto);
		Mockito.when(approvalProcessRepository.findLatestApprovalProcessByProposalStatus(Mockito.anyLong(),Mockito.anyString())).thenReturn(presentQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(vehInctList);
		Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(),Mockito.anyLong())).thenReturn(rptLvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
		this.proposalDto.setCntlReqdFlag(false);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
	}
	
	@Test
	public void test_validateAndConstructSuccess_Controller() {
		
		ApprovalProcessDto presentQueue = new ApprovalProcessDto();
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		ProposalStatusDto status = new ProposalStatusDto();
		status.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(status);
		this.proposalDto.setCntlReqdFlag(true);
		ReportLevelDto rptLvl = new ReportLevelDto();
		rptLvl.setTitleCode(ApprovalConstants.FNM);
		rptLvl.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		ReportLevelDto rptLvl2 = new ReportLevelDto();
		rptLvl2.setTitleCode(ApprovalConstants.GVP);
		rptLvl2.setCode(ApprovalConstants.FNA_RL_CODE);
		this.personDto.setReportLevel(rptLvl);
		this.personDto.setSprcdsidDescription("TestSuperCDSID");
		this.proposalDto.setReportLevel(rptLvl2);
		this.proposalDto.setFordPerson(personDto);
		presentQueue.setReportLevel(rptLvl);
		presentQueue.setSubmittedById(personDto);
		presentQueue.setSubmittedToId(personDto);
		pviExtraInfoDto.setFleetIncentive(5L);
		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto rptLvl1 = new ReportLevelDto();
		rptLvl1.setTitleCode(ApprovalConstants.FNA);
		reportLevelList.add(rptLvl1);
		
		ProposalVehicleLineIncentiveDto lineIncentiveDto = new ProposalVehicleLineIncentiveDto();
		lineIncentiveDto.setMlv(2L);
		List<ProposalVehicleLineIncentiveDto> vehInctList = new ArrayList<>();
		vehInctList.add(lineIncentiveDto);
		Mockito.when(approvalProcessRepository.findLatestApprovalProcessByProposalStatus(Mockito.anyLong(),Mockito.anyString())).thenReturn(presentQueue);
		Mockito.when(approvalProcessRepository.findApprovalProcessByProposalReportLevel(Mockito.anyLong(),Mockito.anyInt())).thenReturn(presentQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(vehInctList);
		Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(),Mockito.anyLong())).thenReturn(rptLvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		rptLvl.setTitleCode(ApprovalConstants.DFO);
		rptLvl.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		this.proposalDto.setReportLevel(rptLvl1);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
	}
	
	
	@Test
	public void test_validateAndConstruct_failure() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		
		assertEquals("MSG-0064",appProcessValidator.validateAndConstruct(apiParams, null, null, null).get().getGenericResponse().getMsgId());
	}
	
	
	@Test
	public void test_validateAndConstructRevised() {
		
		ApprovalProcessDto presentQueue = new ApprovalProcessDto();
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		ProposalStatusDto status = new ProposalStatusDto();
		status.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(status);
		this.proposalDto.setCntlReqdFlag(true);
		ReportLevelDto rptLvl = new ReportLevelDto();
		rptLvl.setTitleCode(ApprovalConstants.FNA);
		rptLvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE_MEX);
		this.personDto.setReportLevel(rptLvl);
		this.personDto.setSprcdsidDescription("TestSuperCDSID");
		this.proposalDto.setReportLevel(rptLvl);
		presentQueue.setReportLevel(rptLvl);
		pviExtraInfoDto.setFleetIncentive(5L);
		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto rptLvl1 = new ReportLevelDto();
		rptLvl1.setTitleCode(ApprovalConstants.DFO);
		reportLevelList.add(rptLvl1);
		
		ProposalVehicleLineIncentiveDto lineIncentiveDto = new ProposalVehicleLineIncentiveDto();
		lineIncentiveDto.setMlv(2L);
		List<ProposalVehicleLineIncentiveDto> vehInctList = new ArrayList<>();
		vehInctList.add(lineIncentiveDto);
		Mockito.when(approvalProcessRepository.findLatestApprovalProcessByProposalStatus(Mockito.anyLong(),Mockito.anyString())).thenReturn(presentQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(vehInctList);
		Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(),Mockito.anyLong())).thenReturn(rptLvl1);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
		rptLvl1.setTitleCode(ApprovalConstants.CEO);
		reportLevelList.add(rptLvl1);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(),Mockito.anyLong())).thenReturn(rptLvl1);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
	}
	
	
	@Test
	public void test_validateAndConstructRevisedNoMaxReportLvel() {
		
		ApprovalProcessDto presentQueue = new ApprovalProcessDto();
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		ProposalStatusDto status = new ProposalStatusDto();
		status.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(status);
		this.proposalDto.setCntlReqdFlag(true);
		ReportLevelDto rptLvl = new ReportLevelDto();
		rptLvl.setTitleCode(ApprovalConstants.FNA);
		rptLvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE_MEX);
		this.personDto.setReportLevel(rptLvl);
		this.personDto.setSprcdsidDescription("TestSuperCDSID");
		this.proposalDto.setReportLevel(rptLvl);
		presentQueue.setReportLevel(rptLvl);
		pviExtraInfoDto.setFleetIncentive(5L);
		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto rptLvl1 = new ReportLevelDto();
		rptLvl1.setTitleCode(ApprovalConstants.DFO);
		reportLevelList.add(rptLvl1);
		
		ProposalVehicleLineIncentiveDto lineIncentiveDto = new ProposalVehicleLineIncentiveDto();
		lineIncentiveDto.setMlv(2L);
		List<ProposalVehicleLineIncentiveDto> vehInctList = new ArrayList<>();
		vehInctList.add(lineIncentiveDto);
		Mockito.when(approvalProcessRepository.findLatestApprovalProcessByProposalStatus(Mockito.anyLong(),Mockito.anyString())).thenReturn(presentQueue);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Mockito.when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(vehInctList);
		Mockito.when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(),Mockito.anyLong())).thenReturn(null);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		assertNotNull(appProcessValidator.validateAndConstruct(apiParams, null, null, null));
		
		
	}

	
}

