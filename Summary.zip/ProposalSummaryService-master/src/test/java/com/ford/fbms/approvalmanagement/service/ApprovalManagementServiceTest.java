package com.ford.fbms.approvalmanagement.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ApprovalRequest;
import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalViewDto;
import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;
import com.ford.fbms.approvalmanagement.domain.TargetBandDto;
import com.ford.fbms.approvalmanagement.domain.VehicleLineOptionDiscountVo;
import com.ford.fbms.approvalmanagement.ruleengines.MxRuleEngine;
import com.ford.fbms.approvalmanagement.ruleengines.NaRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalCommentsVo;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.transport.ProposalVo;
import com.ford.fbms.approvalmanagement.transport.SubsidiariesVo;
import com.ford.fbms.approvalmanagement.transport.ValidateActionsVO;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

/**
 * Test class for ApprovalManagementService class.
 *
 * @author NACHUTHA on 3/08/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalManagementServiceTest {

    @Spy
    @InjectMocks
    private ApprovalManagementService approvalManagementService;

    @Mock
    private NaRuleEngine naRuleEngine;

    @Mock
    private ResponseBuilder responseBuilder;

    @Mock
    private ApprovalRequest approvalRequest;
    @Mock
    private MxRuleEngine mexRuleEngine;
    

    /**
     * This test is for buildApiParams.
     */
    @Test
    public void test_buildApiParams() {
        //Given
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);

        //When
        ApiParams apiParamsresult = approvalManagementService.buildApiParams(apiParams.getUserId(),
            apiParams.getCountryCd(),
            apiParams.getProposalKey());

        //Then
        Assert.assertNotNull(apiParamsresult);
    }
    
  /*  @Test
    public void test_retrieve_approvalChain() {
      List<GenericResponseWrapper> genericResponseWrapperList =
          constructGenericResponseWrapperList();
      
      genericResponseWrapperList.get(0).setGenericResponse(null);
      Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString()))
          .thenReturn(true);
      Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any()))
          .thenReturn(genericResponseWrapperList);
      ApiParams apiParams = new ApiParams();
      apiParams.setUserId("Testuser");
      apiParams.setCountryCd("USA");
      GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
      genericResponseWrapper.setApprovalChainList(genericResponseWrapperList.get(0)
          .getApprovalChainList());
     Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, null,
    	        RequestMode.APPROVAL_CHAIN,null).getHttpStatus());
    }*/


    /**
     * This test is for doing the positive flow for get approvalmanagement and direction from table.
     */
    @Test
    public void should_do_get_approval_success_flow() {
        //Given
//        ApiParams apiParams = new ApiParams();
//        apiParams.setUserId("Fbmstid1");
//        apiParams.setCountryCd("USA");
//        apiParams.setProposalKey(12L);
//
//        GenericResponse expectedGenericResponse = new ApprovalProcessDto();
//        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
//
//        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
//        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
//
//
//        Mockito.doReturn(genericResponseWrapper).when(naRuleEngine)
//                .validate(apiParams, approvalRequest ,RequestMode.GET_APPROVAL, null);
     /*   Mockito.doReturn(expectedGenericResponse).when(naRuleEngine)
                .getApproval(apiParams, genericResponseWrapper);*/


        //When
        /*GenericResponse genericResponse = approvalManagementService.getApproval(apiParams, httpServletRequest
                , RequestMode.GET_APPROVAL);*/

        //Then
        /*Assert.assertNotNull(genericResponse);
        Assert.assertEquals(HttpStatus.OK, genericResponse.getHttpStatus());*/
    }

    /**
     * This test is for doing the negative flow for get approvalmanagement & direction from table.
     */
    @Test
    public void should_do_get_approval_failure_flow() {
        //Given
        ApiParams apiParams = new ApiParams();
        apiParams.setCountryCd("IND");

        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED);

        //When
        Mockito.when(responseBuilder.generateResponse(Mockito.any())).
                thenReturn(expectedGenericResponse);

      /*  Mockito.doReturn(expectedGenericResponse).when(naRuleEngine)
                .getApproval(apiParams, null);*/

        /*GenericResponse genericResponse = approvalManagementService.getApproval(apiParams, null,
            RequestMode.GET_APPROVAL);*/

        //Then
       // Assert.assertNotNull(genericResponse);
        Assert.assertEquals(HttpStatus.EXPECTATION_FAILED, expectedGenericResponse.getHttpStatus());
    }
    
    
  /*  private List<GenericResponseWrapper> constructGenericResponseWrapperList() {
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        GenericResponse genericResponse = new GenericResponse();
        Date currentDate = new Date();
        genericResponse.setHttpStatus(HttpStatus.OK);
        ProposalViewDto proposalViewDto = new ProposalViewDto();
        ProposalViewDto gproposalViewDto = new ProposalViewDto();
        ProposalNotesDto proposalNotesDto = new ProposalNotesDto();
        proposalNotesDto.setProposalComments("Hello test comment");
        proposalNotesDto.setCommentedBy("FBMSTID1");
        proposalNotesDto.setProposalComments("new save text");
        proposalNotesDto.setProposal(1234L);
        proposalViewDto.setProposalYear("2000");
        proposalViewDto.setProposalVersion("4");
        proposalViewDto.setProposalComments("Hello test comment");
        proposalViewDto.setDateSubmitted(currentDate);
        proposalViewDto.setCommentedBy("FBMSTID1");
        proposalNotesDto.setProposalComments("new save text");
        proposalNotesDto.setProposal(1234L);
        gproposalViewDto.setProposalVersion("4");
        gproposalViewDto.setProposalComments("Hello test comment");
        gproposalViewDto.setDateSubmitted(currentDate);
        gproposalViewDto.setCommentedBy("FBMSTID1");
        genericResponseWrapper.setGenericResponse(genericResponse);
        genericResponseWrapper.setProposalNotesRetrival(Collections
            .singletonList(proposalViewDto));
        genericResponseWrapper.setProposalNotes(Collections
            .singletonList(proposalNotesDto));
        genericResponseWrapper.setProposalUpdate(proposalNotesDto);
        return Collections.singletonList(genericResponseWrapper);
        }*/
    @Test
    public void should_do_get_Volume_Options_success() {
    	GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setHttpStatus(HttpStatus.OK);
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS,httpServletRequest)).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.getVolumeFinancials(Mockito.any())).thenReturn(genericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_Volume_Options_failure() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.NO_CONTENT);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.getVolumeFinancials(Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.NO_CONTENT, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS,httpServletResponse).getHttpStatus());
    }
    
   
    @Test
	public void test_retrieve_approvalChain() {
		ApiParams apiParams = new ApiParams();
		apiParams.setUserId("Fbmstid1");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(12L);
		GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.APPROVAL_CHAIN, httpServletRequest)).thenReturn(genericResponseWrapperList);
		Mockito.when(naRuleEngine.getApprovalChain(Mockito.any())).thenReturn(expectedGenericResponse);

		Assert.assertEquals(HttpStatus.OK, approvalManagementService
				.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVAL_CHAIN, httpServletResponse)
				.getHttpStatus());
	}
    
    @Test
    public void should_do_get_Validate_Actions_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.validateAction(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.VALIDATE_ACTIONS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_Validate_Actions_failure() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.NO_CONTENT);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.validateAction(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.NO_CONTENT, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.VALIDATE_ACTIONS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_total_avg_success_NA() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.getTotalAvgFinancials(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_TOTALS_AVG_FINANICIALS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_total_avg_failure_NA() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.NO_CONTENT);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.getTotalAvgFinancials(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.NO_CONTENT, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_TOTALS_AVG_FINANICIALS,httpServletResponse).getHttpStatus());
    }
    

    @Test
    public void should_do_get_total_avg_success_Mex() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("MEX");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(mexRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(mexRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(mexRuleEngine.getTotalAvgFinancials(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_TOTALS_AVG_FINANICIALS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_total_avg_failure_Mex() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("MEX");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.NO_CONTENT);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(mexRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(mexRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(mexRuleEngine.getTotalAvgFinancials(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.NO_CONTENT, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_TOTALS_AVG_FINANICIALS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_financial_list_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.populateFinancialList(Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_FINANCIAL_LIST,httpServletResponse).getHttpStatus());
    }
    
    
    @Test
    public void should_do_get_actual_list_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList =new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.populateFinancialList(Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_ACTUAL_LIST,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void should_do_get_forecast_list_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.populateFinancialList(Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.OK, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_FORECAST_LIST,httpServletResponse).getHttpStatus());
    }
    
    @Test
	public void test_save_proposal() {
		ApiParams apiParams = new ApiParams();
		apiParams.setUserId("Fbmstid1");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(12L);
		
		GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.SAVE_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
		Mockito.when(naRuleEngine.saveProposal(Mockito.any(), Mockito.any())).thenReturn(expectedGenericResponse);
		
		Assert.assertEquals(HttpStatus.OK, approvalManagementService
				.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.SAVE_PROPOSAL, httpServletResponse)
				.getHttpStatus());
	}
    
    @Test
	public void test_recall_proposal() {
		ApiParams apiParams = new ApiParams();
		apiParams.setUserId("Fbmstid1");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(12L);
		
		GenericResponse expectedGenericResponse =  responseBuilder.generateResponse(ResponseCodes.PROPOSAL_RECALLED_SUCCESSFULLY);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.RECALL_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);

		Assert.assertEquals(expectedGenericResponse, approvalManagementService
				.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL, httpServletResponse));
	}
    
    @Test
	public void test_reject_proposal() {
		ApiParams apiParams = new ApiParams();
		apiParams.setUserId("Fbmstid1");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(12L);
		
		GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REJECTED_SUCCESSFULLY);
        
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.REJECT_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
		Assert.assertEquals(expectedGenericResponse, approvalManagementService
				.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.REJECT_PROPOSAL, httpServletResponse)
				);
	}
    
    @Test
	public void test_submitProposal() {
		ApiParams apiParams = new ApiParams();
		apiParams.setUserId("Fbmstid1");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(12L);
		GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SUBMITTED_SUCCESSFULLY);
        
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.SUBMIT_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);

		Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.SUBMIT_PROPOSAL, httpServletResponse));
	}

    @Test
   	public void test_approveProposal() {
   		ApiParams apiParams = new ApiParams();
   		apiParams.setUserId("Fbmstid1");
   		apiParams.setCountryCd("USA");
   		apiParams.setProposalKey(12L);
   		GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY);
   		
           
   		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
   		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
   		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

   		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
   		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.APPROVE_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
   		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);

   		Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL, httpServletResponse));
   	}
    
    @Test
   	public void test_reviseProposal() {
   		ApiParams apiParams = new ApiParams();
   		apiParams.setUserId("Fbmstid1");
   		apiParams.setCountryCd("USA");
   		apiParams.setProposalKey(12L);
           
        GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REVISED_SUCCESSFULLY);   
           
   		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
   		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
   		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

   		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
   		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.REVISE_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
   		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);

   		Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.REVISE_PROPOSAL, httpServletResponse));
   	}
    
    @Test
   	public void test_sendBackProposal() {
   		ApiParams apiParams = new ApiParams();
   		apiParams.setUserId("Fbmstid1");
   		apiParams.setCountryCd("USA");
   		apiParams.setProposalKey(12L);
   		GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY);
           
   		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
   		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
   		List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();

   		Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
   		Mockito.when(naRuleEngine.validate(apiParams, null, RequestMode.SENDBACK_PROPOSAL, httpServletRequest)).thenReturn(genericResponseWrapperList);
   		Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);

   		Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.SENDBACK_PROPOSAL, httpServletResponse));
   		
   	}
    
    @Test
    public void should_do_approve_proposal_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.approveProposal(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testBuildApiParams() {
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Testuser");
        apiParams.setCountryCd("USA");
        apiParams.setVolumeFinancialDataSource("TestCode");
        apiParams.setFleetRating("TestCode");
        Assert.assertEquals(apiParams.getVolumeFinancialDataSource(), approvalManagementService
            .buildApiParams("Testuser", "USA",1l,"TestCode","TestCode").getVolumeFinancialDataSource());
    }
    
    @Test
    public void testBuildApiParams_case1() {
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Testuser");
        apiParams.setCountryCd("USA");
        apiParams.setVolumeFinancialDataSource("TestCode");
        apiParams.setFleetRating("TestCode");
        apiParams.setProposalKey(12L);
        apiParams.setFinKey(12L);
        apiParams.setProposalYr(1);
        apiParams.setProposalYrVer(1);
        Assert.assertEquals(apiParams.getVolumeFinancialDataSource(), approvalManagementService
            .buildApiParams("Testuser", "USA",1l,1,1,12L,"TestCode","TestCode").getVolumeFinancialDataSource());
    }
    
    @Test
    public void testBuildApiParams_case2() {
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Testuser");
        apiParams.setCountryCd("USA");
        apiParams.setFleetRating("TestCode");
        apiParams.setProposalKey(12L);
        apiParams.setFinKey(12L);
        apiParams.setProposalYr(1);
        apiParams.setProposalYrVer(1);
        apiParams.setOrgCd("TestCode");
        apiParams.setOuUnitKey(1L);
        Assert.assertEquals(apiParams.getVolumeFinancialDataSource(), approvalManagementService
            .buildApiParams("Testuser", "USA",1l,1L,1,1,"TestCode",2L).getVolumeFinancialDataSource());
        
    }
    

    @Test
    public void testBuildApiParams_case3() {
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Testuser");
        apiParams.setCountryCd("USA");
        apiParams.setFleetRating("TestCode");
        apiParams.setProposalKey(12L);
        apiParams.setFinKey(12L);
        apiParams.setProposalYr(1);
        apiParams.setProposalYrVer(1);
        apiParams.setOrgCd("TestCode");
        apiParams.setComplete(true);
        Assert.assertTrue(apiParams.getOrgCd(), approvalManagementService
            .buildApiParams("Testuser", "USA",1l,1,1,1L,true,"TestCode").isComplete());
    }
    
    @Test
    public void testBuildApiParams_case4() {
        ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Testuser");
        apiParams.setCountryCd("USA");
        apiParams.setFleetRating("TestCode");
        apiParams.setProposalKey(12L);
        apiParams.setFinKey(12L);
        apiParams.setProposalYr(1);
        apiParams.setProposalYrVer(1);
        apiParams.setOrgCd("TestCode");
        apiParams.setComplete(true);
        Assert.assertTrue(apiParams.getOrgCd(), approvalManagementService
            .buildApiParams("Testuser", "USA",null,1l,"testaction",true).isHighPriority());
    }
    
    @Test
    public void testApprovalManagementService_ruleEngineNotExist() {
    	GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(false);
    	Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    	Assert.assertEquals(HttpStatus.EXPECTATION_FAILED, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void testProcessSummaryAndSubmit_validationFail() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.BAD_REQUEST);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        GenericResponseWrapper wrapper = new GenericResponseWrapper();
        wrapper.setGenericResponse(expectedGenericResponse);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        genericResponseWrapperList.add(wrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.approveProposal(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(HttpStatus.BAD_REQUEST, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse).getHttpStatus());
    }
    
    @Test
    public void testProcessSummaryAndSubmit_exception() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.approveProposal(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenThrow(new ArrayIndexOutOfBoundsException("Test exception"));
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosApprovalProcess() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        List<ApprovalChainVO> approvalChainList = new ArrayList<ApprovalChainVO>();
        genericResponseWrapper.setApprovalChainList(approvalChainList);
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosApprovalProcessList() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setApprovalProcessDtoList(Arrays.asList(new ApprovalProcessDto()));
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosFordPersonList() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setFordPersonDto(new FordPersonDto());
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }

    
    @Test
    public void testfilterRequiredDtosIsAuthorized() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setIsAuthorized(true);
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosIsProposalAssignee() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setIsProposalAssignee(true);
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosPyCountryDefinition() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
        pyCountryDefinition.setActivateAutoearlyFlag("");
        pyCountryDefinition.setArchiveFlag("Y");
        pyCountryDefinition.setArchiveYear(null);
        pyCountryDefinition.setAutoearlyYear(null);
        pyCountryDefinition.setCountry(null);
        pyCountryDefinition.setCreatedProcess(null);
        pyCountryDefinition.setCountryPySaKey(0);
        pyCountryDefinition.setCreatedTimeStamp(null);
        pyCountryDefinition.setCreatedUser(null);
        pyCountryDefinition.setLastUpdatedProcess(null);
        pyCountryDefinition.setLastUpdatedTimeStamp(null);
        pyCountryDefinition.setLastUpdatedUser(null);
        pyCountryDefinition.setEndYear(null);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosUpdateRecalledQueue() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setUpdateRecalledQueue(new ApprovalProcessDto());
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosPriorProposalDto() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        ProposalDto propDto = Mockito.mock(ProposalDto.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setPriorProposalDto(propDto);
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosTargetBandDto() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        TargetBandDto targetBandDto = Mockito.mock(TargetBandDto.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setTargetBandDto(targetBandDto);
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosVehicleLineOptionDiscountVos() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setVehicleLineOptionDiscountVos(Arrays.asList(new VehicleLineOptionDiscountVo()));
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDtosProposalCommentsVos() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setProposalCommentsVos(Arrays.asList(new ProposalCommentsVo()));
        genericResponseWrapperList.add(genericResponseWrapper);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.RECALL_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredTargetList() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setTargetList(Arrays.asList(new ProposalFinancialVO(0l)));
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredFinancialDetailedVOList() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setFinancialDetailedVOList(Arrays.asList(new FinancialDetailedVO()));
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredApprovalResponseVo() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setApprovalResponseVo(new ApprovalResponseVo());
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredFinancialDataStatus() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setFinancialDataStatus(0l);
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredProposalDataDto() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setProposalDataDto(new ProposalDto());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredApprovalResponseNonFinancialVo() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setApprovalResponseNonFinancialVo(new ApprovalResponseVo());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredDropDownMap() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setDropDownMap(new HashMap<String, String>());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredActionsVO() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setActionsVO(new ValidateActionsVO());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredApprovalProcessDto() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setApprovalProcessDto(new ApprovalProcessDto());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredSubsidiariesVos() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setSubsidiariesVos(Arrays.asList(new SubsidiariesVo()));
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterRequiredProposalVo() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setProposalVo(new ProposalVo());
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void testfilterFinancialDetailedMexVOList() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setFinancialDetailedMexVOList(Arrays.asList(new FinancialMexDetailedVO()));
        genericResponseWrapperList.add(genericResponseWrapper);
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void should_do_approve_next_proposal_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.approveProposal(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void should_do_download_Proposal_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.downloadProposal(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL,httpServletResponse));
    }
    
    @Test
    public void should_do_next_Deal_Approve_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.OK); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Mockito.when(naRuleEngine.approveProposal(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.createProposalComments(Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.findNextDeal(Mockito.any(),Mockito.any())).thenReturn(expectedGenericResponse);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.NEXTDEAL_APPROVE,httpServletResponse));
    }
    
    @Test
    public void should_do_financialDataStoredProcedure_success() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper wrp = new GenericResponseWrapper();
        wrp.setFinancialDataStatus(0l);
        genericResponseWrapperList.add(wrp);
        Mockito.when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.financialDataStoredProcedure(apiParams, httpServletRequest, RequestMode.MAINTAIN_FINANCIAL_DATA_SP));
    }
    
    @Test
    public void should_do_financialDataStoredProcedure_Failure() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper wrp = new GenericResponseWrapper();
        wrp.setGenericResponse(expectedGenericResponse);
        genericResponseWrapperList.add(wrp);
        Mockito.when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.financialDataStoredProcedure(apiParams, httpServletRequest, RequestMode.MAINTAIN_FINANCIAL_DATA_SP));
    }
    
    @Test
    public void should_do_financialDataStoredProcedure_FailureWithInvalidCountry() {
    	
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("GBR");
        apiParams.setProposalKey(12L);
        
        GenericResponse expectedGenericResponse = new GenericResponse();
        expectedGenericResponse.setHttpStatus(HttpStatus.EXPECTATION_FAILED); 
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper wrp = new GenericResponseWrapper();
        wrp.setGenericResponse(expectedGenericResponse);
        genericResponseWrapperList.add(wrp);
        Mockito.when(responseBuilder.generateResponse(ResponseCodes.UNEXPECTED_BEHAVIOR)).thenReturn(expectedGenericResponse);
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(false);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertEquals(expectedGenericResponse, approvalManagementService.financialDataStoredProcedure(apiParams, httpServletRequest, RequestMode.MAINTAIN_FINANCIAL_DATA_SP));
    }
    
    @Mock
    private RestService restService;
    @Mock
    private HttpServletRequest httpRequest;
    
    @Test
    public void testGetProposalNotesDetails() throws ExecutionException, InterruptedException {
      ApiParams apiParams = new ApiParams();
      apiParams.setUserId("FBMSTID1");
      apiParams.setCountryCd("USA");
      apiParams.setProposalYrVer(2);
      apiParams.setProposalYr(2020);
      ProposalViewDto viewDto = new ProposalViewDto();
      viewDto.setFinkey("1743");
      viewDto.setProposalVersion("2");
      viewDto.setProposalComments("added comments");
      viewDto.setProposalYear("2020");
      viewDto.setInProcess("N");
      viewDto.setDateSubmitted(new Date());
      viewDto.setProposalNoteKey(13564L);
      viewDto.setCommentedBy("FBMSTID1");
      List<ProposalViewDto> proposalNotesRetrivalDtos = Collections.singletonList(viewDto);
      GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
      responseWrapper.setProposalNotesRetrival(proposalNotesRetrivalDtos);
      Mockito.when(restService.getProposalNotesDetails(apiParams, httpRequest)).thenReturn(responseWrapper);
      assertNotNull(approvalManagementService.getProposalNotesDetails(apiParams, httpRequest, null));
    }
    
    @Test
    public void testGetMultiYearPriceProtectionDetails() {
    	 ApiParams apiParams = new ApiParams();
         apiParams.setUserId("FBMSTID1");
         apiParams.setCountryCd("USA");
         apiParams.setProposalYrVer(2);
         apiParams.setProposalYr(2020);
    	 Mockito.when(restService.getMultiYearPriceProtectionDetails(apiParams, httpRequest)).thenReturn("Data");
    	 String data = approvalManagementService.getMultiYearPriceProtectionDetails(apiParams, httpRequest, null);
    	 assertNotNull(data);
    	 assertEquals("Data", data);
	}
    
    @Test
    public void testfilterRequiredCustomerAcceptanceS3Dto() {
    	ApiParams apiParams = new ApiParams();
        apiParams.setUserId("Fbmstid1");
        apiParams.setCountryCd("USA");
        apiParams.setProposalKey(12L);
        
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        List<GenericResponseWrapper> genericResponseWrapperList = new ArrayList<>();
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setCustomerAcceptanceS3Dto(new CustomerAcceptanceS3Dto());
        genericResponseWrapperList.add(genericResponseWrapper);
        
        
    	Mockito.when(naRuleEngine.isRequestBehalfOfThisImpl(Mockito.anyString())).thenReturn(true);
    	Mockito.when(naRuleEngine.validate(Mockito.any(), Mockito.any(), Mockito.any(),Mockito.any())).thenReturn(genericResponseWrapperList);
    	Assert.assertNull(approvalManagementService.processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVE_PROPOSAL,httpServletResponse));
    }
    
       
}

