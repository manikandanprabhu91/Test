package com.ford.fbms.approvalmanagement;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * This test class is written to perform unit testing for ApprovalManagementLauncher class.
 *
 * @author NACHUTHA on 3/08/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalManagementLauncherTest {
    @Spy
    @InjectMocks
    private ApprovalManagementLauncher approvalManagementLauncher;

    /**
     * This method is used to test newsApi.
     */
    @Test
    public void test_newsApi() {
        //When
        Docket docket = approvalManagementLauncher.newsApi();
        //Then
        Assert.assertNotNull(docket);
    }
}
