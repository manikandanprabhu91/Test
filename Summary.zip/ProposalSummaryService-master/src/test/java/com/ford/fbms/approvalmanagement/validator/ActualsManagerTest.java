package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ActualsManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ActualsManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private ActualsManager validator;
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(0);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorProposals(proposalDto)).thenReturn(proposalDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorProposalCase2() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto1(1l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto1();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.identifyPriorProposals(proposalDto)).thenReturn((proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	@Test
	public void testValidateAndConstructWithPopulate() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewView() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(0l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier1() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(0l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier2() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(1);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(2);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier3() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(1);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(3);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier4() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(1);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(4);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier5() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(1);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(5);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposalWithPerUnitIncentiveNewViewTier6() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(0l);
		loadExpandedBodyFinancialViewDto(0);
		loadActualSalesFinancialViewDto();
		loadPerUnitIncentiveNewViewDto(1);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(actualSalesFinancialViewRepo.getSalesFinancialViewListByProposal(Mockito.anyLong())).thenReturn(actualSalesFinancialViewDtos);
		when(perUnitIncNewViewRepo.findPerUnitNewViewByProposal(Mockito.anyLong())).thenReturn(perUnitIncentiveNewViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(6);
		when(proposalManager.isPriorYearVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	@Test
	public void testValidateAndConstructWithProposalTier1() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	@Test
	public void testValidateAndConstructWithProposalTier2() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(2);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithProposalTier3() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(3);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithProposalTier4() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(4);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithProposalTier5() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(5);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithProposalTier6() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(6);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand1() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getTargetBandLevel(Mockito.anyLong())).thenReturn(1);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand2() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getTargetBandLevel(Mockito.anyLong())).thenReturn(2);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand3() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getTargetBandLevel(Mockito.anyLong())).thenReturn(3);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand4() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getTargetBandLevel(Mockito.anyLong())).thenReturn(4);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithTargetBand5() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadPerUnitExpandedViewDto(1l);
		loadExpandedBodyFinancialViewDto(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(perUnitExpandedViewRepo.findPerUnitExpandedBodystylesByProposal(Mockito.anyLong())).thenReturn(perUnitExpandedViewDtos);
		when(expandedBodyFinancialViewRepo.findExpandedBodyFinancialbyProposal(Mockito.anyLong())).thenReturn(expandedBodyFinancialViewDtos);
		when(proposalManager.getTargetBandLevel(Mockito.anyLong())).thenReturn(5);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
}
