package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.TierIncentiveManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class TierIncentiveManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private TierIncentiveManager validator;
	
	@Test
	public void testValidateAndConstructWithEmptyTierVolume() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithNullTierVolume() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(tierVolumeRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadTierVolume(0, 0);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(tierVolumeRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(tierVolumes);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper genericResponseWrapper = wrapper.get();
		assertNotNull(genericResponseWrapper);
	}
	
	@Test
	public void testValidateAndConstructWithProposalVehicleLineIncentive() throws InterruptedException, ExecutionException {
		loadTierVolume(2, 3);
		loadProposalVehicleLineIncentiveDto(1);
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0063");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_INCENTIVES)).thenReturn(genericResponse);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(tierVolumeRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(tierVolumes);
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(genericResponse);
		assertEquals("MSG-0063", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstructWithPviAndTierIncentives() throws InterruptedException, ExecutionException {
		loadTierVolume(2, 3);
		loadProposalVehicleLineIncentiveDto(1);
		//loadTierIncentive(2,1,1,2); Required re-factor from original Business Logic
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0063");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_INCENTIVES)).thenReturn(genericResponse);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(tierVolumeRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(tierVolumes);
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(tierIncentiveRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(tierIncentives));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(genericResponse);
		assertEquals("MSG-0063", actualGenericResponse.getMsgId());
	}
	
	
}
