package com.ford.fbms.approvalmanagement.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * This test class is written to perform unit testing for GenericAssister class.
 *
 * @author AGOVADA on 2/10/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class GenericAssisterTest {

    /**
     * This method is to test the constructor
     */
    @Test(expected = Exception.class)
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException,
            InvocationTargetException, InstantiationException {
        Constructor<GenericAssister> constructor = GenericAssister.class.getDeclaredConstructor();
        Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

    /**
     * This method is to test the non numeric values
     */
    @Test
    public void isNotNumeric() {
        Assert.assertTrue(GenericAssister.isNotNumeric("test"));
        Assert.assertFalse(GenericAssister.isNotNumeric("2"));
        Assert.assertTrue(GenericAssister.isNotNumeric(" "));
    }

    /**
     * This method is to test the numeric values
     */
    @Test
    public void isNumeric() {
        Assert.assertTrue(GenericAssister.isNumeric("10"));
        Assert.assertTrue(GenericAssister.isNumeric("-10"));
        Assert.assertFalse(GenericAssister.isNumeric("test"));
        Assert.assertFalse(GenericAssister.isNumeric(""));
        Assert.assertFalse(GenericAssister.isNumeric(null));
        Assert.assertFalse(GenericAssister.isNumeric("a"));
        Assert.assertFalse(GenericAssister.isNumeric("10-2"));
    }


    /**
     * This method is to test the given string is not empty
     */
    @Test
    public void isNotEmptyString() {
        Assert.assertTrue(GenericAssister.isNotEmptyString("2"));
        Assert.assertFalse(GenericAssister.isNotEmptyString(" "));
        Assert.assertFalse(GenericAssister.isNotEmptyString(null));
    }

    /**
     * This method is to test the given string is empty
     */
    @Test
    public void isEmptyString() {
        Assert.assertTrue(GenericAssister.isEmptyString(" "));
        Assert.assertTrue(GenericAssister.isEmptyString(""));
        Assert.assertFalse(GenericAssister.isEmptyString("test"));
        Assert.assertTrue(GenericAssister.isEmptyString(null));

    }

    /**
     * This method is to test all given strings are empty
     */
    @Test
    public void isAllStringsEmpty() {
        Assert.assertTrue(GenericAssister.isAllStringsEmpty(" ","",null));
        Assert.assertFalse(GenericAssister.isAllStringsEmpty("test","1","null"));
        Assert.assertTrue(GenericAssister.isAllStringsEmpty(null,null));
    }

    /**
     * This method is to test all given strings are not empty
     */
    @Test
    public void isAllStringsNotEmpty() {
        Assert.assertFalse(GenericAssister.isAllStringsNotEmpty(" ","",null));
        Assert.assertTrue(GenericAssister.isAllStringsNotEmpty("test","1","null"));
        Assert.assertFalse(GenericAssister.isAllStringsNotEmpty(null,null));
    }

    /**
     * This method is to test if at least one of the input strings is not null and not empty.
     */
    @Test
    public void isAnyStringNotEmpty() {
        Assert.assertFalse(GenericAssister.isAnyStringNotEmpty(" ","",null));
        Assert.assertTrue(GenericAssister.isAnyStringNotEmpty("test",null));
        Assert.assertFalse(GenericAssister.isAnyStringNotEmpty(null,null));
    }

    /**
     * This method is to test the truncated string equal to the expected string.
     */
    @Test
    public void truncateString() {
        Assert.assertTrue(GenericAssister.truncateString(" ",10).equals(" "));
        Assert.assertTrue(GenericAssister.truncateString("truncate test",3).equals("tru"));
        Assert.assertEquals(GenericAssister.truncateString(null,1),null);
        Assert.assertEquals(GenericAssister.truncateString("test",10),"test");
        Assert.assertNotEquals(GenericAssister.truncateString("test",1),"test");
    }

    /**
     * This method is to test the given collection is not empty.
     */
    @Test
    public void isCollectionNotEmpty() {
        Collection collection = Arrays.asList("1","2","3","4");
        Assert.assertTrue(GenericAssister.isCollectionNotEmpty(collection));
        collection=new HashSet();
        Assert.assertFalse(GenericAssister.isCollectionNotEmpty(collection));
        Assert.assertFalse(GenericAssister.isCollectionNotEmpty(null));
    }

    /**
     * This method is to test the given collection is not empty or not.
     */
    @Test
    public void isCollectionEmpty() {
        Collection collection = Arrays.asList("1","2","3","4");
        Assert.assertFalse(GenericAssister.isCollectionEmpty(collection));
        collection=new HashSet();
        Assert.assertTrue(GenericAssister.isCollectionEmpty(collection));
    }

    /**
     * This method is to test the given Map is not empty.
     */
    @Test
    public void isMapNotEmpty() {
        Map map = new HashMap();
        Assert.assertFalse(GenericAssister.isMapNotEmpty(map));
        map.put("1","one");
        Assert.assertTrue(GenericAssister.isMapNotEmpty(map));
        Assert.assertFalse(GenericAssister.isMapNotEmpty(null));
        Assert.assertNotNull(map);
    }

    /**
     * This method is to test the given date is converted the format.
     */
    @Test
    public void convertDateToStringPositiveCase() {
        String pattern = "yyyy-MM-dd";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        Date inputDate = new Date();
        Assert.assertNotNull(inputDate);
        String expectedDate = simpleDateFormat.format(inputDate);
        String dateString =GenericAssister.convertDateToString(new Date(),pattern);
        Assert.assertEquals(expectedDate,dateString);
    }

    /**
     * This method is to test the given date is converted to the format null case.
     */
    @Test
    public void convertDateToStringNullCase() {
            String pattern = "yyyy-MM-dd";
            GenericAssister.convertDateToString(null, pattern);
    }

    /**
     * This method is to test the given date is converted to the format Exception case.
     */
    @Test
    public void convertDateToStringExceptionCase() {
       String stringDate = GenericAssister.convertDateToString(new Date(), null);
       Assert.assertNull(stringDate);
    }
}