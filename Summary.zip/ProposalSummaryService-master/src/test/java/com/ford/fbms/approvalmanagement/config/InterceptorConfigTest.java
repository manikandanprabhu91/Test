package com.ford.fbms.approvalmanagement.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

/*
 * This test class is written to perform unit testing for InterceptorConfig class.
 *
 * @author SJAGATJO on 2/9/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class InterceptorConfigTest {

  @Spy
  @InjectMocks
  private InterceptorConfig interceptorConfig;

  /*
   *This method is used to test httpFirewall Method.
   *
   */
  @Test
  public void testHttpFirewall() throws Exception {
    final StrictHttpFirewall firewall = interceptorConfig.httpFirewall();
    Assert.assertNotNull(firewall);
  }

  /*
   *This method is used to test addInterceptors Method.
   *
   */
  @Test
  public void testAddInterceptors() throws Exception {
    InterceptorRegistry interceptorRegistry = Mockito.spy(InterceptorRegistry.class);
    interceptorConfig.addInterceptors(interceptorRegistry);
    Assert.assertNotNull(interceptorRegistry);
  }
}
