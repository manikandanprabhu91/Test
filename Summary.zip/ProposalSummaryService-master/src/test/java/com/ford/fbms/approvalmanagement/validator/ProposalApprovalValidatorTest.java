/**
 * 
 */
package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.AccountClassDto;
import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ControllerThresholdDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FinProfileDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermViewDto;
import com.ford.fbms.approvalmanagement.domain.PriceProtectionLevelYearOverYearDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumePk;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.Constants;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ProposalApprovalValidator;
import com.ford.fbms.approvalmanagement.validators.ProposalManager;

/**
 * @author vvm
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ProposalApprovalValidatorTest {
	
	@Mock
	private ProposalRepository proposalRepository;
	@Mock
	private ResponseBuilder responseBuilder;
	@Mock
	private FordPersonRepository fordPersonRepo;
	@Mock
	private ProposalStatusRepository proposalStatusRepo;
	@Mock
	private ApprovalProcessRepository approvalProcessRepo;
	@InjectMocks
	private ProposalApprovalValidator proposalApprovalVld;
	@Mock
	private ProposalManager proposalManager;
	@Mock
	private FinProfileRepository finProfileRepository;
	@Mock
	private ControllerThresholdRepository controllerThresholdRepo;
	@Mock
	private ReportLevelRepository reportLevelRepo;
	
	private ApiParams apiParams = new ApiParams();
	private ProposalDto proposalDto = new ProposalDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	private FordPersonDto personDto = new FordPersonDto();
	
	@Before
	public void setup() {
		
		apiParams = this.getApiParams();
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
	}
	
	public ApiParams getApiParams() {
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("MEX");
		apiParams.setFleetRating("test");
		return apiParams;
	}
	
	@Test
	public void test_validateAndConstruct_failure() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0015");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(genericResponse);
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		
		assertEquals("MSG-0015",proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get().getGenericResponse().getMsgId());
	}
	
	@Test
	public void test_validateAndConstruct_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(true);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		FinProfileDto finProfileDto = setFinProfile();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(finProfileDto));
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl));
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}

	private FinProfileDto setFinProfile() {
		FinProfileDto finProfileDto = new FinProfileDto(); 
		AccountClassDto accountClassDto = new AccountClassDto();
		accountClassDto.setCode(null);
		accountClassDto.setDescription(null);
		accountClassDto.getDescription();
		accountClassDto.getCode();
		finProfileDto.setSpecialFinClassification(accountClassDto);
		finProfileDto.setApproverCdsid(Constants.BLANK);
		finProfileDto.setAutoEst(false);
		finProfileDto.setCorporateEmail(null);
		finProfileDto.setCurrTemplateFin(null);
		finProfileDto.setDealerAssignType(null);
		finProfileDto.setFinMasterKey(null);
		finProfileDto.setFleetRating(null);
		finProfileDto.setGenericFin(false);
		finProfileDto.setPreferredLanguage(null);
		finProfileDto.setReqTemplateFin(null);
		finProfileDto.setRequestedCdsid(null);
		finProfileDto.setRequestedDate(null);
		finProfileDto.setTaxId(null);
		finProfileDto.setTemplateComments(null);
		finProfileDto.getSpecialFinClassification();
		finProfileDto.getApproverCdsid();
		finProfileDto.isAutoEst();
		finProfileDto.getCorporateEmail();
		finProfileDto.getCurrTemplateFin();
		finProfileDto.getDealerAssignType();
		finProfileDto.getFinMasterKey();
		finProfileDto.getFleetRating();
		finProfileDto.isGenericFin();
		finProfileDto.getPreferredLanguage();
		finProfileDto.getReqTemplateFin();
		finProfileDto.getRequestedCdsid();
		finProfileDto.getRequestedDate();
		finProfileDto.getTaxId();
		finProfileDto.getTemplateComments();
		return finProfileDto;
	}
	
	@Test
	public void test_validateAndConstructAccountMngr_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl1)).thenReturn(Optional.of(rptlvl));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(rptlvl);
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}
	
	@Test
	public void test_validateAndConstructAccountMng_revised2_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList2();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		

		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto dto = new ReportLevelDto();
		dto.setTitleCode(ApprovalConstants.RSM);
		reportLevelList.add(dto);
		
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl1)).thenReturn(Optional.of(rptlvl));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}
	

	@Test
	public void test_validateAndConstructAccountMng_revised3_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		PriceProtectionLevelYearOverYearDto ppl = new PriceProtectionLevelYearOverYearDto();
		ppl.setPriceProLevYrOverYearCode("test");
		this.proposalDto.setPplYoy(ppl);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList3();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		

		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto dto = new ReportLevelDto();
		dto.setTitleCode(ApprovalConstants.RSM);
		reportLevelList.add(dto);
		
		MultiYearTermViewDto multiYearTermDto = setMultiYearDto();
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(0l);
		Mockito.when(proposalManager.getMultiYearTerm(Mockito.any())).thenReturn(multiYearTermDto);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl1)).thenReturn(Optional.of(rptlvl));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}

	private MultiYearTermViewDto setMultiYearDto() {
		MultiYearTermViewDto multiYearTermDto = new MultiYearTermViewDto();
		multiYearTermDto.setBonusFimpsFlag(null);
		multiYearTermDto.setEndYr(null);
		multiYearTermDto.setManualBonusAmount(null);
		multiYearTermDto.setManualBonusFlag(null);
		multiYearTermDto.setMaxVolume(null);
		multiYearTermDto.setMicroCheckDate(null);
		multiYearTermDto.setMicroCheckNumber(null);
		multiYearTermDto.setMinVolume(null);
		multiYearTermDto.setPaymentMadeFlag(null);
		multiYearTermDto.setProposalKey(null);
		multiYearTermDto.setRequiredVolume(null);
		multiYearTermDto.setStartYr(null);
		multiYearTermDto.setTotalBonusPaidAmount(null);
		
		multiYearTermDto.getBonusFimpsFlag();
		multiYearTermDto.getEndYr();
		multiYearTermDto.getManualBonusAmount();
		multiYearTermDto.getManualBonusFlag();
		multiYearTermDto.getMaxVolume();
		multiYearTermDto.getMicroCheckDate();
		multiYearTermDto.getMicroCheckNumber();
		multiYearTermDto.getMinVolume();
		multiYearTermDto.getPaymentMadeFlag();
		multiYearTermDto.getProposalKey();
		multiYearTermDto.getRequiredVolume();
		multiYearTermDto.getStartYr();
		multiYearTermDto.getTotalBonusPaidAmount();
		return multiYearTermDto;
	}
	
	
	@Test
	public void test_validateAndConstructAccountMng_revised4_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		this.proposalDto.setVersionNumber(1);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		PriceProtectionLevelYearOverYearDto ppl = new PriceProtectionLevelYearOverYearDto();
		ppl.setPriceProLevYrOverYearCode("NON");
		this.proposalDto.setPplYoy(ppl);
		
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList3();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		

		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto dto = new ReportLevelDto();
		dto.setTitleCode(ApprovalConstants.RSM);
		reportLevelList.add(dto);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(0l);
		Mockito.when(proposalManager.getMultiYearTerm(Mockito.any())).thenReturn(null);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl1)).thenReturn(Optional.of(rptlvl));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		this.proposalDto.setVersionNumber(0);
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
	}

	
	@Test
	public void test_validateAndConstructAccountMng_revised5_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		PriceProtectionLevelYearOverYearDto ppl = new PriceProtectionLevelYearOverYearDto();
		ppl.setPriceProLevYrOverYearCode("NON");
		this.proposalDto.setPplYoy(ppl);
		
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList3();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		ControllerThresholdDto controllerThresholdDto1 = new ControllerThresholdDto();
		controllerThresholdDto1.setThresholdAmount(-1);

		List<ReportLevelDto> reportLevelList = new ArrayList<>();
		ReportLevelDto dto = new ReportLevelDto();
		dto.setTitleCode(ApprovalConstants.RSM);
		reportLevelList.add(dto);
		
		ProposalStatusDto proposalStatusDto1 = new ProposalStatusDto();
		proposalStatusDto1.setProposalStatusCode(ApprovalConstants.APPROVED);
		ProposalDto dto2 = new ProposalDto();
		dto2.setProposalStatus(proposalStatusDto1);
		List<TierVolumeDto> pTierVolumeList = new ArrayList<>();
		TierVolumeDto tierVolumeDto = new TierVolumeDto();
		TierVolumePk pk = new TierVolumePk();
		pk.setTierLevel(2);
		tierVolumeDto.setTierVolumePk(pk);
		pTierVolumeList.add(tierVolumeDto);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(0l);
		Mockito.when(proposalManager.getMultiYearTerm(Mockito.any())).thenReturn(null);
		Mockito.when(proposalManager.identifyPriorProposals(Mockito.any())).thenReturn(dto2);
		Mockito.when(proposalManager.getTierVolumeList(Mockito.any())).thenReturn(pTierVolumeList);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto1).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl1)).thenReturn(Optional.of(rptlvl));
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(null);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(reportLevelList);
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
	}



	
	@Test
	public void test_validateAndConstructAccountMngrcase2_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl)).thenReturn(Optional.of(rptlvl1));
		
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}
	

	@Test
	public void test_validateAndConstructAccountMngrcase3_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl)).thenReturn(Optional.of(rptlvl1));
		
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
	}
	
	@Test
	public void test_validateAndConstructAccountMngrcase4_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.proposalDto.setReportLevel(rptlvl1);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		processDto.setSubmittedToId(personDto);
		processDto.setSubmittedById(personDto);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl)).thenReturn(Optional.of(rptlvl1));
		
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		rptlvl.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		this.proposalDto.setReportLevel(rptlvl);
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
		
	}
	

	@Test
	public void test_validateAndConstructAccountMngrcase5_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.personDto.setCdsid("test cdsid");
		this.proposalDto.setReportLevel(rptlvl1);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		processDto.setSubmittedToId(personDto);
		processDto.setSubmittedById(personDto);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl)).thenReturn(Optional.of(rptlvl1));
		
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
		
		
		
	}
	
	@Test
	public void test_validateAndConstructAccountMngrcase6_success() throws InterruptedException, ExecutionException {
		ReportLevelDto rptlvl = new ReportLevelDto();
		this.apiParams.setReportLevel((long)ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		rptlvl.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		
		ReportLevelDto rptlvl1 = new ReportLevelDto();
		rptlvl1.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		
		this.personDto.setSprcdsidDescription("test");
		this.personDto.setReportLevel(rptlvl);
		this.personDto.setCdsid("test cdsid");
		this.proposalDto.setReportLevel(rptlvl1);
		this.proposalDto.setCntlReqdFlag(false);
		FinMasterDto finMasterDto = new FinMasterDto();
		finMasterDto.setFinMasterKey(1l);
		this.proposalDto.setFinMasterKey(finMasterDto);
		ApprovalProcessDto processDto = new ApprovalProcessDto();
		processDto.setReportLevel(rptlvl);
		processDto.setSubmittedToId(personDto);
		processDto.setSubmittedById(personDto);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		this.proposalDto.setProposalStatus(proposalStatusDto);
		List<ProposalFinancialVO> puFinancialList = new ArrayList<>();
		List<FinancialDetailedVO> financialDetailedVOList = setDealDetailedList();
		ControllerThresholdDto controllerThresholdDto = new ControllerThresholdDto();
		controllerThresholdDto.setThresholdAmount(2l);
		
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(this.personDto));
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		Mockito.when(approvalProcessRepo.findByProposalKeyAndProposalStatus(Mockito.any(), Mockito.any())).thenReturn(Optional.of(processDto));
		Mockito.when(proposalManager.buildProposalFinancialsEstimate(Mockito.any(), Mockito.any())).thenReturn(puFinancialList);
		Mockito.when(proposalManager.getAggregateIncentiv(Mockito.any())).thenReturn(1l);
		Mockito.when(proposalManager.populateFinancialsForEstimate(Mockito.any(), Mockito.any(),Mockito.anyList())).thenReturn(financialDetailedVOList);
		Mockito.when(finProfileRepository.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.empty());
		Mockito.when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any())).thenReturn(controllerThresholdDto);
		Mockito.when(reportLevelRepo.getReportLevelDataByCountryTitleCode(Mockito.anyString(), Mockito.anyString())).thenReturn(rptlvl);
		Mockito.when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(rptlvl)).thenReturn(Optional.of(rptlvl1));
		
		
		
		assertNotNull(proposalApprovalVld.validateAndConstruct(apiParams, null, null, null).get());
		
		
		
		
		
	}





	private List<FinancialDetailedVO> setDealDetailedList() {
		FinancialDetailedVO vo = new FinancialDetailedVO();
		vo.setPresentProposal(true);
		vo.setRecType(FinancialDetailedVO.rowType.VehicleLine);
		vo.setPresentKey(2l);
		vo.setPrevVerKey(2l);
		vo.setPriorPYVM(2d);
		vo.setPresentVM(3d);
		vo.setBwTargetVM(1d);
		FinancialDetailedVO vo1 = new FinancialDetailedVO();
		vo1.setPresentProposal(true);
		vo1.setRecType(FinancialDetailedVO.rowType.GrandTotal);
		vo1.setPresentVM(1);
		vo1.setPresentVM(2d);
		vo1.setBwTargetVM(2);
		vo1.setBwPrevVerVM(2);
		List<FinancialDetailedVO> financialDetailedVOList = new ArrayList<FinancialDetailedVO>();
		financialDetailedVOList.add(vo);
		financialDetailedVOList.add(vo1);
		return financialDetailedVOList;
	}
	
	private List<FinancialDetailedVO> setDealDetailedList2() {
		FinancialDetailedVO vo = new FinancialDetailedVO();
		vo.setPresentProposal(true);
		vo.setRecType(FinancialDetailedVO.rowType.VehicleLine);
		vo.setPresentKey(2l);
		vo.setPrevVerKey(1l);
		vo.setPriorPYVM(2d);
		vo.setPresentVM(3d);
		vo.setBwTargetVM(1d);
		FinancialDetailedVO vo1 = new FinancialDetailedVO();
		vo1.setPresentProposal(true);
		vo1.setRecType(FinancialDetailedVO.rowType.GrandTotal);
		vo1.setPresentVM(1);
		vo1.setPresentVM(2d);
		vo1.setBwTargetVM(2);
		vo1.setBwPrevVerVM(2);
		List<FinancialDetailedVO> financialDetailedVOList = new ArrayList<FinancialDetailedVO>();
		financialDetailedVOList.add(vo);
		financialDetailedVOList.add(vo1);
		return financialDetailedVOList;
	}
	
	private List<FinancialDetailedVO> setDealDetailedList3() {
		FinancialDetailedVO vo = new FinancialDetailedVO();
		vo.setPresentProposal(true);
		vo.setRecType(FinancialDetailedVO.rowType.VehicleLine);
		vo.setPresentKey(2l);
		vo.setPrevVerKey(1l);
		vo.setPriorPYVM(2d);
		vo.setPresentVM(3d);
		vo.setBwTargetVM(3d);
		FinancialDetailedVO vo1 = new FinancialDetailedVO();
		vo1.setPresentProposal(true);
		vo1.setRecType(FinancialDetailedVO.rowType.GrandTotal);
		vo1.setPresentVM(1);
		vo1.setPresentVM(2d);
		vo1.setBwTargetVM(2);
		vo1.setBwPrevVerVM(2);
		List<FinancialDetailedVO> financialDetailedVOList = new ArrayList<FinancialDetailedVO>();
		financialDetailedVOList.add(vo);
		financialDetailedVOList.add(vo1);
		return financialDetailedVOList;
	}
	
	

}
