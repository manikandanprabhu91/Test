package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.SubmitProcessMexValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class SubmitProcessMexValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private SubmitProcessMexValidator validator;
	@Mock
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;
	@Mock
	protected PviExtraInfoRepository pviExtraInfoRepository;
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0235");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_PERUNIT_INCENTIVES)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0235", actualGenericResponse.getMsgId());
		
	}
	
	@Test
	public void testValidateAndConstructWithPVI() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.NAM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfo() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.NAM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoWithFleetTypeA() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.NAM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.FLEET_TYPE_A);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoWithFleetTypeB() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.NAM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.FLEET_TYPE_B);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoWithFleetTypeC() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.NAM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.FLEET_TYPE_C);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAndFna() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.FNA);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAndDfo() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.DFO);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAndGvp() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.GVP);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAndCeo() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.CEO);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAmountAndCeo() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.CEO);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(reportLevelDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAmountAndFsm() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.FSM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(reportLevelDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAmountAndDfo() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.DFO);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(reportLevelDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithPVIExtarInfoAmountAndRsm() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalVehicleLineIncentiveDto(1l);
		loadReportLevel(1);
		reportLevelDto.setTitleCode(ApprovalConstants.RSM);
		proposalDto.setProposalSaKey(1l);
		apiParams.setCountryCd("USA");
		PviExtraInfoDto pviExtraInfoDto= new PviExtraInfoDto();
		pviExtraInfoDto.setFleetRating(ApprovalConstants.BUSINESS_CASE);
		pviExtraInfoDto.setFleetIncentive(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalVehicleLineIncentiveRepository.findByProposal(Mockito.any())).thenReturn(Optional.of(pviDtos));
		when(proposalVehicleLineIncentiveRepository.getVehicleLineIncentiveDetailsByProposal(Mockito.anyLong())).thenReturn(pviDtos);
		when(pviExtraInfoRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(reportLevelDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
}
