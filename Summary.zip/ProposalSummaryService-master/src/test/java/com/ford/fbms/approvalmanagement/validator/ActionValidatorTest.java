package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ActionValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ActionValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private ActionValidator validator;
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getProposalDataDto());
	}
	
	@Test
	public void testValidateAndConstructWithProposalAssignAttribute() throws InterruptedException, ExecutionException {
		ProposalAssignAttributeDto ProposalAssignAttributeDto = new ProposalAssignAttributeDto();
		loadProposalDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(ProposalAssignAttributeDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getProposalDataDto());
		assertFalse(actualGenericResponse.getIsProposalAssignee());
	}
	
}
