package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.FordPersonAccessManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class FordPersonAccessManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private FordPersonAccessManager validator;
	
	@Test
	public void testValidateAndConstructWithEmptyFordPerson() throws InterruptedException, ExecutionException {
		when(fordPersonRepository.queryFordPersonDealAuthoringByCdsid(Mockito.anyString())).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertFalse(actualGenericResponse.getIsAuthorized());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		when(fordPersonRepository.queryFordPersonDealAuthoringByCdsid(Mockito.anyString())).thenReturn(fordPersonDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertTrue(actualGenericResponse.getIsAuthorized());
	}
	
	
	
}
