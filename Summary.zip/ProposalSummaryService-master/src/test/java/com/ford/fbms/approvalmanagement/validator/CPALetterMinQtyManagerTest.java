package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.CPALetterMinQtyManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class CPALetterMinQtyManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private CPALetterMinQtyManager validator;
	
	private void loadLetterQuantity(int quantityValue) {
		BigDecimal quantity = new BigDecimal(quantityValue);
		proposalDto.setLetterMinQty(quantity);
	}
	

	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadLetterQuantity(2);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithZeroQuantityLetter() throws InterruptedException, ExecutionException {
		loadLetterQuantity(0);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertFalse(actualGenericResponse.getIsValidCPALetterMinQty());
	}
	
}
