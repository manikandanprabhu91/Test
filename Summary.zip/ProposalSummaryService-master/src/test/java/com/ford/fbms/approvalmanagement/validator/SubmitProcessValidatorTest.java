package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO.rowType;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.SubmitProcessValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class SubmitProcessValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private SubmitProcessValidator validator;
	
	private ReportLevelDto reportLevelDtoUser = new ReportLevelDto();
	 private void loadReportLevelDtoUser(int code) {
		 reportLevelDtoUser.setCode(code);
	}

	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
    	when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadSegment("IN_VALID_CODE");
		loadNonFinancialFlag(true);
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithValidSegment() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(true);
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialMode() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	@Test
	public void testValidateAndConstructWithFinancialModeAndFinProfile() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFordPersion("FBMSTID1");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithInvaliSegment() throws InterruptedException, ExecutionException {
		loadSegment("IN_VALID");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithInvaliSegmentFordPersonUnAssignedFlag() throws InterruptedException, ExecutionException {
		loadSegment("IN_VALID");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVO() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.VehicleLine, 1l, 1l);
		loadVM();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVONonPYVersion() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadVM();
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.VehicleLine, 1l, 0l);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVONonPYVersionAndSamePeriorVersion() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadVM();
		financialDetailedVO.setPrevVerKey(1);
		financialDetailedVO.setBwPrevVerVM(-1);
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.VehicleLine, 1l, 0l);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVOSamePeriorVersion() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadVM();
		financialDetailedVO.setPrevVerKey(1);
		financialDetailedVO.setBwPrevVerVM(-1);
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.VehicleLine, 1l, 1l);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVORowTypeGrandTotal() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.GrandTotal, 1l, 1l);
		loadVM();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(finProfileRepo.findIdAndAccountClass(Mockito.anyLong())).thenReturn(Optional.of(FinProfileDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVORowTypeGrandTotalMaxReportLevel() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.GrandTotal, 1l, 1l);
		loadVM();
		loadReportLevel(6);
		loadReportLevelDtoUser(7);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		when(reportLevelRepo.getReportLevelDataByCountryApprovalAmt(Mockito.anyString(), Mockito.anyLong())).thenReturn(reportLevelDto);
		when(reportLevelRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(reportLevelDtoUser));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVORowTypeGrandTotalMaxApprover() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("Code", "Desc");
		loadFinancialDetailedVO(true, rowType.GrandTotal, 1l, 1l);
		loadVM();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	
	@Test
	public void testValidateAndConstructWithFinancialDetailVORowTypeGrandTotalMaxApproverRsmTitle() throws InterruptedException, ExecutionException {
		loadSegment("R");
		loadNonFinancialFlag(false);
		loadProposalDto();
		loadReportLevel(1);
		loadFordPersion("FBMSTID1", "N");
		loadPriceProtectionLevelYearOverYearDtoData("NON", "Desc");
		loadFinancialDetailedVO(true, rowType.GrandTotal, 1l, 1l);
		loadVM();
		reportLevelDto.setTitleCode("RSM");
		reportLevelDto.setMaxApprovalAmount(new BigDecimal(20));
		financialDetailedVO.setPresentVol(-1);
		financialDetailedVO.setBwTargetVM(1);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(controllerThresholdRepo.controllerThresholdByCodeEffectiveDate(Mockito.anyString(), Mockito.any(Date.class))).thenReturn(controllerThresholdDto);
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalManager.populateFinancialsForEstimate(Mockito.any(ApiParams.class), Mockito.any(ProposalDto.class), Mockito.anyList())).thenReturn(financialDetailedVOs);
		when(reportLevelRepo.getReportLevelDataByCountry(Mockito.anyString())).thenReturn(Arrays.asList(reportLevelDto));
		when(reportLevelRepo.getReportLevelDataByCountryReportLevelCode(Mockito.anyString(), Mockito.anyInt())).thenReturn(Arrays.asList(reportLevelDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseVo());
	}
	

	
}
