package com.ford.fbms.approvalmanagement.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.junit.Assert;
import org.junit.Test;

/**
 * This test class is written to perform unit testing for Constants class.
 *
 * @author AGOVADA on 02/10/2021
 */
public class ConstantsTest {

    /**
     * This method is to test the constructor
     */
    @Test(expected = Exception.class)
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException,
            InvocationTargetException, InstantiationException {
        Constructor<Constants> constructor = Constants.class.getDeclaredConstructor();
        Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

    /**
     * The method is to test the Constant class fields not null.
     */
    @Test
    public void testConstantsNotNull(){
       Assert.assertEquals(Constants.REQUEST_FIELD_NAME,"Request");
    }
}