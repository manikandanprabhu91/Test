package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.repository.MaintainFinancialDataRepository;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.MaintainFinancialDataValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class MaintainFinancialDataValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private MaintainFinancialDataValidator validator;

	@Mock
	protected MaintainFinancialDataRepository maintainFinancialDataRepository;

	@Test
	public void testValidateAndConstructWithEmptyProposalExtraInfo() throws InterruptedException, ExecutionException {
		when(maintainFinancialDataRepository.maintainFinancialData(1l)).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine,
				httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNull(actualGenericResponse.getFinancialDataStatus());
	}

	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		when(maintainFinancialDataRepository.maintainFinancialData(1l)).thenReturn(1l);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine,
				httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDataStatus());
	}

}
