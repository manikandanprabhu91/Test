package com.ford.fbms.approvalmanagement.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalVo;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;

/**
 * @author SJAGATJO
 * @created 06/02/2021 - 10:55 AM
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class RestServiceTest {
  @Mock
  private ResponseBuilder responseBuilder;
  @Mock
  private ConfigProperties configProperties;
  @Mock
  private RestTemplate restTemplate;
  @Mock
  private ObjectMapper objectMapper;
  
  @Spy
  @InjectMocks
  private RestService restService;
  

  @Test
  public void testGetPerUnitIncentiveDetails() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalServiceInternal("url");
    service.setProposalServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNotNull(restService.getPerUnitIncentiveDetails(apiParams, request));
  }
  
  
  @Test
  public void testGetPerUnitIncentiveDetailsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
    GenericResponseWrapper genericResponse = new GenericResponseWrapper();
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalServiceInternal("url");
    service.setProposalServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenThrow(httpStatusCodeException);
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    GenericResponse actualResponse = restService.getPerUnitIncentiveDetails(apiParams, request);
    Assert.assertNotNull(actualResponse);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getHttpStatus());    
  }
  
  @Test()
  public void testGetPerUnitIncentiveDetailsError() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalServiceInternal("url");
    service.setProposalServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getPerUnitIncentiveDetails(apiParams, request));
  }
  

  @Test
  public void testGetPerUnitIncentiveDetailsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalServiceInternal("url");
    service.setProposalServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getPerUnitIncentiveDetails(apiParams, request));
  }
  
  @Test
  public void testGetProposalComments() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlExternal("url");
    service.setNotesServiceUrlInternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNotNull(restService.getProposalComments(apiParams, request));
  }
  
  @Test
  public void testGetProposalCommentsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
    GenericResponseWrapper genericResponse = new GenericResponseWrapper();
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlExternal("url");
    service.setNotesServiceUrlInternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenThrow(httpStatusCodeException);
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
    GenericResponse actualResponse = restService.getProposalComments(apiParams, request);
    Assert.assertNotNull(actualResponse);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getHttpStatus());
  }
  
  @Test()
  public void testGetProposalCommentsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlExternal("url");
    service.setNotesServiceUrlInternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getProposalComments(apiParams, request));
  }
  

  @Test
  public void testGetProposalCommentsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlExternal("url");
    service.setNotesServiceUrlInternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getProposalComments(apiParams, request));
  }



  @Test
  public void testSubsidiariesDetails() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setSubsidiariesServiceInternal("url");
    service.setSubsidiariesServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNotNull(restService.getSubsidiariesDetails(apiParams, request));
  }
  
  @Test
  public void testSubsidiariesDetailsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setSubsidiariesServiceInternal("url");
    service.setSubsidiariesServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenThrow(httpStatusCodeException);
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
    GenericResponse actualResponse = restService.getSubsidiariesDetails(apiParams, request);
    Assert.assertNotNull(actualResponse);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getHttpStatus());
  }
  
  @Test
  public void testSubsidiariesDetailsWithHttpStatusCodeExceptionAndParseException() throws JsonMappingException, JsonProcessingException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setSubsidiariesServiceInternal("url");
    service.setSubsidiariesServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenThrow(httpStatusCodeException);
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    GenericResponse actualResponse = restService.getSubsidiariesDetails(apiParams, request);
    Assert.assertNull(actualResponse);
  }
  
  
  @Test()
  public void testSubsidiariesDetailsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setSubsidiariesServiceInternal("url");
    service.setSubsidiariesServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getSubsidiariesDetails(apiParams, request));
  }
  

  @Test
  public void testSubsidiariesDetailsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setSubsidiariesServiceInternal("url");
    service.setSubsidiariesServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getSubsidiariesDetails(apiParams, request));
  }



  @Test
  public void testGetVehicleIncentiveOptionsData() {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setVehicleServiceInternal("url");
    service.setVehicleServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNotNull(restService.getVehicleIncentiveOptionsData(apiParams, request));
  }
  
  @Test
  public void testGetVehicleIncentiveOptionsDataWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
    GenericResponseWrapper genericResponse = new GenericResponseWrapper();
    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setVehicleServiceInternal("url");
    service.setVehicleServiceExternal("url");
    service.setBackoffAttemptNum(2);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<Object>) Mockito.any())).thenThrow(new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    GenericResponse actualResponse = restService.getVehicleIncentiveOptionsData(apiParams, request);
    Assert.assertNotNull(actualResponse);
    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getHttpStatus());
  }
  
  @Test()
  public void testGetVehicleIncentiveOptionsDataErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setVehicleServiceInternal("url");
    service.setVehicleServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getVehicleIncentiveOptionsData(apiParams, request));
  }
  

  @Test
  public void testGetVehicleIncentiveOptionsDataErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setVehicleServiceInternal("url");
    service.setVehicleServiceExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getVehicleIncentiveOptionsData(apiParams, request));
  }
  
  @Test
  public void testProposalTermsDetails() {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.OK);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setProposalTermsInternal("url");
	    service.setProposalTermsExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<String>) Mockito.any())).thenReturn(new ResponseEntity<>("Test", HttpStatus.OK));
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNotNull(restService.getProposalTermsDetails(apiParams, request));
	  }
  
  @Test
  public void testProposalTermsDetailsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setProposalTermsInternal("url");
	    service.setProposalTermsExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
	    
	    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<String>) Mockito.any())).thenThrow(httpStatusCodeException);
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    String actualResponse = restService.getProposalTermsDetails(apiParams, request);
	    Assert.assertNull(actualResponse);
	  }
  
  @Test
  public void testProposalTermsDetailsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalTermsInternal("url");
    service.setProposalTermsExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getProposalTermsDetails(apiParams, request));
  }
  

  @Test
  public void testProposalTermsDetailsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setProposalTermsInternal("url");
    service.setProposalTermsExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getProposalTermsDetails(apiParams, request));
  }
  
  @Test
  public void testProposalNotesDetails() {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.OK);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setNotesServiceUrlInternal("url");
	    service.setNotesServiceUrlExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<GenericResponseWrapper>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNotNull(restService.getProposalNotesDetails(apiParams, request));
	  }
  
  @Test
  public void testProposalNotesDetailsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
	    GenericResponseWrapper genericResponse = new GenericResponseWrapper();
	    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setNotesServiceUrlInternal("url");
	    service.setNotesServiceUrlExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
	    
	    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<GenericResponseWrapper>) Mockito.any())).thenThrow(httpStatusCodeException);
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    GenericResponse actualResponse = restService.getProposalNotesDetails(apiParams, request);
	    Assert.assertNull(actualResponse);
	  }

  @Test
  public void testProposalNotesDetailsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlInternal("url");
    service.setNotesServiceUrlExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getProposalNotesDetails(apiParams, request));
  }
  

  @Test
  public void testProposalNotesDetailsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlInternal("url");
    service.setNotesServiceUrlExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getProposalNotesDetails(apiParams, request));
  }
  
  
  @Test
  public void testMultiYearPriceProtectionDetails() {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.OK);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setMultiYearPriceProtInternal("url");
	    service.setMultiYearPriceProtExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<String>) Mockito.any())).thenReturn(new ResponseEntity<>("Test", HttpStatus.OK));
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNotNull(restService.getMultiYearPriceProtectionDetails(apiParams, request));
	  }
  
  @Test
  public void testMultiYearPriceProtectionDetailsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setMultiYearPriceProtInternal("url");
	    service.setMultiYearPriceProtExternal("url");
	    service.setBackoffAttemptNum(2);
	    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
	    
	    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<String>) Mockito.any())).thenThrow(httpStatusCodeException);
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNull(restService.getMultiYearPriceProtectionDetails(apiParams, request));
	  }
  

  @Test
  public void testMultiYearPriceProtectionDetailsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setMultiYearPriceProtInternal("url");
    service.setMultiYearPriceProtExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.getMultiYearPriceProtectionDetails(apiParams, request));
  }
  

  @Test
  public void testMultiYearPriceProtectionDetailsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setMultiYearPriceProtInternal("url");
    service.setMultiYearPriceProtExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.getMultiYearPriceProtectionDetails(apiParams, request));
  }
  
  
  @Test
  public void testcreateProposalComments() {
	    GenericResponse genericResponse = new GenericResponse();
	    genericResponse.setHttpStatus(HttpStatus.OK);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setNotesServiceUrlInternal("url");
	    service.setNotesServiceUrlExternal("url");
	    service.setBackoffAttemptNum(2);
	    CreateProposalRequest request = Mockito.mock(CreateProposalRequest.class);
	    HttpServletRequest request1 = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request1.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request1.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<GenericResponse>) Mockito.any())).thenReturn(new ResponseEntity<>(responseWrapper, HttpStatus.OK));
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNotNull(restService.createProposalComments(apiParams, request,request1));
	  }
  
  @Test
  public void testcreateProposalCommentsWithHttpStatusCodeException() throws JsonMappingException, JsonProcessingException {
	    GenericResponseWrapper genericResponse = new GenericResponseWrapper();
	    genericResponse.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
	    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
	    responseWrapper.setProposalVo(new ProposalVo());
	    ApiParams apiParams = getApiParams();
	    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
	    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
	    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
	    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
	    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
	    service.setNotesServiceUrlInternal("url");
	    service.setNotesServiceUrlExternal("url");
	    service.setBackoffAttemptNum(2);
	    CreateProposalRequest request = Mockito.mock(CreateProposalRequest.class);
	    HttpServletRequest request1 = Mockito.mock(HttpServletRequest.class);
	    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
	    Mockito.when(request1.getHeader(Mockito.any())).thenReturn("Test Header");
	    Mockito.when(request1.getAttribute(Mockito.any())).thenReturn("Test attribute");
	    HttpStatusCodeException httpStatusCodeException = new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
	    
	    when(objectMapper.readValue(Mockito.anyString(), Mockito.any(Class.class))).thenReturn(genericResponse);
	    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), (Class<GenericResponse>) Mockito.any())).thenThrow(httpStatusCodeException);
	    Mockito.when(configProperties.getRestService()).thenReturn(service);
	    Assert.assertNotNull(restService.createProposalComments(apiParams, request,request1));
	    GenericResponse actualResponse = restService.createProposalComments(apiParams, request, request1);
	    Assert.assertNotNull(actualResponse);
	    assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actualResponse.getHttpStatus());
	  }
  

  @Test
  public void testcreateProposalCommentsErrorCase1() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlInternal("url");
    service.setNotesServiceUrlExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    CreateProposalRequest request1 = Mockito.mock(CreateProposalRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new RestClientResponseException(null, HttpStatus.BAD_GATEWAY.value(), null, null, null, null));
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Assert.assertNull(restService.createProposalComments(apiParams, request1,request));
  }
  

  @Test
  public void testcreateProposalCommentsErrorCase2() throws InterruptedException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalVo(new ProposalVo());
    ApiParams apiParams = getApiParams();
    ReflectionTestUtils.setField(restService, "configProperties", configProperties);
    ReflectionTestUtils.setField(restService, "restTemplate", restTemplate);
    ReflectionTestUtils.setField(restService, "objectMapper", objectMapper);
    //ReflectionTestUtils.setField(restService, "responseBuilder", responseBuilder);
    com.ford.fbms.approvalmanagement.config.RestService service = new com.ford.fbms.approvalmanagement.config.RestService();
    service.setNotesServiceUrlInternal("url");
    service.setNotesServiceUrlExternal("url");
    service.setBackoffAttemptNum(2);
    service.setBackoffLow(1);
    service.setBackoffHigh(3);
    service.setBackoffMaxInterval(1);
    CreateProposalRequest request1 = Mockito.mock(CreateProposalRequest.class);
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(responseBuilder.generateResponse(Mockito.any())).thenReturn(genericResponse);
    Mockito.when(request.getHeader(Mockito.any())).thenReturn("Test Header");
    Mockito.when(request.getAttribute(Mockito.any())).thenReturn("Test attribute");
    Mockito.when(configProperties.getRestService()).thenReturn(service);
    Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(), ArgumentMatchers.<Class<GenericResponseWrapper>>any())).thenThrow(new ResourceAccessException(null));
    Assert.assertNull(restService.createProposalComments(apiParams, request1,request));
  }
  




  @Test
  public void test_setHttpHeaders() {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    Assert.assertNotNull(restService.setHttpHeaders(httpServletRequest));
  }

  @Test
  public void test_getObjectJsonAsString() throws JsonProcessingException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    Mockito.when(objectMapper.writeValueAsString(Mockito.any())).thenReturn("");
    Assert.assertNotNull(restService.getObjectJsonAsString(genericResponse));
  }

  @Test
  public void test_getObjectJsonAsStringException() throws JsonProcessingException {
    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.OK);
    Mockito.when(objectMapper.writeValueAsString(Mockito.any()))
        .thenThrow(new JsonProcessingException("Exception") {
        });
    Assert.assertNull(restService.getObjectJsonAsString(genericResponse));
  }

  @Test
  public void test_checkResponseStatusforRetry() {
    Assert.assertTrue(restService.checkResponseStatusforRetry(403));
    Assert.assertTrue(restService.checkResponseStatusforRetry(404));
    Assert.assertTrue(restService.checkResponseStatusforRetry(502));
    Assert.assertTrue(restService.checkResponseStatusforRetry(503));
    Assert.assertTrue(restService.checkResponseStatusforRetry(504));
    Assert.assertFalse(restService.checkResponseStatusforRetry(101));
  }


  private ApiParams getApiParams() {
    ApiParams apiParams = new ApiParams();
    apiParams.setCountryCd("USA");
    apiParams.setUserId("fbmstid1");
    apiParams.setProposalKey(5222L);
    apiParams.setProposalYr(2020);
    apiParams.setProposalYrVer(5);
    apiParams.setFinKey(10000L);
    apiParams.setComplete(true);
    return apiParams;
  }

}