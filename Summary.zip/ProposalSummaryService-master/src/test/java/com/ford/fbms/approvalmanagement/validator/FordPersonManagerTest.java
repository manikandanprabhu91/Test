package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.validators.FordPersonManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class FordPersonManagerTest {

	@InjectMocks
	private FordPersonManager validator;
	@Mock
	private MasterRuleEngine ruleEngine;
	
	@Mock
	private ResponseBuilder responseBuilder;
	
	@Mock
	private FordPersonRepository fordPersonRepository;

	private ApiParams apiParams = new ApiParams();
	private FordPersonDto personDto = new FordPersonDto();

	private HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

	public ApiParams getApiParams() {
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("USA");
		return apiParams;
	}
	
	public void loadFordPersion(String cdsid) {
		personDto.setCdsid(cdsid);
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadFordPersion("FBMSTID1");
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFordPersonDto());
		assertEquals("FBMSTID1", actualGenericResponse.getFordPersonDto().getCdsid());
	}
	
	@Test
	public void testValidateAndConstructWithInavildCdsi() throws InterruptedException, ExecutionException {
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNull(actualGenericResponse.getFordPersonDto());
	}
}
