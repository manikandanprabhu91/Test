package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.PriorProposalManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class PriorProposalManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private PriorProposalManager validator;

	@Test
	public void testValidateAndConstructWithEmptyProposalExtraInfo() throws InterruptedException, ExecutionException {
		apiParams.setFinKey(1l);
		apiParams.setProposalYr(2021);
		apiParams.setProposalYrVer(2);
		when(proposalRepository.proposalByFinMasterProposalYearVersion(1l, 2021, 1)).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNull(actualGenericResponse.getPriorProposalDto());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		apiParams.setFinKey(1l);
		apiParams.setProposalYr(2021);
		apiParams.setProposalYrVer(2);
		when(proposalRepository.proposalByFinMasterProposalYearVersion(1l, 2021, 1)).thenReturn(proposalDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getPriorProposalDto());
	}

}
