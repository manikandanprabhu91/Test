package com.ford.fbms.approvalmanagement.repository;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.repository.impl.ProcedureRepositoryImpl;

/**
 * @author VSHANMU8
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ProcedureRepositoryImplTest {

	@InjectMocks
	private ProcedureRepositoryImpl repository;
	@Mock
	private EntityManager entityManager;
	@Mock
	private ConfigProperties configProperties;

	@Test
	public void testMaintainFinancialData() {
		StoredProcedureQuery query = mock(StoredProcedureQuery.class);
		when(configProperties.getSchema()).thenReturn("FBMS");
		when(entityManager.createStoredProcedureQuery(Mockito.anyString())).thenReturn(query);
		repository.updateFinancialData(1l);
	}

}
