package com.ford.fbms.approvalmanagement.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RequestModeTest {


  private final static int NUM_REQUESTMODE = 24;
  @Test
  public void testIntegrity() {
    assertEquals(NUM_REQUESTMODE, RequestMode.values().length);


  }

}