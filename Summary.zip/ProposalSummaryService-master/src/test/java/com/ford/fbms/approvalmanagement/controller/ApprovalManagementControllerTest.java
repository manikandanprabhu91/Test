package com.ford.fbms.approvalmanagement.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.ApprovalRequest;
import com.ford.fbms.approvalmanagement.service.ApprovalManagementService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.RequestMode;

/**
 * Test class for ApprovalManagementController class.
 *
 * @author NACHUTHA on 2/23/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalManagementControllerTest {

    @Spy
    @InjectMocks
    private ApprovalManagementController approvalManagementController;
    @Mock
    private ApprovalManagementService approvalManagementService;
    /*@Mock
    private DownloadProposalService downloadProposalService;*/

    /**
     * This test is to check get approval success flow.
     */
    @Test
    public void test_getApproval_success() {
        //Given
//        String cdsId = "test";
//        String countryCd = "USA";
//        Long proposalKey = 1L;
//
//        ApiParams apiParams = Mockito.mock(ApiParams.class);
//        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
//        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
//        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
//
//        //When
//        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey
//        )).thenReturn(apiParams);
//        Mockito.doReturn(genericResponse).when(approvalManagementService)
//            .getApprovalDetails(apiParams, httpServletRequest, null);
//        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));
//
//        //Then
//        Assert.assertEquals(genericResponse, approvalManagementController.getApproval(cdsId, countryCd,
//            proposalKey, httpServletRequest, httpServletResponse));
    }

    /**
     * This test is to check create approval success flow.
     */
    @Test
    public void test_createApproval_success() {
        //Given
        String cdsId = "test";
        String countryCd = "USA";
        Long proposalKey = 2L;

        ApiParams apiParams = Mockito.mock(ApiParams.class);
        new GenericResponse(HttpStatus.OK);
        Mockito.mock(ApprovalRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        Mockito.mock(HttpServletRequest.class);

        //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey
        )).thenReturn(apiParams);
      /*  Mockito.doReturn(genericResponse).when(approvalManagementService)
                .createApprovalDetails(apiParams, httpServletRequest, approvalRequest, RequestMode.CREATE_APPROVAL);*/
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
       /* Assert.assertEquals(genericResponse, approvalManagementController.createApproval(cdsId, countryCd, proposalKey,
                approvalRequest, httpServletRequest, httpServletResponse));*/
    }

    /**
     * This test is to check delete approval success flow.
     */
    @Test
    public void test_deleteApproval_success() {
        //Given
        String cdsId = "test";
        String countryCd = "USA";
        Long proposalKey = 2L;

        ApiParams apiParams = Mockito.mock(ApiParams.class);
        new GenericResponse(HttpStatus.OK);
        Mockito.mock(ApprovalRequest.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        Mockito.mock(HttpServletRequest.class);

        //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey
        )).thenReturn(apiParams);
     /*   Mockito.doReturn(genericResponse).when(approvalManagementService)
            .deleteApproval(apiParams, httpServletRequest, RequestMode.DELETE_APPROVAL);*/
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
     /*   Assert.assertEquals(genericResponse, approvalManagementController.deleteApproval(cdsId, countryCd, proposalKey,
            httpServletRequest, httpServletResponse));*/
    }


    /**
     * This test is to check get approval success flow.
     */
    @Test
    public void test_financialDataStoredProcedure_success() {
        //Given
        String cdsId = "test";
        String countryCd = "USA";
        Long proposalKey = 1L;

        ApiParams apiParams = Mockito.mock(ApiParams.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

        //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey
        )).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .financialDataStoredProcedure(apiParams, httpServletRequest, RequestMode.MAINTAIN_FINANCIAL_DATA_SP);
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
        Assert.assertEquals(genericResponse,
            approvalManagementController.financialDataStoredProcedure(cdsId, countryCd,
                proposalKey, httpServletRequest, httpServletResponse));
    }
    
    
    
    @Test
    public void test_populateApprovalChain_success()
         {
    	String  cdsId = "testUser";
    	String countryCd = "USA";
    	Long proposalKey = 2L;
    	
    	ApiParams apiParams = Mockito.mock(ApiParams.class);
    	HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        
      //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey)).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVAL_CHAIN, httpServletResponse);
        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.populateApprovalChain("testUser","USA", 2L,
                httpServletRequest, httpServletResponse));
     
    }
    
    @Test
    public void test_populateApprovalChain_failure()
         {
    	String  cdsId = "testUser";
    	String countryCd = "USA";
    	Long proposalKey = 2L;
    	
    	ApiParams apiParams = Mockito.mock(ApiParams.class);
    	HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.NO_CONTENT);
        
      /*  GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
        responseWrapper.setApprovalChainList(new ArrayList<>());
        responseWrapper.setGenericResponse(genericResponse);*/
        
      //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey)).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.APPROVAL_CHAIN, httpServletResponse);
        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.populateApprovalChain("testUser","USA", 2L,
                httpServletRequest, httpServletResponse));
     
    }
    
    
	@Test
	public void test_submitProposal_success() {
		getApiParams("SUBMIT_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.SUBMIT_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "SUBMIT_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_recallProposal_success() {
		getApiParams("RECALL_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.RECALL_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "RECALL_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_saveProposal_success() {
		getApiParams("SAVE_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.SAVE_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "SAVE_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_sendBackProposal_success() {
		getApiParams("SENDBACK_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.SENDBACK_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "SENDBACK_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_rejectProposal_success() {
		getApiParams("REJECT_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.REJECT_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "REJECT_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_reviseProposal_success() {
		getApiParams("REVISE_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.REVISE_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "REVISE_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
	
	@Test
	public void test_approveProposal_success() {
		getApiParams("APPROVE_PROPOSAL");
		getCreateProposalRequest();
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.CREATED);

		// When
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.APPROVE_PROPOSAL, httpServletResponse);
		// Then
		Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "APPROVE_PROPOSAL", false, httpServletRequest, httpServletResponse));

	}
	
    private ApiParams apiParams = new ApiParams();
    private CreateProposalRequest createProposalRequest = new CreateProposalRequest();
    
    private ApiParams getApiParams(String action) {
		apiParams.setUserId("testUser");
		apiParams.setCountryCd("USA");
		apiParams.setComments(getCreateProposalRequest());
		apiParams.setProposalKey(2L);
		apiParams.setAction(action);
		apiParams.setHighPriority(false);
		return apiParams;
	}
    
    private CreateProposalRequest getCreateProposalRequest() {
		createProposalRequest.setCdsid("testUser");
		createProposalRequest.setInProcess("Y");
		createProposalRequest.setProposalKey(2L);
		createProposalRequest.setProposalNoteDescription("commentsDesc");
		createProposalRequest.setStatusCd("SUB");
		return createProposalRequest;
	}
    
    private ApiParams getFinancialApiParams(String dataSource) {
    	apiParams.setUserId("testUser");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(2L);
		apiParams.setProposalYr(2020);
		apiParams.setProposalYrVer(2);
		apiParams.setFinKey(1l);
		apiParams.setVolumeFinancialDataSource(dataSource);
		apiParams.setFleetRating("TEST_RATING");
		return apiParams;
    }
    
	


    /**
     * This test download to excel flow.
     */
    @Test
    public void test_downloadProposal_success() {
        //Given
        String cdsId = "test";
        String countryCd = "USA";
        Long proposalKey = 1L;
        Integer proposalYr = 2020;
        Integer proposalYrVer = 5;
        Long finKey = 1743L;
        boolean isComplete = true;
        String volFinance = "5_pact_svm_vs_cfct_mvm";
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
        responseWrapper.setProposalDownload("test data");
        //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer, finKey, isComplete, volFinance)).thenReturn(apiParams);
        Mockito.doReturn(responseWrapper).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL, httpServletResponse);
        //Then
        Assert.assertNotNull(approvalManagementController.downloadProposal(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer,
            finKey, isComplete, volFinance, httpServletRequest, httpServletResponse));
    }

    /**
     * This test download to excel flow.
     */
    @Test
    public void test_downloadProposal_failure() {
        //Given
        String cdsId = "test";
        String countryCd = "USA";
        Long proposalKey = 1L;
        Integer proposalYr = 2020;
        Integer proposalYrVer = 5;
        Long finKey = 1743L;
        boolean isComplete = true;
        String volFinance = "5_pact_svm_vs_cfct_mvm";

        ApiParams apiParams = Mockito.mock(ApiParams.class);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
        //When
        Mockito.when(approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer, finKey, isComplete, volFinance)).thenReturn(apiParams);
        Mockito.doReturn(responseWrapper).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.DOWNLOAD_PROPOSAL, httpServletResponse);
        //Then
        Assert.assertNotNull(approvalManagementController.downloadProposal(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer,
            finKey, isComplete, volFinance, httpServletRequest, httpServletResponse));
    }
	
	@Test
    public void test_get_VolumeFinancialOption_success() {
        
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        
        //When
        Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong()
        )).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS, httpServletResponse);
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.getVolumeFinancialOption("testUser","USA", 2L,
            httpServletRequest, httpServletResponse));
    }
	
	@Test
    public void test_getTotalAvgFinancials_success() {
        
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        
        //When
        Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(),Mockito.anyString(),Mockito.anyString()
        )).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_TOTALS_AVG_FINANICIALS, httpServletResponse);
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.getTotalAvgFinancials("testUser","USA", 2L,"6_pest_mvm_vs_cest_mvm","B",
            httpServletRequest, httpServletResponse));
    }
	
	@Test
    public void test_getProposalNotesDetails_success() {
        
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
        genericResponseWrapper.setGenericResponse(genericResponse);
        
        //When
        Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(),Mockito.any(),Mockito.anyLong(),Mockito.any(),Mockito.any(),Mockito.any(),Mockito.any()
        )).thenReturn(apiParams);
        Mockito.doReturn(genericResponseWrapper).when(approvalManagementService)
            .getProposalNotesDetails(apiParams, httpServletRequest, RequestMode.GET_PROSAL_NOTES);
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
        Assert.assertEquals(genericResponseWrapper, approvalManagementController.retrieveProposalNotesDetails("testUser","USA",2L,httpServletRequest,httpServletResponse));
    }
    
    @Test
    public void test_get_ValidateAction_success() {
    	
        
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
        HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        
        //When
        Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong()
        )).thenReturn(apiParams);
        Mockito.doReturn(genericResponse).when(approvalManagementService)
            .processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.VALIDATE_ACTIONS,httpServletResponse);
        Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));

        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.getValidateActions("testUser","USA", 2L,
            httpServletRequest, httpServletResponse));
    }

    @Test
	public void test_getFinancialListPriorEstMlvCurrentEstMlvCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_FINANCIAL_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_getFinancialListPriorActMlvVmCurrentActMlvVmCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_ACTUAL_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));
	}
	
	@Test
	public void test_getFinancialListPriorActCurrentActMlvVmCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_ACTUAL_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_ACT_CURR_ACT_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));
	}
	
	@Test
	public void test_getFinancialListPriorActCurrentActCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_ACTUAL_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_ACT_CURR_ACT_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));
	}
	
	@Test
	public void test_getFinancialListPriorActMlvVmCurrentFstMlvVmCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_FORECAST_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_getFinancialListPriorActCurrentFstMlvVmCode() {
		getFinancialApiParams(ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE);
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);

		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams, httpServletRequest, RequestMode.GET_FORECAST_LIST, httpServletResponse);
		Assert.assertEquals(genericResponse, approvalManagementController.getFinancialList("testUser", "USA",
				2L,2020,2,1l, "PRIOR_ACT_CURR_FCT_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse));

	}
	
	@Test(expected=NullPointerException.class)
	public void test_getFinancialListInvalidResource() {
		getFinancialApiParams("INVALID");
		HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.anyLong(), Mockito.anyInt(), Mockito.anyInt(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyString())).thenReturn(apiParams);
		 approvalManagementController.getFinancialList("testUser", "USA",
					2L,2020,2,1l, "PRIOR_ACT_CURR_FCT_MLV_VM_CODE", "TEST_RATING", httpServletRequest, httpServletResponse);
	}
	
	@Test
	public void test_nextDealApproveProposal_success() {
		getApiParams("NEXTDEAL_APPROVE");
		//getCreateProposalRequest();
        HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
		HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		GenericResponse genericResponse = new GenericResponse(HttpStatus.OK);
        
        //When
        Mockito.when(approvalManagementService.buildApiParams(Mockito.anyString(), Mockito.anyString(), Mockito.any(),
				Mockito.anyLong(), Mockito.anyString(), Mockito.anyBoolean())).thenReturn(apiParams);
        
		Mockito.doReturn(genericResponse).when(approvalManagementService).processSummaryAndSubmit(apiParams,
				httpServletRequest, RequestMode.NEXTDEAL_APPROVE, httpServletResponse);

        //Then
        Assert.assertEquals(genericResponse, approvalManagementController.processProposal("testUser", "USA",
				createProposalRequest, 2L, "NEXTDEAL_APPROVE", false, httpServletRequest, httpServletResponse));

	}
	
	@Test
	public void test_retrieveMultiYrPriceProtDetails() {
		
		when(approvalManagementService.getMultiYearPriceProtectionDetails(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn("Data");
		
		 HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
			HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
		assertEquals("Data", approvalManagementController.retrieveMultiYrPriceProtDetails("testUser", "USA",
				2L, 2L, 1,1, httpServletRequest, httpServletResponse));
	}


}