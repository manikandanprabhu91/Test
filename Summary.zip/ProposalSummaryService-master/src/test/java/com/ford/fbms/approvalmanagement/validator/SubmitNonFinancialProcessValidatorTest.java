package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.BodyStyleDto;
import com.ford.fbms.approvalmanagement.domain.PaymentTypeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.SubmitNonFinancialProcessValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class SubmitNonFinancialProcessValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private SubmitNonFinancialProcessValidator validator;
	
	@Mock
	  protected ProposalStatusRepository proposalStatusRepo;
	
	private ProposalDto sourceProposal = new ProposalDto();
	
	private void loadSourceProposalDto() {
		sourceProposal.setCntlReqdFlag(true);
		sourceProposal.setLongTermDemoR(new BigDecimal(1));
	}
	
	private List<ProposalVehicleLineIncentiveDto> sourcePviDtos = new ArrayList<>();
	private ProposalVehicleLineIncentiveDto sourcePviDto = new ProposalVehicleLineIncentiveDto();
	protected ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
	protected ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0015");
    	when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0015", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(false);
		loadProposalDto();
		approvalResponseVo.setProposalStatus("URV");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		//when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	
	@Test
	public void testValidateAndConstructWithNonFinancialMode() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithNonFinancialModeAndSourceProposal() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, null);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithNonFinancialModeAndSourceProposalAndAPVStatus() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "APV");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithNonFinancialModeAndSourceProposalAndESTStatus() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithNonFinancialModeAndSourceProposalAndESTStatusAndURVStatus() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalStatus("URV");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(2021, 1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithNonFinancialModeAndSourceProposalAndESTStatusAndSubSidiary() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	//
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByQfcFlag() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		sourceProposal.setQfcFlag(true);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByXplanRequiredFlag() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		sourceProposal.setXplanRequiredFlag(true);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByPaymentType() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("SourceCode");
		sourceProposal.setPaymentType(paymentTypeDto);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByChangeInCpaLetterMin() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		sourceProposal.setPaymentType(paymentTypeDto);
		sourceProposal.setLetterMinQty(new BigDecimal(2));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByPaymentRoute() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		sourceProposal.setPaymentType(paymentTypeDto);
		sourceProposal.setLetterMinQty(new BigDecimal(1));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto)).thenReturn(Optional.empty());
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByChangeInTier1Flag() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		BodyStyleDto bodyStyleDto = new BodyStyleDto();
		bodyStyleDto.setBodyStyleSaKey(1l);
		sourceProposal.setPaymentType(paymentTypeDto);
		sourceProposal.setLetterMinQty(new BigDecimal(1));
		sourcePviDto.setTier1InctvToDlrFlag("Y");
		sourcePviDto.setBodyStyle(bodyStyleDto);
		sourcePviDtos.add(sourcePviDto);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos)).thenReturn(Optional.of(sourcePviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByChangeInSubFin() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		sourceProposal.setPaymentType(paymentTypeDto);
		sourceProposal.setLetterMinQty(new BigDecimal(1));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos)).thenReturn(Optional.of(proposalSubsidiaryDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	@Test
	public void testValidateAndConstructWithDifferentProposalByLongTermDemoR() throws InterruptedException, ExecutionException {
		loadNonFinancialFlag(true);
		loadProposalDto();
		loadSourceProposal(2l, "EST");
		loadPaymentType();
		loadProposalSummaryViewDto("PaymentRoutingCode");
		loadProposalVehicleLineIncentiveDto(1l);
		loadProposalSubsidiaryDto();
		loadSourceProposalDto();
		PaymentTypeDto paymentTypeDto = new PaymentTypeDto();
		paymentTypeDto.setPaymentTypeCode("Code");
		sourceProposal.setPaymentType(paymentTypeDto);
		sourceProposal.setLetterMinQty(new BigDecimal(1));
		sourceProposal.setLongTermDemoR(BigDecimal.ONE);
		proposalDto.setProposalSubsidiaryList(null);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto)).thenReturn(Optional.of(sourceProposal));
		when(proposalSummaryViewRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalVehicleLineRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalResponseNonFinancialVo());
	}
	
	

	
}
