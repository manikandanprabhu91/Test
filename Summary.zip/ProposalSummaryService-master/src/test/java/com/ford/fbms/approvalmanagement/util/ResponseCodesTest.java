package com.ford.fbms.approvalmanagement.util;

import org.apache.http.HttpStatus;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * This test class is written to perform unit testing for class ResponseCodes
 *
 * @author AGOVADA on 02/10/2021
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ResponseCodesTest {

    /**
     * The method is a test method to test the isSuccess ResponseCode
     */
    @Test
    public void isSuccess() {
        Assert.assertTrue(ResponseCodes.SUCCESS.isSuccess());
    }

    /**
     * The method is a test method to test the getHttpStatus ResponseCode
     */
    @Test
    public void getHttpStatus() {
        Assert.assertEquals(ResponseCodes.SUCCESS.getHttpStatus().value(), HttpStatus.SC_OK);
    }

    /**
     * The method is a test method to test the getMsgId ResponseCode
     */
    @Test
    public void getMsgId() {
        Assert.assertEquals(ResponseCodes.SUCCESS.getMsgId(), "MSG-0001");
    }

    /**
     *
     */
    @Test
    public void values() {
    }

    /**
     *
     */
    @Test
    public void valueOf() {
    }
}