package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalManagementValidatorTest extends AbstarctValidatorTest {

	@InjectMocks
	private ApprovalManagementValidator validator;

	@Test
	public void testValidateAndConstructWithEmptyProposalExtraInfo() throws InterruptedException, ExecutionException {
		when(approvalProcessRepository.findApprovalProcessById(1l)).thenReturn(Collections.emptyList());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNull(actualGenericResponse.getApprovalProcessDtoList());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		when(approvalProcessRepository.findApprovalProcessById(1l)).thenReturn(Arrays.asList(approvalProcessDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalProcessDtoList());
	}

}
