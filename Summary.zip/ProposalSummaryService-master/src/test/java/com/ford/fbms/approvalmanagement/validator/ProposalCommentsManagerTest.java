package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalViewDto;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.ProposalCommentsManager;

/**
 * Test class for ProposalCommentsManagerTest class.
 *
 * @author SJAGATJO on 6/1/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ProposalCommentsManagerTest {

  @Spy
  @InjectMocks
  private ProposalCommentsManager proposalCommentsManager;
  @Mock
  private RestService restService;
  @Mock
  private HttpServletRequest httpRequest;

  @Test
  public void testValidateAndConstruct() throws ExecutionException, InterruptedException {
    ApiParams apiParams = new ApiParams();
    apiParams.setUserId("FBMSTID1");
    apiParams.setCountryCd("USA");
    apiParams.setProposalYrVer(2);
    apiParams.setProposalYr(2020);
    ProposalViewDto viewDto = new ProposalViewDto();
    viewDto.setFinkey("1743");
    viewDto.setProposalVersion("2");
    viewDto.setProposalComments("added comments");
    viewDto.setProposalYear("2020");
    viewDto.setInProcess("N");
    viewDto.setDateSubmitted(new Date());
    viewDto.setProposalNoteKey(13564L);
    viewDto.setCommentedBy("FBMSTID1");
    List<ProposalViewDto> proposalNotesRetrivalDtos = Collections.singletonList(viewDto);
    GenericResponseWrapper responseWrapper = new GenericResponseWrapper();
    responseWrapper.setProposalNotesRetrival(proposalNotesRetrivalDtos);
    Mockito.when(restService.getProposalComments(apiParams, httpRequest)).thenReturn(responseWrapper);
    assertNotNull(proposalCommentsManager
        .validateAndConstruct(apiParams, null, null,httpRequest).get().getProposalNotesRetrival());
  }
}