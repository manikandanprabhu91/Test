package com.ford.fbms.approvalmanagement.config;

import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtDecoder;

/*
 * This test class is written to perform unit testing for AdfsConfig class.
 *
 * @author SJAGATJO on 2/9/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class AdfsConfigTest {

  @Autowired
  private transient JwtDecoder jwtDecoder;
  /*
   *This method is used to test createExpressionHandler Method.
   *
   */
  @Test
  public void testCreateExpressionHandler() throws Exception {
    ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
    AdfsPermissionEvaluator adfsPermissionEvaluator = new AdfsPermissionEvaluator(configProperties);
    AdfsConfig AdfsConfig = new AdfsConfig(adfsPermissionEvaluator);
    Assert.assertNotNull(AdfsConfig.createExpressionHandler());
  }

  /*
   *This method is used to test configure Method.
   *
   */
  @Test
  @Ignore
  public void testConfigure() throws Exception { //TODO
    HttpSecurity http = Mockito.mock(HttpSecurity.class);
    //Mockito.when(http.antMatcher("/putControllerEndpointHere/**")).thenReturn(http);
    Mockito.when(http
        .antMatcher("/approval-management-service/**")
        .authorizeRequests()
        .anyRequest().authenticated()
        .and()
        .sessionManagement()
        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .oauth2ResourceServer()
        .jwt()
        .decoder(jwtDecoder)).thenReturn(null);
    AdfsConfig.ResourceServerSecurityConfiguration adfsConfig = new AdfsConfig.ResourceServerSecurityConfiguration();
    adfsConfig.configure(http);
  }
}
