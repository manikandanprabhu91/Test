package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.AccountAssignmentDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryPK;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.SubfinManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class SubfinManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private SubfinManager validator;
	
	private FinMasterDto subFinMasterDto = new FinMasterDto();
	private ProposalSubsidiaryDto subProposalSubsidiaryDto = new ProposalSubsidiaryDto();
	private List<ProposalSubsidiaryDto> subProposalSubsidiaryDtos = new ArrayList<>();
	
	private void loadSubFinData(){
		subFinMasterDto.setFinMasterKey(3l);
		ProposalSubsidiaryPK proposalSubsidiaryPK =  new ProposalSubsidiaryPK();
		proposalSubsidiaryPK.setSubFinMaster(subFinMasterDto);
		subProposalSubsidiaryDto.setProposalSubsidiaryPK(proposalSubsidiaryPK);
		subProposalSubsidiaryDtos.add(subProposalSubsidiaryDto);
	}

	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(2l)).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithEmptySubsidiary() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithEmptySubsidiaryAndMaxEstUrvProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndMaxEstUrvProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalSubsidiaryDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndEmptyMaxEstUrvProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos)).thenReturn(Optional.empty());
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndEmptyListMaxEstUrvProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalSubsidiaryDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}

	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndMaxEstUrvProposalActiveEligFinMaster() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalSubsidiaryDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		when(finMasterRepository.findActiveAndEligibleFinMasterByFinMaster(1l)).thenReturn(finMasterDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndMaxEstUrvProposalAndDifferenFinMaster() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalSubsidiaryDto();
		loadSubFinData();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		GenericResponse actualGenericResponse = new GenericResponse();
		actualGenericResponse.setMsgId("MSG-0083");
		actualGenericResponse.setMsgDesc("test");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos)).thenReturn(Optional.of(subProposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIN)).thenReturn(actualGenericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		actualGenericResponse = wrapper.get();
		genericResponseWrapper.setGenericResponse(actualGenericResponse);
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithSubsidiaryAndMaxEstUrvProposalAndDifferenFinMasterActiveEligFinMaster() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadProposalSubsidiaryDto();
		loadSubFinData();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		GenericResponse actualGenericResponse = new GenericResponse();
		actualGenericResponse.setMsgId("MSG-0083");
		actualGenericResponse.setMsgDesc("test");

		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proposalSubsidiaryDtos)).thenReturn(Optional.of(subProposalSubsidiaryDtos));
		when(proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(2021,1l)).thenReturn(Optional.of(proposalDto));
		when(finMasterRepository.findEligibleFinBySubFinProposalYearCountry(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(finMasterDto));
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIN)).thenReturn(actualGenericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		actualGenericResponse = wrapper.get();
		genericResponseWrapper.setGenericResponse(actualGenericResponse);
		assertNotNull(actualGenericResponse);
	}
	
}
