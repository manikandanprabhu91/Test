package com.ford.fbms.approvalmanagement.controller;

import org.junit.Assert;
import org.junit.Test;

/**
 * @author MKALLATA
 * @created 20/04/2021 - 5:12 AM
 */
public class SwaggerRouterTest {


    @Test
    public void getApiInfo() {
        SwaggerRouter swaggerRouter = new SwaggerRouter();
        Assert.assertNotNull(swaggerRouter.getApiInfo());
    }
}