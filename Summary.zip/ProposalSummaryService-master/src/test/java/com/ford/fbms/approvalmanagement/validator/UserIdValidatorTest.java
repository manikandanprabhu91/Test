package com.ford.fbms.approvalmanagement.validator;

import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.validators.UserIdValidator;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

/**
 * Test class for MasterRuleEngine class.
 *
 * @author SNITHY11 on 2/8/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class UserIdValidatorTest {

  @Spy
  @InjectMocks
  private UserIdValidator userIdValidator;

  @Spy
  private ResponseBuilder responseBuilder;
  
  @Mock
  private HttpServletRequest httpRequest;

  /**
   * This test is to validate user id validation - positive flow. Method return NULL ment for
   * success scenario, NOT NULL for failure scenario.
   */
  @Test
  public void should_return_no_error() {
    //Given
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId("TestuserId");

    //When
    /*Future<GenericResponseWrapper> genericResponseFuture = userIdValidator
        .validateAndConstruct(apiParams, null, null, httpRequest);

    //Then
    Assert.assertNotNull(genericResponseFuture);
    try {
      GenericResponse genericResponse = (GenericResponse) genericResponseFuture.get();
      Assert.assertNull(genericResponse);
    } catch (InterruptedException e) {
      Assert.fail("InterruptedException");
    } catch (ExecutionException e) {
      Assert.fail("ExecutionException");
    }*/
  }

  /**
   * This test is to validate user id validation - Failure scenario. Method return NULL ment for
   * success scenario, NOT NULL for failure scenario.
   */
  @Test
  public void should_return_an_error() {
    //Given
    final ApiParams apiParams = new ApiParams();

    //When
   /* Future<GenericResponseWrapper> genericResponseFuture = userIdValidator
        .validateAndConstruct(apiParams, null, null, httpRequest);

    //Then
    Assert.assertNotNull(genericResponseFuture);
    try {
      GenericResponse genericResponse = (GenericResponse) genericResponseFuture.get();
      Assert.assertNotNull(genericResponse);
      Assert.assertEquals(HttpStatus.PRECONDITION_FAILED, genericResponse.getHttpStatus());
      Assert.assertEquals("MSG-0053", genericResponse.getMsgId());
    } catch (InterruptedException e) {
      Assert.fail("InterruptedException");
    } catch (ExecutionException e) {
      Assert.fail("ExecutionException");
    }*/
  }

  /**
   * This test is to validate user id validation - Exception scenario. Method return NULL ment for
   * success scenario, NOT NULL for failure scenario.
   */
//  @Test(expected = Exception.class)
  public void should_throw_an_error() {
    //Given

    //When
  /*  Future<GenericResponseWrapper> genericResponseFuture = userIdValidator
        .validateAndConstruct(null, null,null, httpRequest);*/
  }

}
