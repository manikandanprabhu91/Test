package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.repository.CustomerAcceptanceS3Repository;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.CustomerAcceptanceManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomerAcceptanceManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private CustomerAcceptanceManager validator;
	
	@Mock
	private CustomerAcceptanceS3Repository customerAcceptanceS3Repository;
	
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		proposalDto.setSourceProposalCode(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(customerAcceptanceS3Repository.findCurrentProposal(1l)).thenReturn(new CustomerAcceptanceS3Dto());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getCustomerAcceptanceS3Dto());
	}
	
	@Test
	public void testValidateAndConstructWithNullCustomerAcceptanceS3Dto() throws InterruptedException, ExecutionException {
		loadProposalDto();
		proposalDto.setSourceProposalCode(1l);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNull(actualGenericResponse.getCustomerAcceptanceS3Dto());
	}
	
	
}
