package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.SDATier1Manager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class SDATier1ManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private SDATier1Manager validator;

	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(2);
		loadProposalAssignAttributeDto("Y");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.empty());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	@Test
	public void testValidateAndConstructWithProposalAssigneeFinMaster() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(2);
		loadProposalAssignAttributeDto("Y");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(proposalAssignAttributeDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithProposalAssigneeFinMasterNFlag() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(2);
		loadProposalAssignAttributeDto("N");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterActive(Mockito.anyLong())).thenReturn(Optional.of(proposalAssignAttributeDtos));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithAccountManageLevel() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(7);
		loadProposalAssignAttributeDto("Y");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithAccountManageLevelProposalAssigneeFinMasterCdsid() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(7);
		loadProposalAssignAttributeDto("Y");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(proposalAssignAttributeDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithAccountManageLevelProposalAssigneeFinMasterCdsidNFlag() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(7);
		loadProposalAssignAttributeDto("N");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(proposalAssignAttributeDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithPaymentRouting() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(2);
		loadProposalAssignAttributeDto("Y");
		loadProposalSummaryViewDto("None");
		when(proposalSummaryViewRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(proposalAssignAttributeDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithPaymentRoutingSDA() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadFordPersion("FBMSTID1");
		loadReportLevel(2);
		loadProposalAssignAttributeDto("Y");
		loadProposalSummaryViewDto("SDA");
		when(proposalSummaryViewRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalSummaryViewDto));
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(fordPersonDto));
		when(proposalAssignAttributeRepository.findProposalAssignAttributeByFinMasterCdsid(Mockito.anyLong(), Mockito.anyString())).thenReturn(proposalAssignAttributeDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test(expected=NullPointerException.class)
	public void testValidateAndConstructWithInvalidUser() {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
	}

	
}
