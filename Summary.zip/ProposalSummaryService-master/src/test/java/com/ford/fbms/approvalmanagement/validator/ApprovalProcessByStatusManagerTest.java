package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.ApprovalProcessByStatusManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalProcessByStatusManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private ApprovalProcessByStatusManager validator;
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		when(approvalProcessRepository.findApprovalProcessByProposalStatus(1l)).thenReturn(approvalProcessDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getApprovalProcessDto());
	}
	
}
