package com.ford.fbms.approvalmanagement.util;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Timestamp;
import java.util.Date;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author VSHANMU8
 *
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class FbmsComparatorTest {
	
	FbmsComparator comparator;
	
	@Getter
	@Setter
	public static class TestData {
		private Float floatValue;
		private float smallFloatValue;
		private double doubleValue;
		private Date dateValue;
		private Timestamp timesTampValue;
	}
	
	@Test
	public void testCompareWithRuntimeException() {
		comparator = new FbmsComparator("sourceProposalCode");
		ProposalDto source = new ProposalDto();
		ProposalDto destination = new ProposalDto();
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithLongEqual() {
		comparator = new FbmsComparator("proposalSaKey");
		ProposalDto source = new ProposalDto();
		source.setProposalSaKey(0);
		ProposalDto destination = new ProposalDto();
		destination.setProposalSaKey(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithSmallIntEqual() {
		comparator = new FbmsComparator("versionNumber");
		ProposalDto source = new ProposalDto();
		source.setVersionNumber(0);
		ProposalDto destination = new ProposalDto();
		destination.setVersionNumber(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithSmallIntLess() {
		comparator = new FbmsComparator("versionNumber");
		ProposalDto source = new ProposalDto();
		source.setVersionNumber(-1);
		ProposalDto destination = new ProposalDto();
		destination.setVersionNumber(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithDateEqual() {
		comparator = new FbmsComparator("dateValue");
		TestData source = new TestData();
		source.setDateValue(new Date());
		TestData destination = new TestData();
		destination.setDateValue(new Date());
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithDateLess() {
		comparator = new FbmsComparator("dateValue");
		TestData source = new TestData();
		source.setDateValue(new Date(System.currentTimeMillis()+(2 * 24 * 60 * 60 * 1000)));
		TestData destination = new TestData();
		destination.setDateValue(new Date());
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithDateGreater() {
		comparator = new FbmsComparator("dateValue");
		TestData source = new TestData();
		source.setDateValue(new Date());
		TestData destination = new TestData();
		destination.setDateValue(new Date(System.currentTimeMillis()+(2 * 24 * 60 * 60 * 1000)));
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	@Ignore
	public void testCompareWithTimestampEqual() {
		comparator = new FbmsComparator("timesTampValue");
		TestData source = new TestData();
		source.setTimesTampValue(new Timestamp(new Date().getTime()));
		TestData destination = new TestData();
		destination.setTimesTampValue(new Timestamp(new Date().getTime()));
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithTimestampLess() {
		
		comparator = new FbmsComparator("timesTampValue");
		TestData source = new TestData();
		source.setTimesTampValue(new Timestamp(new Date(System.currentTimeMillis()+(2 * 24 * 60 * 60 * 1000)).getTime()));
		TestData destination = new TestData();
		destination.setTimesTampValue(new Timestamp(new Date().getTime()));
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithTimestampGreater() {
		
		comparator = new FbmsComparator("timesTampValue");
		TestData source = new TestData();
		source.setTimesTampValue(new Timestamp(new Date().getTime()));
		TestData destination = new TestData();
		destination.setTimesTampValue(new Timestamp(new Date(System.currentTimeMillis()+(2 * 24 * 60 * 60 * 1000)).getTime()));
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithFloatEqual() {
		comparator = new FbmsComparator("floatValue");
		TestData source = new TestData();
		source.setFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setFloatValue(3.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithFloatLess() {
		comparator = new FbmsComparator("floatValue");
		TestData source = new TestData();
		source.setFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setFloatValue(2.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithFloatGreater() {
		comparator = new FbmsComparator("floatValue");
		TestData source = new TestData();
		source.setFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setFloatValue(4.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithDoubleEqual() {
		comparator = new FbmsComparator("doubleValue");
		TestData source = new TestData();
		source.setDoubleValue(3.3);
		TestData destination = new TestData();
		destination.setDoubleValue(3.3);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithDoubleLess() {
		comparator = new FbmsComparator("doubleValue");
		TestData source = new TestData();
		source.setDoubleValue(1);
		TestData destination = new TestData();
		destination.setDoubleValue(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithDoubleGreater() {
		comparator = new FbmsComparator("doubleValue");
		TestData source = new TestData();
		source.setDoubleValue(3);
		TestData destination = new TestData();
		destination.setDoubleValue(4);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithSmallFloatEqual() {
		comparator = new FbmsComparator("smallFloatValue");
		TestData source = new TestData();
		source.setSmallFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setSmallFloatValue(3.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithSmallFloatLess() {
		comparator = new FbmsComparator("smallFloatValue");
		TestData source = new TestData();
		source.setSmallFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setSmallFloatValue(2.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithSmallFloatGreater() {
		comparator = new FbmsComparator("smallFloatValue");
		TestData source = new TestData();
		source.setSmallFloatValue(3.3f);
		TestData destination = new TestData();
		destination.setSmallFloatValue(4.3f);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	@Test
	public void testCompareWithSmallIntGreater() {
		comparator = new FbmsComparator("versionNumber");
		ProposalDto source = new ProposalDto();
		source.setVersionNumber(-1);
		ProposalDto destination = new ProposalDto();
		destination.setVersionNumber(-2);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithLongLess() {
		comparator = new FbmsComparator("proposalSaKey");
		ProposalDto source = new ProposalDto();
		source.setProposalSaKey(0);
		ProposalDto destination = new ProposalDto();
		destination.setProposalSaKey(1);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}

	@Test
	public void testCompareWithIntegerEqual() {
		comparator = new FbmsComparator("letterStatus");
		CustomerAcceptanceS3Dto source = new CustomerAcceptanceS3Dto();
		source.setLetterStatus(1);
		CustomerAcceptanceS3Dto destination = new CustomerAcceptanceS3Dto();
		destination.setLetterStatus(1);
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithIntegerLess() {
		comparator = new FbmsComparator("letterStatus");
		CustomerAcceptanceS3Dto source = new CustomerAcceptanceS3Dto();
		source.setLetterStatus(0);
		CustomerAcceptanceS3Dto destination = new CustomerAcceptanceS3Dto();
		destination.setLetterStatus(1);
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	@Test
	public void testCompareWithIntegerGreater() {
		comparator = new FbmsComparator("letterStatus");
		CustomerAcceptanceS3Dto source = new CustomerAcceptanceS3Dto();
		source.setLetterStatus(1);
		CustomerAcceptanceS3Dto destination = new CustomerAcceptanceS3Dto();
		destination.setLetterStatus(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithLongGreater() {
		comparator = new FbmsComparator("proposalSaKey");
		ProposalDto source = new ProposalDto();
		source.setProposalSaKey(1);
		ProposalDto destination = new ProposalDto();
		destination.setProposalSaKey(0);
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithSourceNotNullAndDestNotNull() {
		comparator = new FbmsComparator("createdProcess");
		ProposalDto source = new ProposalDto();
		source.setCreatedProcess("CREATE");
		ProposalDto destination = new ProposalDto();
		destination.setCreatedProcess("CREATE");
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithSourceNullAndDestNull() {
		comparator = new FbmsComparator("createdProcess");
		ProposalDto source = new ProposalDto();
		ProposalDto destination = new ProposalDto();
		int returnData = comparator.compare(source, destination);
		assertEquals(0, returnData);
	}
	
	@Test
	public void testCompareWithSourceNotNullAndDestNull() {
		comparator = new FbmsComparator("createdProcess");
		ProposalDto source = new ProposalDto();
		source.setCreatedProcess("CREATE");
		ProposalDto destination = new ProposalDto();
		int returnData = comparator.compare(source, destination);
		assertEquals(1, returnData);
	}
	
	@Test
	public void testCompareWithSourceNullAndDestNotNull() {
		comparator = new FbmsComparator("createdProcess");
		ProposalDto source = new ProposalDto();
		ProposalDto destination = new ProposalDto();
		destination.setCreatedProcess("CREATE");
		int returnData = comparator.compare(source, destination);
		assertEquals(-1, returnData);
	}
	
	

}
