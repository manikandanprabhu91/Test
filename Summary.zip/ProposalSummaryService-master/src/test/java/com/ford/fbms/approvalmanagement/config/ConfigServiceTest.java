package com.ford.fbms.approvalmanagement.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
/*
 * This test class is written to perform unit testing for ConfigService class.
 *
 * @author SJAGATJO on 2/9/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class ConfigServiceTest {

  /*
   *This method is used to test getAsyncScopeAwareExecutor method.
   *
   */
  @Test
  public void testGetAsyncScopeAwareExecutor() throws Exception {
    ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
    TaskExecutorConfig taskExecutorConfig = new TaskExecutorConfig();
    taskExecutorConfig.setCorePoolSize(5);
    configProperties.setTaskExecuter(taskExecutorConfig);
    ConfigService configService = new ConfigService(configProperties);
    Assert.assertNotNull(configService.getAsyncScopeAwareExecutor());
  }

  /*
   *This method is used to test requestScopedCapDataStore method.
   *
   */
  @Test
  public void testRequestScopedCapDataStore() throws Exception {
    ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
    ConfigService configService = new ConfigService(configProperties);
    Assert.assertNotNull(configService.requestScopedCapDataStore());
  }
  
  @Test
  public void testConfigureRestTemplate() {
	  RestService restService = new RestService();
	  restService.setConnectTimeout(5);
	  restService.setReadTimeout(5);
	  ConfigProperties configProperties = Mockito.spy(ConfigProperties.class);
	  configProperties.setRestService(restService);
	  ConfigService configService = new ConfigService(configProperties);
	  Assert.assertNotNull(configService.configureRestTemplate());
	
}
  
  
}