package com.ford.fbms.approvalmanagement.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

/*
 * This test class is written to perform unit testing for MethodInterceptor class.
 *
 * @author SJAGATJO on 2/9/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MethodInterceptorTest {

  @Spy
  @InjectMocks
  private MethodInterceptor methodInterceptor;

  /*
   * This method is used to test the positive case for preHandle Method.
   *
   */
  @Test
  public void testPreHandleWithValidHttpMethod() throws Exception {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(httpServletRequest.getMethod()).thenReturn("GET");
    Assert.assertTrue(methodInterceptor.preHandle(httpServletRequest,httpServletResponse,""));
  }

  /*
   * This method is used to test the negative case for preHandle Method.
   *
   */
  @Test
  public void testPreHandleWithInValidHttpMethod() throws Exception {
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    Mockito.when(httpServletRequest.getMethod()).thenReturn("TRACE");
    Assert.assertFalse(methodInterceptor.preHandle(httpServletRequest,httpServletResponse,""));
  }

}