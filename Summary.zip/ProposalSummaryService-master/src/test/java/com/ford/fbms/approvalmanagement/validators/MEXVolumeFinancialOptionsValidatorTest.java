package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.transport.ApiParams;
import java.util.concurrent.ExecutionException;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.jupiter.api.Assertions.*;

/**
 * @author MKALLATA
 * @created 22/06/2021 - 7:34 AM
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MEXVolumeFinancialOptionsValidatorTest {
  @InjectMocks
  MEXVolumeFinancialOptionsValidator mexVolumeFinancialOptionsValidator;
  @Test
  public void validateAndConstruct_success() throws ExecutionException, InterruptedException {
    ApiParams apiParams = new ApiParams();
    apiParams.setUserId("FBMSTID1");
    Assert.assertNotNull(
        mexVolumeFinancialOptionsValidator.validateAndConstruct(apiParams,null,null,null).get().getDropDownMap());
  }
}