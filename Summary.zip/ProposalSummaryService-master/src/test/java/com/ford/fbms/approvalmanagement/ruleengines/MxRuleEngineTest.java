package com.ford.fbms.approvalmanagement.ruleengines;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.CountryDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FinOpUnitMaster;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalViewRepository;
import com.ford.fbms.approvalmanagement.repository.FinOpUnitMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.MqUtil;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.Validator;

/**
 *
 * @author VSHANMU8
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class MxRuleEngineTest {

  @Spy
  @InjectMocks
  private MxRuleEngine mxRuleEngine;
  @Mock
  private ResponseBuilder responseBuilder;
  @Mock
  private RestService restService;
  @Mock
  protected ProposalRepository proposalRepository;
  @Mock
  private MqUtil mqUtil;
  @Mock
  protected ProposalStatusRepository proposalStatusRepo;
  @Mock
  protected FinOpUnitMasterRepository finOpUnitMasterRepository;
  @Mock
  protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
  @Mock
  protected ApprovalProcessRepository approvalProcessRepository;
  @Mock
  protected FordPersonRepository fordPersonRepo;
  @Mock
  protected ProcedureRepository procedureRepository;
  @Mock
  protected ReportLevelRepository reportLevelRepo;
  @Mock
  protected ApprovalViewRepository approvalViewRepo;
  
  protected HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
  protected HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
  
  protected ApiParams apiParams = new ApiParams();
  protected FordPersonDto fordPersonDto = new FordPersonDto();
  protected ProposalDto proposalDto = new ProposalDto();
  protected FinMasterDto finMasterDto = new FinMasterDto();
  protected FinOpUnitMaster finOpUnitMaster = new FinOpUnitMaster();
  protected PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
  protected CreateProposalRequest createProposalRequest =  new CreateProposalRequest();
  protected ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
  protected ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
  protected ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
  protected FinancialDetailedVO financialDetailedVO = new FinancialDetailedVO();
  protected FinancialMexDetailedVO financialMexDetailedVO = new FinancialMexDetailedVO();
  
  protected void loadProposalDto() {
		fordPersonDto.setCdsid("FBMSTID1");
		proposalDto.setFordPerson(fordPersonDto);
		pyDefinitionDto.setProposalYearCode(2021);
		proposalDto.setPyDefinition(pyDefinitionDto);
		proposalDto.setCntlReqdFlag(true);
		finMasterDto.setFinMasterKey(1L);
		proposalDto.setProposalSaKey(1l);
		proposalDto.setFinMasterKey(finMasterDto);
		proposalDto.setProposalMlv(new BigDecimal(25));
		proposalDto.setLetterMinQty(BigDecimal.ONE);
		proposalDto.setCntlReqdFlag(true);
		proposalDto.setLongTermDemoR(new BigDecimal(2));
		CountryDto countryDto = new CountryDto();
		countryDto.setCountryIso3Code("USA");
		finMasterDto.setCountry(countryDto);
		proposalStatusDto.setProposalStatusCode("APV");
		proposalDto.setProposalStatus(proposalStatusDto);
		
		
	}
  
  
	@Test
	public void testGetValidators() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_APPROVAL, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithCREATE_APPROVAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.CREATE_APPROVAL, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithDELETE_APPROVAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.DELETE_APPROVAL, apiParams);
		assertEquals(1, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithMAINTAIN_FINANCIAL_DATA_SP() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.MAINTAIN_FINANCIAL_DATA_SP, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithGET_FINANCIAL_LIST() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_FINANCIAL_LIST, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithGET_TOTALS_AVG_FINANICIALS() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsWithGET_ACTUAL_LIST() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_ACTUAL_LIST, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsGET_FORECAST_LIST() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_FORECAST_LIST, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsSUBMIT_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.SUBMIT_PROPOSAL, apiParams);
		assertEquals(5, validators.size());
	}
	
	@Test
	public void testGetValidatorsSAVE_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.SAVE_PROPOSAL, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsSENDBACK_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.SENDBACK_PROPOSAL, apiParams);
		assertEquals(3, validators.size());
	}
	
	@Test
	public void testGetValidatorsRECALL_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.RECALL_PROPOSAL, apiParams);
		assertEquals(3, validators.size());
	}
	
	@Test
	public void testGetValidatorsAPPROVAL_CHAIN() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.APPROVAL_CHAIN, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsDOWNLOAD_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams);
		assertEquals(5, validators.size());
	}
	
	@Test
	public void testGetValidatorsGET_VOLUME_FINANCIAL_OPTIONS() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.GET_VOLUME_FINANCIAL_OPTIONS, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsVALIDATE_ACTIONS() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.VALIDATE_ACTIONS, apiParams);
		assertEquals(5, validators.size());
	}
	
	@Test
	public void testGetValidatorsAPPROVE_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.APPROVE_PROPOSAL, apiParams);
		assertEquals(4, validators.size());
	}
	
	@Test
	public void testGetValidatorsREVISE_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.REVISE_PROPOSAL, apiParams);
		assertEquals(2, validators.size());
	}
	
	@Test
	public void testGetValidatorsREJECT_PROPOSAL() {
		List<Validator> validators = mxRuleEngine.getValidators(RequestMode.REJECT_PROPOSAL, apiParams);
		assertEquals(3, validators.size());
	}
	
	@Test
	public void testCreateApproval() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		approvalResponseVo.setReportlevel(2);
		approvalResponseVo.setApprovedByFordPerson(fordPersonDto);
		approvalResponseVo.setProposalStatus("SUB");
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0231");
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SUBMITTED_SUCCESSFULLY)).thenReturn(genericResponse);
		when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusDto));
		GenericResponse actualGenericResponse = mxRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL);
		assertEquals("MSG-0231", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAction() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		approvalResponseVo.setReportlevel(2);
		approvalResponseVo.setApprovedByFordPerson(fordPersonDto);
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0005");
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		when(responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT)).thenReturn(genericResponse);
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals("MSG-0005", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateActionWithValiUser() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(0);
		fordPersonDto.setReportLevel(reportLevel);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithNewStatus() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(0);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.NEW);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithRevisedStatus() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(0);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatus() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(0);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatusAndApprovalProcess() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(7);
		approvalProcessDto.setReportLevel(reportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithRevisedStatusAndApprovalProcess() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(9);
		approvalProcessDto.setReportLevel(reportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatusAndApprovalProcessAndReportLevelCode9() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(9);
		approvalProcessDto.setReportLevel(reportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatusAndApprovalProcessAndReportLevelCode9AndPresentQueue() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(8);
		ReportLevelDto presentQueueReportLevel = new ReportLevelDto();
		presentQueueReportLevel.setCode(2);
		approvalProcessDto.setReportLevel(presentQueueReportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatusAndApprovalProcessAndReportLevelCode9AndPresentQueue9() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(9);
		ReportLevelDto presentQueueReportLevel = new ReportLevelDto();
		presentQueueReportLevel.setCode(2);
		approvalProcessDto.setReportLevel(presentQueueReportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithSubmittedStatusAndApprovalProcessAndReportLevelCode8() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(8);
		approvalProcessDto.setReportLevel(reportLevel);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithNewStatusAndReportlevel14() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setIsProposalAssignee(true);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(false);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(14);
		fordPersonDto.setReportLevel(reportLevel);
		loadProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.NEW);
		proposalDto.setProposalStatus(proposalStatusDto);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithReportLevel7() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(7);
		fordPersonDto.setReportLevel(reportLevel);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithReportLevel9() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(9);
		fordPersonDto.setReportLevel(reportLevel);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
	@Test
	public void testValidateActionWithReportLevel8() {
		loadProposalDto();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setProposalDataDto(proposalDto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		PyCountryDefinition pyCountryDefinition = new PyCountryDefinition();
		pyCountryDefinition.setArchiveFlag("N");
		genericResponseWrapper.setPyCountryDefinition(pyCountryDefinition);
		genericResponseWrapper.setIsAuthorized(true);
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(8);
		fordPersonDto.setReportLevel(reportLevel);
		when(reportLevelRepo.findById(2l)).thenReturn(Optional.of(new ReportLevelDto()));
		GenericResponse actualGenericResponse = mxRuleEngine.validateAction(apiParams, genericResponseWrapper);
		assertEquals(HttpStatus.OK, actualGenericResponse.getHttpStatus());
	}
	
}