package com.ford.fbms.approvalmanagement.exception;


import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This test class is written to perform unit testing for CustomRuntimeExceptionTest class.
 *
 * @author BKUMARA1 on 2/10/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomRuntimeExceptionTest {

    @Autowired
    private ResponseCodes responseCodes;
    private String messages;
    
    /**
     * This test  is written to perform unit testing for custom_exception_test.
     *
     */
    @Test
    public void custom_exception_test()
    {
        CustomRuntimeException  customRuntimeException= new CustomRuntimeException(responseCodes,messages);
        Assert.assertNotNull(customRuntimeException);
    }

}