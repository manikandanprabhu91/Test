package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalExtraInfoDto;
import com.ford.fbms.approvalmanagement.repository.ProposalExtraInfoRepository;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.QuotationExpirationDateManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class QuotationExpirationDateManagerTest extends AbstarctValidatorTest {

	@Mock
	private ProposalExtraInfoRepository proposalExtraInfoRepository;

	@InjectMocks
	private QuotationExpirationDateManager validator;

	@Test
	public void testValidateAndConstructWithEmptyProposalExtraInfo() throws InterruptedException, ExecutionException {
		when(proposalExtraInfoRepository.findById(1l)).thenReturn(Optional.empty());
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		ProposalExtraInfoDto proExtraInfo = new ProposalExtraInfoDto();
		proExtraInfo.setProposalExpirationTS(new Timestamp(System.currentTimeMillis()-(1000 * 60 * 60 * 24)));
		when(proposalExtraInfoRepository.findById(1l)).thenReturn(Optional.of(proExtraInfo));
		GenericResponse genericResponse = new GenericResponse();
		genericResponse.setMsgId("MSG-0247");
		when(responseBuilder.generateResponse(ResponseCodes.QUOTATION_DATE_IS_EXPIRED)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0247", actualGenericResponse.getMsgId());
	}

}
