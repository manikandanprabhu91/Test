package com.ford.fbms.approvalmanagement.util;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.concurrent.Future;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.fbms.approvalmanagement.controller.ApprovalManagementController;
import com.ford.fbms.approvalmanagement.ruleengines.NaRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.UserIdValidator;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ServiceAspectsTest {
  @Rule
  public MockitoRule mockitoRule = MockitoJUnit.rule();
  ApprovalManagementController notesManagementServiceController;
  @InjectMocks
  private UserIdValidator userIdValidator;
  @Mock
  private ResponseBuilder responseBuilder;
  @Mock
  private ProceedingJoinPoint proceedingJoinPoint;
  private LogAround logAround;
  private final ServiceAspects serviceAspects = new ServiceAspects();
  @Autowired
  private NaRuleEngine naRuleEngine;

  @Test
  public void test_valid() throws Throwable {
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    when(joinPoint.getTarget()).thenReturn(notesManagementServiceController);
    when(joinPoint.getSignature()).thenReturn(signature);
    when(joinPoint.getSignature().getDeclaringType()).thenReturn(ApprovalManagementController.class);
    when(joinPoint.getSignature().getName()).thenReturn("getAccountNotes");
    when(joinPoint.proceed()).thenReturn(1);
    serviceAspects.logMethod(joinPoint, logAround);
    joinPoint.proceed();
    verify(joinPoint, times(2)).proceed();
    // 'proceed(Object[])' is never called
    verify(joinPoint, never()).proceed(null);
  }

  @Test(expected = Throwable.class)
  public void test_throwable_invalid() throws Throwable {
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    mock(Exception.class);
    when(joinPoint.getTarget()).thenReturn("");
    when(joinPoint.getSignature()).thenReturn(signature);
    when(joinPoint.getSignature().getDeclaringType()).thenReturn(ApprovalManagementController.class);
    when(joinPoint.getSignature().getName()).thenReturn("getAccountNotes");
    Mockito.when(signature.getMethod()).thenReturn(this.getClass().getMethods()[0]);
    Mockito.when(signature.getReturnType()).thenReturn(Void.TYPE);
    when(serviceAspects.logMethod(joinPoint, logAround)).thenThrow(new Throwable());
  }

  @Test(expected = RuntimeException.class)
  public void testPositiveLargeNumber() throws Throwable {
    serviceAspects.logMethod(proceedingJoinPoint, logAround);
  }

  @Test(expected = RuntimeException.class)
  public void testLogMethod_exception() throws Throwable {
    ServiceAspects serviceAspects = new ServiceAspects();
    Assert.assertNotNull(serviceAspects);
    ProceedingJoinPoint joinPoint = mock(ProceedingJoinPoint.class);
    MethodSignature signature = mock(MethodSignature.class);
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    mock(Exception.class);
    when(joinPoint.getTarget()).thenReturn(userIdValidator);
    when(joinPoint.getSignature()).thenReturn(signature);
    when(joinPoint.getSignature().getDeclaringType()).thenReturn(UserIdValidator.class);
    when(joinPoint.getSignature().getName()).thenReturn("validateandconstruct");
    Mockito.when(signature.getMethod()).thenReturn(UserIdValidator.class.getMethods()[1]);
    LogAround logAround1 = mock(LogAround.class);
    try {
      final ApiParams apiParams = new ApiParams();
      apiParams.setUserId(null);
      Future<GenericResponseWrapper> genericResponseFuture = userIdValidator
          .validateAndConstruct(apiParams, naRuleEngine, naRuleEngine, null);
      genericResponseWrapper.setGenericResponse(responseBuilder
          .generateResponse(ResponseCodes.USER_ID_NOT_EXISTS));
      when(joinPoint.proceed()).thenReturn(genericResponseFuture);
      when(genericResponseFuture).thenThrow(new Throwable());
      when(joinPoint.proceed()).thenThrow(new Throwable());
    } catch (Throwable e) {
      when(joinPoint.proceed()).thenThrow(new RuntimeException());
      when(serviceAspects.logMethod(joinPoint, logAround1)).thenThrow(new RuntimeException());

    }
  }
}