package com.ford.fbms.approvalmanagement.util;


import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ford.fbms.approvalmanagement.transport.ApiParams;

import io.swagger.models.HttpMethod;


/**
 * This test class is written to perform unit testing for LoggerBuilderTest class.
 *
 * @author AGOVADA on 2/10/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class LoggerBuilderTest {

    /**
     * This method is to test the constructor
     */
    @Test(expected = Exception.class)
    public void testConstructorIsPrivate() throws NoSuchMethodException, IllegalAccessException,
            InvocationTargetException, InstantiationException {
        Constructor<LoggerBuilder> constructor = LoggerBuilder.class.getDeclaredConstructor();
        Assert.assertTrue(Modifier.isPrivate(constructor.getModifiers()));
        constructor.setAccessible(true);
        constructor.newInstance();
    }

    /**
     * the method is to test the printInfo method
     */
    @Test
    public void testPrintInfo() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.methodName("testPrintInfo").message("test info"));
    }
    /**
     * the method is to test the printInfo method
     */
    @Test
    public void testPrintInfoLogger() {
        Logger logger = LoggerFactory.getLogger(LoggerBuilderTest.class);
        LoggerBuilder.printInfo(logger, loggerBuilder ->
                loggerBuilder.methodName("testPrintInfoLogger").message("test info"));
    }

    /**
     * the method is to test the printDebug method
     */
    @Test
    public void printDebug() {
        Logger logger = LoggerFactory.getLogger(LoggerBuilderTest.class);
        LoggerBuilder.printDebug(logger, loggerBuilder ->
                loggerBuilder.methodName("printDebug").message("test debug"));
    }

    /**
     * the method is to test the printError method
     */
    @Test
    public void printError() {
        LoggerBuilder.printError(this.getClass(), loggerBuilder ->
                loggerBuilder.methodName("printError").message("test error"));
    }

    /**
     * the method is to test the printError method
     */
    @Test
    public void testPrintError() {
        Logger logger = LoggerFactory.getLogger(LoggerBuilderTest.class);
        LoggerBuilder.printError(logger, loggerBuilder ->
                loggerBuilder.methodName("testPrintError").message("test error"));
    }

    /**
     * the method is to test the logApiRequestResponse method
     */
    @Test
    public void logApiRequestResponseSuccess() {
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        HttpMethod httpMethod = HttpMethod.GET;
        LoggerBuilder.logApiRequestResponse(apiParams ,new Object(),null, httpMethod);
        LoggerBuilder.logApiRequestResponse(apiParams, null, null, httpMethod);
    }

    /**
     * the method is to test the logApiRequestResponse method
     */
    @Test
    public void logApiRequestResponseException() {
        ApiParams apiParams = Mockito.mock(ApiParams.class);
        HttpMethod httpMethod = HttpMethod.GET;
        LoggerBuilder.logApiRequestResponse(apiParams, "{\"name\"123}", null, httpMethod);
    }

    /**
     * the method is to test the serviceGroup method
     */
    @Test
    public void serviceGroup() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.serviceGroup("serviceGroup").message("test info"));
    }

    /**
     * the method is to test the serviceId method
     */
    @Test
    public void serviceId() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.serviceId("serviceId").message("test info"));
    }

    /**
     * the method is to test the correlationId method
     */
    @Test
    public void correlationId() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.correlationId("correlationId").message("test info"));
    }

    /**
     * the method is to test the vcapRequestId method
     */
    @Test
    public void vcapRequestId() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.vcapRequestId("vcapRequestId").message("test info"));
    }

    /**
     * the method is to test the buildVersion method
     */
    @Test
    public void buildVersion() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.buildVersion("buildVersion").message("test info"));
    }

    /**
     * the method is to test the traceId method
     */
    @Test
    public void traceId() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.traceId("traceId").message("test traceId"));
    }

    /**
     * the method is to test the className method
     */
    @Test
    public void className() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.className("className").message("test info"));
    }


    /**
     * the method is to test the methodName method
     */
    @Test
    public void methodName() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.methodName("method name").message("test method name"));
    }

    /**
     * the method is to test the action method
     */
    @Test
    public void action() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.action("test action"));
    }

    /**
     * the method is to test the userId method
     */
    @Test
    public void userId() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.userId("test user"));
    }

    /**
     * the method is to test the message method
     */
    @Test
    public void message() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.message("test message"));
    }

    /**
     * the method is to test the exceptionMessage method
     */
    @Test
    public void exceptionMessage() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.exceptionMessage("test exception").message("test info"));
    }

    /**
     * the method is to test the exception method
     */
    @Test
    public void exception() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.exception(new Exception("test")).message("test info"));
    }


    /**
     * the method is to test the responseTime method
     */
    @Test
    public void responseTime() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.responseTime(System.currentTimeMillis()).message("test info"));
    }

    /**
     * the method is to test the request method
     */
    @Test
    public void request() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.request("request").message("test info"));
    }

    /**
     * the method is to test the mqName method
     */
    @Test
    public void mqName() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.mqName("mqName").message("test info"));
    }

    /**
     * the method is to test the dateTime method
     */
    @Test
    public void dateTime() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.dateTime("dateTime").message("test info"));
    }

    /**
     * the method is to test the httpMethod method
     */
    @Test
    public void httpMethod() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.httpMethod("httpMethod").message("test info"));
    }

    /**
     * the method is to test the json method
     */
    @Test
    public void json() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.json("json").message("test info"));
    }

    /**
     * the method is to test the resourceUri method
     */
    @Test
    public void resourceUri() {
        LoggerBuilder.printInfo(this.getClass(), loggerBuilder ->
                loggerBuilder.resourceUri("resourceUri").message("test info"));
    }
}