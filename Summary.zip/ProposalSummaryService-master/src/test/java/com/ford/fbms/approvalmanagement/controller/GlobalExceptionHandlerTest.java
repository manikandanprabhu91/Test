package com.ford.fbms.approvalmanagement.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.isA;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

/**
 * Test class for GlobalExceptionHandlerTest class.
 *
 * @author APARAMA2.
 * @author MKALLATA
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class GlobalExceptionHandlerTest {
  @Mock
  private ResponseBuilder responseBuilder; 

  @InjectMocks
  private GlobalExceptionHandler globalExceptionHandler;

  @Mock
  private HttpServletRequest request;

  @Mock
  private HttpServletResponse response;

  @Mock
  Exception exception;
  @Mock
  HttpRequestMethodNotSupportedException httpRequestMethodNotSupportedException;

  /**
   * Test class for handleHttpRequestMethodNotSupportedException.
   *
   * @author APARAMA2.
   *
   */
  @Test
  public void testhandleHttpRequestMethodNotSupportedException() {

    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.METHOD_NOT_ALLOWED);
    Mockito.doNothing().when(responseBuilder).storeRequestHeaderAttributes(request);
    Mockito.doNothing().when(responseBuilder).setResponseHeaderAttributes(response);
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.UNSUPPORTED_METHOD_ERROR)).thenReturn(genericResponse);
    assertEquals(HttpStatus.METHOD_NOT_ALLOWED, globalExceptionHandler.handleHttpRequestMethodNotSupportedException(request, response, exception).getHttpStatus());
  }

  /**
   * Test class for handleAccessDeniedException.
   *
   * @author APARAMA2.
   *
   */
  @Test
  public void testhandleAccessDeniedException() {

    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.UNAUTHORIZED);
    Mockito.doNothing().when(responseBuilder).storeRequestHeaderAttributes(request);
    Mockito.doNothing().when(responseBuilder).setResponseHeaderAttributes(response);
    Mockito.doNothing().when(response).setStatus(HttpStatus.UNAUTHORIZED.value());
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.UNAUTHORIZED_ERROR)).thenReturn(genericResponse);
    assertEquals(HttpStatus.UNAUTHORIZED, globalExceptionHandler.handleAccessDeniedException(request, response, exception).getHttpStatus());
  }

  /**
   * Test class for handleMissingParams.
   *
   * @author APARAMA2.
   *
   */
  @Test
  public void testMissingParams() {

    GenericResponse genericResponse = new GenericResponse();
    genericResponse.setHttpStatus(HttpStatus.PRECONDITION_FAILED);
    response.setStatus(genericResponse.getHttpStatus().value());
    Mockito.doNothing().when(responseBuilder).storeRequestHeaderAttributes(request);
    Mockito.doNothing().when(responseBuilder).setResponseHeaderAttributes(response);
    Mockito.doNothing().when(response).setStatus(HttpStatus.UNAUTHORIZED.value());
    Mockito.when(responseBuilder.generateResponse(ResponseCodes.INVALID_REQUEST_URL)).thenReturn(genericResponse);
    assertEquals(HttpStatus.PRECONDITION_FAILED, globalExceptionHandler.handleMissingParams(request, response, exception).getHttpStatus());
  }

  /**
   * Test class for GlobalExceptionHandlerTest
   *
   * @author MKALLATA
   * @created 20/04/2021 - 3:35 AM
   */
  @Test
  public void handleException_test() {
    //Given
    GenericResponse genericResponse = new GenericResponse(HttpStatus.INTERNAL_SERVER_ERROR);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
    Exception exception = Mockito.mock(Exception.class);
    //When
    Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));
    Mockito.when(responseBuilder.generateResponse(any())).thenReturn(genericResponse);
    Mockito.doNothing().when(responseBuilder).storeRequestHeaderAttributes(request);
    Mockito.doNothing().when(responseBuilder).setResponseHeaderAttributes(response);
    //Then
    Assert.assertEquals(genericResponse, globalExceptionHandler.handleException(
        httpServletRequest, httpServletResponse, exception));
  }

  @Test
  public void handleConstraintViolationException_test() {
    //Given
    GenericResponse genericResponse = new GenericResponse(HttpStatus.EXPECTATION_FAILED);
    HttpServletResponse httpServletResponse = Mockito.mock(HttpServletResponse.class);
    HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

    ConstraintViolation<?> violation1 = Mockito.mock(ConstraintViolationImpl.class);
    ConstraintViolation<?> violation2 = Mockito.mock(ConstraintViolationImpl.class);

    Set<ConstraintViolation<?>> set = new HashSet<>();
    set.add(violation1);
    set.add(violation2);

    ConstraintViolationException exception = Mockito.mock(ConstraintViolationException.class);
    Mockito.when(exception.getConstraintViolations()).thenReturn(set);

    //When
    Mockito.doNothing().when(httpServletResponse).setStatus(isA(Integer.class));
    Mockito.when(responseBuilder.generateResponse(any())).thenReturn(genericResponse);
    Mockito.doNothing().when(responseBuilder).storeRequestHeaderAttributes(request);
    Mockito.doNothing().when(responseBuilder).setResponseHeaderAttributes(response);
    //Then
    Assert.assertEquals(genericResponse, globalExceptionHandler.handleConstraintViolationException(
        httpServletRequest, httpServletResponse, exception));
  }
}



