/**
 * 
 */
package com.ford.fbms.approvalmanagement.ruleengines;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.CustomerAcceptanceS3Repository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearTermRepository;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

/**
 * @author vvm
 *
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class NaRuleEngineTest {
	
	@Spy
	  @InjectMocks
	  private NaRuleEngine naRuleEngine;
	@Mock
	  private ResponseBuilder responseBuilder;
	
	@Mock 
	private ProposalStatusRepository proposalStatusRepo;
	
	@Mock 
	private ProposalRepository proposalRepo;
	
	@Mock 
	private FordPersonRepository fordPersonRepo;
	
	@Mock
	private ApprovalProcessRepository approvalProcessRepository;
	
	@Mock
	private ProcedureRepository procedureRepository;
	
	@Mock
	private ReportLevelRepository reportLevelRepo;
	@Mock
	private CustomerAcceptanceS3Repository customerAcceptanceS3Repository;
	@Mock
	private MultiYearTermRepository multiYearTermRepository;
	@Mock
	protected ProposalSubsidiaryRepository proposalSubsidiaryRepository;
	
	
	
	@Test
	public void test_getValidatorsSuccess() {
		
		ApiParams apiParams = new ApiParams();
		
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_APPROVAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.CREATE_APPROVAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.DELETE_APPROVAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.MAINTAIN_FINANCIAL_DATA_SP, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_TOTALS_AVG_FINANICIALS, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_FINANCIAL_LIST, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_ACTUAL_LIST, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_FORECAST_LIST, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.SUBMIT_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.SAVE_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.SENDBACK_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.RECALL_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.APPROVAL_CHAIN, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE);
		assertNotNull(naRuleEngine.getValidators(RequestMode.DOWNLOAD_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.GET_VOLUME_FINANCIAL_OPTIONS, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.VALIDATE_ACTIONS, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.APPROVE_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.REVISE_PROPOSAL, apiParams));
		assertNotNull(naRuleEngine.getValidators(RequestMode.REJECT_PROPOSAL, apiParams));
		
	}
	
	@Test
	public void test_createApprovalSuccess() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SUBMITTED_SUCCESSFULLY);
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		proposalStatusdto.setProposalStatusCode("SUB");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(8);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}
	
	@Test
	public void test_createApprovalSuccess_FSM() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL);
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		approvalProcessDto.setApprovalKey(1l);
		approvalProcessList.add(approvalProcessDto);
		proposalStatusdto.setProposalStatusCode("SUB");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}
	

	@Test
	public void test_createApprovalSuccess_EST() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_FULLY);
		ApiParams apiParams = new ApiParams();
		apiParams.setProposalKey(1l);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		CustomerAcceptanceS3Dto customerAcceptanceS3Dto = setCustomerAcceptance();
		genericResponseWrapper.setCustomerAcceptanceS3Dto(customerAcceptanceS3Dto);
		ProposalDto dto = new ProposalDto();
		dto.setProposalSaKey(1l);
		FinMasterDto finMasterKey = new FinMasterDto();
		finMasterKey.setFinMasterKey(1l);
		finMasterKey.setFinCode("FIN123");
		dto.setFinMasterKey(finMasterKey);
		PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
		pyDefinitionDto.setProposalYearCode(2021);
		dto.setPyDefinition(pyDefinitionDto);
		dto.setSourceProposalCode(1l);
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		approvalProcessDto.setApprovalKey(1l);
		approvalProcessList.add(approvalProcessDto);
		proposalStatusdto.setProposalStatusCode("EST");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		MultiYearTermDto multiYearTermDto = new MultiYearTermDto();
		multiYearTermDto.setCurrentProposalInEffect(dto);
		multiYearTermDto.setSourceProposalAtEstablishment(dto);
		multiYearTermDto.setProposalKey(1l);
		multiYearTermDto.setEndYr(2022l);
		multiYearTermDto.setStartYr(2021l);
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(proposalRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(dto));
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		Mockito.doReturn(null).when(customerAcceptanceS3Repository).save(Mockito.any());
		Mockito.when(multiYearTermRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(multiYearTermDto));
		Mockito.when(multiYearTermRepository.save(Mockito.any(MultiYearTermDto.class))).thenReturn(null);
		Mockito.when(multiYearTermRepository.queryListMultiYearTermByFinMasterProposalYear(Mockito.anyLong(),Mockito.anyLong()))
		.thenReturn(Collections.singletonList(multiYearTermDto));
	
		Mockito.when(proposalRepo.getMaxEstOrUrvOnProposalByProposalYearFinMaster(Mockito.anyLong(),Mockito.anyLong())).thenReturn(Optional.of(dto));
		ProposalSubsidiaryDto ProposalSubsidiaryDto=  new ProposalSubsidiaryDto();
		List<ProposalSubsidiaryDto> proSubList = new ArrayList<>();
		proSubList.add(ProposalSubsidiaryDto);
		when(proposalSubsidiaryRepository.findByProposalKey(Mockito.anyLong())).thenReturn(Optional.of(proSubList));
		List<ProposalDto> proDtos =  new ArrayList<>();
		ProposalDto proposalDto = new ProposalDto();
		proposalDto.setVersionNumber(2);
		proposalDto.setProposalSubsidiaryList(proSubList);
		proDtos.add(proposalDto);
		when(proposalRepo.proposalByFinMasterProposalYear(Mockito.anyString(), Mockito.anyInt())).thenReturn(Optional.of(proDtos));
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}
	private CustomerAcceptanceS3Dto setCustomerAcceptance() {
		CustomerAcceptanceS3Dto customerAcceptanceS3Dto = new CustomerAcceptanceS3Dto();
		customerAcceptanceS3Dto.setLetterSource(null);
		customerAcceptanceS3Dto.setProposalStatus("EST");
		customerAcceptanceS3Dto.setLetterGenerateYear(null);
		customerAcceptanceS3Dto.setLetterOfferYear(null);
		customerAcceptanceS3Dto.setLetterExpireDaysR(null);
		customerAcceptanceS3Dto.setLetterOriginalL(null);
		customerAcceptanceS3Dto.setLetterModifiedL(null);
		customerAcceptanceS3Dto.setLetterTemplate(null);
		customerAcceptanceS3Dto.setAcceptedByCdsid(null);
		customerAcceptanceS3Dto.setLetterGenCdsis(null);
		customerAcceptanceS3Dto.setLetterStatus(null);
		customerAcceptanceS3Dto.setMailSentToDesc(null);
		return customerAcceptanceS3Dto;
	}
	@Test
	public void test_createApprovalSuccess_APV_NONF() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_NON_FINANCIAL_APPROVED);
		ApiParams apiParams = new ApiParams();
		apiParams.setProposalKey(1l);
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		dto.setProposalSaKey(1l);
		PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
		pyDefinitionDto.setProposalYearCode(2021);
		dto.setPyDefinition(pyDefinitionDto);
		dto.setSourceProposalCode(1l);
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		approvalProcessDto.setApprovalKey(1l);
		approvalProcessList.add(approvalProcessDto);
		proposalStatusdto.setProposalStatusCode("APV");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(5);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		MultiYearTermDto multiYearTermDto = new MultiYearTermDto();
		multiYearTermDto.setCurrentProposalInEffect(dto);
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}

	@Test
	public void test_createApprovalSuccess_DFO() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_LL5CONTROLLER_APPROVAL);
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		proposalStatusdto.setProposalStatusCode("SUB");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(4);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}
	
	@Test
	public void test_createApprovalSuccess_GVP() {
	
		GenericResponse expectedResponse = responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_GLOBALCONTROLLER_APPROVAL);
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		ProposalStatusDto proposalStatusdto = new ProposalStatusDto();
		List<ApprovalProcessDto> approvalProcessList= new ArrayList<ApprovalProcessDto>();
		proposalStatusdto.setProposalStatusCode("SUB");
		ReportLevelDto reportLevel = new ReportLevelDto();
		reportLevel.setCode(2);
		dto.setNonFinancialFlag(true);
		ApprovalResponseVo vo = new ApprovalResponseVo();
		vo.setControllerApprovalRequired(true);
		vo.setProposalStatus("SUB");
		vo.setMaxReportLevel(reportLevel);
		vo.setSourceProposalDto(dto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setApprovalResponseNonFinancialVo(vo);
		FordPersonDto fordPersonDto = new FordPersonDto();
		vo.setApprovedByFordPerson(fordPersonDto);
		Mockito.when(proposalStatusRepo.findById(Mockito.anyString())).thenReturn(Optional.of(proposalStatusdto));
		Mockito.when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(approvalProcessList);
		Mockito.when(proposalRepo.save(Mockito.any(ProposalDto.class))).thenReturn(null);
		Mockito.when(fordPersonRepo.findById(Mockito.anyString())).thenReturn(Optional.of(new FordPersonDto()));
		Mockito.when(approvalProcessRepository.save(Mockito.any(ApprovalProcessDto.class))).thenReturn(null);
		Mockito.when(reportLevelRepo.findById(Mockito.any())).thenReturn(Optional.of(new ReportLevelDto()));
		
		assertEquals(expectedResponse, naRuleEngine.createApproval(apiParams, genericResponseWrapper, RequestMode.CREATE_APPROVAL));
		
	}
	
	@Test
	public void test_validateActionSuccess() {
		
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.NEW);
		dto.setProposalStatus(proposalStatusDto);
		FordPersonDto fordPersonDto = new FordPersonDto();
		ReportLevelDto rptLvlDto = new ReportLevelDto();
		rptLvlDto.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		fordPersonDto.setReportLevel(rptLvlDto);
		PyCountryDefinition pyDefn = new PyCountryDefinition();
		pyDefn.setArchiveFlag("N");
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		ReportLevelDto levelDto = new ReportLevelDto();
		levelDto.setCode(ApprovalConstants.ACCOUNT_MANAGER_RL_CODE);
		approvalProcessDto.setReportLevel(levelDto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setPyCountryDefinition(pyDefn);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setIsProposalAssignee(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		assertEquals(HttpStatus.OK,naRuleEngine.validateAction(apiParams, genericResponseWrapper).getHttpStatus());
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		dto.setProposalStatus(proposalStatusDto);
		genericResponseWrapper.setProposalDataDto(dto);
		assertEquals(HttpStatus.OK,naRuleEngine.validateAction(apiParams, genericResponseWrapper).getHttpStatus());
	}
	
	@Test
	public void test_validateActionSuccess_2() {
		
		ApiParams apiParams = new ApiParams();
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		ProposalDto dto = new ProposalDto();
		dto.setCntlReqdFlag(true);
		ProposalStatusDto proposalStatusDto = new ProposalStatusDto();
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.NEW);
		dto.setProposalStatus(proposalStatusDto);
		FordPersonDto fordPersonDto = new FordPersonDto();
		ReportLevelDto rptLvlDto = new ReportLevelDto();
		rptLvlDto.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		fordPersonDto.setReportLevel(rptLvlDto);
		PyCountryDefinition pyDefn = new PyCountryDefinition();
		pyDefn.setArchiveFlag("N");
		ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
		ReportLevelDto levelDto = new ReportLevelDto();
		levelDto.setCode(ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
		approvalProcessDto.setReportLevel(levelDto);
		genericResponseWrapper.setProposalDataDto(dto);
		genericResponseWrapper.setFordPersonDto(fordPersonDto);
		genericResponseWrapper.setPyCountryDefinition(pyDefn);
		genericResponseWrapper.setIsAuthorized(true);
		genericResponseWrapper.setIsProposalAssignee(true);
		genericResponseWrapper.setApprovalProcessDto(approvalProcessDto);
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.REVISED);
		dto.setProposalStatus(proposalStatusDto);
		genericResponseWrapper.setProposalDataDto(dto);
		assertEquals(HttpStatus.OK,naRuleEngine.validateAction(apiParams, genericResponseWrapper).getHttpStatus());
		proposalStatusDto.setProposalStatusCode(ApprovalConstants.SUBMITTED);
		dto.setProposalStatus(proposalStatusDto);
		genericResponseWrapper.setProposalDataDto(dto);
		assertEquals(HttpStatus.OK,naRuleEngine.validateAction(apiParams, genericResponseWrapper).getHttpStatus());
		FordPersonDto fordPersonDto1 = new FordPersonDto();
		ReportLevelDto rptLvlDto1 = new ReportLevelDto();
		rptLvlDto1.setCode(ApprovalConstants.CONTROLLER_RL_CODE);
		fordPersonDto1.setReportLevel(rptLvlDto1);
		genericResponseWrapper.setFordPersonDto(fordPersonDto1);
		assertEquals(HttpStatus.OK,naRuleEngine.validateAction(apiParams, genericResponseWrapper).getHttpStatus());
		
	}
	
	
	

}
