package com.ford.fbms.approvalmanagement.util;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ResponseBuilderTest {

    @InjectMocks
    private ResponseBuilder responseBuilder;

    @Mock
    HttpServletRequest request;

    @Mock
    HttpServletResponse response;
    @Mock
    CacheUtil cacheUtil;

    /**
     * the method is to test the response builder object
     */
    @Test
    public void testResponseBuilderObject(){
        Assert.assertNotNull(responseBuilder);
    }

    /**
     * the method is to test the generateResponse of  response builder object
     */
    @Test
    public void generateResponse() {
        GenericResponse genericResponse =
                responseBuilder.generateResponse(ResponseCodes.UNSUPPORTED_METHOD_ERROR);
        Assert.assertNotNull(genericResponse);
    }

    /**
     * the method is to test the storeRequestHeaderAttributes of  response builder object
     */
    @Test
    public void testStoreRequestHeaderAttributes() {
        responseBuilder.storeRequestHeaderAttributes(request);
        responseBuilder.setResponseHeaderAttributes(response);
        GenericResponse genericResponse =
                responseBuilder.generateResponse(ResponseCodes.UNSUPPORTED_METHOD_ERROR);
        Assert.assertNotNull(genericResponse);
    }

    /**
     * the method is to test the setResponseHeaderAttributes of  response builder object
     */
    @Test
    public void testSetResponseHeaderAttributes() {
        responseBuilder.storeRequestHeaderAttributes(request);
        responseBuilder.setResponseHeaderAttributes(response);
        GenericResponse genericResponse =
                responseBuilder.generateResponse(ResponseCodes.UNSUPPORTED_METHOD_ERROR);
        Assert.assertNotNull(genericResponse);
    }
}