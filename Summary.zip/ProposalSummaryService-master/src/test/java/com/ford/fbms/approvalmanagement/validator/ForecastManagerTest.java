package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.assertj.core.util.Arrays;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import com.ford.fbms.approvalmanagement.domain.ExpandedBodyStyleViewDto;
import com.ford.fbms.approvalmanagement.domain.ExpandedBodyStyleViewPK;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyStyleViewRepository;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ForecastManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ForecastManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private ForecastManager validator;
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(1l)).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0015");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(actualGenericResponse);
		assertEquals("MSG-0015", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		when(proposalManager.getTotalTier(proposalDto)).thenReturn(1);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalFinancialVO();
		loadVehicleLineDto();
		ExpandedBodyStyleViewDto dto = new ExpandedBodyStyleViewDto();
		ExpandedBodyStyleViewPK id = new ExpandedBodyStyleViewPK();
		id.setBodyStyleSaKey(1l);
		dto.setId(id);
		List<ExpandedBodyStyleViewDto> ex = new ArrayList<>();
		ex.add(dto);
		proposalFinancialVOs.get(0).setPerUnitDescription("ALL");
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		when(proposalManager.getTotalTier(proposalDto)).thenReturn(1);
		when(proposalManager.getProposalFinancialList(getApiParams(), proposalDto, true)).thenReturn(proposalFinancialVOs);
		when(proposalManager.identifyPriorProposals(proposalDto)).thenReturn(proposalDto);
		when(vehLineRepo.vehicleLineListByVehicleLineDesc(Mockito.anyString())).thenReturn(vehicleLineDtos);
		when(proposalManager.getAverageFinancials(Mockito.any(FinancialDetailedVO.class))).thenReturn(financialDetailedVO);
		when(expandedBodyStyleViewRepo.findByIdBodyStyleSaKey(Mockito.anyLong())).thenReturn(Optional.of(ex));
		when(actualManager.buildProposalFinancialsActual(Mockito.any(),Mockito.any())).thenReturn(proposalFinancialVOs);
		
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
		
		when(actualManager.buildProposalFinancialsActual(Mockito.any(),Mockito.any())).thenReturn(Collections.singletonList(new ProposalFinancialVO(0)));
		assertNotNull(validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest));
	}
	
	@Test
	public void testValidateAndConstructWithIndenticalPeriorPYProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalFinancialVO();
		loadVehicleLineDto();
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		when(proposalManager.getTotalTier(proposalDto)).thenReturn(1);
		when(proposalManager.getProposalFinancialList(getApiParams(), proposalDto, true)).thenReturn(proposalFinancialVOs);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(vehLineRepo.vehicleLineListByVehicleLineDesc(Mockito.anyString())).thenReturn(vehicleLineDtos);
		when(proposalManager.getAverageFinancials(Mockito.any(FinancialDetailedVO.class))).thenReturn(financialDetailedVO);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	@Test
	public void testValidateAndConstructMoreFinancialRecord() throws InterruptedException, ExecutionException {
		loadProposalDto();
		loadReportLevel(7);
		loadProposalStatus("NEW");
		loadProposalFinancialVO();
		loadVehicleLineDto();
		ProposalFinancialVO proposalFinancialVO = new ProposalFinancialVO(0);
		proposalFinancialVO.setVehicleLineDescription("DESC1");
		proposalFinancialVO.setModelYear(2021);
		proposalFinancialVOs.add(proposalFinancialVO);
		when(proposalRepository.findById(1l)).thenReturn(Optional.of(proposalDto));
		when(proposalManager.getProposalTier(proposalDto, true)).thenReturn(1);
		when(proposalManager.isPresentVMbasedOnActualVolume(getApiParams())).thenReturn(true);
		when(proposalManager.getTotalTier(proposalDto)).thenReturn(1);
		when(proposalManager.getProposalFinancialList(getApiParams(), proposalDto, true)).thenReturn(proposalFinancialVOs);
		when(proposalManager.identifyPriorPYProposals(proposalDto)).thenReturn(Optional.of(proposalDto));
		when(vehLineRepo.vehicleLineListByVehicleLineDesc(Mockito.anyString())).thenReturn(vehicleLineDtos);
		when(proposalManager.getAverageFinancials(Mockito.any(FinancialDetailedVO.class))).thenReturn(financialDetailedVO);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFinancialDetailedVOList());
	}
	
	
	
}
