package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.PyDefinitionDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ApprovalChainValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalChainValidatorTest {

	@InjectMocks
	private ApprovalChainValidator validator;
	@Mock
	private MasterRuleEngine ruleEngine; 
	@Mock
	private ProposalRepository proposalRepository;
	@Mock
	private AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Mock
	private ResponseBuilder responseBuilder;
	@Mock
	private ApprovalProcessRepository approvalProcessRepository;
	@Mock
	private FordPersonRepository fordPersonRepository;

	private ApiParams apiParams = new ApiParams();
	private ProposalDto proposalDto = new ProposalDto();
	private FinMasterDto finMasterDto = new FinMasterDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	private FordPersonDto personDto = new FordPersonDto();
	private ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();

	private HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

	public ApiParams getApiParams() {
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("USA");
		return apiParams;
	}
	
	public void loadFordPersion(String cdsid, boolean isSprcd) {
		personDto.setCdsid(cdsid);
		personDto.setSprcdsidDescription(isSprcd ? cdsid : null);
	}

	public Optional<ProposalDto> getProposalDto() {
		PyDefinitionDto pyDefinitionDto = new PyDefinitionDto();
		pyDefinitionDto.setActivateAutoearlyFlag("");
		pyDefinitionDto.setArchiveFlag("");
		pyDefinitionDto.setArchiveYear(null);
		pyDefinitionDto.setAutoearlyYear(null);
		pyDefinitionDto.setCreatedProcess(null);
		pyDefinitionDto.setCreatedTimeStamp(null);
		pyDefinitionDto.setCreatedUser(null);
		pyDefinitionDto.setCurrentPyFlag(null);
		pyDefinitionDto.setEndYear(null);
		pyDefinitionDto.setLastUpdatedProcess(null);
		pyDefinitionDto.setLastUpdatedTimeStamp(null);
		pyDefinitionDto.setLastUpdatedUser(null);
		pyDefinitionDto.setProposals(Collections.emptyList());
		pyDefinitionDto.setProposalYearCode(0);
		pyDefinitionDto.setStartYear(null);
		proposalDto.setFordPerson(personDto);
		proposalDto.setPyDefinition(pyDefinitionDto);
		proposalDto.setCntlReqdFlag(true);
		finMasterDto.setFinMasterKey(1L);
		proposalDto.setFinMasterKey(finMasterDto);
		return proposal;
	}
	
	public void loadProposalStatus(String status) {
		ProposalStatusDto statusDto = new ProposalStatusDto();
		statusDto.setProposalStatusCode(status);
		proposalDto.setProposalStatus(statusDto);
		approvalProcessDto.setProposalStatus(statusDto);
	}
	
	public void loadReportLevel(int code) {
		ReportLevelDto levelDto = new ReportLevelDto();
		levelDto.setCode(code);
		levelDto.setTitleCode("");
		levelDto.setCommentDesc("");
		levelDto.setCountry("");
		levelDto.setCreatedProcess("");
		levelDto.setCreatedTimeStamp(null);
		levelDto.setCreatedUser("");
		levelDto.setLastUpdatedProcess("");
		levelDto.setLastUpdatedTimeStamp(null);
		levelDto.setLastUpdatedUser("");
		levelDto.setMaxApprovalAmount(null);
		levelDto.setMinApprovalAmount(null);
		levelDto.setSaKey(code);
		levelDto.setTitleDesc("");
		proposalDto.setReportLevel(levelDto);
		approvalProcessDto.setReportLevel(levelDto);
		personDto.setReportLevel(levelDto);
	}
	
	public List<ApprovalChainVO> getApprovalChainVOs(int role, String title, String cdsid, String status, Date statusDate) {
		List<ApprovalChainVO> approvalChainVOs = new ArrayList<>();
		ApprovalChainVO approvalChainVO = new ApprovalChainVO(role, title, cdsid, status, statusDate);
		approvalChainVOs.add(approvalChainVO);
		return approvalChainVOs;
	}
	
	public List<ApprovalProcessDto>	getApprovalProcessDto(){
		List<ApprovalProcessDto> approvalProcessDtos = new ArrayList<>();
		approvalProcessDto.setSubmittedToId(personDto);
		approvalProcessDto.setSubmittedById(personDto);
		approvalProcessDto.setApprovedById(personDto);
		approvalProcessDtos.add(approvalProcessDto);
		return approvalProcessDtos;
	}

	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(genericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstructWithNewStatusProposal()  throws InterruptedException, ExecutionException{
		loadProposalStatus(ApprovalConstants.NEW);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0006");
		when(responseBuilder.generateResponse(ResponseCodes.APPROVAL_CHAIN_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(genericResponse);
		assertEquals("MSG-0006", actualGenericResponse.getMsgId());	
	}
	
	@Test
	public void testValidateAndConstructWithSubmittedStatusProposal()  throws InterruptedException, ExecutionException{
    	loadReportLevel(1);
    	loadProposalStatus(ApprovalConstants.SUBMITTED);
    	loadFordPersion("FBMSTID1", false);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(-1, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("Approval Chain not available for this version.", approvalChainVO.getCdsid());
		assertEquals("Not Applicable", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	
	@Test
	public void testValidateAndConstructWithRevisedStatusProposal()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.REVISED);
    	loadReportLevel(1);
    	loadFordPersion("FBMSTID1", false);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(-1, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("Approval Chain not available for this version.", approvalChainVO.getCdsid());
		assertEquals("Not Applicable", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	
	@Test
	public void testValidateAndConstructWithApvStatusProposal()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.APPROVED);
    	loadReportLevel(1);
    	loadFordPersion("FBMSTID1", false);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(-1, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("Approval Chain not available for this version.", approvalChainVO.getCdsid());
		assertEquals("Not Applicable", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	
	@Test
	public void testValidateAndConstructWithApvStatusProposalWithApprovalProcessDtos()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.APPROVED);
    	loadReportLevel(1);
    	loadFordPersion("FBMSTID1", false);
    	getApprovalProcessDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(getApprovalProcessDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(-1, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("Approval Chain not available for this version.", approvalChainVO.getCdsid());
		assertEquals("Not Applicable", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	@Test
	public void testValidateAndConstructWithApvStatusProposalWithApprovalProcessDtosWithAutoApvId()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.APPROVED);
    	loadReportLevel(1);
    	loadFordPersion(ApprovalConstants.AUTOAPV, false);
    	getApprovalProcessDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(getApprovalProcessDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(-1, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("Approval Chain not available for this version.", approvalChainVO.getCdsid());
		assertEquals("Not Applicable", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	
	@Test
	public void testValidateAndConstructWithApvStatusProposalWithApprovalProcessDto()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.APPROVED);
    	loadReportLevel(2);
    	loadFordPersion(ApprovalConstants.AUTOAPV, true);
    	getApprovalProcessDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.any(), Mockito.any(), Mockito.anyInt())).thenReturn(getApprovalProcessDto());
		when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.any(), Mockito.any())).thenReturn(getApprovalProcessDto().get(0));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(14, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("AUTOAPV", approvalChainVO.getCdsid());
		assertEquals("SUB", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}
	
	@Test
	public void testValidateAndConstructWithApvStatusProposalWithApprovalProcessDtoLevel3()  throws InterruptedException, ExecutionException{
    	loadProposalStatus(ApprovalConstants.APPROVED);
    	loadReportLevel(3);
    	loadFordPersion(ApprovalConstants.AUTOAPV, false);
    	getApprovalProcessDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(getProposalDto());
		when(approvalProcessRepository.findApprovalProcessByProposalFordPerson(Mockito.any(), Mockito.any(), Mockito.anyInt())).thenReturn(getApprovalProcessDto());
		when(approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(Mockito.any(), Mockito.any())).thenReturn(getApprovalProcessDto().get(0));
		when(fordPersonRepository.findById(Mockito.anyString())).thenReturn(Optional.of(personDto));
		when(approvalProcessRepository.findApprovalProcessById(Mockito.anyLong())).thenReturn(getApprovalProcessDto());
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		genericResponseWrapper.setApprovalChainList(getApprovalChainVOs(-1, "Account Manager", "Approval Chain not available for this version.", "Not Applicable", null));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponseWrapper = wrapper.get();
		assertNotNull(actualGenericResponseWrapper);
		ApprovalChainVO approvalChainVO = actualGenericResponseWrapper.getApprovalChainList().get(0);
		assertEquals(14, approvalChainVO.getRole());	
		assertEquals("Account Manager", approvalChainVO.getTitle());	
		assertEquals("AUTOAPV", approvalChainVO.getCdsid());
		assertEquals("SUB", approvalChainVO.getStatus());
		assertNull(approvalChainVO.getStatusDate());
	}

}
