package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ApprovalRequest;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementCreateValidator;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ApprovalManagementCreateValidatorTest {

	@InjectMocks
	private ApprovalManagementCreateValidator validator;
	@Mock
	private MasterRuleEngine ruleEngine;
	
	@Mock
	private ResponseBuilder responseBuilder;
	
	@Mock
	private FordPersonRepository fordPersonRepository;

	private ApiParams apiParams = new ApiParams();
	private ApprovalRequest approvalRequest;
	private FordPersonDto personDto = new FordPersonDto();

	private HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

	public ApiParams getApiParams() {
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("USA");
		return apiParams;
	}
	
	public void loadFordPersion(String cdsid) {
		personDto.setCdsid(cdsid);
	}
	
	public ApprovalRequest getApprovalRequest(String segmentGroup) {
		approvalRequest = new ApprovalRequest();
		approvalRequest.setSegmentGroup(segmentGroup);
		return approvalRequest;
	}

	@Test
	public void testValidateAndConstructWith() throws InterruptedException, ExecutionException {
		loadFordPersion("FBMSTID1");
		when(fordPersonRepository.findIdAndKey(Mockito.anyString())).thenReturn(personDto);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), getApprovalRequest("C"), ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFordPersonDto());
		assertEquals("FBMSTID1", actualGenericResponse.getFordPersonDto().getCdsid());
	}
	
	@Test
	public void testValidateAndConstructWithOtherSegmentGroup() throws InterruptedException, ExecutionException {
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), getApprovalRequest("D"), ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getFordPersonDto());
		assertNotEquals("FBMSTID1", actualGenericResponse.getFordPersonDto().getCdsid());
	}
}
