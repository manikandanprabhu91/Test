package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static com.ford.fbms.approvalmanagement.util.Constants.BLANK;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.BodyStyleDto;
import com.ford.fbms.approvalmanagement.domain.CatalogDataDto;
import com.ford.fbms.approvalmanagement.domain.CatalogFinancialDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.VehicleLineDto;
import com.ford.fbms.approvalmanagement.domain.WERSVehicleEntityDto;
import com.ford.fbms.approvalmanagement.repository.CatalogFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.MexProposalManager;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MexProposalManagerTest {
	
	@InjectMocks
	private MexProposalManager mexProposalMngr;
	@Mock
	private ProposalRepository proposalRepository;
	@Mock
	private ProposalExtraInfoRepository proposalExtraInfoRepo;
	@Mock
	private ResponseBuilder responseBuilder;
	@Mock
	private ProposalVehicleLineIncentiveRepository proposalVehicleLineRepo;
	
	@Mock
	private PviExtraInfoRepository pviExtraInfoRepo;
	@Mock
	private CatalogFinancialRepository catalogFinancialRepo;
	
	private ApiParams apiParams = new ApiParams();
	private ProposalDto proposalDto = new ProposalDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	private FordPersonDto personDto = new FordPersonDto();
	
	@Before
	public void setup() {
		
		apiParams = this.getApiParams();
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
	}
	
	public ApiParams getApiParams() {
		apiParams.setProposalKey(2L);
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("MEX");
		apiParams.setFleetRating("test");
		return apiParams;
	}
	
	@Test
	public void test_validateAndConstruct_failure() throws InterruptedException, ExecutionException {
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0015");
		when(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED)).thenReturn(genericResponse);
		Mockito.when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		
		assertEquals("MSG-0015",mexProposalMngr.validateAndConstruct(apiParams, null, null, null).get().getGenericResponse().getMsgId());
	}
	
	@Test
	public void test_validateAndConstruct_success() throws InterruptedException, ExecutionException {
		
		ProposalExtraInfoDto extraInfoDto = new ProposalExtraInfoDto();
		Calendar now = Calendar.getInstance();
		extraInfoDto.setProposalExpirationTS(new Timestamp(now.getTime().getTime()));
		
		List<ProposalVehicleLineIncentiveDto> list = new ArrayList<>();
		list.add(setVehicleDetails(1l,"Test Data1"));
		list.add(setVehicleDetails(2l,"Test Data2"));
		PviExtraInfoDto pviExtraInfoDto = setExtraInfo();
		CatalogFinancialDto targetCatalog = new CatalogFinancialDto();
		targetCatalog.setFleetIncentive(1L);
		targetCatalog.setContMargin(1l);
		
		Mockito.when(proposalExtraInfoRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(extraInfoDto));
		Mockito.when(proposalVehicleLineRepo.findByProposal(Mockito.any())).thenReturn(Optional.of(list));
		Mockito.when(pviExtraInfoRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(catalogFinancialRepo.getMarketingProgram(Mockito.anyLong(),Mockito.anyString())).thenReturn(targetCatalog);
		assertNotNull(mexProposalMngr.validateAndConstruct(apiParams, null, null, null).get());
	}
	
	@Test
	public void test_validateAndConstruct_success_ProposalExpire() throws InterruptedException, ExecutionException {
		
		ProposalExtraInfoDto extraInfoDto = new ProposalExtraInfoDto();
		Calendar now = Calendar.getInstance();
		now.set(1980, 1, 1);
		extraInfoDto.setProposalExpirationTS(new Timestamp(now.getTime().getTime()));
		
		List<ProposalVehicleLineIncentiveDto> list = new ArrayList<>();
		list.add(setVehicleDetails(1l,"Test Data1"));
		list.add(setVehicleDetails(2l,"Test Data2"));
		PviExtraInfoDto pviExtraInfoDto = setExtraInfo();
		pviExtraInfoDto.setBusinessCase(null);
		CatalogFinancialDto targetCatalog = setCatalogFinancial();
		
		
		Mockito.when(proposalExtraInfoRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(extraInfoDto));
		Mockito.when(proposalVehicleLineRepo.findByProposal(Mockito.any())).thenReturn(Optional.of(list));
		Mockito.when(pviExtraInfoRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviExtraInfoDto));
		Mockito.when(catalogFinancialRepo.getMexFinanceTargetDetails(Mockito.anyLong(),Mockito.anyString(),Mockito.any())).thenReturn(targetCatalog);
		assertNotNull(mexProposalMngr.validateAndConstruct(apiParams, null, null, null).get());
	}

	private CatalogFinancialDto setCatalogFinancial() {
		CatalogFinancialDto targetCatalog = new CatalogFinancialDto();
		targetCatalog.setFleetIncentive(1L);
		targetCatalog.setContMargin(1l);
		targetCatalog.setBodyStyleKey(0l);
		targetCatalog.setCatFinKey(0l);
		targetCatalog.setContMarginPct(0d);
		targetCatalog.setCreatedProcess(null);
		targetCatalog.setCreatedTimeStamp(null);
		targetCatalog.setCreatedUser(null);
		targetCatalog.setDealerMargin(0l);
		targetCatalog.setDealerMarginPct(0d);
		targetCatalog.setEffStartDate(null);
		targetCatalog.setFleetPrice(0l);
		targetCatalog.setFleetRating(null);
		targetCatalog.setLastUpdatedProcess(null);
		targetCatalog.setLastUpdatedTimeStamp(null);
		targetCatalog.setLastUpdatedUser(null);
		targetCatalog.setMarketingProgram(null);
		targetCatalog.setRetailIncentive(0l);
		targetCatalog.setRetailPrice(0l);
		
		targetCatalog.getFleetIncentive();
		targetCatalog.getContMargin();
		targetCatalog.getBodyStyleKey();
		targetCatalog.getCatFinKey();
		targetCatalog.getContMarginPct();
		targetCatalog.getCreatedProcess();
		targetCatalog.getCreatedTimeStamp();
		targetCatalog.getCreatedUser();
		targetCatalog.getDealerMargin();
		targetCatalog.getDealerMarginPct();
		targetCatalog.getEffStartDate();
		targetCatalog.getFleetPrice();
		targetCatalog.getFleetRating();
		targetCatalog.getLastUpdatedProcess();
		targetCatalog.getLastUpdatedTimeStamp();
		targetCatalog.getLastUpdatedUser();
		targetCatalog.getMarketingProgram();
		targetCatalog.getRetailIncentive();
		targetCatalog.getRetailPrice();
		return targetCatalog;
	}
	
	@Test
	public void test_showIncludedInPriorSection() throws InterruptedException, ExecutionException {
		
		List<FinancialDetailedVO> financialDetaiedList = new ArrayList<>();
		FinancialDetailedVO vo = new FinancialDetailedVO();
		vo.setPresentProposal(false);
		financialDetaiedList.add(vo);
		assertTrue(mexProposalMngr.showIncludedInPriorSection(financialDetaiedList));
	}

	private PviExtraInfoDto setExtraInfo() {
		PviExtraInfoDto pviExtraInfoDto = new PviExtraInfoDto();
		pviExtraInfoDto.setBusinessCase("Test");
		pviExtraInfoDto.setFleetIncentive(2L);
		pviExtraInfoDto.setFloorPlanCost(1L);
		pviExtraInfoDto.setFleetPrice(1L);
		pviExtraInfoDto.setContMargin(1L);
		pviExtraInfoDto.setDealerMargin(1l);
		pviExtraInfoDto.setDealerMarginPct(2d);
		return pviExtraInfoDto;
	}

	private ProposalVehicleLineIncentiveDto setVehicleDetails(Long my,String vlCode) {
		ProposalVehicleLineIncentiveDto incentiveDto = new ProposalVehicleLineIncentiveDto();
		BodyStyleDto bs = new BodyStyleDto();
		bs.setBodyStyleSaKey(1L);
		VehicleLineDto vlDto = new  VehicleLineDto();
		vlDto.setModelYear(my);
		vlDto.setVehlnDesc("Test VL");
		vlDto.setVehlnCode(vlCode);
		bs.setVehicleLine(vlDto);
		bs.setBodyStyleCode("Test BS");
		incentiveDto.setBodyStyle(bs);
		incentiveDto.setMlv(2L);
		WERSVehicleEntityDto wersVehicleEntityDto = setWersVehicleEntity();
		incentiveDto.setWersvehicleEntity(wersVehicleEntityDto);
		
		return incentiveDto;
	}

	private WERSVehicleEntityDto setWersVehicleEntity() {
		WERSVehicleEntityDto wersVehicleEntityDto = new WERSVehicleEntityDto();
		CatalogDataDto catalogDataDto = new CatalogDataDto();
		catalogDataDto.setCatalogDataId(BLANK);
		catalogDataDto.setCreatedProcess(BLANK);
		catalogDataDto.setCreatedTimeStamp(null);
		catalogDataDto.setCreatedUser(BLANK);
		catalogDataDto.setLastUpdatedProcess(BLANK);
		catalogDataDto.setLastUpdatedTimeStamp(null);
		catalogDataDto.setLastUpdatedUser(BLANK);
		catalogDataDto.setModelYearCode(BLANK);
		catalogDataDto.setNamePlateDesc(BLANK);
		catalogDataDto.setNamePlateId(BLANK);
		catalogDataDto.setPtvlCode(BLANK);
		catalogDataDto.setSaKey(0);
		catalogDataDto.setSegmentCode(BLANK);
		catalogDataDto.setSegmentDesc(BLANK);
		catalogDataDto.setTimingPointYear(null);
		catalogDataDto.setWersMarketCode(BLANK);
		
		catalogDataDto.getCatalogDataId();
		catalogDataDto.getCreatedProcess();
		catalogDataDto.getCreatedTimeStamp();
		catalogDataDto.getCreatedUser();
		catalogDataDto.getLastUpdatedProcess();
		catalogDataDto.getLastUpdatedTimeStamp();
		catalogDataDto.getLastUpdatedUser();
		catalogDataDto.getModelYearCode();
		catalogDataDto.getNamePlateDesc();
		catalogDataDto.getNamePlateId();
		catalogDataDto.getPtvlCode();
		catalogDataDto.getSaKey();
		catalogDataDto.getSegmentCode();
		catalogDataDto.getSegmentDesc();
		catalogDataDto.getTimingPointYear();
		catalogDataDto.getWersMarketCode();
		wersVehicleEntityDto.setCatalogData(catalogDataDto);
		return wersVehicleEntityDto;
	}

}
