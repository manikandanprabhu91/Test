/**
 * 
 */
package com.ford.fbms.approvalmanagement.util;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;

/**
 * @author vvm
 *
 */
public class FBmsutilTest {
	
	
	@Test
	public void testFbmsUtilcurrencyFormat1() {
		
		assertNotEquals(0, FbmsUtil.currencyFormat(2l));
		
	}
	
	@Test
	public void testFbmsUtilCurrencyFormat2() {
		
		assertNotEquals(0, FbmsUtil.currencyFormat(2l,1));
		assertNotEquals(0, FbmsUtil.currencyFormat(-1,1));
		
	}
	
	
	@Test
	public void testFbmsUtilCurrencyFormat4() {
		
		assertNotNull(FbmsUtil.currencyFormatforDwnload(2,1,true,true));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(2,1,true,false));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(2,1,false,true));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(-1,1,false,true));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(-1,1,true,false));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(-1,1,true,true));
		assertNotNull(FbmsUtil.currencyFormatforDwnload(-1,1,false,false));
		
	}
	
	

}
