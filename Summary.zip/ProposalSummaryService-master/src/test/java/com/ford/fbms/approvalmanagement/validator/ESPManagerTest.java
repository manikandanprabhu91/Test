package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.validators.ESPManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class ESPManagerTest extends AbstarctValidatorTest {

	@InjectMocks
	private ESPManager validator;
	
	@Test
	public void testValidateAndConstructWithEmptyTierVolume() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstructWithNullTierVolume() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(tierVolumeRepo.findAllByProposalKey(Mockito.anyLong())).thenReturn(null);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
	}
	
	@Test
	public void testValidateAndConstruct() throws InterruptedException, ExecutionException {
		loadProposalVehicleLineIncentiveDto(2);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(propsalVlRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviDto));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper genericResponseWrapper = wrapper.get();
		assertNotNull(genericResponseWrapper);
	}
	
	@Test
	public void testValidateAndConstructWithOptionIncentiveIncentive() throws InterruptedException, ExecutionException {
		loadProposalVehicleLineIncentiveDto(2);
		loadOptionIncentiveDto(null);
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(propsalVlRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviDto));
		when(optionIncentiveRepository.findByValidOptionIncentiveByVehicleLineIncentive(Mockito.anyLong())).thenReturn(Optional.of(optionIncentives));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper genericResponseWrapper = wrapper.get();
		assertNotNull(genericResponseWrapper);
	}
	
	@Test
	public void testValidateAndConstructWithOptionIncentiveIncentiveAndValidActiveCode() throws InterruptedException, ExecutionException {
		loadProposalVehicleLineIncentiveDto(2);
		loadOptionIncentiveDto("Y");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(propsalVlRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviDto));
		when(optionIncentiveRepository.findByValidOptionIncentiveByVehicleLineIncentive(Mockito.anyLong())).thenReturn(Optional.of(optionIncentives));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper genericResponseWrapper = wrapper.get();
		assertNotNull(genericResponseWrapper);
	}
	
	@Test
	public void testValidateAndConstructWithOptionIncentiveIncentiveAndInValidActiveCode() throws InterruptedException, ExecutionException {
		loadProposalVehicleLineIncentiveDto(2);
		loadOptionIncentiveDto("I");
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(proposalDto));
		when(propsalVlRepo.findByProposal(Mockito.any(ProposalDto.class))).thenReturn(Optional.of(pviDtos));
		when(propsalVlRepo.findById(Mockito.anyLong())).thenReturn(Optional.of(pviDto));
		when(optionIncentiveRepository.findByValidOptionIncentiveByVehicleLineIncentive(Mockito.anyLong())).thenReturn(Optional.of(optionIncentives));
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper genericResponseWrapper = wrapper.get();
		assertNotNull(genericResponseWrapper);
	}
	
	
	
}
