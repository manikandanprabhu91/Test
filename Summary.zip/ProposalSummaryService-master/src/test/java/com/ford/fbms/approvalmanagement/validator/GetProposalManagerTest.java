package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.GetProposalManager;

/**
 *
 * @author VSHANMU8
 */

@RunWith(MockitoJUnitRunner.Silent.class)
public class GetProposalManagerTest {

	@InjectMocks
	private GetProposalManager validator;
	@Mock
	private MasterRuleEngine ruleEngine;
	
	@Mock
	private ResponseBuilder responseBuilder;
	
	@Mock
	private ProposalRepository proposalRepository;

	private ApiParams apiParams = new ApiParams();
	private FordPersonDto personDto = new FordPersonDto();
	private ProposalDto proposalDto = new ProposalDto();
	private Optional<ProposalDto> proposal = Optional.of(proposalDto);
	
	public void loadProposalDto() {
		personDto.setCdsid("FBMSTID1");
		proposalDto.setFordPerson(personDto);
	}

	private HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);

	public ApiParams getApiParams() {
		apiParams.setUserId("TestUser");
		apiParams.setCountryCd("USA");
		apiParams.setProposalKey(1l);
		return apiParams;
	}
	
	@Test
	public void testValidateAndConstructWithEmptyProposal() throws InterruptedException, ExecutionException {
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
		GenericResponse genericResponse = new GenericResponse();
    	genericResponse.setMsgId("MSG-0064");
		when(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS)).thenReturn(genericResponse);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponse actualGenericResponse = wrapper.get().getGenericResponse();
		assertNotNull(genericResponse);
		assertEquals("MSG-0064", actualGenericResponse.getMsgId());
	}
	
	@Test
	public void testValidateAndConstructWithValidProposal() throws InterruptedException, ExecutionException {
		loadProposalDto();
		when(proposalRepository.findById(Mockito.anyLong())).thenReturn(proposal);
		Future<GenericResponseWrapper> wrapper = validator.validateAndConstruct(getApiParams(), null, ruleEngine, httpServletRequest);
		GenericResponseWrapper actualGenericResponse = wrapper.get();
		assertNotNull(actualGenericResponse);
		assertNotNull(actualGenericResponse.getProposalDataDto());
		assertEquals("FBMSTID1", actualGenericResponse.getProposalDataDto().getFordPerson().getCdsid());
	}
	
	
}
