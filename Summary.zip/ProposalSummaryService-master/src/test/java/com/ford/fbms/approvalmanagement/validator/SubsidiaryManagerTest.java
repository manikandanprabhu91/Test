package com.ford.fbms.approvalmanagement.validator;

import static org.junit.Assert.assertNotNull;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ProposalSubsidiariesVO;
import com.ford.fbms.approvalmanagement.transport.SubsidiaryResponse;
import com.ford.fbms.approvalmanagement.validators.SubsidiaryManager;

/**
 * Test class for ProposalCommentsManagerTest class.
 *
 * @author SJAGATJO on 6/1/2021.
 */
@RunWith(MockitoJUnitRunner.Silent.class)
public class SubsidiaryManagerTest {

  @Spy
  @InjectMocks
  private SubsidiaryManager subsidiaryManager;
  @Mock
  private RestService restService;
  @Mock
  private HttpServletRequest httpRequest;

  @Test
  public void testValidateAndConstruct() throws ExecutionException, InterruptedException {
    ApiParams apiParams = new ApiParams();
    apiParams.setUserId("FBMSTID1");
    apiParams.setCountryCd("USA");
    List<ProposalSubsidiariesVO> subsidiariesVos = Collections.singletonList(getSubsidiariesVo());
    SubsidiaryResponse subsidiaryResponse = new SubsidiaryResponse();
    subsidiaryResponse.setSubsidiariesVOList(subsidiariesVos);
    subsidiaryResponse.setSubsidiaryDtoList(Collections.emptyList());
    Mockito.when(restService.getSubsidiariesDetails(apiParams, httpRequest)).thenReturn(subsidiaryResponse);
    assertNotNull(subsidiaryManager
        .validateAndConstruct(apiParams, null, null,httpRequest).get().getSubsidiariesVos());
  }

  private ProposalSubsidiariesVO getSubsidiariesVo() {
    ProposalSubsidiariesVO viewDto = new ProposalSubsidiariesVO();
    viewDto.setFin("1743");
    viewDto.setAccountName("Hertz Corp");
    viewDto.setStateCode("FL");
    viewDto.setCity("Brandon");
    return viewDto;
  }
}