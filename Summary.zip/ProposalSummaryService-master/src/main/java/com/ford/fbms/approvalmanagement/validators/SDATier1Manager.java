package com.ford.fbms.approvalmanagement.validators;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class SDATier1Manager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  private ProposalSummaryViewRepository proposalSummaryViewRepo;
  @Autowired
  private ProposalRepository proposalRepository;
  @Autowired
  private ProposalAssignAttributeRepository proposalAssignAttributeRepository;
  @Autowired
  private  FordPersonRepository fordPersonRepo;
  
  

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").message("Inside ProposalAssignmentManager"));
    Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
    genericResponseWrapper =this.validatePrimaryFIN(proposalDTO.get(), genericResponseWrapper,apiParams);
    return new AsyncResult<>(genericResponseWrapper);
  }
  
  
	private GenericResponseWrapper validatePrimaryFIN(ProposalDto proposal,GenericResponseWrapper genericResponseWrapper,ApiParams apiParams) {
				
		Optional<ProposalSummaryViewDto> proposalSummaryView = this.proposalSummaryViewRepo.findById(proposal.getProposalSaKey());
		String paymentRouting = null;
		if(proposalSummaryView.isPresent()) {
			ProposalSummaryViewDto dto = proposalSummaryView.get();
			if("SDA".equalsIgnoreCase(dto.getPaymentRouting())) {
				paymentRouting = "Selling Dealer Assigned\"";
			}else {
				paymentRouting = dto.getPaymentRouting();
			}
		}
		
		if (!"None".equalsIgnoreCase(paymentRouting)) {
			
			boolean isSDAallowed = false;
			FordPersonDto user = getUser(apiParams.getUserId());
			int userLevel = user.getReportLevel().getCode();
			if (userLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
				
				ProposalAssignAttributeDto proposalAssignAttributeDto = this.proposalAssignAttributeRepository
						.findProposalAssignAttributeByFinMasterCdsid(proposal.getFinMasterKey().getFinMasterKey(),
								user.getCdsid());
				if(proposalAssignAttributeDto!=null && "Y".equalsIgnoreCase(proposalAssignAttributeDto.getSellingDlrAsgnFlag())) {
					isSDAallowed = true;
				}
			}else {
				// user is one of the Approver and hence get directly the
				// proposal assignee attributes for the FIN and validate the
				// SDA/Tier
				
				Optional<List<ProposalAssignAttributeDto>> dtos = this.proposalAssignAttributeRepository
						.findProposalAssignAttributeByFinMasterActive(proposal.getFinMasterKey().getFinMasterKey());
				
				
				if(dtos.isPresent()) {
					
					Optional<ProposalAssignAttributeDto> sellingDlrAssigne = dtos.get().stream()
							.filter(aaDto ->"Y".equalsIgnoreCase(aaDto.getSellingDlrAsgnFlag())).findAny();
					if(sellingDlrAssigne.isPresent()) {
						isSDAallowed = true;
					}
				}
				
			}
			
			if(!isSDAallowed) {
				genericResponseWrapper.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.SDA_NOT_ALLOWED_FIN));	
			}
		}
		
		return genericResponseWrapper;
}
	
private FordPersonDto getUser(String cdsid) {
		
		Optional<FordPersonDto> fordPersonOpt = this.fordPersonRepo.findById(cdsid);
		if(fordPersonOpt.isEmpty()) {
			return null;
		}
		return fordPersonOpt.get();
	}
}