// ******************************************************************************
// * Copyright (c) 2010 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   ExpandedBodyFinancialViewBO.java  $
// * $Revision:   1.0  $
// * $Author : PSIRISIN $
// * $Date : $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * ExpandedBodyFinancialViewBO
 */


@Entity
@Table(name = "FBMS_E18_A04_EXPANDED_VIEW")

public class ExpandedBodyFinancialViewDto implements Serializable {
    // Logging Setup
    
    
    public ExpandedBodyFinancialViewPK getId() {
		return id;
	}

	public void setId(ExpandedBodyFinancialViewPK id) {
		this.id = id;
	}

	public Long getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(Long bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public Long getProposalSaKey() {
		return proposalSaKey;
	}

	public void setProposalSaKey(Long proposalSaKey) {
		this.proposalSaKey = proposalSaKey;
	}

	public Long getContributionCost() {
		return (contributionCost==null?0:contributionCost);
	}

	public void setContributionCost(Long contributionCost) {
		this.contributionCost = contributionCost;
	}

	public java.util.Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(java.util.Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Long getRevenue() {
		return (revenue==null?0:revenue);
	}

	public void setRevenue(Long revenue) {
		this.revenue = revenue;
	}

	public String getSegmentGroup() {
		return segmentGroup;
	}

	public void setSegmentGroup(String segmentGroup) {
		this.segmentGroup = segmentGroup;
	}

	public Long getTier1Target() {
		return (tier1Target==null?0:tier1Target);
	}

	public void setTier1Target(Long tier1Target) {
		this.tier1Target = tier1Target;
	}

	public Long getTier2Target() {
		return (tier2Target==null?0:tier2Target);
	}

	public void setTier2Target(Long tier2Target) {
		this.tier2Target = tier2Target;
	}

	public Long getTier3Target() {
		return (tier3Target==null?0:tier3Target);
	}

	public void setTier3Target(Long tier3Target) {
		this.tier3Target = tier3Target;
	}

	public Long getTier4Target() {
		return (tier4Target==null?0:tier4Target);
	}

	public void setTier4Target(Long tier4Target) {
		this.tier4Target = tier4Target;
	}

	public Long getTier5Target() {
		return (tier5Target==null?0:tier5Target);
	}

	public void setTier5Target(Long tier5Target) {
		this.tier5Target = tier5Target;
	}

	public Long getYearOverYearTarget() {
		return (yearOverYearTarget==null?0:yearOverYearTarget);
	}

	public void setYearOverYearTarget(Long yearOverYearTarget) {
		this.yearOverYearTarget = yearOverYearTarget;
	}

	public String getAccountClassCode() {
		return accountClassCode;
	}

	public void setAccountClassCode(String accountClassCode) {
		this.accountClassCode = accountClassCode;
	}

	public Long getCurrentYrRevenue() {
		return (currentYrRevenue==null?0:currentYrRevenue);
		
	}

	public void setCurrentYrRevenue(Long currentYrRevenue) {
		this.currentYrRevenue = currentYrRevenue;
	}

	public Long getCurrentYrContributionCost() {
		return (currentYrContributionCost==null?0:currentYrContributionCost);
	}

	public void setCurrentYrContributionCost(Long currentYrContributionCost) {
		this.currentYrContributionCost = currentYrContributionCost;
	}

	public Long getBodyStyleThrshld() {
		return (bodyStyleThrshld==null?0:bodyStyleThrshld);
	}

	public void setBodyStyleThrshld(Long bodyStyleThrshld) {
		this.bodyStyleThrshld = bodyStyleThrshld;
	}

	private static final long serialVersionUID = 1L;
    
    public static final String TABLE_NAME = "FBMS_E18_A04_EXPANDED_VIEW";
    
    @EmbeddedId
    private ExpandedBodyFinancialViewPK id;
    
    @Column(name = "FBME03_BDYSTL_K_1")
	private Long bodyStyle;
    
	@Column(name = "FBMA01_PROPOSAL_K")
    private Long proposalSaKey;
	
	@Column(name = "FBME18_CONTRIBUTION_COST_R")
    private Long contributionCost;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME18_EFFECTIVE_S")
    private java.util.Date effectiveDate;
	
	@Column(name = "FBME18_REVENUE_R")
    private Long revenue;
	
	@Column(name = "FBMD99_SEGMENT_GROUP_TYPE_C")
    private String segmentGroup;
	
	@Column(name = "FBME18_TIER1_TARGET_R")
    private Long tier1Target;
	
	@Column(name = "FBME18_TIER2_TARGET_R")
    private Long tier2Target;
	
	@Column(name = "FBME18_TIER3_TARGET_R")
    private Long tier3Target;
	
	@Column(name = "FBME18_TIER4_TARGET_R")
    private Long tier4Target;
	
	@Column(name = "FBME18_TIER5_TARGET_R")
    private Long tier5Target;
	
	@Column(name = "FBME18_MY_OVER_MY_TARGET_R")
    private Long yearOverYearTarget;
	
	@Column(name = "FBME50_ACCOUNT_CLASS_C")
    private String accountClassCode;
	
	@Column(name = "FBME18_EST_CURT_YR_REVN_CHNG_A")
    private Long currentYrRevenue;
	
	@Column(name = "FBME18_EST_CURT_YR_CONTB_CST_A")
    private Long currentYrContributionCost;
	
	@Column(name = "FBME18_BDY_STYL_THRSHLD_P")
    private Long bodyStyleThrshld;

    
}
