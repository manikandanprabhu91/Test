package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for them MFBME41_PD_MARKET database table.
 * 
 */
@Entity
@Table(name = PviExtraInfoDto.TABLE_NAME)
public class PviExtraInfoDto implements Serializable {

  public Long getPviKey() {
		return pviKey;
	}

	public void setPviKey(Long pviKey) {
		this.pviKey = pviKey;
	}

	public String getFleetRating() {
		return fleetRating;
	}

	public void setFleetRating(String fleetRating) {
		this.fleetRating = fleetRating;
	}

	public String getMarketingProgram() {
		return marketingProgram;
	}

	public void setMarketingProgram(String marketingProgram) {
		this.marketingProgram = marketingProgram;
	}

	public Long getRetailPrice() {
		return retailPrice;
	}

	public void setRetailPrice(Long retailPrice) {
		this.retailPrice = retailPrice;
	}

	public Long getRetailIncentive() {
		return retailIncentive;
	}

	public void setRetailIncentive(Long retailIncentive) {
		this.retailIncentive = retailIncentive;
	}

	public Long getFleetPrice() {
		return fleetPrice;
	}

	public void setFleetPrice(Long fleetPrice) {
		this.fleetPrice = fleetPrice;
	}

	public Long getFleetIncentive() {
		return fleetIncentive;
	}

	public void setFleetIncentive(Long fleetIncentive) {
		this.fleetIncentive = fleetIncentive;
	}

	public Long getFloorPlanCost() {
		return (floorPlanCost==null?0:floorPlanCost);
	}

	public void setFloorPlanCost(Long floorPlanCost) {
		this.floorPlanCost = floorPlanCost;
	}

	public Long getContMargin() {
		return (contMargin==null?0:contMargin);
	}

	public void setContMargin(Long contMargin) {
		this.contMargin = contMargin;
	}

	public Double getContMarginPct() {
		return contMarginPct;
	}

	public void setContMarginPct(Double contMarginPct) {
		this.contMarginPct = contMarginPct;
	}

	public Long getDealerMargin() {
		return (dealerMargin==null?0:dealerMargin);
	}

	public void setDealerMargin(Long dealerMargin) {
		this.dealerMargin = dealerMargin;
	}

	public Double getDealerMarginPct() {
		return dealerMarginPct;
	}

	public void setDealerMarginPct(Double dealerMarginPct) {
		this.dealerMarginPct = dealerMarginPct;
	}

	public Date getEffStartDate() {
		return effStartDate;
	}

	public void setEffStartDate(Date effStartDate) {
		this.effStartDate = effStartDate;
	}

	public String getBusinessCase() {
		return businessCase;
	}

	public void setBusinessCase(String businessCase) {
		this.businessCase = businessCase;
	}

	public String getCompanyStock() {
		return companyStock;
	}

	public void setCompanyStock(String companyStock) {
		this.companyStock = companyStock;
	}

	public Date getCreatedTimeStamp() {
		return createdTimeStamp;
	}

	public void setCreatedTimeStamp(Date createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}

	public String getCreatedProcess() {
		return createdProcess;
	}

	public void setCreatedProcess(String createdProcess) {
		this.createdProcess = createdProcess;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public Date getLastUpdatedTimeStamp() {
		return lastUpdatedTimeStamp;
	}

	public void setLastUpdatedTimeStamp(Date lastUpdatedTimeStamp) {
		this.lastUpdatedTimeStamp = lastUpdatedTimeStamp;
	}

	public String getLastUpdatedProcess() {
		return lastUpdatedProcess;
	}

	public void setLastUpdatedProcess(String lastUpdatedProcess) {
		this.lastUpdatedProcess = lastUpdatedProcess;
	}

	public String getLastUpdatedUser() {
		return lastUpdatedUser;
	}

	public void setLastUpdatedUser(String lastUpdatedUser) {
		this.lastUpdatedUser = lastUpdatedUser;
	}

private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBMA22_PVI_EXTRA_INFO";

  @Id
  @Column(name = "FBMA04_PVI_K")
  private Long pviKey;

  @Column(name = "FBMA22_FLEET_RATING_C")
  private String fleetRating;

  @Column(name = "FBMA22_MKTG_PROGRAM_C")
  private String marketingProgram;

  @Column(name = "FBMA22_RETAIL_PRCE_R")
  private Long retailPrice;

  @Column(name = "FBMA22_RETAIL_INCENTIVE_R")
  private Long retailIncentive;

  @Column(name = "FBMA22_FLEET_PRICE_R")
  private Long fleetPrice;

  @Column(name = "FBMA22_FLEET_INCENTIVE_R")
  private Long fleetIncentive;

  @Column(name = "FBMA22_FLOOR_PLAN_COST_R")
  private Long floorPlanCost;

  @Column(name = "FBMA22_CONTR_MARGIN_R")
  private Long contMargin;

  @Column(name = "FBMA22_CONTR_MARGIN_PCT_R")
  private Double contMarginPct;

  @Column(name = "FBMA22_DEALER_MARGIN_R")
  private Long dealerMargin;

  @Column(name = "FBMA22_DEALER_MARGIN_PCT_R")
  private Double dealerMarginPct;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA22_EFFECTIVE_START_S")
  private Date effStartDate;

  @Column(name = "FBMA22_BUSINESS_CASE_C")
  private String businessCase;

  @Column(name = "FBMA22_COMPANY_STOCK_F")
  private String companyStock;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA22_CREATE_S")
  private Date createdTimeStamp;

  @JsonIgnore
  @Column(name = "FBMA22_CREATE_PROCESS_C")
  private String createdProcess;

  @JsonIgnore
  @Column(name = "FBMA22_CREATE_USER_C")
  private String createdUser;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA22_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @JsonIgnore
  @Column(name = "FBMA22_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @JsonIgnore
  @Column(name = "FBMA22_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}