package com.ford.fbms.approvalmanagement.repository;

import java.util.Optional;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ford.fbms.approvalmanagement.domain.FinOpUnitMaster;
@Repository
public interface FinOpUnitMasterRepository extends JpaRepository<FinOpUnitMaster, Long> {
	
	
	@Query("select fom from FinOpUnitMaster fom where fom.finMasterDto.finMasterKey=:finMaster and fom.operationUnitCode=:finOpUnit")
	Optional<FinOpUnitMaster> findByFinMasterFinOpUnit(@Param("finMaster") Long finMaster,@Param("finOpUnit") String finOpUnit);

}
