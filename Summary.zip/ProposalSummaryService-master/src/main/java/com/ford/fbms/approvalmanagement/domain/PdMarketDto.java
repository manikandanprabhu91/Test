package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for them MFBME41_PD_MARKET database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = PdMarketDto.TABLE_NAME)
public class PdMarketDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBME41_PD_MARKET";

	@Id
	@Column(name = "FBME41_PD_MARKET_C")
	private String pdMarketCode;

	@Column(name = "FBME41_IMPORT_NOTE_C")
	private String importNoteCode;

	@Column(name = "FBME41_LANGUAGE_N")
	private String languageName;

	@Column(name = "FBME41_PD_MARKET_N")
	private String pdMarketName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME41_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME41_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME41_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME41_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME41_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME41_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
