package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ProposalRepository extends JpaRepository<ProposalDto, Long> {
  @Query(value="Select proposal.* "
  		+ "from {h-schema}MFBMA01_PROPOSAL proposal "
      + "where proposal.FBMA01_PROPOSAL_K = :proposalKey",nativeQuery = true)
  ProposalDto findAllByProposalKey(@Param("proposalKey") long proposalKey);

  @Query(value ="Select proposalDto.* "+
		  "from {h-schema}MFBMA01_PROPOSAL proposalDto "
      + "where proposalDto.FBME01_FIN_MASTER_K = :finMaster "
      + "and proposalDto.FBMD12_PROPOSAL_YEAR_C = :proposalYear "
      + "and proposalDto.FBMA01_VERNUM_R = :versionNumber",nativeQuery = true)
 <Optional>ProposalDto proposalByFinMasterProposalYearVersion(@Param("finMaster")Long finMaster,
		  @Param("proposalYear")int proposalYear,@Param("versionNumber") int versionNumber);
  
  
	@Query(value ="SELECT PROP.*"+
			"FROM {h-schema}MFBMA01_PROPOSAL PROP,"+
			 "(SELECT MAX_EST_URV_VER FBMA01_VERNUM_R,"+ 
			  "FBMD12_PROPOSAL_YEAR_C, "+
			  "FBME01_FIN_MASTER_K "+
			 "FROM (SELECT MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C= 'TRM' THEN FBMA01_VERNUM_R ELSE -1 END) MAX_TRM_VER,"+
			                        "MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C = 'EST' THEN FBMA01_VERNUM_R WHEN FBMD11_PROPOSAL_STATUS_C ='URV' THEN FBMA01_VERNUM_R ELSE -1 END) MAX_EST_URV_VER,"+
			                        "FBMD12_PROPOSAL_YEAR_C,"+        
			                        "FBME01_FIN_MASTER_K"+
			                        " FROM  {h-schema}MFBMA01_PROPOSAL " +
			       "WHERE FBMD12_PROPOSAL_YEAR_C = :proposalYear AND "+
			                        "FBME01_FIN_MASTER_K = :finMaster "+ 
			                        "GROUP BY FBMD12_PROPOSAL_YEAR_C, "+
			                        "FBME01_FIN_MASTER_K"+
			              ") TMP "+
			 "WHERE TMP.MAX_TRM_VER < TMP.MAX_EST_URV_VER AND " +
			  " TMP.MAX_EST_URV_VER > 0 "+
			        "UNION ALL " +
			        "SELECT MAX_APV_VER FBMA01_VERNUM_R, "+ 
			  "FBMD12_PROPOSAL_YEAR_C,"+
			  "FBME01_FIN_MASTER_K "+
			 "FROM  (SELECT MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C='TRM' THEN FBMA01_VERNUM_R WHEN FBMD11_PROPOSAL_STATUS_C='DEC' THEN FBMA01_VERNUM_R ELSE -1 END ) MAX_TRM_DEC_VER,"+
			                      "  MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C= 'EST' THEN FBMA01_VERNUM_R WHEN FBMD11_PROPOSAL_STATUS_C='URV' THEN FBMA01_VERNUM_R ELSE -1 END) MAX_EST_URV_VER," +
			                      " MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C ='APV' THEN FBMA01_VERNUM_R ELSE -1 END ) MAX_APV_VER,"+
			                      " FBMD12_PROPOSAL_YEAR_C, "+        
			                      "FBME01_FIN_MASTER_K  " +
			                      "   FROM   {h-schema}MFBMA01_PROPOSAL " +
			       "WHERE FBMD12_PROPOSAL_YEAR_C = :proposalYear AND "+ 
			                       " FBME01_FIN_MASTER_K = :finMaster " +
			             " GROUP BY FBMD12_PROPOSAL_YEAR_C, "+
			             "FBME01_FIN_MASTER_K "+
			              ") TMP0 " +
			 "WHERE TMP0.MAX_TRM_DEC_VER < TMP0.MAX_APV_VER AND  "+
			  "TMP0.MAX_EST_URV_VER = -1 " +

			" ) TMP2 "+
			"WHERE PROP.FBMD12_PROPOSAL_YEAR_C = TMP2.FBMD12_PROPOSAL_YEAR_C AND "+
			      "PROP.FBME01_FIN_MASTER_K = TMP2.FBME01_FIN_MASTER_K AND "+
			      "PROP.FBMA01_VERNUM_R = TMP2.FBMA01_VERNUM_R "+
			      "",nativeQuery = true)
	Optional<ProposalDto> getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(@Param("proposalYear") long proposalYear,
			@Param("finMaster") long finMaster);
	
	
	@Query(value = "SELECT PROP.*"
			+ "FROM {h-schema}MFBMA01_PROPOSAL PROP,"
			+ " (SELECT MAX_EST_URV_VER FBMA01_VERNUM_R, "
			+ "  FBMD12_PROPOSAL_YEAR_C,"
			+ "  FBME01_FIN_MASTER_K"
			+ "  FROM (SELECT MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C='TRM' THEN FBMA01_VERNUM_R ELSE -1 END) MAX_TRM_VER,"
			+ "                        MAX(CASE WHEN FBMD11_PROPOSAL_STATUS_C='EST'THEN  FBMA01_VERNUM_R WHEN FBMD11_PROPOSAL_STATUS_C='URV'THEN FBMA01_VERNUM_R ELSE -1 END) MAX_EST_URV_VER,"
			+ "                        FBMD12_PROPOSAL_YEAR_C,        "
			+ "   FBME01_FIN_MASTER_K"
			+ "              FROM {h-schema}MFBMA01_PROPOSAL"
			+ "       WHERE FBMD12_PROPOSAL_YEAR_C =:proposalYear AND "
			+ "                        FBME01_FIN_MASTER_K = :finMaster "
			+ "              GROUP BY FBMD12_PROPOSAL_YEAR_C,"
			+ "   FBME01_FIN_MASTER_K"
			+ "              ) TMP"
			+ " WHERE TMP.MAX_TRM_VER < TMP.MAX_EST_URV_VER AND "
			+ "  TMP.MAX_EST_URV_VER > 0"
			+ " ) TMP2"
			+ " WHERE PROP.FBMD12_PROPOSAL_YEAR_C = TMP2.FBMD12_PROPOSAL_YEAR_C AND"
			+ "      PROP.FBME01_FIN_MASTER_K = TMP2.FBME01_FIN_MASTER_K AND"
			+ "      PROP.FBMA01_VERNUM_R = TMP2.FBMA01_VERNUM_R",nativeQuery = true)
	
	Optional<ProposalDto> getMaxEstOrUrvOnProposalByProposalYearFinMaster(@Param("proposalYear") long proposalYear,
			@Param("finMaster") long finMaster);
	
	
	@Query(value ="Select *   "+
			  "from {h-schema}MFBMA01_PROPOSAL proposalDto ,{h-schema}mfbme01_fin_master  e01 "
	      + "where proposalDto.FBME01_FIN_MASTER_K = e01.FBME01_FIN_MASTER_K    "
	      + "and    e01.FBME01_FIN_C = :finMaster "
	      + "and proposalDto.FBMD12_PROPOSAL_YEAR_C = :proposalYear "
	     ,nativeQuery = true)
	Optional<List<ProposalDto>> proposalByFinMasterProposalYear(@Param("finMaster")String finMaster,
			  @Param("proposalYear")int proposalYear);


}
