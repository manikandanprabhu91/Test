package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.AutoearlyBodystyle;
import com.ford.fbms.approvalmanagement.domain.AutoearlyBodystylePK;
import com.ford.fbms.approvalmanagement.domain.BodyGroupAssignment;
import com.ford.fbms.approvalmanagement.domain.OptionIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PyVehicleDefinition;
import com.ford.fbms.approvalmanagement.repository.AutoearlyBodystyleRepository;
import com.ford.fbms.approvalmanagement.repository.OptionIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PyVehicleDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.TierIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class VehicleLineBodyStyleEligibilityManager implements Validator {

	@Autowired
	private ProposalRepository proposalRepository;
	@Autowired
	protected TierIncentiveRepository tierIncentiveRepo;
	@Autowired
	protected ProposalVehicleLineIncentiveRepository propsalVlRepo;
	@Autowired
	protected TierVolumeRepository tierVolumeRepo;
	@Autowired
	protected OptionIncentiveRepository optionIncentiveRepository;
	@Autowired
	protected PyVehicleDefinitionRepository pyVehicleDfnRepo;
	@Autowired
	protected AutoearlyBodystyleRepository autoEarlyRepo;
	@Autowired
	private ResponseBuilder responseBuilder;

	
	@Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams, final Object request,
			final MasterRuleEngine masterRuleEngine, final HttpServletRequest httpRequest) {
		GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log,
				logger -> logger.methodName("validateAndConstruct").message("Inside ProposalAssignmentManager"));
		Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
		genericResponseWrapper = this.validateVehicleLineBodyStyle(proposalDTO.get(),genericResponseWrapper);
		return new AsyncResult<>(genericResponseWrapper);
	}

	private GenericResponseWrapper validateVehicleLineBodyStyle(ProposalDto proposal,GenericResponseWrapper genericResponseWrapper) {
		List<ProposalVehicleLineIncentiveDto> lineIncentiveDtos = getVehicleLineIncentiveList(proposal);
		boolean isAllVehicleLineIncentivesValid = true;
		StringBuilder vliWarning = new StringBuilder();
		if (null != lineIncentiveDtos && !lineIncentiveDtos.isEmpty()) {

			int pYear = -1;
			Long vehicleLineSaKey = -1L;
			for (ProposalVehicleLineIncentiveDto incentiveRO : lineIncentiveDtos) {

				pYear = proposal.getPyDefinition().getProposalYearCode();
				// both can't be null so if bodyGroup is null..bodyStyle
				// will not be null
				vehicleLineSaKey = incentiveRO.getBodyStyle().getVehicleLine().getVehlnSaKey();
				String vehicleLine = incentiveRO.getBodyStyle().getVehicleLine().getModelYear() + " "
						+ incentiveRO.getBodyStyle().getVehicleLine().getVehlnDesc();
				
				Optional<PyVehicleDefinition> pydOpt = this.pyVehicleDfnRepo.findByProposalYearVehicleLine(pYear,
						vehicleLineSaKey);
				if (pydOpt.isPresent()) {
					// that means the vehicle line is valid for this proposal

					if  ("Y".equalsIgnoreCase(incentiveRO.getBodyStyle().getBodyGroupIndFlag())) {

						List<BodyGroupAssignment> bodyStyleList = incentiveRO.getBodyStyle().getBodyGroupAssignemnts();

						if (bodyStyleList != null && !(bodyStyleList.isEmpty())) {
							for (BodyGroupAssignment assignmentRO : bodyStyleList) {
								AutoearlyBodystylePK pk = new AutoearlyBodystylePK();
								pk.setBodyStyle(assignmentRO.getId().getBodystyleSaKey());
								pk.setPyVehicleDefinition(pydOpt.get());
								Optional<AutoearlyBodystyle> findById = autoEarlyRepo.findById(pk);
								if (findById.isPresent()) {
									// good to go...no issues
								} else {
									// body style is not valid for adding to
									// proposal
									isAllVehicleLineIncentivesValid = false;
									vliWarning.append(
											assignmentRO.getId().getMfbme03BodyStyle().
													getBodyStyleCode()).append("[")
											.append(
													   assignmentRO.getId().getBodystyleSaKey()
															).append(
													"], ");

								}
							}

						} else {
							// empty body group
							isAllVehicleLineIncentivesValid = false;
							vliWarning
							.append(
									incentiveRO.getBodyStyle()
											.getBodyStyleCode())
							.append(
									"[No body styles defined for this group], ");
						}

					} else {
						AutoearlyBodystylePK pk = new AutoearlyBodystylePK();
						pk.setBodyStyle(incentiveRO.getBodyStyle());
						pk.setPyVehicleDefinition(pydOpt.get());
						Optional<AutoearlyBodystyle> findByIdOpt = this.autoEarlyRepo.findById(pk);
						if (findByIdOpt.isEmpty()) {
							isAllVehicleLineIncentivesValid = false;
							vliWarning.append(
									incentiveRO.getBodyStyle().getBodyStyleCode())
									.append("[").append(
											incentiveRO.getBodyStyle()
													.getVehicleLine()
													.getVehlnDesc()).append(
											" ").append(
											incentiveRO.getBodyStyle()
													.getVehicleLine()
													.getModelYear()).append(
											"], ");
							
							
						}
					}
				} else {
					isAllVehicleLineIncentivesValid = false;
					vliWarning.append("vehicleLine[").append(vehicleLine)
					.append("], ");
					vehicleLine = null;
					
				}
			}
		}
		if (!isAllVehicleLineIncentivesValid) {
			String vliWarningMsg = vliWarning.substring(0, vliWarning
					.lastIndexOf(", "));
			GenericResponse genericResponse= responseBuilder.generateResponse(ResponseCodes.INVALID_PER_UNIT_ROWS);
			genericResponse.setMsgDesc(MessageFormat.format(genericResponse.getMsgDesc(),vliWarningMsg));
			genericResponseWrapper.setGenericResponse(genericResponse);
			
		}
		
		return genericResponseWrapper;
	}

	private List<ProposalVehicleLineIncentiveDto> getVehicleLineIncentiveList(ProposalDto proposal) {
		List<ProposalVehicleLineIncentiveDto> vehLineList = null;
		Optional<List<ProposalVehicleLineIncentiveDto>> vehLineList_Final = propsalVlRepo.findByProposal(proposal);
		if (vehLineList_Final.isPresent()) {
			return vehLineList_Final.get();
		}
		return vehLineList;
	}

	public List<OptionIncentiveDto> getOptionIncentiveList(ProposalVehicleLineIncentiveDto vlIncentive) {

		Optional<List<OptionIncentiveDto>> oList = this.optionIncentiveRepository
				.findByValidOptionIncentiveByVehicleLineIncentive(vlIncentive.getPviSaKey());

		if (oList.isPresent()) {

			return oList.get();
		} else {
			return new ArrayList<OptionIncentiveDto>();
		}
	}

}