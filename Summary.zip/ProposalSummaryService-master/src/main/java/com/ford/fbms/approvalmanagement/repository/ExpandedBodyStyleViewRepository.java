package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.ExpandedBodyStyleViewDto;
import com.ford.fbms.approvalmanagement.domain.ExpandedBodyStyleViewPK;

@Repository
public interface ExpandedBodyStyleViewRepository extends JpaRepository<ExpandedBodyStyleViewDto,ExpandedBodyStyleViewPK>{
	
	Optional<List<ExpandedBodyStyleViewDto>> findByIdBodyStyleSaKey(@Param("bodyStyleSaKey")long bodyStyleSaKey);

}
