package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME03_BODY_STYLE database table.
 *
 */
@Setter
@Getter
@Entity
@Table(name = "MFBME03_BODY_STYLE")
public class BodyStyleDto implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBME03_BDYSTL_K")
  private long bodyStyleSaKey;

  @Column(name = "FBME03_BDYSTL_C")
  private String bodyStyleCode;

  @Column(name = "FBME03_BDYSTL_X")
  private String bodyStyleDesc;

  @Column(name = "FBME03_BODY_GROUP_IND_F")
  private String bodyGroupIndFlag;

  @Column(name = "FBME03_CATALOG_IND_F")
  private String catalogIndFlag;

  @Column(name = "FBME03_EXCEPTION_EFFECTIVE_S")
  private Timestamp exceptionEffectiveTS;

  @Column(name = "FBME03_EXCEPTION_IND_F")
  private String exceptionIndFlag;

  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBME04_VEHLN_K")
  private VehicleLineDto vehicleLine;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME03_CREATE_S")
  private Date createdTimeStamp;

  @JsonIgnore
  @Column(name = "FBME03_CREATE_PROCESS_C")
  private String createdProcess;

  @JsonIgnore
  @Column(name = "FBME03_CREATE_USER_C")
  private String createdUser;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME03_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @JsonIgnore
  @Column(name = "FBME03_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @JsonIgnore
  @Column(name = "FBME03_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
  
  @OneToMany(fetch = FetchType.EAGER,mappedBy = "id.mfbme03BodyStyle")
  private List<BodyGroupAssignment> bodyGroupAssignemnts;
}
