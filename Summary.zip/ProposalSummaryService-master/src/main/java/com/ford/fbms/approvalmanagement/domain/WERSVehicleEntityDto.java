package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = WERSVehicleEntityDto.TABLE_NAME)
public class WERSVehicleEntityDto implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME79_WERS_VEHICLE_ENTITY";
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME79_VEHICLE_ENTITY_K")
	private long vehicleEntitySaKey;

	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME69_WERS_CATALOG_DATA_K")
	private CatalogDataDto catalogData;
	
	@Column(name = "FBME79_BODY_STYLE_C")
	private String bodyStyleCode;

	@Column(name = "FBME79_DERIVATIVE_C")
	private String derivativeCode;

	@Column(name = "FBME79_ENGINE_C")
	private String engineCode;

	@Column(name = "FBME79_EXCLUDE_F")
	private String excludeFlag;

	@Column(name = "FBME79_EXCLUDE_S")
	private Timestamp excludeTS;

	@Column(name = "FBME79_LOCAL_SVP_C")
	private String localSvpCode;

	@Column(name = "FBME79_MODEL_C")
	private String modelCode;

	@Column(name = "FBME79_MODEL_YEAR_C")
	private String modelYearCode;

	@Column(name = "FBME79_PAYLOAD_C")
	private String payloadCode;

	@Column(name = "FBME79_TRANSMISSION_C")
	private String transmissionCode;

	@Column(name = "FBME79_VEHICLE_ENTITY_C")
	private String vehicleEntityCode;

	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME79_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME79_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME79_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME79_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME79_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME79_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
	
}
