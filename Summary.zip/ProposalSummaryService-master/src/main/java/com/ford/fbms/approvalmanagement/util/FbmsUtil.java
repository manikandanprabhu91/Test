package com.ford.fbms.approvalmanagement.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FbmsUtil {
	
	 private FbmsUtil() {
		    throw new IllegalStateException("Utility class");
		  }

  /**
   * This method format Number to Curency
   *
   * @param commaSeparater
   * @return
   */
  public static String currencyFormat(long commaSeparater) {
    NumberFormat nf = NumberFormat.getNumberInstance();
   return nf.format(commaSeparater);
  }

  /**
   * Formats the currency without currency symbol. If -ve values are
   * represented as (). Internally uses NumberInstance of NumberFormat.
   *
   * @param currencyValue
   * @param fractionValue
   * @return String
   */
  public static String currencyFormat(long currencyValue, int fractionValue) {
    NumberFormat nf = NumberFormat.getNumberInstance();
    nf.setMaximumFractionDigits(fractionValue);
    String formattedStr = nf.format(currencyValue);
    if (currencyValue >= 0) {
      formattedStr =
          ApprovalConstants.FONT_BEGIN_GREEN + formattedStr + ApprovalConstants.FONT_END_TAG;
    } else {
      formattedStr = nf.format(currencyValue * -1);
      formattedStr = ApprovalConstants.FONT_BEGIN_RED + formattedStr + ApprovalConstants.FONT_END_BRACE+ApprovalConstants.FONT_END_TAG1;
    }
    return formattedStr;
  }

  public static String currencyFormatforDwnload(double currencyValue, int fractionValue,boolean colorCode,boolean isBold) {
    double value = 0.0;
    boolean postive = false;
    if(currencyValue>=0){
      postive = true;
      value = currencyValue;
    }else{
      postive = false;
      value = currencyValue * -1;
    }
    value = Math.round(value);
    NumberFormat nf = NumberFormat.getNumberInstance();
    nf.setMaximumFractionDigits(fractionValue);
    String formattedStr = nf.format(value);
    if (postive) {
      if((colorCode)&&(!(isBold))){
        formattedStr = "<ss:Data ss:Type='String' xmlns='http://www.w3.org/TR/REC-html40'><Font Color='#008000'>"+formattedStr+"</Font></ss:Data>";
      }else if((colorCode)&&(isBold)){
        formattedStr = "<ss:Data ss:Type='String' xmlns='http://www.w3.org/TR/REC-html40'><B><Font Color='#008000'>"+formattedStr+"</Font></B></ss:Data>";
      }else{
        formattedStr =
            ApprovalConstants.FONT_BEGIN_TAG + formattedStr + ApprovalConstants.FONT_END_TAG;
      }
    } else {
      if(colorCode && isBold){
        formattedStr = "<ss:Data ss:Type='String' xmlns='http://www.w3.org/TR/REC-html40'><B><Font Color='#FF0000'>("+formattedStr+")</Font></B></ss:Data>";
      }else if(colorCode && !isBold){
        formattedStr = "<ss:Data ss:Type='String' xmlns='http://www.w3.org/TR/REC-html40'><Font Color='#FF0000'>("+formattedStr+")</Font></ss:Data>";
      }else if(!colorCode && isBold){
        formattedStr = "<ss:Data ss:Type='String' xmlns='http://www.w3.org/TR/REC-html40'><B>("+formattedStr+")</B></ss:Data>";
      }else{
        formattedStr = ApprovalConstants.FONT_BEGIN_TAG+ApprovalConstants.FONT_BEGIN_BRACE + formattedStr + ApprovalConstants.FONT_END_BRACE+ApprovalConstants.FONT_END_TAG1;
      }
    }
    return formattedStr;
  }



  /**
   * Formats the currency without currency symbol. If -ve values are
   * represented as (). Internally uses NumberInstance of NumberFormat.
   *
   * @param currencyValue
   * @param fractionValue
   * @param colorCode -
   *        set true to apply color coding
   * @return String
   */
  public static String currencyFormat(long currencyValue, int fractionValue,
                                      boolean colorCode) {
    NumberFormat nf = NumberFormat.getNumberInstance();
    nf.setMaximumFractionDigits(fractionValue);
    String formattedStr = nf.format(currencyValue);
    if (currencyValue >= 0) {
      if (colorCode) {
        formattedStr =
            ApprovalConstants.FONT_BEGIN_GREEN + formattedStr + ApprovalConstants.FONT_END_TAG;
      } else {
        formattedStr = ApprovalConstants.FONT_BEGIN_TAG + formattedStr + ApprovalConstants.FONT_END_TAG;
      }
    } else {
      formattedStr = nf.format(currencyValue * -1);
      if (colorCode) {
        formattedStr =
            ApprovalConstants.FONT_BEGIN_RED + formattedStr + ApprovalConstants.FONT_END_BRACE+ApprovalConstants.FONT_END_TAG1;
      } else {
        formattedStr = ApprovalConstants.FONT_BEGIN_TAG+ApprovalConstants.FONT_BEGIN_BRACE + formattedStr + ApprovalConstants.FONT_END_BRACE+ApprovalConstants.FONT_END_TAG1;
      }
    }
    return formattedStr;
  }



  
  
  public static void sort(List list, String field, boolean sortAsc) {
  	
  
  		Collections.sort(list, new FbmsComparator(field, sortAsc));	
  	
 
 }

  /**
   * Sort with list and field
   * 
   * @param list
   * @param field
   */
  @SuppressWarnings("unchecked")
  public static void sort(List list, String field) {
      Collections.sort(list, new FbmsComparator(field));
  }
  
  public static boolean isProposalExpired(Date proposalExpirationDate){
   	Date  sProposalExpDate =  new Date(FbmsUtil.formatDate(proposalExpirationDate));
      Date  currentDate =new Date(FbmsUtil.formatDate(new Date()));
      boolean isProposalExpired = true;
	  if((sProposalExpDate.compareTo(currentDate))>=0){
		isProposalExpired = false;
	  }
	  return isProposalExpired;
	}
  
  public static String formatDate(Date inputDate) {
      String formatedDateString = "";
      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");

      if (inputDate != null && inputDate.toString().trim().length() > 0) {
          formatedDateString = sdf.format(inputDate);
      }

      return formatedDateString;
  }

  /**
   * This method inserts data into columns of a table row
   * @param tableRow
   * @param  - business object holding data to populate the table row
   * @return
   * @throws Exception
   */
  public static String populateRow(String tableRow, String[] cols, int numOfCols){
    int s = 0;
    int e;
    StringBuilder result = new StringBuilder();
    String colName;
    for (int i=0; i < numOfCols; i++) {
      colName = "xx_Col" + Integer.toString(i + 1 ) + "_xx";
      if((e = tableRow.indexOf(colName, s)) >= 0) {
        result.append(tableRow.substring(s, e));
        if (i < cols.length){
          result.append(cols[i]);
        }else{
          result.append("");
        }
        s = e+colName.length();
      }
    }
    result.append(tableRow.substring(s));
    return result.toString();
  }

  /**
   * This method reads a row template and converts it to a string
   * The code here will be replaced with a call to database to get a row from
   * database as string (or converted to string).
   * @param tableRow - a template of a row element of a table
   * @return - string representation of that row
 * @throws IOException 
   * @throws Exception
   */
  public static String getRow(File tableRow) throws IOException{
    StringBuilder row = new StringBuilder();
    String s;
    boolean eof = false;
    int c;
    try (FileInputStream in = new FileInputStream(tableRow)) {
      do {
        c = in.read();
        if (c == -1) {
          eof = true;
        } else {
          s = Character.toString((char) c);
          row.append(s);
        }
      } while (!eof);
    } catch (IOException e) {
      LoggerBuilder
          .printError(log, loggerBuilder -> loggerBuilder.message("Can't read from Stream"));
      throw e;
    }
    return row.toString();
  }
}
