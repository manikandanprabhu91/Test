package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.VehicleLineRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

@Service
@Slf4j

public class SubmitProcessMexValidator implements Validator{

	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected FinProfileRepository finProfileRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepo;
	@Autowired
	protected VehicleLineRepository vehicleLineRepository;
	@Autowired
	protected PviExtraInfoRepository pviExtraInfoRepository;
	@Autowired
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;

	@Override
	public Future<GenericResponseWrapper> validateAndConstruct(ApiParams apiParams, Object approvalRequest,
																														 MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {
		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside submit process"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
		      final Optional<List<ProposalVehicleLineIncentiveDto>> vehicleLineIncentiveDtos_initial =
		    		  proposalVehicleLineIncentiveRepository.findByProposal(proposal);
		      if(vehicleLineIncentiveDtos_initial.isEmpty()) {
		    	  genericResponseWrapper
		          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_PERUNIT_INCENTIVES));
		      } else {
			ApprovalResponseVo approvalResponseVo = submitProposal(apiParams, proposal);
			genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		      }
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	private ApprovalResponseVo submitProposal(ApiParams apiParams, ProposalDto proposal) {
		// Get the proposal
		ReportLevelDto maxReportLevel = null;
		boolean controllerApprovalRequired = false;
		boolean standardMktProgramExists = false;
		boolean businessCaseExists = false;

		long fleetIncentive =0;
		long mlv =0;
		long totalFleetIncentive = 0;
		long totalMLV = 0 ;
		long totalAmount=0;
		List<ProposalVehicleLineIncentiveDto> vehInctList = null;
		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();

		vehInctList = proposalVehicleLineIncentiveRepository
				.getVehicleLineIncentiveDetailsByProposal(proposal.getProposalSaKey());

		for(ProposalVehicleLineIncentiveDto vehicleLineIncentiveDto: vehInctList) {

			Optional<PviExtraInfoDto> pviExtraInfoDto
					= pviExtraInfoRepository.findById(vehicleLineIncentiveDto.getPviSaKey());

			if (pviExtraInfoDto.isPresent()) {
				if (ApprovalConstants.BUSINESS_CASE.equalsIgnoreCase(pviExtraInfoDto.get().getFleetRating())) {
					log.info("Business case data available");
					businessCaseExists = true;

					mlv = vehicleLineIncentiveDto.getMlv();
					fleetIncentive = pviExtraInfoDto.get().getFleetIncentive();

					totalMLV = totalMLV + mlv;
					totalFleetIncentive = totalFleetIncentive + fleetIncentive;
				}
				if (ApprovalConstants.FLEET_TYPE_A.equalsIgnoreCase(pviExtraInfoDto.get().getFleetRating()) ||
						ApprovalConstants.FLEET_TYPE_B.equalsIgnoreCase(pviExtraInfoDto.get().getFleetRating()) ||
						ApprovalConstants.FLEET_TYPE_C.equalsIgnoreCase(pviExtraInfoDto.get().getFleetRating())) {
					standardMktProgramExists = true;
				}
			}
			totalAmount = totalFleetIncentive * totalMLV;

			log.info("Total Fleet Incentive:" + totalFleetIncentive);
			log.info("Total Amount:" + totalAmount);
			log.info("Standard Marketing Program Exists:" + standardMktProgramExists);
			log.info("BusinessCase Exists:" + businessCaseExists);

			// validate if Controller approval required
			if (businessCaseExists) {
				// Get max approver report level
				maxReportLevel = calculateMaxApproverForMex(apiParams, totalAmount);

				// Controller approver required for business case
				controllerApprovalRequired = isControllerApprovalRequiredForMex();

				String submitUser = apiParams.getUserId();
				String submitStatus = null;

				// Get the Submit status RO
				submitStatus = ApprovalConstants.SUBMITTED;

				// associate the maxReportLevel
				if (maxReportLevel != null) {
					approvalResponseVo.setMaxReportLevel(maxReportLevel);
				}

				//now create the Approval Queue
				FordPersonDto submittedToFordPerson = new FordPersonDto();
				Long submittedToReportLevel = null;

				submittedToFordPerson = fordPersonRepo.findById(ApprovalConstants.DEFAULT_FNA).get();
				submittedToReportLevel = submittedToFordPerson.getReportLevel().getSaKey();

				approvalResponseVo.setSubmittedToFordPerson(submittedToFordPerson.getCdsid());
				approvalResponseVo.setProposalStatus(submitStatus);
				approvalResponseVo.setApprovedTime(new Date());
				approvalResponseVo.setReportlevel(submittedToReportLevel.intValue());
				approvalResponseVo.setProposalStatus(submitStatus);
				approvalResponseVo.setSubmittedByFordPerson(submitUser);
				approvalResponseVo.setMaxReportLevel(maxReportLevel);
				approvalResponseVo.setControllerApprovalRequired(controllerApprovalRequired);

			} else {
				// Created new method for standard marketing program
				approvalResponseVo = submitStandardMarketingProgram(apiParams);
			}
		}
		return approvalResponseVo;
	}

	@LogAround
	private ApprovalResponseVo submitStandardMarketingProgram(ApiParams apiParams) {
		ReportLevelDto maxReportLevel = null;
		String countryCode = apiParams.getCountryCd();
		// submit calculations are done..unlock the form
		List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
		for (ReportLevelDto reportLevelDto : reportLevelList) {
			if (ApprovalConstants.NAM.equalsIgnoreCase(reportLevelDto.getTitleCode())) {
				maxReportLevel = reportLevelDto;
			}
		}

		String submitUser = apiParams.getUserId();

		String approvedStatus = null;
		approvedStatus = ApprovalConstants.APPROVED;

		Long submittedToReportLevel = null;
		FordPersonDto submittedToFordPerson = null;

		submittedToFordPerson = fordPersonRepo.findById(ApprovalConstants.DEFAULT_FNA).get();
		Optional<FordPersonDto> approvedByFordPerson = fordPersonRepo.findById(submitUser);
		submittedToReportLevel = submittedToFordPerson.getReportLevel().getSaKey();
		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
		approvalResponseVo.setSubmittedToFordPerson(submittedToFordPerson.getCdsid());
		approvalResponseVo.setProposalStatus(approvedStatus);
		approvalResponseVo.setApprovedTime(new Date());
		approvalResponseVo.setReportlevel(submittedToReportLevel.intValue());
		approvalResponseVo.setSubmittedByFordPerson(submitUser);
		approvalResponseVo.setSubmittedTime(new Date());
		approvalResponseVo.setApprovedTime(new Date());
		approvalResponseVo.setApprovedByFordPerson(approvedByFordPerson.get());
		approvalResponseVo.setMaxReportLevel(maxReportLevel);
		approvalResponseVo.setControllerApprovalRequired(false);

		return approvalResponseVo;

	}

	@LogAround
	private ReportLevelDto calculateMaxApproverForMex(ApiParams apiParams, long totalAmount) {
		String countryCode = apiParams.getCountryCd();
		ReportLevelDto maxReportLevel = null;
		maxReportLevel = reportLevelRepo.getReportLevelDataByCountryApprovalAmt(countryCode, totalAmount);
		if (maxReportLevel != null) {
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelRO : reportLevelList) {
				if(ApprovalConstants.FNA.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.CONTROLLER_CODE.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.FNM.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.RSM.equalsIgnoreCase(maxReportLevel.getTitleCode())){
					if(ApprovalConstants.RSM.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
						maxReportLevel = reportLevelRO;
					}
				}else if(ApprovalConstants.FSM.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.DFO.equalsIgnoreCase(maxReportLevel.getTitleCode())) {
					if(ApprovalConstants.DFO.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
						maxReportLevel = reportLevelRO;
					}
				}else if((ApprovalConstants.CEO.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.GVP.equalsIgnoreCase(maxReportLevel.getTitleCode()))&&(ApprovalConstants.CEO.equalsIgnoreCase(reportLevelRO.getTitleCode()))){
						maxReportLevel = reportLevelRO;
				}
			}
		} else{
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelRO : reportLevelList) {

				if (ApprovalConstants.FNA.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.DFO.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.GVP.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.CEO.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
					maxReportLevel = reportLevelRO;

				}
			}
		}
		return maxReportLevel;

	}

	@LogAround
	private boolean isControllerApprovalRequiredForMex() {
		return true;
	}
}