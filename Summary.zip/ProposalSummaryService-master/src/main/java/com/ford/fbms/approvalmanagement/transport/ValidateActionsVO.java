package com.ford.fbms.approvalmanagement.transport;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class ValidateActionsVO implements Serializable{

	/**
	 * 
	 */
	@JsonIgnore
	private static final long serialVersionUID = 1L;
	
	private boolean recallActionValid;

	private boolean submitActionValid;

	private boolean approveActionValid;

	private boolean rejectActionValid;

	private boolean sendbackActionValid;

	private boolean reviseActionValid;

	private boolean saveActionValid;

	private boolean deleteActionValid;
	
	private boolean highPriorityFlag;

}
