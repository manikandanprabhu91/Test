package com.ford.fbms.approvalmanagement.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.domain.PerUnitIncentiveNewViewDto;

@Transactional
@Repository

public class PerUnitIncentiveNewViewRepository {

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  ConfigProperties configProperties;

  /**
   * This method is to call the Stored procedure to get Proposals by Account Name.
   *
   * @param accountName  Account name
   * @param proposalYear proposal Year
   * @param status       proposal Status
   * @param apiParams    {@link ApiParams}
   * @return {@link AccountSearchView}
   */
  public List<PerUnitIncentiveNewViewDto> findPerUnitNewViewByProposal(long proposalSaKey) {

    StoredProcedureQuery query = entityManager
        .createStoredProcedureQuery(configProperties.getSchema()
            + ".FBMS_A04_EXPANDED_OPT_NB_VIEW_OSP", PerUnitIncentiveNewViewDto.class);
    query.registerStoredProcedureParameter("p_PROPOSAL_KEY", Long.class,
        ParameterMode.IN);
    query.setParameter("p_PROPOSAL_KEY", proposalSaKey);
    query.execute();
    List<PerUnitIncentiveNewViewDto> outputList = new ArrayList<>();
    outputList.addAll(query.getResultList());
    return outputList;
  }
}

