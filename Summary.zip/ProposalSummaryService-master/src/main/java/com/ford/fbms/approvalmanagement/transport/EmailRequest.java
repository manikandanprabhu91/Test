package com.ford.fbms.approvalmanagement.transport;

import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EmailRequest implements Serializable {

  private static final long serialVersionUID = 1L;

  private String from;

  @NotBlank(message = "To/Receiver is mandatory")
  private String to;

  private String cc;

  private String bcc;

  @NotBlank(message = "Sender is mandatory")
  private String sender;

  @NotBlank(message = "Subject is mandatory")
  private String subject;

  @NotBlank(message = "Content is mandatory")
  private String content;

  @NotBlank(message = "ContentType is mandatory")
  private String contentType;

  private String attachmentName;

  private byte[] attachment;

  private String attachmentType;

  private boolean attachWithHtmlBody;

}
