package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA18_PROPOSAL_FINANCIAL database table.
 *
 */
@Getter
@Setter
@Entity
@Table(name = ProposalFinancialDto.TABLE_NAME)
public class ProposalFinancialDto implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBMA18_PROPOSAL_FINANCIAL";

  // bi-directional one-to-one association to Mfbma04ProposalVehlnInctv
  @Id
  @OneToOne(fetch = FetchType.EAGER,cascade=CascadeType.REMOVE)
  @JoinColumn(name = "FBMA04_PVI_K")
  private ProposalVehicleLineIncentiveDto proposalVehlnInctv;

  @Column(name = "FBMA18_CONTRIBUTION_COST_R")
  private BigDecimal contributionCost;

  @Column(name = "FBMA18_NEW_VM_TRG_R")
  private BigDecimal newVarMktTrg;

  @Column(name = "FBMA18_REVENUE_R")
  private BigDecimal revenue;

  @Column(name = "FBMA18_VAR_MKT_R")
  private BigDecimal VarMkt;

  @Column(name = "FBMA18_YOY_VM_R")
  private BigDecimal yoyVarMkt;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA18_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBMA18_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBMA18_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA18_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBMA18_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBMA18_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}