package com.ford.fbms.approvalmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.PerUnitNewViewDto;


@Repository
public interface PerUnitNewViewRepository extends JpaRepository<PerUnitNewViewDto, Long>{
	
	
	@Query(value="SELECT * FROM {h-schema}FBMS_PERUNIT_OPT_NB_VIEW WHERE FBMA01_PROPOSAL_K = :proposalSaKey",nativeQuery=true)
	List<PerUnitNewViewDto> findListPerUnitNewViewByProposal(@Param("proposalSaKey") long proposalSaKey);
	
}

