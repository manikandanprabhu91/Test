package com.ford.fbms.approvalmanagement.exception;

import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import lombok.Getter;

/**
 * An exception to catch customized exceptions.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Getter
public class CustomRuntimeException extends RuntimeException {

  private static final long serialVersionUID = 1L;

  private final ResponseCodes responseCodes;

  /**
   * To construct ConsentRuntimeException with {@link ResponseCodes} and Message String.
   *
   * @param responseCodes {@link ResponseCodes}
   * @param message       - String
   */
  public CustomRuntimeException(final ResponseCodes responseCodes, final String message) {
    super(message);
    this.responseCodes = responseCodes;
  }
}
