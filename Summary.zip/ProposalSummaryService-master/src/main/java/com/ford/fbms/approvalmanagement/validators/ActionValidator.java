package com.ford.fbms.approvalmanagement.validators;

import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.PyCountryDefinitionRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to validate Action buttons.
 *
 * @author vvm on 4/28/2021.
 */
@Service
@Slf4j
public class ActionValidator implements Validator {

  @Autowired
  private  ResponseBuilder responseBuilder;
  @Autowired
  protected ProposalRepository proposalRepository;
  @Autowired
  protected PyCountryDefinitionRepository pyCountryDefinitionRepository;
  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;
  @Autowired
  protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
  @Autowired
  protected FordPersonRepository fordPersonRepo;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(
      final ApiParams apiParams, final Object approvalRequest,
      final MasterRuleEngine masterRuleEngine, final HttpServletRequest httpRequest) {

    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .message("Inside ActionValidator"));
    Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDtoOptional.isEmpty()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("proposalDtoOptional is Empty()"));
      genericResponseWrapper
          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    } else {
      ProposalDto proposal = proposalDtoOptional.get();
      genericResponseWrapper.setProposalDataDto(proposal);
      ProposalAssignAttributeDto proposalAssigneeAttribute = proposalAssignAttributeRepository.
          findProposalAssignAttributeByFinMasterCdsid(proposal.getFinMasterKey().getFinMasterKey(), apiParams.getUserId());
      if (proposalAssigneeAttribute != null) {
        boolean isProposalAssignee = "A".equals(proposalAssigneeAttribute.getActive());
        genericResponseWrapper.setIsProposalAssignee(isProposalAssignee);
      }
      Optional<PyCountryDefinition> pyCountryDef = pyCountryDefinitionRepository
          .findByPyAndCountryCode(proposal.getPyDefinition().getProposalYearCode(),
              proposal.getFinMasterKey().getCountry().getCountryIso3Code());
      pyCountryDef.ifPresent(genericResponseWrapper::setPyCountryDefinition);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}