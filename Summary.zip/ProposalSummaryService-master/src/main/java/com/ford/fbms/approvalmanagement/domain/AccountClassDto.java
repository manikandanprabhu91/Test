package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "MFBME50_ACCOUNT_CLASS")
public class AccountClassDto implements Serializable{
	
	public static final String TABLE_NAME = "MFBME50_ACCOUNT_CLASS";
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME50_ACCOUNT_CLASS_C")
	private String code;
	
	
	@Column(name = "FBME50_ACCOUNT_CLASS_X")
	private String description;

}
