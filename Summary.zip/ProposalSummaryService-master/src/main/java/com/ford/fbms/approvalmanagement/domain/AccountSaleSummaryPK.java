package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;


import lombok.Getter;
import lombok.Setter;

@Embeddable
@Getter
@Setter
public class AccountSaleSummaryPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "FBME03_BDYSTL_K")
	private Long bodyStyle;

	@Column(name = "FBME01_FIN_MASTER_K")
	private Long finMaster;

	@Column(name = "FBMD12_PROPOSAL_YEAR_C")
	private int pyDefinition;

	@Column(name = "FBMD09_SEG_C")
	private String segment;

}