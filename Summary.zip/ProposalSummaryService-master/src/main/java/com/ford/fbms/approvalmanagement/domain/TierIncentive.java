package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA11_TIER_INCENTIVE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = TierIncentive.TABLE_NAME)
// @NamedQuery(name="Mfbma11TierIncentive.findAll", query="SELECT m FROM
// Mfbma11TierIncentive m")
public class TierIncentive implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMA11_TIER_INCENTIVE";

	@EmbeddedId
	private TierIncentivePK tierIncentivePK;

	@Column(name = "FBMA11_TIER_INCTV_A")
	private BigDecimal tierInctvAmount;

	@Column(name = "FBMA11_TIER_INCTV_P")
	private BigDecimal tierInctvPercentage;

	/*
	 * //bi-directional many-to-one association to Mfbma04ProposalVehlnInctv
	 * 
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumn(name="FBMA04_PVI_K") private ProposalVehlnInctv
	 * proposalVehlnInctv;
	 */

	// bi-directional many-to-one association to Mfbma29IncentiveIndicator
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMA29_INCENTIVE_INDICATOR_C")
	private IncentiveIndicator incentiveIndicator;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA11_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMA11_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMA11_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA11_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMA11_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMA11_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
