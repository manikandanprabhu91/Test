package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD99_SEGMENT_GROUP_TYPE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = SegmentGroupTypeDto.TABLE_NAME)
// @NamedQuery(name = "SegmentGroupType.findAll", query = "SELECT m FROM
// SegmentGroupType m")
public class SegmentGroupTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD99_SEGMENT_GROUP_TYPE";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD99_SEGMENT_GROUP_TYPE_C")
	private String segmentGroupTypeCode;

	@Column(name = "FBMD99_SEGMENT_GROUP_TYPE_X")
	private String segmentGroupTypeDesc;

	// bi-directional many-to-one association to Mfbmd09Segment
	/*
	 * @OneToMany(mappedBy = "segmentGroupType") private List<Segment> segments;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD99_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD99_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD99_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD99_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD99_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD99_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
