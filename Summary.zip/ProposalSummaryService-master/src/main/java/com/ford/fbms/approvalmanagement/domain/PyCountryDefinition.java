package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD13_PY_COUNTRY_DEFINITION database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = PyCountryDefinition.TABLE_NAME)
// @NamedQuery(name="PyCountryDefinition.findAll", query="SELECT m FROM
// PyCountryDefinition m")
public class PyCountryDefinition implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD13_PY_COUNTRY_DEFINITION";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD13_COUNTRY_PY_K")
	private long countryPySaKey;

	@Column(name = "FBMD13_ACTIVATE_AUTOEARLY_F")
	private String activateAutoearlyFlag;

	@Column(name = "FBMD13_ARCHIVE_F")
	private String archiveFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD13_ARCHIVE_Y")
	private Date archiveYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD13_AUTOEARLY_Y")
	private Date autoearlyYear;

	@Column(name = "FBMD13_CURRENT_PY_F")
	private String currentPyFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD13_END_Y")
	private Date endYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD13_PURGE_CMPLT_Y")
	private Date purgeCmpltYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD13_START_Y")
	private Date startYear;

	// bi-directional many-to-one association to Mfbmd12PyDefinition
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD12_PROPOSAL_YEAR_C")
	private PyDefinitionDto pyDefinition;

	// bi-directional many-to-one association to Mfbmd42Country
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD42_COUNTRY_ISO3_C")
	private CountryDto country;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD13_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD13_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD13_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD13_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD13_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD13_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
