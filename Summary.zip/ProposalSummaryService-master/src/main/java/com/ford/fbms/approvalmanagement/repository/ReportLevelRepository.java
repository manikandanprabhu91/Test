package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ReportLevelRepository extends JpaRepository<ReportLevelDto, Long> {
  /**
   * Query to get the cdsid from ford person table
   * @param countryCd
   * @return FordPersonDto
   */
  
  @Query(value="select top 1 * from {h-schema}MFBMD14_REPORT_LEVEL "
	      + "where FBMD42_COUNTRY_ISO3_C = :countryCd and  :approvalAmt >=FBMD14_MIN_APPROVAL_A  and  :approvalAmt  < FBMD14_MAX_APPROVAL_A",nativeQuery = true)
	 ReportLevelDto getReportLevelDataByCountryApprovalAmt(@Param("countryCd")final String countryCd,@Param("approvalAmt")long approvalAmt);

Optional<ReportLevelDto> findById(Long long1);

@Query(value="select * from {h-schema}MFBMD14_REPORT_LEVEL "
	      + "where FBMD42_COUNTRY_ISO3_C = :countryCd ",nativeQuery = true)
	List<ReportLevelDto> getReportLevelDataByCountry(@Param("countryCd")final String countryCd);


@Query(value="select * from {h-schema}MFBMD14_REPORT_LEVEL "
	      + "where FBMD42_COUNTRY_ISO3_C = :country  and FBMD14_TITLE_C = :titleCode",nativeQuery = true)
	ReportLevelDto getReportLevelDataByCountryTitleCode(@Param("country")final String country,@Param("titleCode")final String titleCode);

@Query(value="select * from {h-schema}MFBMD14_REPORT_LEVEL "
	      + "where FBMD42_COUNTRY_ISO3_C = :country  and FBMD14_RPTLVL_C = :reportLevelCode",nativeQuery = true)
	List<ReportLevelDto> getReportLevelDataByCountryReportLevelCode(@Param("country")final String country,@Param("reportLevelCode")final int reportLevelCode);


}
