package com.ford.fbms.approvalmanagement.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.CatalogFinancialDto;



public interface CatalogFinancialRepository extends JpaRepository<CatalogFinancialDto, Long> {

	  /**
	   * A method to retrieve the Max finance target details by fleet rating and marketing program.
	   *
	   * @param bodyStyleKey a body style key
	   * @param fleetRating  fleet rating code
	   * @param mrktPrgm     marketing program
	   * @param effStartDate effective start date
	   * @return {@link CatalogFinancialDto}
	   */
	  @Query(value = "select * from {h-schema}mfbme30_catalog_financial \n"
	      + "where fbme03_bdystl_k= :bodyStyleKey \n"
	      + "and fbme30_fleet_rating_c = :fleetRating and FBME30_MKTG_PROGRAM_C= :mrktPrgm \n"
	      + "and CONVERT(VARCHAR(10),fbme30_effective_start_s,101) <= CONVERT(VARCHAR(10), \n"
	      + ":effStartDate ,101)\n"
	      + "and fbme30_effective_start_s IN \n"
	      + "(select max(fbme30_effective_start_s) from {h-schema}mfbme30_catalog_financial\n"
	      + "where fbme03_bdystl_k= :bodyStyleKey  and fbme30_fleet_rating_c = :fleetRating \n"
	      + "and FBME30_MKTG_PROGRAM_C = :mrktPrgm\n"
	      + "and CONVERT( VARCHAR(10),fbme30_effective_start_s,101) <= CONVERT( VARCHAR(10), \n"
	      + ":effStartDate,101))",
	      nativeQuery = true)
	  CatalogFinancialDto getMaxFinanceTargetDetailsByFleetRatingMrkProgram(@Param("bodyStyleKey")
	      Long bodyStyleKey, @Param("fleetRating") String fleetRating,
	      @Param("mrktPrgm") String mrktPrgm,
	      @Param("effStartDate") Date effStartDate);

	  /**
	   * A method to retrieve the Max finance target details by fleet rating.
	   *
	   * @param bodyStyleKey a body style key.
	   * @param fleetRating  fleet rating code
	   * @param effStartDate effective start date
	   * @return {@link CatalogFinancialDto}
	   */
	  @Query(value = "select * from {h-schema}mfbme30_catalog_financial \n"
	      + "where fbme03_bdystl_k= :bodyStyleKey \n"
	      + "and fbme30_fleet_rating_c = :fleetRating \n"
	      + "and CONVERT(VARCHAR(10),fbme30_effective_start_s,101) <= CONVERT(VARCHAR(10), \n"
	      + ":effStartDate ,101)\n"
	      + "and fbme30_effective_start_s IN \n"
	      + "(select max(fbme30_effective_start_s) from {h-schema}mfbme30_catalog_financial\n"
	      + "where fbme03_bdystl_k= :bodyStyleKey  and fbme30_fleet_rating_c = :fleetRating \n"
	      + "and CONVERT( VARCHAR(10),fbme30_effective_start_s,101) <= CONVERT( VARCHAR(10), \n"
	      + ":effStartDate,101))",
	      nativeQuery = true)
	  CatalogFinancialDto getMexFinanceTargetDetails(@Param("bodyStyleKey")
	      Long bodyStyleKey, @Param("fleetRating") String fleetRating,
	      @Param("effStartDate") Date effStartDate);

	  /**
	   * A method to retrieve the marketing program details by fleet rating.
	   *
	   * @param bodyStyleKey a body style key.
	   * @param fleetRating  fleet rating code
	   * @return {@link CatalogFinancialDto}
	   */
	  @Query(value = "SELECT "
	  		+ "	CF.* "
	  		+ "FROM  "
	  		+ "	{h-schema}MFBME30_CATALOG_FINANCIAL CF, "
	  		+ "      	( "
	  		+ "	SELECT  "
	  		+ "		FBME03_BDYSTL_K BDYSTLK,  "
	  		+ "             		FBME30_FLEET_RATING_C FR_CODE, "
	  		+ "             		MAX(FBME30_EFFECTIVE_START_S) EFS  "
	  		+ "      	FROM  "
	  		+ "		{h-schema}MFBME30_CATALOG_FINANCIAL "
	  		+ "      	WHERE  "
	  		+ "		FBME03_BDYSTL_K = :bodyStyleKey 		 "
	  		+ "		AND FBME30_FLEET_RATING_C = :fleetRating  "
	  		+ "		GROUP BY  "
	  		+ "		FBME03_BDYSTL_K,FBME30_FLEET_RATING_C  "
	  		+ "      	) MAXBF "
	  		+ " WHERE   "
	  		+ "	MAXBF.BDYSTLK = CF.FBME03_BDYSTL_K  AND  "
	  		+ "        	MAXBF.FR_CODE =  CF.FBME30_FLEET_RATING_C  AND "
	  		+ "        	MAXBF.EFS =  CF.FBME30_EFFECTIVE_START_S",
	      nativeQuery = true)
	  CatalogFinancialDto getMarketingProgram(@Param("bodyStyleKey")
	      Long bodyStyleKey, @Param("fleetRating") String fleetRating);
	}