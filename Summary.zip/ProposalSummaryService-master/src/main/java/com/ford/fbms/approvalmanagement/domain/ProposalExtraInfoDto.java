// ******************************************************************************
// * Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   ProposalExtraInfoBO.jva  $
// * $Revision:   1.7  $
// * $Author:   KSUBRAHM  $
// * $Date:   Aug 05 2013 13:20:28  $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.domain;
 
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import lombok.Getter;
import lombok.Setter;

/**
 * This Business Object represents Proposal Extra info. <BR>
 * Refer <code>MFBMA21_PROPOSAL_EXTRA_INFO</code>
 */
@Entity
@Getter
@Setter
@Table(name = "MFBMA21_PROPOSAL_EXTRA_INFO")
public class ProposalExtraInfoDto implements Serializable {

		private static final long serialVersionUID = 1L;

		public static final String TABLE_NAME = "MFBMA21_PROPOSAL_EXTRA_INFO";

		// bi-directional one-to-one association to Mfbma01Proposal
		@Id
		@Column(name="FBMA01_PROPOSAL_K")
		private long proposalSaKey;

		@Column(name="FBME01_DEALER_FIN_K")
		private long dealerFinKey;

		@Column(name="FBMA21_FLOOR_PLAN_DAYS_R")
		private int floorPlanDays;

		@Column(name = "FBMA21_ALL_OPT_F")
		private String allOptionFlag;

		@Column(name = "FBMA21_MULTI_ROUTING_F")
		private Boolean multiRoutingFlag;

		@Column(name = "FBMA21_OFLN_APRVL_RCVD_F")
		private String offlineApprovalReceivedFlag;

		@Column(name = "FBMA21_OFLN_APRVL_REQD_F")
		private Boolean offlineApprovalRequiredFlag;

		@Column(name = "FBMA21_PROPOSAL_EXPIRATION_S")
		private Timestamp proposalExpirationTS;

		@Column(name = "FBMA21_SPECIAL_INSTRN_X")
		private String specialInstructionDesc;

		@Column(name = "FBMA21_WAITING_LIST_F")
		private Boolean waitingListFlag;

		@Column(name = "FBMD08_CNTRY_SLS_TYP_K")
		private BigDecimal countrySalesType;

		@Temporal(TemporalType.TIMESTAMP)
		@Column(name = "FBMA21_CREATE_S")
		private Date createdTimeStamp;

		@Column(name = "FBMA21_CREATE_PROCESS_C")
		private String createdProcess;

		@Column(name = "FBMA21_CREATE_USER_C")
		private String createdUser;

		@Temporal(TemporalType.TIMESTAMP)
		@Column(name = "FBMA21_LAST_UPDT_S")
		private Date lastUpdatedTimeStamp;

		@Column(name = "FBMA21_LAST_UPDT_PROCESS_C")
		private String lastUpdatedProcess;

		@Column(name = "FBMA21_LAST_UPDT_USER_C")
		private String lastUpdatedUser;
	}	
	


