package com.ford.fbms.approvalmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.ford.fbms.approvalmanagement.domain.VehicleLineDto;

public interface VehicleLineRepository  extends JpaRepository<VehicleLineDto, String>{
	
	@Query(value ="SELECT DISTINCT E04.*\r\n"
			+ "FROM \r\n"
			+ "  {h-schema}MFBME04_VEHICLE_LINE E04\r\n"
			+ "WHERE\r\n"
			+ "  FBME04_VEHLN_X=:vehlnDesc" ,nativeQuery = true)
	List<VehicleLineDto> vehicleLineListByVehicleLineDesc(@Param("vehlnDesc") final String vehlnDesc);
}
