package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * The persistent class for the MFBMD69_ACCT_SOURCE_TYPE database table.
 * 
 */
@Entity
@Table(name = AcctSourceType.TABLE_NAME)
public class AcctSourceType implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD69_ACCT_SOURCE_TYPE";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD69_ACCT_SOURCE_C")
	private String acctSourceC;

	@Column(name = "FBMD69_ACCT_SOURCE_X")
	private String acctSourceDescription;


	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD69_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD69_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMD69_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD69_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD69_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMD69_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
