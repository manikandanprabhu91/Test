package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
//FBMS_A04_EXPANDED_OPT_VIEW
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = PerUnitIncentiveNewViewDto.TABLE_NAME)
public class PerUnitIncentiveNewViewDto implements Serializable {

	
	/**
	 * 
	 */
	public static final String TABLE_NAME = "FBMS_A04_EXPANDED_OPT_NB_VIEW";
	/**
	 * 
	 */
	private static final Long serialVersionUID = 1L;
	
	@Column(name="ESP")
	private Long eSPIncentive;
	
	@Column(name="MLB")
	private Long mLBIncentive;
	
	@Column(name="OTHER")
    private Long optionIncentive;
	
	@Column(name="FBMA01_PROPOSAL_K" )
	private Long proposalSaKey;
	
	@EmbeddedId
    private PerUnitIncentiveNewViewPK id;
	
	public PerUnitIncentiveNewViewPK getId() {
		return id;
	}

	public void setId(PerUnitIncentiveNewViewPK id) {
		this.id = id;
	}

	
	@Column(name="FBME04_VEHLN_X")
	private String vehicleLineDesc;
	
	@Column(name="FBME04_VEHLN_MDLYR_C")
	private int modelYear;
	
	@Column(name="FBME04_VEHLN_C")
	private String vehicleLineCode;
	
	@Column(name="FBME03_BODY_GROUP_IND_F")
	private String bodyGroupIndicator;
	
	
	@Column(name="FBME03_BDYSTL_C_1") 
	  private String bodyStyleCode_1;
	
	  @Column(name="FBME03_BDYSTL_C_2") 
	  private String bodyStyleCode_2;
	  
	  
	  @Column(name="FBME03_BDYSTL_K_1")
	  private Long bodyStyleKey1;
	  
	  @Column(name="FBME03_NEW_BDYSTL_K_1")
	  private Long NewBodyStyleKey1;
	  
	  @Column(name="FBME03_NEW_BDYSTL_K_2")
	  private Long NewBodyStyleKey2;
	  
	
		/*
		 * @Column(name="FBMA04_SYS_ADDED_EARLY_F") private String autoEarlyFlag;
		 */
	 
	
	/*@Column(name="FBMA04_SYS_ADDED_EARLY_S")
	private Date autoEarlyDate;*/
	
	@Column(name="FBMA04_REPURCHASE_Q")
	private Long repurchaseQty;
	
	public String getBodyStyleCode_2() {
		return bodyStyleCode_2;
	}

	public void setBodyStyleCode_2(String bodyStyleCode_2) {
		this.bodyStyleCode_2 = bodyStyleCode_2;
	}


	public Long getBodyStyleKey1() {
		return bodyStyleKey1;
	}

	public void setBodyStyleKey1(Long bodyStyleKey1) {
		this.bodyStyleKey1 = bodyStyleKey1;
	}

	public Long getNewBodyStyleKey1() {
		return this.NewBodyStyleKey1;
	}

	public void setNewBodyStyleKey1(Long newBodyStyleKey1) {
		this.NewBodyStyleKey1 = newBodyStyleKey1;
	}

	public Long getNewBodyStyleKey2() {
		return (NewBodyStyleKey2==null?0:NewBodyStyleKey2);
	}

	public void setNewBodyStyleKey2(Long newBodyStyleKey2) {
		this.NewBodyStyleKey2 = newBodyStyleKey2;
	}

	@Column(name="FBMA04_TIER1_INCTV_TO_DLR_F")
	private String tierIncentiveToDealer;
	
	
/*	@Column(name="FBME03_BDYSTL_K")
	private Long bodyStyleSaKey;*/
	
	/*@Column(name="FBMA04_START_Y")
	private Date startDate;
	
	@Column(name="FBMA04_END_Y")
	private Date endDate;*/
	
	@Column(name="FBMA04_MLV_Q")
	private int mlvForecast;
	
	/*@Column(name="FBMA11_TIER_INCTV_P_6")
	private Float tier6IncentivePercent;
	
	@Column(name="FBMA11_TIER_INCTV_P_5")
	private Float tier5IncentivePercent;
	
	@Column(name="FBMA11_TIER_INCTV_P_4")
	private Float tier4IncentivePercent;
	
	@Column(name="FBMA11_TIER_INCTV_P_3")
	private Float tier3IncentivePercent;
	
	@Column(name="FBMA11_TIER_INCTV_P_2")
	private Float tier2IncentivePercent;
	
	@Column(name="FBMA11_TIER_INCTV_P_1")
	private Float tier1IncentivePercent;*/
	
	@Column(name="FBMA11_Tier_Inctv_A_6")
	private Long tier6Incentive;
	
	@Column(name="FBMA11_Tier_Inctv_A_5")
	private Long tier5Incentive;
	
	@Column(name="FBMA11_Tier_Inctv_A_4")
	private Long tier4Incentive;
	
	@Column(name="FBMA11_Tier_Inctv_A_3")
	private Long tier3Incentive;
	
	@Column(name="FBMA11_Tier_Inctv_A_2")
	private Long tier2Incentive;
	
	@Column(name="FBMA11_Tier_Inctv_A_1")
	private Long tier1Incentive;


	public Long geteSPIncentive() {
		return (eSPIncentive==null?0:eSPIncentive);
	}

	public void seteSPIncentive(Long eSPIncentive) {
		this.eSPIncentive = eSPIncentive;
	}

	public Long getmLBIncentive() {
		return (mLBIncentive==null?0:mLBIncentive);
	}

	public void setmLBIncentive(Long mLBIncentive) {
		this.mLBIncentive = mLBIncentive;
	}

	public Long getOptionIncentive() {
		return (optionIncentive==null?0:optionIncentive);
	}

	public void setOptionIncentive(Long optionIncentive) {
		this.optionIncentive = optionIncentive;
	}

	public Long getProposalSaKey() {
		return proposalSaKey;
	}

	public void setProposalSaKey(Long proposalSaKey) {
		this.proposalSaKey = proposalSaKey;
	}


	public String getVehicleLineDesc() {
		return vehicleLineDesc;
	}

	public void setVehicleLineDesc(String vehicleLineDesc) {
		this.vehicleLineDesc = vehicleLineDesc;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public String getVehicleLineCode() {
		return vehicleLineCode;
	}

	public void setVehicleLineCode(String vehicleLineCode) {
		this.vehicleLineCode = vehicleLineCode;
	}

	public String getBodyGroupIndicator() {
		return bodyGroupIndicator;
	}

	public void setBodyGroupIndicator(String bodyGroupIndicator) {
		this.bodyGroupIndicator = bodyGroupIndicator;
	}

	public String getBodyStyleCode_1() {
		return bodyStyleCode_1;
	}

	public void setBodyStyleCode_1(String bodyStyleCode_1) {
		this.bodyStyleCode_1 = bodyStyleCode_1;
	}
	/*
	 * public String getAutoEarlyFlag() { return autoEarlyFlag; }
	 * 
	 * public void setAutoEarlyFlag(String autoEarlyFlag) { this.autoEarlyFlag =
	 * autoEarlyFlag; }
	 */
/*	public Date getAutoEarlyDate() {
		return autoEarlyDate;
	}

	public void setAutoEarlyDate(Date autoEarlyDate) {
		this.autoEarlyDate = autoEarlyDate;
	}*/

	public Long getRepurchaseQty() {
		return (repurchaseQty==null?0:repurchaseQty);
	}

	public void setRepurchaseQty(Long repurchaseQty) {
		this.repurchaseQty = repurchaseQty;
	}

	public String getTierIncentiveToDealer() {
		return tierIncentiveToDealer;
	}

	public void setTierIncentiveToDealer(String tierIncentiveToDealer) {
		this.tierIncentiveToDealer = tierIncentiveToDealer;
	}


	public int getMlvForecast() {
		return mlvForecast;
	}

	public void setMlvForecast(int mlvForecast) {
		this.mlvForecast = mlvForecast;
	}

	public Long getTier6Incentive() {
		return (tier6Incentive==null?0:tier6Incentive);
	}

	public void setTier6Incentive(Long tier6Incentive) {
		this.tier6Incentive = tier6Incentive;
	}

	public Long getTier5Incentive() {
		return (tier5Incentive==null?0:tier5Incentive);
	}

	public void setTier5Incentive(Long tier5Incentive) {
		this.tier5Incentive = tier5Incentive;
	}

	public Long getTier4Incentive() {
		return (tier4Incentive==null?0:tier4Incentive);
	}

	public void setTier4Incentive(Long tier4Incentive) {
		this.tier4Incentive = tier4Incentive;
	}

	public Long getTier3Incentive() {
		return (tier3Incentive==null?0:tier3Incentive);
	}

	public void setTier3Incentive(Long tier3Incentive) {
		this.tier3Incentive = tier3Incentive;
	}

	public Long getTier2Incentive() {
		return (tier2Incentive==null?0:tier2Incentive);
	}

	public void setTier2Incentive(Long tier2Incentive) {
		this.tier2Incentive = tier2Incentive;
	}

	public Long getTier1Incentive() {
		return (tier1Incentive==null?0:tier1Incentive);
	}

	public void setTier1Incentive(Long tier1Incentive) {
		this.tier1Incentive = tier1Incentive;
	}
	
	/*@Column(name="FBME49_VEHICLE_ENTITY_K")
	private Long entitySakey;
	
	@Column(name="FBME49_MLS_VEHICLE_ENTITY_K")
	private Long mlsEntitySakey;
	
	@Column(name="FBMA04_MLS_USC_COMBINED_X")
	private String mlsUscCombined;
	
	//Added for FoE ph1
	@Column(name="FBMA04_USC_COMBINED_X")
	private String uscCombined;
	
	@Column(name="FBMA23_PAYMENT_ROUTE_C")
	private String paymentRouteCode;
	
	@Column(name="FBMA23_PAYMENT_ROUTE_N")
	private String paymentRouteDesc;
	
	@Column(name="FBMA26_Purchase_Method_C")
	private String purchargeMehtodCode;
	
	@Column(name="FBMA26_Purchase_Method_N")
	private String purchargeMehtodDesc;
	
	@Column(name="FBMA04_TIER_VOLUME_VALUE_Q")
	private int countToAggregate;
		
	@Column(name="FBMA29_Incentive_Indicator_C_6")
	private String tier6IncentiveIndicator;
	
	@Column(name="FBMA29_Incentive_Indicator_C_5")
	private String tier5IncentiveIndicator;
	
	@Column(name="FBMA29_Incentive_Indicator_C_4")
	private String tier4IncentiveIndicator;
	
	@Column(name="FBMA29_Incentive_Indicator_C_3")
	private String tier3IncentiveIndicator;
	
	@Column(name="FBMA29_Incentive_Indicator_C_2")
	private String tier2IncentiveIndicator;
	
	@Column(name="FBMA29_Incentive_Indicator_C_1")
	private String tier1IncentiveIndicator;
	
	//FOE US87971
	@Column(name="FBMA21_LCL_CUST_BONUS_C")
	public String  proposalLocalCustomerBonus;
	
	@Column(name="FBMA21_LCL_LSNG_BONUS_C")
	public String proposalLeasingBonus;
	
	@Column(name="FBMA21_PAN_EUR_BONUS_C")
	public String proposalPanEuropean;      
	
	@Column(name="FBMD30_COUNTRY_VI_P")
	public String incentiveEligiblityCode;  
	
	@Column(name="VL_ALL_OPT")
	public String optionsAllModel;*/                                                                                                                                                                                 
	
	/*@Column(name="FBMA26_Purchase_Method_N")
	public int registeredDays;              
	
	@Column(name="FBMA26_Purchase_Method_N")
	public int retailedDays;*/                
	
	/*@Column(name="FBMA29_INCENTIVE_IND_PE")
	public String incentiveIndicatorCodePanEuropean;     
	
	@Column(name="FBMA29_INCENTIVE_IND_MB")
	public String incentiveIndicatorCodeLeasingBonus;
	
	@Column(name="FBMA29_INCENTIVE_IND_LB")
	public String incentiveIndicatorCodeLocalCustomerBonus;
	
	@Column(name="FBMA30_BONUS_A_PE")
	public String bonusAmountPanEuropean;    
	
	@Column(name="FBMA30_BONUS_A_MB")
	public String bonusAmountLeasingBonus;   
	
	@Column(name="FBMA30_BONUS_A_LB")
	public String bonusAmountLocalCustomerBonus;
	
	@Column(name="FBMA30_BONUS_P_PE")
	public Double bonusPercentagePanEuropean;
	
	@Column(name="FBMA30_BONUS_P_MB")
	public Double bonusPercentageLeasingBonus;
	
	@Column(name="FBMA30_BONUS_P_LB")
	public Double bonusPercentageLocalCustomerBonus; 
	
	@Column(name="FBMA30_BONUS_LB_PAY_ROUTE_C")
	public String localCustomerBonusPaymentRoute;
	
	@Column(name="FBMA30_BONUS_MB_PAY_ROUTE_C")
	public String leasingBonusPaymentRoute; 
	
	@Column(name="FBMA30_BONUS_PE_PAY_ROUTE_C")
	public String panEuropeanBonusPaymentRoute;
	
	@Column(name="BANDINGGROUPEXIST")
	private String groupExists;
	
	@Column(name="VL_PP")
	private String premiumPaint;	
	
	@Column(name="FBME79_VEHICLE_ENTITY_K")
	private Long wersSakey;
	
	@Column(name="FBME79_MLS_VEHICLE_ENTITY_K")
	private Long wersMlsSakey;*/

	
	
}
