
package com.ford.fbms.approvalmanagement.validators;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ControllerThresholdDto;
import com.ford.fbms.approvalmanagement.domain.FinProfileDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.AutoearlyBodystyleRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FinMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FinOpUnitMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.OptionIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PyVehicleDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.ServiceDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.TierIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * @author vvm
 *
 */
@Service(value="propApprovalValidator")
@Slf4j
public class ProposalApprovalValidator implements Validator {
	
	@Autowired
	private  ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	
	@Autowired
	protected ProposalVehicleLineIncentiveRepository propsalVlRepo;
	@Autowired
	protected FinMasterRepository finMasterRepository;
	@Autowired
	protected ProposalSummaryViewRepository proposalSummaryViewRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
	@Autowired
	protected ProposalSubsidiaryRepository proposalSubsidiaryRepository;
	@Autowired
	protected TierVolumeRepository tierVolumeRepo;
	@Autowired
	protected TierIncentiveRepository tierIncentiveRepo;
	@Autowired
	protected FinOpUnitMasterRepository finOpUnitRepo;
	
	@Autowired
	protected ServiceDefinitionRepository serDefinitionRepository;
	
	@Autowired
	protected OptionIncentiveRepository optionIncentiveRepository;
	@Autowired
	protected PyVehicleDefinitionRepository pyVehicleDfnRepo;
	@Autowired
	protected AutoearlyBodystyleRepository autoEarlyRepo;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepo;
	@Autowired
	protected FinProfileRepository finProfileRepository;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepo;
	@Autowired
	protected ProposalStatusRepository proposalStatusRepo;
	
	@Override
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
            final Object approvalRequest,
            final MasterRuleEngine masterRuleEngine, final HttpServletRequest httpRequest) {
		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside ProposalApprovalValidator"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED));
		} else {
			
			ProposalDto proposalDto = proposalDtoOptional.get();
			ApprovalResponseVo approvalResponseVo = approveProposal(proposalDto, genericResponseWrapper,apiParams);
			genericResponseWrapper.setProposalDataDto(proposalDto);
			genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);

			
			
			
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	
	
	private ApprovalResponseVo approveProposal(ProposalDto proposal,
			GenericResponseWrapper genericResponseWrapper,ApiParams apiParams) {
		ApprovalResponseVo approvalResponseVO = new ApprovalResponseVo();

		Date updatedDate = new Date();
		int maxApprovalLevelCode = proposal.getReportLevel().getCode();
		boolean isControllerApprovalRequired = proposal
				.getCntlReqdFlag();
		boolean isControllerApproved = false;
		boolean isProposalApproved = false;
		boolean isProposalInRevise = false;

		// Get the logged in user RO
		FordPersonDto approverUser = getUser(apiParams.getUserId());
		String nextApproverCdsid = null;
		int presentReportLevelCode = -1;
		int firstLevelApproverReportLevelCode = -1;
		Optional<ProposalStatusDto> proposalStatus=proposalStatusRepo.findById(ApprovalConstants.SUBMITTED); 
		Optional<ApprovalProcessDto> presentQueue = this.approvalProcessRepo
				.findByProposalKeyAndProposalStatus(proposal,proposalStatus.get());
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
		List<ProposalFinancialVO> puFinancialList = proposalManager.buildProposalFinancialsEstimate(apiParams,
				proposal);
		List<FinancialDetailedVO> financialDetailedVOList = proposalManager.populateFinancialsForEstimate(apiParams,
				proposal, puFinancialList);
		if(presentQueue.isPresent()) {
			ReportLevelDto maxReportLevel = null;
			Optional<FinProfileDto> finprofile = finProfileRepository.findIdAndAccountClass(proposal.getFinMasterKey().getFinMasterKey());
			if (ApprovalConstants.REVISED.equals(proposal.getProposalStatus()
					.getProposalStatusCode())) {
				isProposalInRevise = true;
				approvalResponseVO.setProposalInRevise(isProposalInRevise);
				approvalResponseVO = populateFinancialsForSubmitProcess(financialDetailedVOList);
				if(finprofile.isPresent()) {
					maxReportLevel = calculateMaxApproverForMajorRentalFin(apiParams.getCountryCd());
					maxApprovalLevelCode=maxReportLevel.getCode();
					// Controller approval always required for Major rental fin 
					isControllerApprovalRequired = true;
					approvalResponseVO.setControllerApprovalRequired(isControllerApprovalRequired);
				} else{
					maxReportLevel = calculateMaxApprover(apiParams,proposal,financialDetailedVOList);
					maxApprovalLevelCode=maxReportLevel.getCode();
					isControllerApprovalRequired = isControllerApprovalRequired(apiParams, proposal, approvalResponseVO);
					approvalResponseVO.setControllerApprovalRequired(isControllerApprovalRequired);
				}

			}
			ApprovalProcessDto presentQueueDto = presentQueue.get();
			Optional<ReportLevelDto> presentReportOpt = reportLevelRepo.findById(presentQueueDto.getReportLevel().getSaKey());
			if(presentReportOpt.isPresent()) {
				ReportLevelDto presentReport = presentReportOpt.get();
				presentReportLevelCode = presentReport.getCode();
				String presentReportLevelTitle = presentReport.getTitleCode();
				approvalResponseVO.setPresentReportLevelTitle(presentReportLevelTitle);
				firstLevelApproverReportLevelCode=ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE;
				if (presentReportLevelCode == firstLevelApproverReportLevelCode) {
					if (isControllerApprovalRequired) {
						nextApproverCdsid = ApprovalConstants.DEFAULT_CONTROLLER;
						approvalResponseVO.setNextApproverCdsid(nextApproverCdsid);
					}else {
						if (maxApprovalLevelCode == presentReportLevelCode) {
							// proposal is Approved and no need to create next queue
							isProposalApproved = true;
							approvalResponseVO.setProposalApproved(isProposalApproved);
						} else{
							// Create supervisor approval queue
							nextApproverCdsid = approverUser.getSprcdsidDescription();
							approvalResponseVO.setNextApproverCdsid(nextApproverCdsid);
						}
					}
				} else if (presentReportLevelCode == ApprovalConstants.CONTROLLER_RL_CODE) {
					isControllerApproved = true;
					approvalResponseVO.setControllerApproved(true);
					if (maxApprovalLevelCode == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE) {
						isProposalApproved = true;
						approvalResponseVO.setProposalApproved(isProposalApproved);
						approvalResponseVO.setNextApproverCdsid(presentQueue.get().getSubmittedToId().getSprcdsidDescription());
					} else if(maxApprovalLevelCode == ApprovalConstants.CONTROLLER_RL_CODE){
						isProposalApproved = true;
						approvalResponseVO.setProposalApproved(isProposalApproved);
					} else {
						String submittedCdsid = presentQueueDto.getSubmittedById().getCdsid();
						Optional<FordPersonDto> submittedFordPerson = this.fordPersonRepo.findById(submittedCdsid);
						if(submittedFordPerson.isPresent()) {
							nextApproverCdsid = submittedFordPerson.get().getSprcdsidDescription();
						}
						approvalResponseVO.setNextApproverCdsid(nextApproverCdsid);
					}

				} else {
					if (maxApprovalLevelCode == presentReportLevelCode) {
						// proposal is Approved and no need to create next queue
						isProposalApproved = true;
						approvalResponseVO.setProposalApproved(isProposalApproved);
					} else {
						nextApproverCdsid = approverUser.getSprcdsidDescription();
						approvalResponseVO.setNextApproverCdsid(nextApproverCdsid);

					}

				}
				// update the present Queue as Approved
				approvalResponseVO.setProposalStatus(ApprovalConstants.APPROVED);
				approvalResponseVO.setApprovedByFordPerson(approverUser);
				ProposalDto updateProposal = this.proposalRepository.findById(proposal.getProposalSaKey()).get();
				if (isProposalApproved || isControllerApproved
						|| isProposalInRevise) {
					approvalResponseVO.setApprovalPriorityFlag(false);
					if (isProposalInRevise) {
						// update the status from Revise to Submit
						Optional<ReportLevelDto> aMaxReportLevel = this.reportLevelRepo.findById(maxReportLevel.getSaKey());
						approvalResponseVO.setProposalStatus(ApprovalConstants.SUBMITTED);
						approvalResponseVO.setMaxReportLevel(aMaxReportLevel.get());
						approvalResponseVO.setControllerApprovalRequired(isControllerApprovalRequired);
						approvalResponseVO.setProposalInRevise(isProposalInRevise);
					}
					if (isProposalApproved) {
						approvalResponseVO.setProposalStatus(ApprovalConstants.APPROVED);
						approvalResponseVO.setApprovedTime(updatedDate);
						approvalResponseVO.setStatusDate(updatedDate);
					}
					if (isControllerApproved) {
						approvalResponseVO.setControllerApprovalYear(updatedDate);

					}
				}else {
					approvalResponseVO.setApprovalPriorityFlag(false);
				}
			}
		}

		return approvalResponseVO;
	}
	
	@LogAround		
	private ReportLevelDto calculateMaxApproverForMajorRentalFin(String countryCd) {
				return reportLevelRepo.getReportLevelDataByCountryTitleCode(countryCd,ApprovalConstants.CTL);
			}
	
	@LogAround
	private ReportLevelDto calculateMaxApprover(ApiParams apiParams, ProposalDto proposal,
			List<FinancialDetailedVO> financialDetailedList) {

		ReportLevelDto maxReportLevel = null;

		// FoM chnages: passing the country code to get the max report level

		String countryCode = apiParams.getCountryCd();
		long totalBwTargetVM = 0L;
		if (null != financialDetailedList && !(financialDetailedList.isEmpty())) {
			for (FinancialDetailedVO fdVO : financialDetailedList) {
				if (fdVO.getRecType().toString().equalsIgnoreCase(FinancialDetailedVO.rowType.GrandTotal.toString())) {
					totalBwTargetVM = Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol());
					if (totalBwTargetVM < 0) {
						totalBwTargetVM = totalBwTargetVM * (-1);
					} else {
						totalBwTargetVM = 0L;
					}
				}
			}
		}
		maxReportLevel = reportLevelRepo.getReportLevelDataByCountryApprovalAmt(countryCode, totalBwTargetVM);
		if (maxReportLevel != null) {
			Optional<FordPersonDto> fordPerson = fordPersonRepo.findById(apiParams.getUserId());
			Optional<ReportLevelDto> reportlevelDto_1 = reportLevelRepo.findById(fordPerson.get().getReportLevel().getSaKey());
			int userLevelCode = reportlevelDto_1.get().getCode();
			if (maxReportLevel.getCode() == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE
					&& userLevelCode == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
				String submittedToFordPerson = null;
				Optional<ReportLevelDto> submittedToReportLevel = null;
				Optional<FordPersonDto> fordPersonDto = fordPersonRepo.findById(apiParams.getUserId());
				submittedToFordPerson = fordPersonDto.get().getSprcdsidDescription();
				submittedToReportLevel = reportLevelRepo.findById(fordPersonDto.get().getReportLevel().getSaKey());
				maxReportLevel = submittedToReportLevel.get();
			}
			// SMW fix 5212181 end
		} else {
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelDto : reportLevelList) {
				if (ApprovalConstants.RSM.equalsIgnoreCase(reportLevelDto.getTitleCode())) {
					maxReportLevel = reportLevelDto;
				}
			}

		}

		return maxReportLevel;

	}
	
	@LogAround		
	private ApprovalResponseVo populateFinancialsForSubmitProcess(
					List<FinancialDetailedVO> financialDetailedList) {
				String METHOD_NAME = "populateFinancialsForSubmitProcess";
				ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
				approvalResponseVo.setMatrixTargetLimit(false);
				approvalResponseVo.setBwTargetLimitExceededOnAnyPerUnit(false);

				// run the financial calculations without Submit process validation
				Date today = new Date();
				long ctlRoutingLimit = 0L;
				long newPerUnitTargetVMLimit = 0L;
				long perUnitBwPriorVerVMLimit = 0L;
				long perUnitBwTargetVMLimit = 0L;
				long totalBwPriorVerVMLimit = 0L;
				long totalBwTargetVMLimit = 0L;
				long totalVMLimit = 0L;

				ctlRoutingLimit = getControllerThresholdAmount(ApprovalConstants.CTL_ROUTING_LIMIT, today);

				newPerUnitTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.NEW_PU_BW_TARGET_VM_LIMIT,
						today);
				perUnitBwPriorVerVMLimit = getControllerThresholdAmount(ApprovalConstants.PU_BW_PRIOR_VER_VM_LIMIT,
						today);
				perUnitBwTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.PU_BW_TARGET_VM_LIMIT, today);
				totalBwPriorVerVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_BW_PRIOR_VER_VM_LIMIT,
						today);
				totalBwTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_BW_TARGET_VM_LIMIT, today);
				totalVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_VM_LIMIT, today);

				long totalBwTargetVM = 0L;
				if (financialDetailedList != null && !(financialDetailedList.isEmpty())) {

					for (FinancialDetailedVO f : financialDetailedList) {
						if (f.isPresentProposal()
								&& f.getRecType().name().equals(FinancialDetailedVO.rowType.VehicleLine.name())) {
							if((f.getPresentKey() > 0L)&&((int)f.getPriorPYVM() != 0)) {
									if ((Math.abs(f.getPresentVM()) > Math.abs(f.getPriorPYVM())
											&& Math.abs(f.getPriorPYVM()) - Math.abs(f.getPresentVM())
													+ f.getYoyTarget() < 0) &&(Math.abs(f.getPresentVM()) > Math.abs(f.getMatrixTargetVM()))) {
											approvalResponseVo.setMatrixTargetLimit(true);
											break;
									}
								 else {
									if (Math.abs(f.getPresentVM()) > Math.abs(f.getTargetVM())) {
										approvalResponseVo.setMatrixTargetLimit(true);
										break;
									}
								}
							}
						}

					}

					for (FinancialDetailedVO fdVO : financialDetailedList) {
						if (fdVO.isPresentProposal()
								&& fdVO.getRecType().equals(FinancialDetailedVO.rowType.VehicleLine)) {
							
							if (fdVO.getPresentKey() > 0L) {
								if (Math.round(fdVO.getBwTargetVM()) <= perUnitBwTargetVMLimit) {
									approvalResponseVo.setBwTargetLimitExceededOnAnyPerUnit(true);
								}

								if (fdVO.getPresentKey() == fdVO.getPrevVerKey()) {
									if (Math.round(fdVO.getBwPrevVerVM()) < perUnitBwPriorVerVMLimit) {
										approvalResponseVo.setBwPrevVerLimitExceededOnAnyPerUnit(true);
										if ((int)fdVO.getPriorPYVM() != 0L) {
											if ((Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getPriorPYVM())
													&& Math.abs(fdVO.getPriorPYVM()) - Math.abs(fdVO.getPresentVM())
															+ fdVO.getYoyTarget() < 0) && (Math.abs(fdVO.getPresentVM()) > Math
																	.abs(fdVO.getMatrixTargetVM()))) {
												if (Math.abs(fdVO.getPresentVM()) > Math
														.abs(fdVO.getMatrixTargetVM())) {
													approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
													break;
												}
											}

										} else {
											if (Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getTargetVM())) {
												approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
												break;
											}
										}
									}
								} else {
									// new vehicle add in this version
									if (Math.round(fdVO.getBwTargetVM()) <= newPerUnitTargetVMLimit) {
										approvalResponseVo.setBwTargetLimitExceededOnNewPerUnit(true);
										if (BigDecimal.valueOf(fdVO.getPriorPYVM()) != BigDecimal.ZERO) {
											if ((Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getPriorPYVM())
													&& Math.abs(fdVO.getPriorPYVM()) - Math.abs(fdVO.getPresentVM())
															+ fdVO.getYoyTarget() < 0)&&(Math.abs(fdVO.getPresentVM()) > Math
														.abs(fdVO.getMatrixTargetVM()))) {
													approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
													break;
											}

										} else {
											if (Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getTargetVM())) {
												approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
												break;
											}
										}
									}
								}

							}
						}

						if (fdVO.getRecType().equals(FinancialDetailedVO.rowType.GrandTotal)) {
							if (Math.round(fdVO.getPresentVM() * fdVO.getPresentVol()) <= totalVMLimit) {
								approvalResponseVo.setTotalVMLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol()) < totalBwTargetVMLimit) {
								approvalResponseVo.setTotalBwTargetLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol()) <= ctlRoutingLimit) {
								approvalResponseVo.setControllerLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwPrevVerVM() * fdVO.getPresentVol()) < totalBwPriorVerVMLimit) {
								approvalResponseVo.setTotalBwPrevVerLimitExceeded(true);
							}
						}
					}
				}
				return approvalResponseVo;
			}
	
	@LogAround		
	private long getControllerThresholdAmount(String code,
					Date effectiveDate) {

				ControllerThresholdDto controllerThresholdDto = controllerThresholdRepo
						.controllerThresholdByCodeEffectiveDate(code, effectiveDate);
				return controllerThresholdDto.getThresholdAmount();
			}
	
	@LogAround
	private boolean isControllerApprovalRequired(ApiParams apiparams, ProposalDto proposal,
			ApprovalResponseVo approvalResponseVO) {

		boolean isControllerApprovalRequired = false;
		boolean isExceptionRulesProcessReq = true;

		if (0 != proposalManager.getAggregateIncentiv(proposal)) {
			isControllerApprovalRequired = true;
			return true;
		}

		if ((proposalManager.getMultiYearTerm(proposal) != null)
				|| (proposal.getPplYoy().getPriceProLevYrOverYearCode() != null
						&& !"NON".equalsIgnoreCase(proposal.getPplYoy().getPriceProLevYrOverYearCode()))) {
			isControllerApprovalRequired = true;
			isExceptionRulesProcessReq = false;
			return true;
		}
		if ((approvalResponseVO.isMatrixTargetLimit()) && proposal.getVersionNumber() == 1) {
			isControllerApprovalRequired = true;
			return true;
		} else if (((proposal.getVersionNumber() != 1 && approvalResponseVO.isMatrixTargetLimit()))&&(approvalResponseVO.isMatrixTargetLimitOnNewPerUnit())) {
				isControllerApprovalRequired = true;
				return true;
		}

		if ((!isControllerApprovalRequired)&&(approvalResponseVO.isControllerLimitExceeded())) {
				isControllerApprovalRequired = true;
				isExceptionRulesProcessReq = false;
		}

		if ((!isControllerApprovalRequired) && (approvalResponseVO.isTotalVMLimitExceeded())){
				isControllerApprovalRequired = true;
				} else if ((approvalResponseVO.isTotalBwTargetLimitExceeded()
					|| approvalResponseVO.isBwTargetLimitExceededOnAnyPerUnit()) && (!isControllerApprovalRequired)){ 
				isControllerApprovalRequired = true;
			}
		

		if (isExceptionRulesProcessReq && isControllerApprovalRequired) {

			ProposalDto pvProposal = proposalManager.identifyPriorProposals(proposal);
			String pvProposalStatus = (pvProposal == null) ? " "
					: pvProposal.getProposalStatus().getProposalStatusCode();

			if (pvProposalStatus.equalsIgnoreCase(ApprovalConstants.APPROVED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.DECLINED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.ESTABLISHED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.UNDER_REVIEW)) {
				List<TierVolumeDto> pTierVolumeList = proposalManager.getTierVolumeList(proposal);
				List<TierVolumeDto> pvTierVolumeList = proposalManager.getTierVolumeList(pvProposal);
				boolean isAllTierVolumesMatch = true;
				boolean isNoOfTiersMatch = true;
				if (pTierVolumeList.size() == pvTierVolumeList.size()) {
					for (TierVolumeDto pTierVolume : pTierVolumeList) {
						for (TierVolumeDto pvTierVolume : pvTierVolumeList) {
							if ((pTierVolume.getTierVolumePk().getTierLevel() == pvTierVolume.getTierVolumePk()
									.getTierLevel()) &&(pTierVolume.getTierVolume() != pvTierVolume.getTierVolume())){
									isAllTierVolumesMatch = false;
							}
						}
					}
				} else {
					isNoOfTiersMatch = false;
				}
				if ((isAllTierVolumesMatch && isNoOfTiersMatch)&&(!approvalResponseVO.isTotalBwPrevVerLimitExceeded()
						&& !approvalResponseVO.isBwPrevVerLimitExceededOnAnyPerUnit()
						&& !approvalResponseVO.isBwTargetLimitExceededOnNewPerUnit())) {
						isControllerApprovalRequired = false;
				}
			}
		}
		if (!approvalResponseVO.isMatrixTargetLimit()) {
			isControllerApprovalRequired = false;
		}
		if ((approvalResponseVO.isMatrixTargetLimit())&&(!approvalResponseVO.isMatrixTargetLimitOnNewPerUnit())) {
				isControllerApprovalRequired = false;
		}
		return isControllerApprovalRequired;
	}
	
private FordPersonDto getUser(String cdsid) {
		
		Optional<FordPersonDto> fordPersonOpt = this.fordPersonRepo.findById(cdsid);
		if(fordPersonOpt.isEmpty()) {
			return null;
		}
		return fordPersonOpt.get();
	}

			
}
