package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMC12_ADDRESS database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "MFBMC12_ADDRESS")
public class Address implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMC12_ADDR_K")
	private long addressSaKey;

	@Column(name = "FBMC12_ADDRESS1_POBOX_X")
	private String address1PoboxDescription;

	@Column(name = "FBMC12_ADDRESS2_X")
	private String address2Description;

	@Column(name = "FBMC12_ADDRESS3_X")
	private String address3Description;

	@Column(name = "FBMC12_ADDRESS4_X")
	private String address4Description;

	@Column(name = "FBMC12_CITY_X")
	private String cityDescription;

	@Column(name = "FBMC12_POSTAL_SUFFIX_X")
	private String postalSuffixDescription;

	@Column(name = "FBMC12_POSTAL_X")
	private String postalDescription;

	@Column(name = "FBMC12_PROVINCE_N")
	private String provinceN;

	// bi-directional many-to-one association to Mfbmd42Country
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD42_COUNTRY_ISO3_C")
	private CountryDto country;

	// bi-directional many-to-one association to Mfbmd57AddressType
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD57_ADDRESS_TYPE_C")
	private AddressType addressType;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC12_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMC12_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMC12_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC12_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMC12_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMC12_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
