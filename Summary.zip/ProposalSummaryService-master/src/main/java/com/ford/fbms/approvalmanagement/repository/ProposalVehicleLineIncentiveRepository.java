package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;

/**
 * A repository class for ProposalVehicleLineIncentiv.
 *
 * @author AGOVADA
 */
@Repository
public interface ProposalVehicleLineIncentiveRepository extends
    JpaRepository<ProposalVehicleLineIncentiveDto, Long> {

	Optional<List<ProposalVehicleLineIncentiveDto>> findByProposal(ProposalDto proposal);

	@Query(value = "SELECT A04.* FROM {h-schema}MFBMA04_PROPOSAL_VEHLN_INCTV A04 " +
			"WHERE FBMA01_PROPOSAL_K = ?1", nativeQuery = true)
	List<ProposalVehicleLineIncentiveDto> getVehicleLineIncentiveDetailsByProposal(long proposalSaKey);

}
