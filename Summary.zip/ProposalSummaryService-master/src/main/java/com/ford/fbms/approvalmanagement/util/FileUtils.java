package com.ford.fbms.approvalmanagement.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class FileUtils {
	
	private FileUtils() {
	    throw new IllegalStateException("Utility class");
	  }


  public static StringBuilder readFile(final String name) throws IOException {
    URL url = FileUtils.class.getResource(name);
    File file = new File(url.getPath());
    try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
      String line;
      StringBuilder sb = new StringBuilder();
      while ((line = reader.readLine()) != null) {
        sb.append(line).append(System.getProperty("line.separator"));
      }
      return sb;
    } catch (IOException e) {
      LoggerBuilder
          .printError(log, loggerBuilder -> loggerBuilder.message("Can't read from Stream"));
      throw e;
    }
  }
}