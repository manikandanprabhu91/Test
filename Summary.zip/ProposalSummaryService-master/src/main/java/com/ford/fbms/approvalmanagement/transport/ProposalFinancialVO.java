// ******************************************************************************
// * Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   ProposalFinancialVO.java  $
// * $Revision:   1.15  $
// * $Author:   PSIRISIN  $
// * $Date:   Jul 08 2010 12:15:38  $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

/**
 * Provides the Proposal financial info at PerUnit level used for Proposal
 * Summary page.
 */
@Setter
@Getter
public class ProposalFinancialVO implements Cloneable {
	
	private long perUnit;

    private long vL;
    
    private String vehLineCode;
    
   /* private long proposalTier;
    
    private long prevVerProposalTier;*/

    /*
     * Prior Year BodyStyle or BodyGroup sakey
     */
    private long priorYearPerUnit;

    /**
     * prior year VehicleLineIncentive saKey
     */
    private long priorYearVL;

    /*
     * Prior Version BodyStyle or BodyGroup sakey
     */
    private long priorVerPerUnit;

    /**
     * prior version VehicleLineIncentive saKey
     */
    private long priorVerVL;

    /** ********** variables for Variable Marketing************* */
    /*
     * Present Variable Marketing
     */
    private long vM;
    /*
     * Added CPA,ESP,OPT and AGG columns for Present Proposal data. VM =
     * CPA+ESP+OPT+AGG
     */
    private long cPA;
    private long eSP;
    private long oPT;
    private long aGG;

    private long priorVerCPA;
    private long priorVerESP;
    private long priorVerOPT;
    private long priorVerAGG;
    
    private long priorYearCPA;
    private long priorYearESP;
    private long priorYearOPT;
    private long priorYearAGG;

    /*
     * Prior Year Variable Marketing
     */
    private long priorYearVM;
    /*
     * Prior Version Variable Marketing
     */
    private long priorVerVM;
    /*
     * Year Over Year Target adjustment Variable Marketing
     */
    private long yoyTargetVM;
    /*
     * New Customer (or new VehicleLine) Target Variable Marketing
     */
    private long newTargetVM;

    /**
     * Added following variables that are used for generating the Graph
     */
    private long tier1Target;
    private long tier2Target;
    private long tier3Target;
    private long tier4Target;
    private long tier5Target;

    private long tier6;
    private long tier5;
    private long tier4;
    private long tier3;
    private long tier2;
    private long tier1;

    private long priorVerTier6;
    private long priorVerTier5;
    private long priorVerTier4;
    private long priorVerTier3;
    private long priorVerTier2;
    private long priorVerTier1;

    private long priorYearTier6;
    private long priorYearTier5;
    private long priorYearTier4;
    private long priorYearTier3;
    private long priorYearTier2;
    private long priorYearTier1;
    
    private String presentTier1;
    private String presentTier2;
    private String presentTier3;
    private String presentTier4;
    private String presentTier5;
    private String presentTier6;
    

    /** ********* variables for Volume ******************** */
    /*
     * Present volume (Most likely volume or Actual)
     */
    private long volume;
    /*
     * Prior Year Volume (Most likely volume or Actual)
     */
    private long priorYearVolume;
    /*
     * Prior version volume (Most likely volume or Actual)
     */
    private long priorVerVolume;

    /** ********* variables for Revenue ******************** */
    /*
     * Present Revenue (Actual or Estimate)
     */
    private long actRevenue;
    private long estRevenue;
    /*
     * Prior Year Revenue (Actual or Estimate)
     */
    private long priorYearActRevenue;
    private long priorYearEstRevenue;
    /*
     * Prior Version Revenue (Actual or Estimate)
     */
    private long priorVerActRevenue;
    private long priorVerEstRevenue;
    private long actCC;
    private long estCC;
    private long actNR;
    /*
     * Prior Year Contribution cost (Estimate or Actual)
     */
    private long priorYearActCC;
    private long priorYearEstCC;
    /*
     * Prior Version Contribution cost (Estimate or Actual)
     */
    private long priorVerActCC;
    private long priorVerEstCC;
    private String vehicleLineDescription;
    /*
     * perUnit description. i.e. body style code or body group code
     */
    private String perUnitDescription;
    /*
     * Vehicle Line model year
     */
    private int modelYear;
    /*
     * flag for identifying the perUnit is a body group or not
     */
    private boolean bodyGroup;
    /**
     * flag for identifying the vehicle line is part of present proposal or not
     */
    private boolean presentVehicleLine;

    private long targetEstCC;

    /**
     * Target Revenue
     */
    private long targetEstRevenue;
    
    private String foeVehicleLineDescription;
    
    private String startDate;
    
    private String endDate;
    
    private boolean negativeVOIncentiveFlag;
    
    public ProposalFinancialVO(long perUnit) {
        super();
        this.perUnit = perUnit;
    }
    
    public ProposalFinancialVO(long perUnit, long priorYearPerUnit,
            long priorVerPerUnit) {
	super();
	this.perUnit = perUnit;
	this.priorYearPerUnit = priorYearPerUnit;
	this.priorVerPerUnit = priorVerPerUnit;
	}
    
    public boolean equals(Object o) {
        String METHOD_NAME = "equals";

        if (this == o) {
            return true; }
        if (this == null && o == null) {
            return true; }
        if (getClass() != o.getClass()) {
            return false; }
        final ProposalFinancialVO other = (ProposalFinancialVO)o;
        if (other.getPerUnit() == this.getPerUnit()
            && other.getPriorYearPerUnit() == this.getPriorYearPerUnit()
            && other.getPriorVerPerUnit() == this.getPriorVerPerUnit()) {
            return true;
        }
        return false;
    }
    
	 
	 public long getTargetVM() {
	        String METHOD_NAME = "getYoyTargetExistingVM";
	        long targetVM = 0L;
	        // identify if its new customer/vehicle line existing
	        if (this.priorYearVM == 0L) {
	            targetVM = this.newTargetVM;
	        }else{
	            targetVM = this.priorYearVM + (this.yoyTargetVM * (-1));
	        }
	        return targetVM;
	    }
	 
	 @Override
	    public Object clone()  {
	        String METHOD_NAME = "clone";
	        try {
				return super.clone();
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return METHOD_NAME;

	    }

        /**
     * @return Returns the fctCC.
     */
    public long getFctCC() {
        String METHOD_NAME = "getFctCC";
       if (this.priorYearActCC != 0L) {
        	
            return (this.priorYearActCC + this.estCC - this.priorYearEstCC);
        }
        return this.estCC;
    }

    /**
     * @return Returns the PriorVer fctCC.
     */
    public long getPriorVerFctCC() {
        String METHOD_NAME = "getPriorVerFctCC";
        if (this.priorYearActCC != 0L) {
            return (this.priorYearActCC + this.priorVerEstCC - this.priorYearEstCC);
        }
        return this.priorVerEstCC;
    }

    /**
     * @return Returns the PriorVer fctRevenue.
     */
    public long getPriorVerFctRevenue() {
        String METHOD_NAME = "getPriorVerFctRevenue";
        if (this.priorYearActRevenue > 0L) {
            return (this.priorYearActRevenue + this.priorVerEstRevenue - this.priorYearEstRevenue);
        }
        return this.priorVerEstRevenue;
    }

	public void setmLBIncentive(Long getmLBIncentive) {
		// TODO Auto-generated method stub
		
	}
	
	public long getTargetActCC() {
        if (getPriorYearActCC() > 0L) {
            return (getPriorYearActCC() + getEstCC() - getPriorYearEstCC());
        }
        return (getTargetEstCC());
	}
	
	public long getTargetActRevenue() {
        if (getPriorYearActRevenue() > 0L) {
            return (getPriorYearActRevenue() + getEstRevenue() - getPriorYearEstRevenue());
        }
        return (getTargetEstRevenue());
    }
	
	public long getTargetActNR() {
        return (getTargetActRevenue() + getTargetVM());
    }

	public long getTargetActCM() {
        return (getTargetActRevenue() + getTargetActCC() + getTargetVM());
    }
	public long getFctRevenue() {
      if (this.priorYearActRevenue > 0L) {
            return (this.priorYearActRevenue + this.estRevenue - this.priorYearEstRevenue);
        }
        return this.estRevenue;
    }
	
	public long getTargetFctCC() {
        if (getPriorYearActCC() != 0L) {
            return (getPriorYearActCC() + getEstCC() - getPriorYearEstCC());
        }
        return (getTargetEstCC());
    }
	
	public long getTargetFctRevenue() {
        if (getPriorYearActRevenue() > 0L) {
            return (getPriorYearActRevenue() + getEstRevenue() - getPriorYearEstRevenue());
        }
        return (getTargetEstRevenue());
    }
	
	public long getPriorVerFctNR() {
        return (getPriorVerFctRevenue() + getPriorVerVM());
    }
	
	public long getPriorVerFctCM() {
        return (getPriorVerFctRevenue() + getPriorVerFctCC() + getPriorVerVM());
    }
	
	public long getTargetFctNR() {
        return (getTargetFctRevenue() + getTargetVM());
    }
	
	 public long getTargetFctCM() {
	        return (getTargetFctRevenue() + getTargetFctCC() + getTargetVM());
	    }
    private long priorVerProposalTier;
    private long proposalTier;
    private long priorYearProposalTier;
    private long totalTier;
    private long priorVerTotalTier;
    private long priorYearTotalTier;
    	
}
