package com.ford.fbms.approvalmanagement.datastore;

/**
 * A class to be instantiated for every request in order to share the data in the same session.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public class RequestScopeDataStore {

  //Add your variables to store in request scope
}
