package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class ProposalSubsidiaryPK implements Serializable{
	
	private static final long serialVersionUID = 1L;

	// bi-directional many-to-one association to Mfbma01Proposal
	@ManyToOne(fetch = FetchType.EAGER)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "FBMA01_PROPOSAL_K")
	private ProposalDto proposal;

	// bi-directional many-to-one association to Mfbme01FinMaster
	@ManyToOne(fetch = FetchType.EAGER)
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	@NotFound(action = NotFoundAction.IGNORE)
	@JoinColumn(name = "FBME01_SUBS_FIN_K")
	private FinMasterDto subFinMaster;


}
