package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import java.util.List;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate Addresses.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class ApprovalManagementValidator implements Validator {

  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(
      final ApiParams apiParams, final Object approvalRequest,
      final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .message("Inside Approval Management validator"));

    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();

    final List<ApprovalProcessDto> approvalProcessList
        = approvalProcessRepository.findApprovalProcessById(apiParams.getProposalKey());
    if (!approvalProcessList.isEmpty()) {
      genericResponseWrapper.setApprovalProcessDtoList(approvalProcessList);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}