// ******************************************************************************
// * Copyright (c) 2010 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   PerUnitExpandedViewBO.java  $
// * $Revision:   1.1  $
// * $Author : PSIRISIN $
// * $Date : $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;



/**
 * PerUnitExpandedViewBO
 */
@Entity
@Table(name = PerUnitExpandedViewDto.TABLE_NAME)
public class PerUnitExpandedViewDto implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    public static final String TABLE_NAME = "FBMS_A04_EXPANDED_OPT_VIEW";
    
    @EmbeddedId
    private PerUnitExpandedViewPK id;
    
    @Column(name = "FBMA01_PROPOSAL_K")
    private long proposalSaKey;
        
    @Column(name = "FBMA04_MLV_Q")
    private long  mlv;
    
    @Column(name = "FBMA04_TIER1_INCTV_TO_DLR_F")
    private String  tierIncentiveToDealer;
    
    @Column(name = "FBMA04_REPURCHASE_Q")
    private Long repurchaseQty;
   
    @Column(name = "FBME03_BODY_GROUP_IND_F")
    private String bodyGroupIndicator;
    
   @Column(name ="FBME04_VEHLN_C")
    private String vehicleLineCode;
    
    @Column(name = "FBME04_VEHLN_MDLYR_C")
    private int modelYear;
    
    @Column(name = "FBME04_VEHLN_X")
    private String vehicleLineDesc;

    
    @Column(name = "FBME03_BDYSTL_C_1")
    private String bodyStyleCode;

    @Column(name = "FBME03_BDYSTL_C_2")
    private String expandedBodyStyleCode;
    
    @Column(name = "FBMA11_TIER_INCTV_A_1")
    private Long tier1Incentive;
    
    @Column(name = "FBMA11_TIER_INCTV_A_2")
    private Long tier2Incentive;
    
    @Column(name = "FBMA11_TIER_INCTV_A_3")
    private Long tier3Incentive;
    
    @Column(name = "FBMA11_TIER_INCTV_A_4")
    private Long tier4Incentive;
    
    @Column(name = "FBMA11_TIER_INCTV_A_5")
    private Long tier5Incentive;
    
    @Column(name = "FBMA11_TIER_INCTV_A_6")
    private Long tier6Incentive;

	public long getProposalSaKey() {
		return proposalSaKey;
	}

	public void setProposalSaKey(long proposalSaKey) {
		this.proposalSaKey = proposalSaKey;
	}

	public long getMlv() {
		return mlv;
	}

	public void setMlv(long mlv) {
		this.mlv = mlv;
	}

	public String getTierIncentiveToDealer() {
		return tierIncentiveToDealer;
	}

	public void setTierIncentiveToDealer(String tierIncentiveToDealer) {
		this.tierIncentiveToDealer = tierIncentiveToDealer;
	}

	public long getRepurchaseQty() {
		return (repurchaseQty==null?0:repurchaseQty);
	}

	public void setRepurchaseQty(long repurchaseQty) {
		this.repurchaseQty = repurchaseQty;
	}

	public String getBodyGroupIndicator() {
		return bodyGroupIndicator;
	}

	public void setBodyGroupIndicator(String bodyGroupIndicator) {
		this.bodyGroupIndicator = bodyGroupIndicator;
	}

	public String getVehicleLineCode() {
		return vehicleLineCode;
	}

	public void setVehicleLineCode(String vehicleLineCode) {
		this.vehicleLineCode = vehicleLineCode;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public String getVehicleLineDesc() {
		return vehicleLineDesc;
	}

	public void setVehicleLineDesc(String vehicleLineDesc) {
		this.vehicleLineDesc = vehicleLineDesc;
	}

	public String getBodyStyleCode() {
		return bodyStyleCode;
	}

	public void setBodyStyleCode(String bodyStyleCode) {
		this.bodyStyleCode = bodyStyleCode;
	}

	public String getExpandedBodyStyleCode() {
		return expandedBodyStyleCode;
	}

	public void setExpandedBodyStyleCode(String expandedBodyStyleCode) {
		this.expandedBodyStyleCode = expandedBodyStyleCode;
	}

	public Long getTier1Incentive() {
		return (tier1Incentive==null?0:tier1Incentive);
	}

	public void setTier1Incentive(Long tier1Incentive) {
		this.tier1Incentive = tier1Incentive;
	}

	public Long getTier2Incentive() {
		return (tier2Incentive==null?0:tier2Incentive);
	}

	public void setTier2Incentive(Long tier2Incentive) {
		this.tier2Incentive = tier2Incentive;
	}

	public Long getTier3Incentive() {
		return (tier3Incentive==null?0:tier3Incentive);
	}

	public void setTier3Incentive(Long tier3Incentive) {
		this.tier3Incentive = tier3Incentive;
	}

	public Long getTier4Incentive() {
		return (tier4Incentive==null?0:tier4Incentive);
	}

	public void setTier4Incentive(Long tier4Incentive) {
		this.tier4Incentive = tier4Incentive;
	}

	public Long getTier5Incentive() {
		 return (tier5Incentive==null?0:tier5Incentive);
	}

	public void setTier5Incentive(Long tier5Incentive) {
		this.tier5Incentive = tier5Incentive;
	}

	public Long getTier6Incentive() {
		return (tier6Incentive==null?0:tier6Incentive);
	}

	public void setTier6Incentive(Long tier6Incentive) {
		this.tier6Incentive = tier6Incentive;
	}
    
    
    
    @Column(name = "ESP")
    private Long eSPIncentive;
    
    @Column(name = "MLB")
    private Long mLBIncentive;

    @Column(name = "OTHER")
    private Long optionIncentive;

    
    public Long geteSPIncentive() {
		return (eSPIncentive==null?0:eSPIncentive);
	}
	
	public void seteSPIncentive(Long eSPIncentive) {
		this.eSPIncentive = eSPIncentive;
	}

	public Long getmLBIncentive() {
		return (mLBIncentive==null?0:mLBIncentive);
	}

	public void setmLBIncentive(long mLBIncentive) {
		this.mLBIncentive = mLBIncentive;
	}

	public Long getOptionIncentive() {
		return (optionIncentive==null?0:optionIncentive);
	}

	public void setOptionIncentive(Long optionIncentive) {
		this.optionIncentive = optionIncentive;
	}

	public PerUnitExpandedViewPK getId() {
		return id;
	}

	public void setId(PerUnitExpandedViewPK id) {
		this.id = id;
	}

	

    // private String autoEarlyFlag;
    // private Date autoEarlyDate;
    // private String expandedBodyStyleDesc;
    // private String bodyStyleDesc;




}
