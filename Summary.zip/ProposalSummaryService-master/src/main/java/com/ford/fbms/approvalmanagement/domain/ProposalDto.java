package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Type;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonIgnore;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA01_PROPOSAL database table.
 * 
 */

@Entity
@Table(name = "MFBMA01_PROPOSAL")
@Getter
@Setter

public class ProposalDto extends GenericResponse implements Serializable {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (proposalSaKey ^ (proposalSaKey >>> 32));
		return result;
	}

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMA01_PROPOSAL";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMA01_PROPOSAL_K")
	private long proposalSaKey;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_ACROSS_YEAR_DEAL_F")
	private Boolean acrossYearDealFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_APPROVAL_PRIORITY_F")
	private boolean approvalPriorityFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_APPROVAL_REQD_F")
	private Boolean approvalReqdFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_AUTOEARLY_ACCEPTANCE_F")
	private Boolean autoearlyAcceptanceFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_AUTOEARLY_IMPACTED_F")
	private Boolean autoearlyImpactedFlag;

	@Column(name = "FBMA01_BASE_PROPOSAL_K")
	private BigDecimal baseProposalSaKey;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_CNTL_APPROVE_Y")
	private Date cntlApproveYear;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_CNTL_REQD_F")
	private Boolean cntlReqdFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_COUNT_RENTAL_REPURCH_F")
	private Boolean countRentalRepurchFlag;

	@Column(name = "FBMA01_CUST_SIGN_S")
	private Timestamp custSignTS;

	@Column(name = "FBMA01_DEAL_VER_R")
	private BigDecimal dealVersion;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_END_Y")
	private Date endYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_FORD_APPROVE_Y")
	private Date fordApproveYear;

	@Column(name = "FBMA01_LETTER_MIN_Q")
	private BigDecimal letterMinQty;

	@Column(name = "FBMA01_LONG_TERM_DEMO_R")
	private BigDecimal longTermDemoR;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_MULTI_YEAR_DEAL_F")
	private Boolean multiYearDealFlag;

	@Column(name = "FBMA01_MULTI_YEAR_END_Y")
	private BigDecimal multiYearEndYear;

	@Column(name = "FBMA01_MULTI_YEAR_START_Y")
	private BigDecimal multiYearStartYear;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_NON_FINANCIAL_F")
	private Boolean nonFinancialFlag;

	@Column(name = "FBMA01_PROPOSAL_MLV_Q")
	private BigDecimal proposalMlv;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_PROPOSAL_MULTIYEAR_F")
	private Boolean proposalMultiYearFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_PROPOSAL_SUB_Y")
	private Date proposalSubYear;

	@Column(name = "FBMA01_PROPOSAL_VM_A")
	private BigDecimal proposalVmA;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_QFC_F")
	private Boolean qfcFlag;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_SELLING_DLR_ASGN_F")
	private Boolean sellingDealerAssignedFlag;

	@Column(name = "FBMA01_SOURCE_PROPOSAL_C")
	private Long sourceProposalCode;

	@Column(name = "FBMA01_SOURCE_VER_AT_TRM_R")
	private BigDecimal sourceVersionAtTrmR;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_START_Y")
	private Date startYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA01_STATUS_Y")
	private Date statusYear;

	@Column(name = "FBMA01_VERNUM_R")
	private int versionNumber;

	@Type(type = "yes_no")
	@Column(name = "FBMA01_XPLAN_REQD_F")
	private Boolean xplanRequiredFlag;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME01_FIN_MASTER_K")
	private FinMasterDto finMasterKey;

	@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD95_PPL_YOY_C")
	private PriceProtectionLevelYearOverYearDto pplYoy;
	
	/*@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	@OneToMany(mappedBy="proposalSubsidiaryPK.subFinMaster",fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	  private List<ProposalSubsidiaryDto> proposalSubsidiaryList;*/

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD03_CDSID_C")
	private FordPersonDto fordPerson;

	 /*@JsonIgnore
	@OneToMany(mappedBy="pviSaKey",fetch=FetchType.EAGER,cascade=CascadeType.REMOVE)
	 @NotFound(action = NotFoundAction.IGNORE)
	  private List<ProposalVehicleLineIncentiveDto> vehicleLines;*/
	 
	 
	/* 	@OneToMany(mappedBy="pviSaKey")
		private List<ProposalVehicleLineIncentiveDto> vehicleLines;*/

	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "FBMD05_PMT_TYP_C") 
	 private PaymentTypeDto paymentType;
	
	@JsonIgnore
	  @OneToMany(mappedBy = "proposalSubsidiaryPK.subFinMaster", fetch = FetchType.LAZY,
	          cascade = CascadeType.REMOVE)
	 @NotFound(action = NotFoundAction.IGNORE)
	  private List<ProposalSubsidiaryDto> proposalSubsidiaryList;
	 
	 
	 
	/*@JsonIgnore
	@OneToMany(mappedBy="proposalSubsidiaryPK.subFinMaster", fetch=FetchType.EAGER,cascade=CascadeType.ALL) 
	 @NotFound(action = NotFoundAction.IGNORE)*/
	
	 
	 
	/*
	 * @JsonBackReference
	 * 
	 * @OneToMany(mappedBy = "tierVolumePk.proposalKey") private List<TierVolumeDto>
	 * tierVolumes;
	 */

	/*
	 * @JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBME01_FIN_MASTER_K") private FinMaster finMaster;
	 * 
	 * // bi-directional many-to-one association to Mfbmd04PriceProtectionLevel
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD04_PPL_C") private PriceProtectionLevel
	 * priceProtectionLevel;
	 * 
	 * // bi-directional many-to-one association to Mfbmd05PaymentType
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD05_PMT_TYP_C") private PaymentType paymentType;
	 */

	/*
	 * // bi-directional many-to-one association to Mfbmd03FordPerson
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD03_CDSID_C") private FordPerson fordPerson;
	 * 
	 * // bi-directional many-to-one association to Mfbmd04PriceProtectionLevel
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD04_PPL_C") private PriceProtectionLevel
	 * priceProtectionLevel;
	 * 
	 * // bi-directional many-to-one association to Mfbmd05PaymentType
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD05_PMT_TYP_C") private PaymentType paymentType;
	 * 
	 * // bi-directional many-to-one association to Mfbmd11ProposalStatus
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD11_SOURCEPROPOSAL_STATUS_C") private ProposalStatus
	 * sourceProposalStatusCode;
	 */
	// bi-directional many-to-one association to Mfbmd12PyDefinition
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD12_PROPOSAL_YEAR_C")
	private PyDefinitionDto pyDefinition;

	// bi-directional many-to-one association to Mfbmd11ProposalStatus
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD11_PROPOSAL_STATUS_C")
	private ProposalStatusDto proposalStatus;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD11_SOURCEPROPOSAL_STATUS_C") 
	private ProposalStatusDto sourceProposalStatusCode;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD14_MAX_RPTLVL_K")
	private ReportLevelDto reportLevel;
	
	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA01_CREATE_S")
	private Date createdTimeStamp;

	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Column(name = "FBMA01_CREATE_PROCESS_C")
	private String createdProcess;

	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Column(name = "FBMA01_CREATE_USER_C")
	private String createdUser;

	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA01_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Column(name = "FBMA01_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@Column(name = "FBMA01_LAST_UPDT_USER_C")
	private String lastUpdatedUser;


}
