package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Embeddable
@Getter
@Setter
public class PerUnitExpandedViewPK implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name = "FBMA04_PVI_K")
    private long vehicleLineIncentiveSaKey;
    
    @Column(name = "FBME03_BDYSTL_K_1")
    private long bodyStyleSaKey;
    
    @Column(name = "FBME03_BDYSTL_K_2")
    private long expandedBodyStyleSaKey;


}
