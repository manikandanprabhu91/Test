package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD58_ACCOUNT_ASSIGNMENT database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = AccountAssignmentDto.TABLE_NAME)
public class AccountAssignmentDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD58_ACCOUNT_ASSIGNMENT";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD58_AA_K")
	private long saKey;

	@Column(name = "FBMD58_STATUS_C")
	private String statusCode;

	// bi-directional many-to-one association to Mfbmd03FordPerson
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD03_CDSID_C")
	private FordPersonDto fordPerson;

	// bi-directional many-to-one association to Mfbmd59AssignmentType
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD59_ASSIGNMENT_TYPE_C")
	private AssignmentTypeDto assignmentType;

	// bi-directional many-to-one association to Mfbme01FinMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME01_FIN_MASTER_K")
	private FinMasterDto finMaster;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD58_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD58_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD58_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD58_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD58_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD58_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
