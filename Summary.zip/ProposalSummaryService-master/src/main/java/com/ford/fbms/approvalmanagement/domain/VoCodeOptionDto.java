package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME02_VOCODE_OPTION database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = VoCodeOptionDto.TABLE_NAME)
// @NamedQuery(name="VoCodeOption.findAll", query="SELECT m FROM VoCodeOption
// m")
public class VoCodeOptionDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME02_VOCODE_OPTION";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME02_VOCODE_K")
	private long voCodeSaKey;

	@Column(name = "FBME02_VO_C")
	private String voCode;

	@Column(name = "FBME02_VO_X")
	private String voDesc;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBME02_VOCODE_ENTRY_Y")
	private Date voCodeEntryYear;

	@Column(name = "FBME02_VOCODE_MODIFY_S")
	private Timestamp voCodeModifyTS;

	// bi-directional many-to-one association to Mfbma05OptionIncentive
	/*
	 * @OneToMany(mappedBy="vocodeOption") private List<OptionIncentive>
	 * optionIncentives;
	 */

	// bi-directional many-to-one association to Mfbme04VehicleLine
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME04_VEHLN_K")
	private VehicleLineDto vehicleLine;

	// bi-directional many-to-one association to Mfbme29VocodeStatus
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME29_VOCODE_STATUS_C")
	private VocodeStatusDto vocodeStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME02_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME02_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME02_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME02_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME02_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME02_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
