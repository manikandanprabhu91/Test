package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME15_FIN_OP_UNT_MASTER database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = FinOpUnitMaster.TABLE_NAME)
public class FinOpUnitMaster implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBME15_FIN_OP_UNT_MASTER";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME15_FOU_K")
	private long finOpUnitMasterSaKey;

	@Column(name = "FBME15_ACCT_2_N")
	private String accountName2;

	@Column(name = "FBME15_ACCT_N")
	private String accountName;

	@Column(name = "FBME15_CUPID_D")
	private BigDecimal cupid;

	@Column(name = "FBME15_ENROLLMENT_S")
	private Timestamp enrollDate;

	@Column(name = "FBME15_FLEET_CLASS_C")
	private String fleetClassCode;

	@Column(name = "FBME15_FLEET_TYPE_C")
	private String fleetTypeCode;

	@Column(name = "FBME15_OU_C")
	private String operationUnitCode;

	@Column(name = "FBME15_RESTRICT_FIN_F")
	private String restrictedFinStatus;

	/*
	 * // bi-directional many-to-one association to Mfbmc03Direction
	 * 
	 * @OneToMany(mappedBy = "finOpUnitMaster") private List<Direction> directions;
	 * 
	 * // bi-directional many-to-one association to Mfbmc05AcctPreference
	 * 
	 * @OneToMany(mappedBy = "finOpUnitMaster") private List<AcctPreference>
	 * acctPreferences;
	 */

	// bi-directional many-to-one association to Mfbmc14AccountNote
	@OneToMany(mappedBy = "finOpUnitMaster")
	private List<AccountNote> accountNotes;

	// bi-directional many-to-one association to Mfbmc12Address
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMC12_MAILING_ADDR_K")
	private Address mailingAddress;

	// bi-directional many-to-one association to Mfbmc12Address
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMC12_PHYSICAL_ADDR_K")
	private Address physicalAddress;

	// bi-directional many-to-one association to Mfbmd69AcctSourceType
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD69_ACCT_SOURCE_C")
	private AcctSourceType accountSourceType;

	// bi-directional many-to-one association to Mfbmd90FinStatus
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD90_FIN_STATUS_C")
	private FinStatus finStatus;

	// bi-directional many-to-one association to Mfbme01FinMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME01_FIN_MASTER_K")
	private FinMasterDto finMasterDto;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME15_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME15_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME15_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME15_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME15_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME15_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
