package com.ford.fbms.approvalmanagement.util;

import com.ford.fbms.approvalmanagement.domain.MessageLangDto;
import com.ford.fbms.approvalmanagement.repository.MessageLangRepository;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

/**
 * An util class for Redis cache.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Slf4j
@Service
public class CacheUtil {

  @Autowired
  private  MessageLangRepository messageLangRepository;

  /**
   * The error message will store it "errorMessages" cache (consider as a map), if not available. It
   * will fetch it from redis server, if data available in cache server.
   *
   * @param errorMsgId error message code
   * @return message description as a String
   */
  @Cacheable(cacheNames = "errorMessages", key = "#errorMsgId")
  public String getMsgDesc(final String errorMsgId) {
    final String methodName = "getErrorMessage";
    String errorDesc = null;
    final String logStartMessage = "Getting Error Message for : " + errorMsgId;
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).message(logStartMessage));
    final Optional<MessageLangDto> msgOptional = messageLangRepository.findById(errorMsgId);
    if (msgOptional.isPresent()) {
      errorDesc = msgOptional.get().getMessageDesc();
    }
    final String logMessage = "Retrieved Error Message Description : " + errorDesc;
    LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).message(logMessage));
    return errorDesc;
  }
}
