package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD59_ASSIGNMENT_TYPE database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "MFBMD59_ASSIGNMENT_TYPE")
public class AssignmentTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD59_ASSIGNMENT_TYPE_C")
	private String assignmentTypeCode;

	@Column(name = "FBMD59_ASSIGNMENT_TYPE_X")
	private String assignmentTypeDesc;


	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD59_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD59_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMD59_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD59_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD59_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD59_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
