package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME48_USC_OPTION database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = UscOptionDto.TABLE_NAME)
// @NamedQuery(name="UscOption.findAll", query="SELECT m FROM UscOption m")
public class UscOptionDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME48_USC_OPTION";

	@EmbeddedId
	private UscOptionPK uscOptionPK;

	@Column(name = "FBME48_DARTS_VERSION_R")
	private BigDecimal dartsVersionR;

	@Column(name = "FBME48_DEALER_F")
	private String dealerFlag;

	@Column(name = "FBME48_DISPLAY_F")
	private String displayFlag;

	@Column(name = "FBME48_KEYSTROKE_C")
	private String keystrokeCode;

	@Column(name = "FBME48_KEYSTROKES_MAXIMUM_T")
	private BigDecimal keystrokesMaximumT;

	@Column(name = "FBME48_KEYSTROKES_MINIMUM_T")
	private BigDecimal keystrokesMinimumT;

	@Column(name = "FBME48_OPTION_TYPE_C")
	private String optionTypeCode;

	@Column(name = "FBME48_SALES_F")
	private String salesFlag;

	@Column(name = "FBME48_TABLE_C")
	private String tableCode;

	@Column(name = "FBME48_TABLE_NEXT_C")
	private String tableNextCode;

	@Column(name = "FBME48_TABLE_TYPE_C")
	private String tableTypeCode;

	@Column(name = "FBME48_TABLE_TYPE_X")
	private String tableTypeDesc;

	@Column(name = "FBME48_USC_N")
	private String uscN;

	@Column(name = "FBME48_USC_X")
	private String uscDesc;

	// bi-directional many-to-one association to Mfbma05OptionIncentive
	/*
	 * @OneToMany(mappedBy = "uscOption") private List<OptionIncentive>
	 * optionIncentives;
	 */
	/*
	 * //bi-directional many-to-one association to Mfbme41PdMarket
	 * 
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumn(name="FBME41_PD_MARKET_C") private PdMarket pdMarket;
	 */

	// bi-directional many-to-one association to Mfbme51UscStatus
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME51_USC_STATUS_C")
	private UscStatusDto uscStatus;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME48_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME48_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME48_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME48_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME48_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME48_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
