package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.CatalogFinancialDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.CatalogFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FVADataRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to get proposal details.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class MexProposalManager implements Validator {

	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected ProposalBodyFinancialViewRepository proposalBodyFinancialViewRepo;
	@Autowired
	protected TargetBandRepository targetBandRepo;
	@Autowired
	protected PerUnitOptViewRepository perUnitOptViewRepository;
	@Autowired
	protected ApprovalManagementValidator approvalManagementValidator;
	@Autowired
	protected ApprovalManagementCreateValidator approvalManagementCreateValidator;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepository;
	@Autowired
	protected MultiYearBonusRepository multiYearBonusRepository;
	@Autowired
	protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
	@Autowired
	protected TierVolumeRepository tierVolumeRepository;
	@Autowired
	protected ProposalSummaryViewRepository proposalSummaryViewRepository;
	@Autowired
	protected AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Autowired
	protected BodyFinancialRepository bodyFinancialRepo;
	@Autowired
	protected PerUnitIncentiveNewViewRepository perUnitIncentiveNewViewRepo;
	@Autowired
	protected NewBodyStyleRepository newBodyStyleRepo;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected FVADataRepository fvaDataRepo;
	@Autowired
	protected PerUnitNewViewRepository perUnitNewViewRepo;
	@Autowired
	protected FinProfileRepository finProfileRepo;
	@Autowired
	protected ProposalExtraInfoRepository proposalExtraInfoRepo;
	@Autowired
	private ProposalVehicleLineIncentiveRepository proposalVehicleLineRepo;
	@Autowired
	private PviExtraInfoRepository pviExtraInfoRepo;
	@Autowired
	private CatalogFinancialRepository catalogFinancialRepo;
	

	@Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest, final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.VALIDATE_METHOD).userId(apiParams.getUserId())
				.message("Inside ProposalManager"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.VALIDATE_METHOD)
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
			List<FinancialMexDetailedVO> financialDetailedVOList = this.populateMexFinancial(apiParams, proposal,httpRequest);
			genericResponseWrapper.setFinancialDetailedMexVOList(financialDetailedVOList);
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	private List<FinancialMexDetailedVO> populateMexFinancial(ApiParams apiParams, ProposalDto proposal,HttpServletRequest httpRequest) {
		List<FinancialMexDetailedVO> financialMexDetaiedList = new ArrayList<FinancialMexDetailedVO>();
		
		//Get Proposal Extra info..
		Date proposalExpdate = new Date();
		
		Optional<ProposalExtraInfoDto> propExtraInfoDto=proposalExtraInfoRepo.findById(proposal.getProposalSaKey());
		if(propExtraInfoDto.isPresent()) {
		proposalExpdate = propExtraInfoDto.get().getProposalExpirationTS();
		}

		FinancialMexDetailedVO v = new FinancialMexDetailedVO();
		FinancialMexDetailedVO t = new FinancialMexDetailedVO();
		String lastDescription = " ";
		String lastVehicleCode = " ";
		int lastModelYear = 0;
		Long lastVehicleLineKey = 0L;
		
		final Optional<List<ProposalVehicleLineIncentiveDto>> vehicleLineIncentiveDtos_initial =
				proposalVehicleLineRepo.findByProposal(proposal);
		
		
		if (vehicleLineIncentiveDtos_initial != null && !(vehicleLineIncentiveDtos_initial.isEmpty())) {
			List<ProposalVehicleLineIncentiveDto>	vehicleLineIncentiveDtos=vehicleLineIncentiveDtos_initial.get();
			for (int i = 0; i < vehicleLineIncentiveDtos.size(); i++) {
				ProposalVehicleLineIncentiveDto perunit = vehicleLineIncentiveDtos.get(i);

				Optional<PviExtraInfoDto> pviExtraInfoDto = null;
				PviExtraInfoDto pviExtraInfoDto_final;
				pviExtraInfoDto = pviExtraInfoRepo.findById(perunit.getPviSaKey());
				pviExtraInfoDto_final=pviExtraInfoDto.isPresent()?pviExtraInfoDto.get():null;
				CatalogFinancialDto targetCatalogFinancialDto = this.getMexFinanceTargetDetails(
						perunit.getBodyStyle().getBodyStyleSaKey(),apiParams.getFleetRating(), proposalExpdate);
				CatalogFinancialDto cccCatalogFinancialDto = this.getMexFinanceTargetDetails(
						perunit.getBodyStyle().getBodyStyleSaKey(), ApprovalConstants.FLEETRATING_CCC, proposalExpdate);

				updateMexFinancial(t, perunit, pviExtraInfoDto_final, targetCatalogFinancialDto, cccCatalogFinancialDto);

				FinancialMexDetailedVO fdVO = getMexFinancial(FinancialMexDetailedVO.rowType.VehicleLine, perunit,
						pviExtraInfoDto_final, targetCatalogFinancialDto, cccCatalogFinancialDto);

				financialMexDetaiedList.add(fdVO);

				if (i == 0) {
					lastVehicleCode = perunit.getBodyStyle().getVehicleLine().getVehlnCode();
					lastModelYear = perunit.getBodyStyle().getVehicleLine().getModelYear().intValue();
					lastDescription = perunit.getBodyStyle().getVehicleLine().getVehlnDesc();
					lastVehicleLineKey = perunit.getBodyStyle().getVehicleLine().getVehlnSaKey();
				}
				if (perunit.getBodyStyle().getVehicleLine().getVehlnCode().equals(lastVehicleCode)
						&& perunit.getBodyStyle().getVehicleLine().getModelYear() == lastModelYear) {
					// add this financial rec to vldata as vehicleline and model
					// year are same
					updateMexFinancial(v, perunit, pviExtraInfoDto_final, targetCatalogFinancialDto, cccCatalogFinancialDto);

				} else {
					FinancialMexDetailedVO fdVO1 = getMexAverageFinancial(v);
					// insert prior vl details as
					fdVO1.setVehicleLineKey(lastVehicleLineKey);
					fdVO1.setModelYear(lastModelYear);
					fdVO1.setVehicleLine(lastDescription);
					fdVO1.setVehicleLineCode(lastVehicleCode);
					fdVO1.setBodyStyle(" ");
					fdVO1.setRecType(FinancialMexDetailedVO.rowType.LineTotal);
					fdVO1.setVehDesc(lastDescription+"!"+lastModelYear);
					financialMexDetaiedList.add(fdVO1);
					// start next VL
					v = new FinancialMexDetailedVO();
					updateMexFinancial(v, perunit, pviExtraInfoDto_final, targetCatalogFinancialDto, cccCatalogFinancialDto);
				}
				if (i == vehicleLineIncentiveDtos.size() - 1) {
					// last record...so insert the VL record
					FinancialMexDetailedVO fdVO2 = getMexAverageFinancial(v);
					fdVO2.setVehicleLineKey(perunit.getBodyStyle().getVehicleLine().getVehlnSaKey());
					fdVO2.setModelYear(perunit.getBodyStyle().getVehicleLine().getModelYear().intValue());
					fdVO2.setVehicleLine(perunit.getBodyStyle().getVehicleLine().getVehlnDesc());
					fdVO2.setVehicleLineCode(perunit.getBodyStyle().getVehicleLine().getVehlnCode());
					fdVO2.setBodyStyle(" ");
					fdVO2.setRecType(FinancialMexDetailedVO.rowType.LineTotal);
					fdVO2.setVehDesc(perunit.getBodyStyle().getVehicleLine().getVehlnDesc()+"!"+perunit.getBodyStyle().getVehicleLine().getModelYear());

					financialMexDetaiedList.add(fdVO2);
				}

				lastDescription = perunit.getBodyStyle().getVehicleLine().getVehlnDesc();
				lastVehicleCode = perunit.getBodyStyle().getVehicleLine().getVehlnCode();
				lastModelYear = perunit.getBodyStyle().getVehicleLine().getModelYear().intValue();
				lastVehicleLineKey = perunit.getBodyStyle().getVehicleLine().getVehlnSaKey();
			}
		   }
		
		 t = getMexAverageFinancial(t);
		
		FbmsUtil.sort(financialMexDetaiedList, "recType");
	    FbmsUtil.sort(financialMexDetaiedList, "vehDesc");

		t.setRecType(FinancialMexDetailedVO.rowType.GrandTotal);
		t.setVehicleLine("");
		financialMexDetaiedList.add(t);
		return financialMexDetaiedList;
	    }

	
	@LogAround 
	public boolean showIncludedInPriorSection(List<FinancialDetailedVO> financialDetaiedList) {
		boolean showIncludedInPrior = false;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&((!financialVO.isPresentProposal()))) {
					showIncludedInPrior = true;
					break;
			}
		}
		return showIncludedInPrior;
	}
	
	
	@LogAround
	public CatalogFinancialDto getMexFinanceTargetDetails(long bodyStyleKey,String fleetRating,Date proposalExpdate) {
			CatalogFinancialDto targetCatalog = null;
			if(!FbmsUtil.isProposalExpired(proposalExpdate)){
				targetCatalog = catalogFinancialRepo.getMarketingProgram(bodyStyleKey, fleetRating);
	       	} else {
	   		targetCatalog =  catalogFinancialRepo.getMexFinanceTargetDetails(bodyStyleKey,fleetRating,proposalExpdate);
	        }
		 return targetCatalog!=null?targetCatalog:null ;	
		}
	
	
	@LogAround
	private void updateMexFinancial(FinancialMexDetailedVO o,ProposalVehicleLineIncentiveDto perUnit,PviExtraInfoDto pviExtraInfoDto,
			CatalogFinancialDto targetCatalogFinancialDto,CatalogFinancialDto cccCatalogFinancialDto) {
		o.setModelYear(perUnit.getBodyStyle().getVehicleLine().getModelYear().intValue());
		o.setVehicleLine(perUnit.getBodyStyle().getVehicleLine().getVehlnDesc());
		o.setBodyStyle(perUnit.getBodyStyle().getBodyStyleCode());
		o.setVolume(o.getVolume()+perUnit.getMlv());
		double v = perUnit.getMlv();
		
		if(pviExtraInfoDto != null){
			   o.setFleetType(pviExtraInfoDto.getFleetRating());
			   if(pviExtraInfoDto.getBusinessCase() != null && !"No".equalsIgnoreCase(pviExtraInfoDto.getBusinessCase())) {
				   o.setMarketingProgram("XXXX".equalsIgnoreCase(pviExtraInfoDto.getBusinessCase()) ?" ":pviExtraInfoDto.getBusinessCase());
			   } else{
               o.setMarketingProgram(pviExtraInfoDto.getMarketingProgram());
               	}
			   o.setProposedFleetInventiveVM(o.getProposedFleetInventiveVM()+(pviExtraInfoDto.getFleetIncentive()*v));
			   o.setFloorPlan(o.getFloorPlan()+(pviExtraInfoDto.getFloorPlanCost()));
			   o.setFleetPrice(o.getFleetPrice()+(pviExtraInfoDto.getFleetPrice()*v));
			   o.setProposedCM(o.getProposedCM()+(pviExtraInfoDto.getContMargin()*v));
			   o.setDealerMargin(o.getDealerMargin()+(pviExtraInfoDto.getDealerMargin()*v));
			   
			if(targetCatalogFinancialDto != null){   
			   o.setFleetTargetVM(o.getFleetTargetVM()+(targetCatalogFinancialDto.getFleetIncentive()*v));
			   o.setFleetTargetCM(o.getFleetTargetCM()+(targetCatalogFinancialDto.getContMargin()*v));
			}  
			if(cccCatalogFinancialDto != null){   
			   o.setCccTargetVM(o.getCccTargetVM()+(cccCatalogFinancialDto.getFleetIncentive()*v));
			   o.setCccTargetCM(o.getCccTargetCM()+(cccCatalogFinancialDto.getContMargin()*v));
			}  
		}
		// now do the B/(W) calculation
		updateMexBW(o);

	}
	
	@LogAround
	private  FinancialMexDetailedVO getMexFinancial(FinancialMexDetailedVO.rowType rowType,ProposalVehicleLineIncentiveDto perUnit,PviExtraInfoDto pviExtraInfoDto,
			CatalogFinancialDto targetCatalogFinancialDto,CatalogFinancialDto cccCatalogFinancialDto){
		FinancialMexDetailedVO o = new FinancialMexDetailedVO();
		o.setModelYear(perUnit.getBodyStyle().getVehicleLine().getModelYear().intValue());
		o.setVehicleLine(perUnit.getBodyStyle().getVehicleLine().getVehlnDesc());
		o.setBodyStyle(perUnit.getBodyStyle().getBodyStyleCode());
		o.setVehicleLineKey(perUnit.getBodyStyle().getVehicleLine().getVehlnSaKey());
		o.setRecType(rowType);
		o.setVehicleLineCode(perUnit.getBodyStyle().getVehicleLine().getVehlnCode());
		o.setVehDesc(perUnit.getBodyStyle().getVehicleLine().getVehlnDesc()+"!"+perUnit.getBodyStyle().getVehicleLine().getModelYear()+"!"+perUnit.getBodyStyle().getBodyStyleCode());
		
		
		double v = perUnit.getMlv();
		o.setVolume(v);
		// set volume
		if(pviExtraInfoDto != null){
			   o.setFleetType(pviExtraInfoDto.getFleetRating());
			   if(pviExtraInfoDto.getBusinessCase() != null && !"No".equalsIgnoreCase(pviExtraInfoDto.getBusinessCase())) {
				   o.setMarketingProgram("XXXX".equalsIgnoreCase(pviExtraInfoDto.getBusinessCase()) ?" ":pviExtraInfoDto.getBusinessCase());
			   } else {
               o.setMarketingProgram(pviExtraInfoDto.getMarketingProgram());
               	}
			   o.setProposedFleetInventiveVM(pviExtraInfoDto.getFleetIncentive());
			   o.setFloorPlan(pviExtraInfoDto.getFloorPlanCost());
			   o.setFleetPrice(pviExtraInfoDto.getFleetPrice());
			   o.setProposedCM(pviExtraInfoDto.getContMargin());
			   o.setDealerMargin(pviExtraInfoDto.getDealerMargin());
			   if(pviExtraInfoDto.getDealerMarginPct() !=null) {
			   o.setDealerMarginPrect(pviExtraInfoDto.getDealerMarginPct().floatValue());
			   }
			   
			if(targetCatalogFinancialDto != null){   
			   o.setFleetTargetVM(targetCatalogFinancialDto.getFleetIncentive());
			   o.setFleetTargetCM(targetCatalogFinancialDto.getContMargin());
			}  
			if(cccCatalogFinancialDto != null){   
			   o.setCccTargetVM(cccCatalogFinancialDto.getFleetIncentive());
			   o.setCccTargetCM(cccCatalogFinancialDto.getContMargin());
			}  
		}

		// now calculate B(W)
		updateMexBW(o);
		return o;
	}
	
	private FinancialMexDetailedVO getMexAverageFinancial(FinancialMexDetailedVO o)  {
		if (o.getVolume() > 0) {
			o.setProposedFleetInventiveVM(o.getProposedFleetInventiveVM() / o.getVolume());
			o.setFleetTargetVM(o.getFleetTargetVM() / o.getVolume());
			o.setCccTargetVM(o.getCccTargetVM() / o.getVolume());
			o.setProposedCM(o.getProposedCM() / o.getVolume());
			o.setFleetTargetCM(o.getFleetTargetCM() / o.getVolume());
			o.setCccTargetCM(o.getCccTargetCM() / o.getVolume());
			o.setDealerMargin(o.getDealerMargin() / o.getVolume());
			o.setFleetPrice(o.getFleetPrice() / o.getVolume());
		}
		updateMexBW(o);
		return o;
	}
	
	@LogAround
	private void updateMexBW(FinancialMexDetailedVO o) {
       o.setBwFleetTargetVM(o.getFleetTargetVM()- o.getProposedFleetInventiveVM());
       o.setBwCCCTargetVM(o.getCccTargetVM() - o.getProposedFleetInventiveVM());
       o.setBwFleetTargetCM(o.getProposedCM() - o.getFleetTargetCM());
       o.setBwFleetTargetPrectCM((int)(((int)o.getFleetTargetCM()==0)?0:(o.getBwFleetTargetCM()/o.getFleetTargetCM()*100)));
       o.setBwCCCTargetCM(o.getProposedCM() - o.getCccTargetCM());
       o.setBwCCCTargetPrectCM((float)(((int)o.getCccTargetCM()==0)?0:(o.getBwCCCTargetCM()/o.getCccTargetCM()*100)));
	}

}