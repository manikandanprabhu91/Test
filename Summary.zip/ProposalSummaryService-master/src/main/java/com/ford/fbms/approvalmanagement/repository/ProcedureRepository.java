
package com.ford.fbms.approvalmanagement.repository;

/**
 * @author VSHANMU8
 *
 */
public interface ProcedureRepository {
	void updateFinancialData(Long proposalKey);
}
