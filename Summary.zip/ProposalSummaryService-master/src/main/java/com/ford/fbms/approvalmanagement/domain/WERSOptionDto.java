package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the MFBME71_WERS_OPTION database table.
 *
 */
@Builder(toBuilder = true)
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PACKAGE)
@Setter
@Getter
@Entity
@Table(name = WERSOptionDto.TABLE_NAME)


public class WERSOptionDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBME71_WERS_OPTION";
	@Id
	@SequenceGenerator(name = "E71SeqGenerator", sequenceName = "MFBM_E71_SQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "E71SeqGenerator")
	@Column(name = "FBME71_WERS_OPTION_K")
	private long saKey;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME69_WERS_CATALOG_DATA_K")
	private CatalogDataDto catalogData;

	@Column(name = "FBME71_WERS_OPTION_C")
	private String wersOptionCode;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME71_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME71_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME71_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME71_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME71_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME71_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
