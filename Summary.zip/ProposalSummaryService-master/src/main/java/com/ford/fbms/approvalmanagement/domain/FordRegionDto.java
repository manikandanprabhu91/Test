package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD07_FORD_REGION database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = FordRegionDto.TABLE_NAME)
public class FordRegionDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD07_FORD_REGION";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD07_FORD_REGION_C")
	private String fordRegionCode;

	@Column(name = "FBMD07_FORD_REGION_N")
	private String fordRegionName;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD07_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD07_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD07_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD07_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD07_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD07_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
