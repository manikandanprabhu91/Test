package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD05_PAYMENT_TYPE database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = PaymentTypeDto.TABLE_NAME)
// @NamedQuery(name="PaymentTypeDto.findAll", query="SELECT m FROM PaymentTypeDto m")
public class PaymentTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD05_PAYMENT_TYPE";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD05_PMT_TYP_C")
	private String paymentTypeCode;

	@Column(name = "FBMD05_PMT_TYP_X")
	private String paymentTypeDescription;

	@Column(name = "FBMD07_FORD_REGION_C")
	private String fordRegionCode;

	/*
	 * //bi-directional many-to-one association to Proposal
	 * 
	 * @OneToMany(mappedBy="paymentType") private List<Proposal> proposals;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD05_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD05_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD05_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD05_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD05_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD05_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
