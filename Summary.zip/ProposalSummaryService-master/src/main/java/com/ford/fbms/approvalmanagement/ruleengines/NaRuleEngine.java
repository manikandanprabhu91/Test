package com.ford.fbms.approvalmanagement.ruleengines;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ValidateActionsVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.Validator;

import lombok.extern.slf4j.Slf4j;
/**
 * A class for defining North america business rules and activities.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Slf4j
@Service
public class NaRuleEngine extends MasterRuleEngine {

  private static final String COUNTRY_CODE = "USA";
  private static final Locale LOCALE = Locale.US;

  @Override
  public String getCountryCd() {
    return COUNTRY_CODE;
  }

  @Override
  public Locale getLocale() {
    return LOCALE;
  }

  @Override
  public List<Validator> getValidators(final RequestMode requestMode, final ApiParams apiParams) {
    final List<Validator> validators = new ArrayList<>();
    validators.add(userIdValidator);
	switch (requestMode) {
	case GET_APPROVAL:
		validators.add(approvalManagementValidator);
		break;
	case CREATE_APPROVAL:
		validators.add(approvalManagementCreateValidator);
		break;
	case DELETE_APPROVAL:
		break;
	case MAINTAIN_FINANCIAL_DATA_SP:
		validators.add(maintainFinancialDataValidator);
		break;
	case GET_TOTALS_AVG_FINANICIALS:
		if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE)) {
			validators.add(proposalManager);
		} else if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE)
				|| (ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))
				|| (ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
			validators.add(actualsManager);
		} else if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE)
				|| (ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
			validators.add(forecastManager);
		}
		break;
	case GET_FINANCIAL_LIST:
		validators.add(proposalManager);
		break;
	case GET_ACTUAL_LIST:
		validators.add(actualsManager);
		break;
	case GET_FORECAST_LIST:
		validators.add(forecastManager);
		break;
	case SUBMIT_PROPOSAL:
		validators.add(getProposalManager);
		validators.add(fordPersonManager);
		validators.add(sdaTier1Manager);
		validators.add(subfinManager);
		validators.add(cpaLetterMinQtyManager);
		validators.add(tierVolumeManager);
		validators.add(tierIncentiveManager);
		validators.add(espManager);
		validators.add(vehicleLineBodyStyleEligibilityManager);	
		validators.add(submitProcessValidator);
		validators.add(submitNonFinancialProcessValidator);
		validators.add(customerAcceptanceManager);
		break;
	case SAVE_PROPOSAL:
		validators.add(getProposalManager);
		break;
	case SENDBACK_PROPOSAL:
		validators.add(getProposalManager);
		validators.add(approvalManagementValidator);
		break;
	case RECALL_PROPOSAL:
		validators.add(getProposalManager);
		validators.add(recallProcessValidator);
		break;
	case APPROVAL_CHAIN:
		validators.add(approvalChainValidator);
		break;
	case DOWNLOAD_PROPOSAL:
		// for fetching total/Avg table data
		validators.add(priorProposalManager);
		validators.add(targetBandManager);
		validators.add(subsidiaryManager);
		validators.add(proposalCommentsManager);
		validators.add(vechileLineManager);
		validators.add(perUnitIncentiveManager);
		if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE)) {
			validators.add(proposalManager);
		} else if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE)
				|| (ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))
				|| (ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
			validators.add(actualsManager);
		} else if (apiParams.getVolumeFinancialDataSource()
				.equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE)
				|| (ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE
						.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
			validators.add(forecastManager);
		}
		break;
	case GET_VOLUME_FINANCIAL_OPTIONS:
		validators.add(volumeFinancialsOptionsValidator);
		break;
	case VALIDATE_ACTIONS:
		validators.add(fordPersonManager);
		validators.add(actionValidator);
		validators.add(fordPersonAccessManager);
		validators.add(approvalProcessByStatusManager);
		break;
	case APPROVE_PROPOSAL:
	case NEXTDEAL_APPROVE:
		validators.add(sdaTier1Manager);
		validators.add(subfinManager);
		validators.add(cpaLetterMinQtyManager);
		validators.add(tierVolumeManager);
		validators.add(tierIncentiveManager);
		validators.add(espManager);
		validators.add(vehicleLineBodyStyleEligibilityManager);
		validators.add(propApprovalValidator);
		break;
	case REVISE_PROPOSAL:
		validators.add(getProposalManager);
		break;
	case REJECT_PROPOSAL:
		validators.add(getProposalManager);
		validators.add(approvalProcessManager);
		break;
	default:
		break;
	}
    return validators;
  }

  

  @Override
  public GenericResponse createApproval(final ApiParams apiParams,
                                        final GenericResponseWrapper genericResponseWrapper, final RequestMode approvalRequest) {
    ApprovalResponseVo approvalResponseVo;
    List<ApprovalProcessDto> approvalChainList = new ArrayList<ApprovalProcessDto>();
    
    if (null != genericResponseWrapper.getProposalDataDto()) {
      if ((genericResponseWrapper.getProposalDataDto().getNonFinancialFlag()!=null)&&(genericResponseWrapper.getProposalDataDto().getNonFinancialFlag())&&(null!=genericResponseWrapper.getApprovalResponseNonFinancialVo())) {
        approvalResponseVo = genericResponseWrapper.getApprovalResponseNonFinancialVo();
        if(null!=approvalResponseVo.getSourceProposalDto()) {
        approvalChainList=approvalProcessRepository.findApprovalProcessById(approvalResponseVo.getSourceProposalDto().getProposalSaKey());
        }
      } else {
        approvalResponseVo = genericResponseWrapper.getApprovalResponseVo();
      }
      final Optional<ProposalStatusDto> proposalStatusDto_final = proposalStatusRepo
          .findById(approvalResponseVo.getProposalStatus());
      ProposalDto proposalDto = genericResponseWrapper.getProposalDataDto();
      ProposalStatusDto proposalStatus = proposalStatusDto_final.isPresent() ? proposalStatusDto_final.get() : null;
	proposalDto.setProposalStatus(proposalStatus);
      if(ApprovalConstants.APPROVED.equalsIgnoreCase(proposalDto.getProposalStatus().getProposalStatusCode())) {
    	  proposalDto.setFordApproveYear(new Date());
      }
      proposalDto.setProposalSubYear(new Date());
      proposalDto.setStatusYear(new Date());
      proposalDto.setFordPerson(genericResponseWrapper.getFordPersonDto());
      proposalDto.setReportLevel(approvalResponseVo.getMaxReportLevel());
      proposalDto.setCntlReqdFlag(approvalResponseVo.isControllerApprovalRequired());
      proposalDto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
      proposalDto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
      proposalDto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
      proposalRepository.save(proposalDto);

      if (approvalChainList != null
				&& !approvalChainList.isEmpty()) {
			for (ApprovalProcessDto processRO : approvalChainList) {
				final ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
				approvalProcessDto.setProposalKey(genericResponseWrapper.getProposalDataDto());
				approvalProcessDto.setApprovedById(processRO.getApprovedById());
				approvalProcessDto.setApprovedTime(processRO.getApprovedTime());
				approvalProcessDto.setProposalStatus(processRO.getProposalStatus());
				approvalProcessDto.setSubmittedById(processRO.getSubmittedById());
				approvalProcessDto.setSubmittedTime(processRO.getSubmittedTime());
				approvalProcessDto.setSubmittedToId(processRO.getSubmittedToId());
				approvalProcessDto.setReportLevel(processRO.getReportLevel());
				approvalProcessDto.setCreatedProcess(ApprovalConstants.FBMSNG);
				approvalProcessDto.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
				approvalProcessDto.setCreatedUser(ApprovalConstants.FBMSNG);
				approvalProcessDto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
				approvalProcessDto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
				approvalProcessDto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
				approvalProcessRepository.save(approvalProcessDto);
			}
		} else {
			final ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
			approvalProcessDto.setProposalKey(genericResponseWrapper.getProposalDataDto());
			approvalProcessDto
					.setProposalStatus(proposalStatus);
			approvalProcessDto.setSubmittedById(genericResponseWrapper.getFordPersonDto());
			approvalProcessDto.setSubmittedTime(new Timestamp(new Date().getTime()));
			Optional<FordPersonDto> submittedToId = fordPersonRepo
					.findById(approvalResponseVo.getSubmittedToFordPerson());

			approvalProcessDto.setSubmittedToId(submittedToId.isPresent() ? submittedToId.get() : null);
			approvalProcessDto
					.setReportLevel(reportLevelRepo.findById(Long.valueOf(approvalResponseVo.getReportlevel())).get());
			if (null != approvalResponseVo.getApprovedByFordPerson()) {
				approvalProcessDto.setApprovedById(approvalResponseVo.getApprovedByFordPerson());
			}
			approvalProcessDto.setApprovedTime(new Timestamp(new Date().getTime()));

			approvalProcessDto.setCreatedProcess(ApprovalConstants.FBMSNG);
			approvalProcessDto.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
			approvalProcessDto.setCreatedUser(ApprovalConstants.FBMSNG);
			approvalProcessDto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			approvalProcessDto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			approvalProcessDto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			approvalProcessRepository.save(approvalProcessDto);
		}
      
      if ("SUB".equals(proposalDto.getProposalStatus().getProposalStatusCode()) && proposalDto.getCntlReqdFlag()&& proposalDto.getCntlApproveYear()== null){
    	  if(approvalResponseVo.getMaxReportLevel().getCode() == 5) {
    		 return (responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_LL5CONTROLLER_APPROVAL));
    	  }
    	  if(approvalResponseVo.getMaxReportLevel().getCode() == 4) {
    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL);
    	  }
    	  if(approvalResponseVo.getMaxReportLevel().getCode() == 2) {
    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_GLOBALCONTROLLER_APPROVAL);
    	  }
    }
      if(ApprovalConstants.ESTABLISHED.equalsIgnoreCase(proposalDto.getProposalStatus().getProposalStatusCode()) ) {
    	  
    	  if (proposalDto!= null) {
				
    		  	proposalDto.setCustSignTS(new Timestamp(new Date().getTime()));
    		  	proposalDto.setStatusYear(new Date());
    		  	proposalRepository.save(proposalDto);

				CustomerAcceptanceS3Dto customerAcceptanceS3Dto = new CustomerAcceptanceS3Dto();
				customerAcceptanceS3Dto.setProposalKey(apiParams.getProposalKey());
				customerAcceptanceS3Dto.setLetterSource(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterSource());
				customerAcceptanceS3Dto.setProposalStatus(genericResponseWrapper.getCustomerAcceptanceS3Dto().getProposalStatus());
				customerAcceptanceS3Dto.setLetterGenerateYear(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterGenerateYear());
				customerAcceptanceS3Dto.setLetterOfferYear(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterOfferYear());
				customerAcceptanceS3Dto.setLetterExpireDaysR(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterExpireDaysR());
				customerAcceptanceS3Dto.setLetterOriginalL(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterOriginalL());
				customerAcceptanceS3Dto.setLetterModifiedL(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterModifiedL());
				customerAcceptanceS3Dto.setLetterTemplate(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterTemplate());
				customerAcceptanceS3Dto.setAcceptedByCdsid(genericResponseWrapper.getCustomerAcceptanceS3Dto().getAcceptedByCdsid());
				customerAcceptanceS3Dto.setLetterGenCdsis(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterGenCdsis());
				customerAcceptanceS3Dto.setLetterStatus(genericResponseWrapper.getCustomerAcceptanceS3Dto().getLetterStatus());
				customerAcceptanceS3Dto.setMailSentToDesc(genericResponseWrapper.getCustomerAcceptanceS3Dto().getMailSentToDesc());
				customerAcceptanceS3Dto.setCreatedProcess(ApprovalConstants.FBMSNG);
				customerAcceptanceS3Dto.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
				customerAcceptanceS3Dto.setCreatedUser(ApprovalConstants.FBMSNG);
				customerAcceptanceS3Dto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
				customerAcceptanceS3Dto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
				customerAcceptanceS3Dto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
				customerAcceptanceS3Repository.save(customerAcceptanceS3Dto);
				
                
                    // SMW F20876 - Defect 2453 - End
                  Optional<MultiYearTermDto> multiYearTermDto=multiYearTermRepository.findById(apiParams.getProposalKey());
                
                  if((multiYearTermDto.isPresent() && multiYearTermDto.get().getCurrentProposalInEffect()!=null)&&
                  	(multiYearTermDto.get().getCurrentProposalInEffect().getPyDefinition().getProposalYearCode()==proposalDto.getPyDefinition().getProposalYearCode())&&
                  		(multiYearTermDto.get().getCurrentProposalInEffect().getProposalSaKey()==(proposalDto.getSourceProposalCode()))){
	                    		
                  			multiYearTermDto.get().setCurrentProposalInEffect(proposalDto);
                  			multiYearTermDto.get().setSourceProposalAtEstablishment(proposalDto);
                  			multiYearTermRepository.save(multiYearTermDto.get());
	                    	}
                  if(multiYearTermDto.isPresent()) {
                  postEstablishmentUpdates(multiYearTermDto.get(),proposalDto); 
                  }
          }
    	  
    	  return  responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_AND_ESTABLISHED_FULLY);
      }
      
      
      if(ApprovalConstants.APPROVED.equalsIgnoreCase(proposalDto.getProposalStatus().getProposalStatusCode()) ) {
    	  return  responseBuilder.generateResponse(ResponseCodes.PROPOSAL_NON_FINANCIAL_APPROVED);
      }
    } 
    
    return  responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SUBMITTED_SUCCESSFULLY);
  }
  
  @Override
  public GenericResponse validateAction(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp) {
		ValidateActionsVO actionsVo = null;
		ProposalDto proposal = consolidatedValidationResp.getProposalDataDto();
		FordPersonDto user = consolidatedValidationResp.getFordPersonDto();
		int i=0;
		
		if (null != user) {
			actionsVo = new ValidateActionsVO();
			int userLevel = user.getReportLevel().getCode();
			actionsVo.setHighPriorityFlag(proposal.isApprovalPriorityFlag());
			if (null != consolidatedValidationResp.getPyCountryDefinition()
					&& "N".equals(consolidatedValidationResp.getPyCountryDefinition().getArchiveFlag())) {
				if ((userLevel == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE)
						|| userLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
					userLevel = userLevel * 2;
				}
				
				String proposalStatus = proposal.getProposalStatus().getProposalStatusCode();
				boolean dealAuthorizedFlag = consolidatedValidationResp.getIsAuthorized();
				if (ApprovalConstants.NEW.equals(proposalStatus)
						&& (userLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE * 2 || dealAuthorizedFlag)) {
					if (consolidatedValidationResp.getIsProposalAssignee()) {
						actionsVo.setSubmitActionValid(true);
						actionsVo.setSaveActionValid(true);
						actionsVo.setDeleteActionValid(true);
					}
				} else if (ApprovalConstants.REVISED.equals(proposalStatus)
						|| ApprovalConstants.SUBMITTED.equals(proposalStatus)) {
					int presentQueueLevel = -1;
					if (null != consolidatedValidationResp.getApprovalProcessDto()
							&& null != consolidatedValidationResp.getApprovalProcessDto().getReportLevel()) {
						presentQueueLevel = 
								consolidatedValidationResp.getApprovalProcessDto().getReportLevel().getCode();
										
					
					if ((presentQueueLevel == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE)
							|| presentQueueLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
						presentQueueLevel = presentQueueLevel * 2;
					}
					
						if ((ApprovalConstants.REVISED.equals(proposalStatus))&&((userLevel == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE * 2)
								&& (userLevel == presentQueueLevel))) {
							actionsVo.setApproveActionValid(true);
							actionsVo.setRejectActionValid(true);
							actionsVo.setSendbackActionValid(true);
							actionsVo.setSaveActionValid(true);
						}
					if (ApprovalConstants.SUBMITTED.equals(proposalStatus)) {
						// See if Present approval Queue (report) level is same as user report level
						if (userLevel == presentQueueLevel) {
							actionsVo.setApproveActionValid(true);
							actionsVo.setRejectActionValid(true);
							actionsVo.setSendbackActionValid(true);
							actionsVo.setSaveActionValid(true);
							// FoM changes phase I (#23380) - added country code check for financial analyst
							if ((userLevel == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE * 2)) {
								// If the user level is 1st level approver then revise action should be
								// available
								actionsVo.setReviseActionValid(true);
							}
							if (dealAuthorizedFlag) {
								actionsVo.setRecallActionValid(true);
							}
						}
						if (userLevel < (ApprovalConstants.ACCOUNT_MANAGER_RL_CODE * 2 + 1)
								&& userLevel > presentQueueLevel) {
							// if the proposal is in higher approval queue Recall action should be available
							if (userLevel == ApprovalConstants.CONTROLLER_RL_CODE + i) {
								if (proposal.getCntlReqdFlag()) {
									actionsVo.setRecallActionValid(true);
								}
							} else {
								actionsVo.setRecallActionValid(true);
							}
						}
					}
					}
				}

			}
		}
		if (null == actionsVo) {
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
		} else {
			consolidatedValidationResp.setActionsVO(actionsVo);
			consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
		}
		return consolidatedValidationResp;
	}
  
  public void postEstablishmentUpdates(MultiYearTermDto currVerMultiYearTerm,ProposalDto customerAcceptanceS3Dto)  {
		
	Optional<ProposalDto> maxESTVersionproposalDto=proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(customerAcceptanceS3Dto.getPyDefinition().getProposalYearCode(),customerAcceptanceS3Dto.getFinMasterKey().getFinMasterKey());
	Optional<MultiYearTermDto> oMultiYearTerm = null;
		if (maxESTVersionproposalDto != null) {
				oMultiYearTerm = multiYearTermRepository.findById(maxESTVersionproposalDto.get().getProposalSaKey()) ;
			
			if (oMultiYearTerm.isPresent()
					&& oMultiYearTerm.get().getSourceProposalAtEstablishment() != null
					&& oMultiYearTerm.get().getProposalKey().equals(oMultiYearTerm
							.get().getSourceProposalAtEstablishment().getProposalSaKey())) {
				if (oMultiYearTerm.get().getEndYr() != 0
						&& oMultiYearTerm.get().getStartYr() == maxESTVersionproposalDto.get()
								.getPyDefinition()
								.getProposalYearCode()) {

				    List <MultiYearTermDto> masterMultiList = new ArrayList<MultiYearTermDto>();
					for(int i=oMultiYearTerm.get().getStartYr().intValue();i<=oMultiYearTerm.get().getEndYr();i++){
						List<MultiYearTermDto> multiYearTermBOLst = multiYearTermRepository.queryListMultiYearTermByFinMasterProposalYear(maxESTVersionproposalDto.get().getFinMasterKey().getFinMasterKey(),i);
								
						for (MultiYearTermDto termRO : multiYearTermBOLst) {
							masterMultiList.add(termRO);
						}
					}
					for (MultiYearTermDto termRO : masterMultiList) {
						termRO.setCurrentProposalInEffect(null);
						multiYearTermRepository.save(termRO);
					}
				}
			} 
		}
		
		Optional<ProposalDto> currentVerMultiYearTerm_initial = proposalRepository.findById(currVerMultiYearTerm.getProposalKey());
		ProposalDto	currentVerMultiYearTerm_final = null;
		if(currentVerMultiYearTerm_initial.isPresent()) {
			currentVerMultiYearTerm_final = currentVerMultiYearTerm_initial.get();
		}
		if (currVerMultiYearTerm.getSourceProposalAtEstablishment() != null
				&& currVerMultiYearTerm.getProposalKey()==(currVerMultiYearTerm
						.getSourceProposalAtEstablishment().getProposalSaKey())) {
			if (currVerMultiYearTerm.getEndYr() != 0
					&& currVerMultiYearTerm.getStartYr() == currentVerMultiYearTerm_final
							.getPyDefinition()
							.getProposalYearCode()) {
				
			    List <MultiYearTermDto> masterMultiList = new ArrayList<MultiYearTermDto>();
				for(int i=currVerMultiYearTerm.getStartYr().intValue();i<=currVerMultiYearTerm.getEndYr().intValue();i++) {
					List<MultiYearTermDto> multiYearTermBOLst = multiYearTermRepository.queryListMultiYearTermByFinMasterProposalYear(maxESTVersionproposalDto.get().getFinMasterKey().getFinMasterKey(),i);
					
					for (MultiYearTermDto termRO : multiYearTermBOLst) {
						masterMultiList.add(termRO);
					}
				}
				for (MultiYearTermDto termRO : masterMultiList) {
					termRO.setCurrentProposalInEffect(currentVerMultiYearTerm_final);
				}

			}

		} else {

			// not originated from this proposal..so no need to update others

		}

		// update the fin
		// get the subfin list
		
		Optional<List<ProposalSubsidiaryDto>> proposalSubsidiaryList=proposalSubsidiaryRepository.findByProposalKey(customerAcceptanceS3Dto.getProposalSaKey());

		if(proposalSubsidiaryList.isPresent()) {
		for (ProposalSubsidiaryDto subsidiaryRO : proposalSubsidiaryList.get()) {
			subsidiaryRO.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			subsidiaryRO.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			subsidiaryRO.setEstIncludedFlag("Y");
			proposalSubsidiaryRepository.save(subsidiaryRO);
		}
		}
		
		
		Optional<ProposalDto> proposaldto=proposalRepository.findById(customerAcceptanceS3Dto.getProposalSaKey());  
		
		Optional<List<ProposalDto>> proposalRO	=proposalRepository.proposalByFinMasterProposalYear(proposaldto.get().getFinMasterKey().getFinCode(),customerAcceptanceS3Dto.getPyDefinition().getProposalYearCode());

		if(proposalRO.isPresent()) {	
		for (ProposalDto proposalRO2 : proposalRO.get()) {

				if (proposalRO2.getVersionNumber() != customerAcceptanceS3Dto.getVersionNumber()) {
					// get the proposalsubsidiary list and remove the
					// established
					// flag
					List<ProposalSubsidiaryDto> proposalROSubsidiaryList = proposalRO2
							.getProposalSubsidiaryList();

					for (ProposalSubsidiaryDto subsidiaryRO : proposalROSubsidiaryList) {
						subsidiaryRO.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
						subsidiaryRO.setEstIncludedFlag("N");
						proposalSubsidiaryRepository.save(subsidiaryRO);
					}
				}
			}
	}
  }
  
}