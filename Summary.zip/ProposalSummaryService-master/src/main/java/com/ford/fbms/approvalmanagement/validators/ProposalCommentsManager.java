package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ProposalViewDto;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalCommentsVo;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import java.util.List;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to load fleet person details.
 *
 * @author SJAGATJO on 3/25/2021.
 */
@Service
@Slf4j
public class ProposalCommentsManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  private RestService restService;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).country(apiParams.getCountryCd())
        .message("Inside ProposalCommentsManager"));
    List<ProposalCommentsVo> proposalCommentsVos;
    GenericResponse genericResponse = restService.getProposalComments(apiParams, httpRequest);
    if (genericResponse instanceof GenericResponseWrapper) {
      genericResponseWrapper = (GenericResponseWrapper) genericResponse;
      if (null != genericResponseWrapper.getProposalNotesRetrival()) {
        proposalCommentsVos = filterProposalComments(genericResponseWrapper.getProposalNotesRetrival(), apiParams); //completed
        genericResponseWrapper.setProposalCommentsVos(proposalCommentsVos);
      }
    }
    return new AsyncResult<>(genericResponseWrapper);
  }

  private List<ProposalCommentsVo> filterProposalComments(List<ProposalViewDto> proposalNotesRetrival, final ApiParams apiParams) {
	  return( proposalNotesRetrival.stream()
        .filter(p -> p.getProposalYear().equals(String.valueOf(apiParams.getProposalYr())))
        .filter(p -> p.getProposalVersion().equals(String.valueOf(apiParams.getProposalYrVer())))
        .map(p -> {
          ProposalCommentsVo commentsVo = new ProposalCommentsVo();
          commentsVo.setProposalComments(p.getProposalComments());
          commentsVo.setCommentedBy(p.getCommentedBy());
          commentsVo.setProposalVersion(p.getProposalVersion());
          commentsVo.setProposalYear(p.getProposalYear());
          commentsVo.setDateSubmitted(p.getDateSubmitted());
          return commentsVo;
        })
        .collect(Collectors.toList()));
     
  }
}