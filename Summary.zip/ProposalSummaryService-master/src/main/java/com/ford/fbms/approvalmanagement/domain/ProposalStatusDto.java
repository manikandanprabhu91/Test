package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD11_PROPOSAL_STATUS database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = ProposalStatusDto.TABLE_NAME)
// @NamedQuery(name="ProposalStatusDto.findAll", query="SELECT m FROM
// ProposalStatusDto m")
public class ProposalStatusDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD11_PROPOSAL_STATUS";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD11_PROPOSAL_STATUS_C")
	private String proposalStatusCode;

	@Column(name = "FBMD11_PROPOSAL_STATUS_X")
	private String proposalStatusDescription;
	/*
	 * //bi-directional many-to-one association to Mfbma01Proposal
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<Proposal> proposals;
	 */

	// bi-directional many-to-one association to Mfbma01Proposal
	/*
	 * @OneToMany(mappedBy="proposalStatus2") private List<Proposal> proposals2;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma02ProposalNote
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<ProposalNote>
	 * proposalNotes;
	 * 
	 * //bi-directional many-to-one association to Mfbma09ApprovalProcess
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<ApprovalProcess>
	 * approvalProcesses;
	 * 
	 * //bi-directional many-to-one association to Mfbma13CustomerAcceptance
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<CustomerAcceptance>
	 * customerAcceptances;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma14MultiYearNote
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<MultiYearNote>
	 * multiYearNotes;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma31BuyrDtl
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<BuyerDetails> buyrDtls;
	 * 
	 * //bi-directional many-to-one association to Mfbma40BuyrCustAcptnce
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<BuyrCustAcptnce>
	 * buyrCustAcptnces;
	 * 
	 * //bi-directional many-to-one association to Mfbma41BuyerNote
	 * 
	 * @OneToMany(mappedBy="proposalStatus") private List<BuyerNote> buyerNotes;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD11_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD11_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD11_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD11_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD11_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD11_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
