package com.ford.fbms.approvalmanagement.repository;


import com.ford.fbms.approvalmanagement.domain.TierIncentive;
import com.ford.fbms.approvalmanagement.domain.TierIncentivePK;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * 
 *
 * @author VVM on 5/3/2021.
 */
@Repository
public interface TierIncentiveRepository extends JpaRepository<TierIncentive, TierIncentivePK> {
  @Query(value="select TI from TierIncentive TI where TI.tierIncentivePK.proposalVehlnInctv.pviSaKey=:pviSaKey")
  Optional<List<TierIncentive>> findAllByProposalKey(@Param("pviSaKey")long pviSaKey);
}
