package com.ford.fbms.approvalmanagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;

/**
 * This class to manage the data between model and table.
 *
 * @author PSENTHIK.
 */
@Repository
public interface MultiYearTermRepository extends JpaRepository<MultiYearTermDto, Long> {
	
	
	@Query(value = "select * from {h-schema}MFBMA15_MULTI_YEAR_TERMS A15, {h-schema}MFBMA01_PROPOSAL A01 "+
	"where A01.FBMA01_PROPOSAL_K= A15.FBMA01_PROPOSAL_K  "+
	 "and A01.FBME01_FIN_MASTER_K	 =:finMasterKey   " +
	"and A01.FBMD12_PROPOSAL_YEAR_C in (:proposalYear)   " ,nativeQuery = true)
	
	List<MultiYearTermDto>	queryListMultiYearTermByFinMasterProposalYear(@Param("finMasterKey") long finMasterKey,
			@Param("proposalYear") long proposalYear);
}