package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME04_VEHICLE_LINE database table.
 *
 */
@Entity
@Getter
@Setter
@Table(name = VehicleLineDto.TABLE_NAME)
// @NamedQuery(name="VehicleLine.findAll", query="SELECT m FROM VehicleLine m")
public class VehicleLineDto implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBME04_VEHICLE_LINE";

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBME04_VEHLN_K")
  private long vehlnSaKey;

  @Column(name = "FBME04_VEHLN_C")
  private String vehlnCode;

  @Column(name = "FBME04_VEHLN_CRTKIND_F")
  private String vehlnCrtkindFlag;

  @Column(name = "FBME04_VEHLN_MDLYR_C")
  private Long modelYear;

  @Column(name = "FBME04_VEHLN_X")
  private String vehlnDesc;

  // bi-directional many-to-one association to Mfbmd10Division
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "FBMD10_DIVISION_C")
  private DivisionDto division;

  // bi-directional many-to-one association to Mfbmd42Country
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "FBMD42_COUNTRY_ISO3_C")
  private CountryDto country;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME04_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBME04_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBME04_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME04_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBME04_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBME04_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}
