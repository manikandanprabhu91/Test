// ******************************************************************************
// * Copyright (c) 2010 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   NewBodyStyleViewBO.java  $
// * $Revision:   1.0  $
// * $Author : PSIRISIN $
// * $Date : $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

/** 
 * NewBodyStyleViewBO
 */

@Entity
@Table(name = "FBMS_NEW_BODYSTYLE_VIEW")
@Getter
@Setter

public class NewBodyStyleViewDtO implements Serializable {
    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;

    // Logging Setup
    public static final String TABLE_NAME = "FBMS_NEW_BODYSTYLE_VIEW";
    
    @JsonIgnore
    @EmbeddedId
    private NewBodyStylePKDto newBodyStylePK;
    

}
