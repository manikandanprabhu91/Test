package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ApprovalProcessRepository extends JpaRepository<ApprovalProcessDto, Long> {
  @Query(value="SELECT * "
      + "FROM {h-schema}MFBMA09_APPROVAL_PROCESS "
      + "where  FBMA01_PROPOSAL_K= :proposalKey",nativeQuery = true)
  List<ApprovalProcessDto> findApprovalProcessById(@Param("proposalKey") final Long proposalKey );

  /**
   * Query to delete the existing data.
   *
   */
  
  
  @Query(value="select * from"
  +"("                                
  +"select ap.* from {h-schema}MFBMA09_APPROVAL_PROCESS ap    " 
  +"where FBMA01_PROPOSAL_K=:proposalKey   " 
  +"and FBMD03_SUBMITTED_BY_CDSID_C=:submittedByfordPerson   "
  +"union  " 
  +"select ap.* from {h-schema}MFBMA09_APPROVAL_PROCESS ap,{h-schema}MFBMD14_REPORT_LEVEL rl   " 
  +"where FBMA01_PROPOSAL_K=:proposalKey   " 
  +"and ap.FBMD14_RPTLVL_K=rl.FBMD14_RPTLVL_K   " 
  +"and rl.FBMD14_RPTLVL_C=:reportLevelCode  "
  +") STG "
  +"order by FBMD11_PROPOSAL_STATUS_C,FBMA09_SUBMITTED_S,FBMA09_CREATE_S",nativeQuery =true)
  List<ApprovalProcessDto> findApprovalProcessByProposalFordPerson(@Param("proposalKey") final Long proposalKey,@Param("submittedByfordPerson") final String submittedByfordPerson,@Param("reportLevelCode") final int reportLevelCode);
  
  @Query(value="SELECT * "
	      + "FROM {h-schema}MFBMA09_APPROVAL_PROCESS "
	      + "where  FBMA01_PROPOSAL_K= :proposalKey   "
	      +"and FBMD03_SUBMITTED_BY_CDSID_C=:submittedByfordPerson",nativeQuery = true)
	  ApprovalProcessDto findApprovalProcessByProposalandSubmittedByFordPerson(@Param("proposalKey") final Long proposalKey,@Param("submittedByfordPerson") final String submittedByfordPerson );
  
  @Query(value="select ap.*\r\n"
  		+ "from {h-schema}MFBMA09_APPROVAL_PROCESS ap,\r\n"
  		+ "{h-schema}MFBMD14_REPORT_LEVEL rpt\r\n"
  		+ "where ap.FBMD14_RPTLVL_K = rpt.FBMD14_RPTLVL_K\r\n"
  		+ "and FBMA01_PROPOSAL_K=:proposalKey\r\n"
  		+ "AND (CASE WHEN rpt.FBMD14_RPTLVL_C=6 THEN 12\r\n"
  		+ "		 WHEN rpt.FBMD14_RPTLVL_C=7 THEN 14\r\n"
  		+ "	ELSE rpt.FBMD14_RPTLVL_C END)<  \r\n"
  		+ "	(CASE WHEN :code =6 THEN 12\r\n"
  		+ "	      WHEN :code =7 THEN 14\r\n"
  		+ "		  ELSE :code END)\r\n"
  		+ "ORDER BY (CASE WHEN rpt.FBMD14_RPTLVL_C =6 THEN 12\r\n"
  		+ "			   WHEN rpt.FBMD14_RPTLVL_C=7 THEN 14\r\n"
  		+ "			   ELSE rpt.FBMD14_RPTLVL_C END)DESC",nativeQuery = true)

  List<ApprovalProcessDto> findListHigherApprovalProcessByProposalReportLevelCode(@Param("proposalKey") final Long proposalKey,@Param("code") final int code);
  
  @Query(value="select * FROM {h-schema}MFBMA09_APPROVAL_PROCESS  A09, {h-schema}MFBMD14_REPORT_LEVEL D14 WHERE FBMA01_PROPOSAL_K=:proposalKey AND   "
  		+ "A09.FBMD14_RPTLVL_K = D14.FBMD14_RPTLVL_K  AND  "
		+ "D14.FBMD14_RPTLVL_C = :reportLevelCode ",nativeQuery = true)
  ApprovalProcessDto findApprovalProcessByProposalReportLevelCode(@Param("proposalKey") final Long proposalKey,@Param("reportLevelCode") final int reportLevelCode );

  @Transactional
  void deleteByProposalKey(ProposalDto proposal);
		  
  @Query(value="select * from {h-schema}MFBMA09_APPROVAL_PROCESS a09, {h-schema}MFBMA01_PROPOSAL a01   \r\n"
  		+ "where a09.FBMA01_PROPOSAL_K = a01.FBMA01_PROPOSAL_K   \r\n"
  		+ "and a09.FBMD11_PROPOSAL_STATUS_C = 'SUB'    \r\n"
  		+ "and a09.FBMA01_PROPOSAL_K = :proposalKey ",nativeQuery = true)
	  ApprovalProcessDto findApprovalProcessByProposalStatus(@Param("proposalKey") final Long proposalKey );

  
  Optional<ApprovalProcessDto> findByProposalKeyAndProposalStatus(ProposalDto proposalKey,ProposalStatusDto proposalStatus);

	@Query(value = "select ap.* " +
			"from {h-schema}MFBMA09_APPROVAL_PROCESS ap, {h-schema}MFBMD14_REPORT_LEVEL rpt " +
			"where ap.FBMD14_RPTLVL_K = rpt.FBMD14_RPTLVL_K " +
			"and FBMA01_PROPOSAL_K=?1 " +
			"AND (CASE WHEN rpt.FBMD14_RPTLVL_C=7 THEN 14 " +
			"WHEN rpt.FBMD14_RPTLVL_C=9 THEN 13 " +
			"WHEN rpt.FBMD14_RPTLVL_C=8 THEN 12 " +
			"ELSE rpt.FBMD14_RPTLVL_C END)< " +
			"(CASE WHEN ?2 =7 THEN 14 " +
			"WHEN ?2 =9 THEN 13 " +
			"WHEN ?2 =8 THEN 12 " +
			"ELSE ?2 END) " +
			"ORDER BY (CASE WHEN rpt.FBMD14_RPTLVL_C =7 THEN 14 " +
			"WHEN rpt.FBMD14_RPTLVL_C=9 THEN 13 " +
			"WHEN rpt.FBMD14_RPTLVL_C=8 THEN 12 " +
			"ELSE rpt.FBMD14_RPTLVL_C END)DESC", nativeQuery = true)
	List<ApprovalProcessDto> findHigherApprovalMexProcessByProposalReportLevel(Long proposalKey,
	int reportLevel);


	@Query(value = "SELECT FBMA09_AP_K ,FBMA01_PROPOSAL_K ,FBMD11_PROPOSAL_STATUS_C " +
			",FBMD03_SUBMITTED_BY_CDSID_C ,FBMA09_SUBMITTED_S ,FBMD03_SUBMITTED_TO_CDSID_C " +
			",FBMD14_RPTLVL_K ,FBMD03_APPROVED_BY_CDSID_C ,FBMA09_APPROVED_S " +
			",FBMA09_CREATE_S ,FBMA09_CREATE_PROCESS_C ,FBMA09_CREATE_USER_C " +
			",FBMA09_LAST_UPDT_S ,FBMA09_LAST_UPDT_PROCESS_C " +
			",FBMA09_LAST_UPDT_USER_C FROM ( " +
			"SELECT ROW_NUMBER()Over( ORDER BY A09.FBMA09_LAST_UPDT_S DESC) AS ROWNUM, " +
			"A09.* FROM {h-schema}MFBMA09_APPROVAL_PROCESS A09 WHERE  " +
			"A09. FBMA01_PROPOSAL_K = ?1 AND A09.FBMD11_PROPOSAL_STATUS_C = ?2 ) STG WHERE ROWNUM = 1",
			nativeQuery = true)
	ApprovalProcessDto findLatestApprovalProcessByProposalStatus(long proposalSaKey, String status);

	@Query(value="select * FROM {h-schema}MFBMA09_APPROVAL_PROCESS " +
			"WHERE FBMA01_PROPOSAL_K= ?1 AND   " +
			"FBMD14_RPTLVL_K = ?2 ",nativeQuery = true)
  ApprovalProcessDto findApprovalProcessByProposalReportLevel(long proposalSaKey, int fnmRlCode);
}
