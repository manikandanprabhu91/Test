package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD09_SEGMENT database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = SegmentDto.TABLE_NAME)
// @NamedQuery(name="Segment.findAll", query="SELECT m FROM Segment m")
public class SegmentDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD09_SEGMENT";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD09_SEG_C")
	private String segmentCode;

	@Column(name = "FBMD09_SEG_X")
	private String segmentDescription;

	// bi-directional many-to-one association to Mfbmd99SegmentGroupType
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD99_SEGMENT_GROUP_TYPE_C")
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
	private SegmentGroupTypeDto segmentGroupType;
	/*
	 * //bi-directional many-to-one association to Mfbmd15MetricsObjective
	 * 
	 * @OneToMany(mappedBy="mfbmd09Segment") private List<MetricsObjective>
	 * metricsObjectives;
	 * 
	 * //bi-directional many-to-one association to Mfbme01FinMaster
	 * 
	 * @OneToMany(mappedBy="mfbmd09Segment") private List<FinMaster> finMasters;
	 * 
	 * //bi-directional many-to-one association to Mfbme06TargetBand
	 * 
	 * @OneToMany(mappedBy="mfbmd09Segment") private List<TargetBand> targetBands;
	 * 
	 * //bi-directional many-to-one association to Mfbme08AcctSale
	 * 
	 * @OneToMany(mappedBy="mfbmd09Segment") private List<AcctSale> acctSales;
	 * 
	 * //bi-directional many-to-one association to Mfbme18BodyFinancial
	 * 
	 * @OneToMany(mappedBy="mfbmd09Segment") private List<BodyFinancial>
	 * bodyFinancials;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD09_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD09_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD09_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD09_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD09_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD09_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
