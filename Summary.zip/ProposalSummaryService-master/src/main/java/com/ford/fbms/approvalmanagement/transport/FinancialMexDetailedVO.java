// ********************************************
// *
// * $Workfile:   FinancialMexDetailedVO.java  $
// * $Revision:   1.0  $
// * $Author:   PSIRISIN  $
// * $Date:   Oct 08 2010 30:30:36  $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.transport;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * This Value Object holds Mexico Detailed Volume/Financial Data
 */
@Getter
@Setter
public class FinancialMexDetailedVO  {
    // Logging Setup
    private static final String CLASS_NAME =
            FinancialDetailedVO.class.getName();

    /**
     * Model Year
     */
    private int modelYear;
    /**
     * Vehicle Line
     */
    private String vehicleLine;

    /**
     * Body Style
     */
    private String bodyStyle;

    /**
     * Present vehicle volume
     */
    private double volume;
    
    private String fleetType;
    
    private String marketingProgram;
    
    private double proposedFleetInventiveVM;
    private double fleetTargetVM;
    private double cccTargetVM;
    private double bwFleetTargetVM;
    private double bwCCCTargetVM;
    private long floorPlan;
    private double fleetPrice;
    private double proposedCM;
    private double fleetTargetCM;
    private double cccTargetCM;
    private double bwFleetTargetCM;
    private float bwFleetTargetPrectCM;
    private double bwCCCTargetCM;
    private float bwCCCTargetPrectCM;
    private double dealerMargin;
    private float dealerMarginPrect;

    /**
     * Present variable marketing (per unit)
     */
    private double presentVM;

    
    /**
     * recType used for identifying the record Type i.e. VehicleLine, LineTotal,
     * GrandTotal
     */
    private rowType recType;
    private String vehDesc;
    private Long vehicleLineKey;
    private String vehicleLineCode;

    /**
     * Allowed Record Types
     */
    public enum rowType {
        /**
         * Comment for <code>VehicleLine</code>
         */
        VehicleLine,
        /**
         * Comment for <code>LineTotal</code>
         */
        LineTotal,
        /**
         * Comment for <code>GrandTotal</code>
         */
        GrandTotal
    }

private List<FinancialMexDetailedBaseVO> financialDetailedBaseVOList;
    
    public FinancialMexDetailedVO() {
        this.financialDetailedBaseVOList = new ArrayList<>();
    }
		

    
}
