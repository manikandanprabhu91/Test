package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to load fleet person details.
 *
 * @author SJAGATJO on 3/25/2021.
 */
@Service
@Slf4j
public class PerUnitIncentiveManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  private RestService restService;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).country(apiParams.getCountryCd())
        .message("Inside PerUnitIncentiveManager"));
    GenericResponse genericResponse = restService.getPerUnitIncentiveDetails(apiParams, httpRequest);
    if (genericResponse instanceof GenericResponseWrapper) {
      genericResponseWrapper = (GenericResponseWrapper) genericResponse;
      genericResponseWrapper.setProposalVo(genericResponseWrapper.getProposalVo());
    } else {
      genericResponseWrapper.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}