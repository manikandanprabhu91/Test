package com.ford.fbms.approvalmanagement.repository.impl;

import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;

/**
 * @author VSHANMU8
 *
 */
@Repository
public class ProcedureRepositoryImpl implements ProcedureRepository {
	@PersistenceContext
	private EntityManager manager;

	@Autowired
	ConfigProperties configProperties;

	@Override
	public void updateFinancialData(Long proposalKey) {
		callOSP(configProperties.getSchema() + ".FBMS_MAINTAIN_FINANCIAL_APV", proposalKey);
	}

	private void callOSP(String ospName, Long proposalKey) {
		StoredProcedureQuery query = manager.createStoredProcedureQuery(ospName);
		query.registerStoredProcedureParameter(ApprovalConstants.PROC_PROPOSAL_KEY, Long.class, ParameterMode.IN);
		query.registerStoredProcedureParameter(ApprovalConstants.PROC_OK, String.class, ParameterMode.OUT);
		query.registerStoredProcedureParameter(ApprovalConstants.PROC_ERROR_MSG, String.class, ParameterMode.OUT);
		query.setParameter(ApprovalConstants.PROC_PROPOSAL_KEY, proposalKey);
		query.execute();
	}

}
