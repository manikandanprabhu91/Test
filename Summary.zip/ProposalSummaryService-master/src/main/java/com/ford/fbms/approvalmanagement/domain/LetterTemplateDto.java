package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD85_LETTER_TEMPLATE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = LetterTemplateDto.TABLE_NAME)
public class LetterTemplateDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD85_LETTER_TEMPLATE";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD85_LETTER_TEMPLATE_K")
	private Long letterTemplateKey;

	@Column(name = "FBMD85_LETTER_DOCUMENT_CHG_X")
	private String changeDetails;

	@JsonIgnore
	@Lob
	@Column(name = "FBMD85_LETTER_DOCUMENT_L")
	private byte[] letterDocument;

	@Column(name = "FBMD85_LETTER_TEMPLATE_IN_S")
	private Timestamp inDate;

	@JsonIgnore
	@Lob
	@Column(name = "FBMD85_LETTER_TEMPLATE_L")
	private byte[] letterTemplate;

	@Column(name = "FBMD85_LETTER_TEMPLATE_OUT_S")
	private Timestamp outDate;


	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD87_TEMPLATE_K")
	private TemplateNamesDto templateNamesDto;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD85_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD85_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMD85_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD85_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD85_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMD85_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}