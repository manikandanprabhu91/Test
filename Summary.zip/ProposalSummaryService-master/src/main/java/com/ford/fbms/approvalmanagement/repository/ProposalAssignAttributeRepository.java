package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;


public interface ProposalAssignAttributeRepository extends JpaRepository<ProposalAssignAttributeDto, Long> {

	@Query("SELECT proposalAA FROM ProposalAssignAttributeDto proposalAA WHERE"
			+ " proposalAA.accountAssignment.assignmentType.assignmentTypeCode = 'P'"
			+ " AND proposalAA.accountAssignment.finMaster.finMasterKey = :finMasterSaKey"
			+ " AND proposalAA.accountAssignment.fordPerson.cdsid = :cdsid")
	public ProposalAssignAttributeDto findProposalAssignAttributeByFinMasterCdsid(
			@Param("finMasterSaKey") long finMasterSaKey, @Param("cdsid") String cdsid);
	
	@Query("SELECT proposalAA FROM ProposalAssignAttributeDto proposalAA WHERE"
			+ " proposalAA.accountAssignment.assignmentType.assignmentTypeCode = 'P'"
			+ " AND proposalAA.active = 'A'"
			+ " AND proposalAA.accountAssignment.finMaster.finMasterKey = :finMasterSaKey")
	public Optional<List<ProposalAssignAttributeDto>> findProposalAssignAttributeByFinMasterActive(
			@Param("finMasterSaKey") long finMasterSaKey);
}
