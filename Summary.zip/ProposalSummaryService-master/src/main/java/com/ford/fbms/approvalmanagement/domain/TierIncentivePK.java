package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the MFBMA11_TIER_INCENTIVE database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class TierIncentivePK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	// bi-directional many-to-one association to Mfbma04ProposalVehlnInctv
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMA04_PVI_K")
	private ProposalVehicleLineIncentiveDto proposalVehlnInctv;

	@Column(name = "FBMA11_TIER_LEVEL_R")
	private long tierLevel;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((proposalVehlnInctv == null) ? 0 : proposalVehlnInctv.hashCode());
		result = prime * result + (int) (tierLevel ^ (tierLevel >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true; }
		if (obj == null) {
			return false; }
		if (!(obj instanceof TierIncentivePK)){
			return false; }
		TierIncentivePK other = (TierIncentivePK) obj;
		if (proposalVehlnInctv == null) {
			if (other.proposalVehlnInctv != null){
				return false; }
		} else if (!proposalVehlnInctv.equals(other.proposalVehlnInctv)){
			return false; }
		if (tierLevel != other.tierLevel){
			return false; }
		return true;
	}

}