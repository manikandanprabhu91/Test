package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ActualSalesFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.ExpandedBodyFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitExpandedViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitIncentiveNewViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.ActualSalesFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitExpandedViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to get proposal details.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class ActualsManager implements Validator {

	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected TargetBandRepository targetBandRepo;
	@Autowired
	protected PerUnitOptViewRepository perUnitOptViewRepository;
	@Autowired
	protected ApprovalManagementValidator approvalManagementValidator;
	@Autowired
	protected ApprovalManagementCreateValidator approvalManagementCreateValidator;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepository;
	@Autowired
	protected MultiYearBonusRepository multiYearBonusRepository;
	@Autowired
	protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
	@Autowired
	protected TierVolumeRepository tierVolumeRepository;
	@Autowired
	protected ProposalSummaryViewRepository proposalSummaryViewRepository;
	@Autowired
	protected AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Autowired
	protected BodyFinancialRepository bodyFinancialRepo;
	@Autowired
	protected NewBodyStyleRepository newBodyStyleRepo;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected PerUnitExpandedViewRepository perUnitExpandedViewRepo;
	@Autowired
	protected ExpandedBodyFinancialViewRepository expandedBodyFinancialViewRepo;
	@Autowired
	protected ActualSalesFinancialViewRepository actualSalesFinancialViewRepo;
	@Autowired
	protected PerUnitIncentiveNewViewRepository perUnitIncNewViewRepo;

	@Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest, final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside ProposalManager"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
			genericResponseWrapper.setProposalDataDto(proposal);
			int proposalTier = (int) proposalManager.getProposalTier(proposal,
					proposalManager.isPresentVMbasedOnActualVolume(apiParams));
			int tTier = proposalManager.getTotalTier(proposal);
			List<ProposalFinancialVO> puFinanceList = buildProposalFinancialsActual(proposal, apiParams);
			List<FinancialDetailedVO> financialDetailedVOList = this.populateDetailedFinancialsForActual(proposal,
					puFinanceList,proposalTier,tTier);
			genericResponseWrapper.setFinancialDetailedVOList(financialDetailedVOList);

		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	public List<ProposalFinancialVO> buildProposalFinancialsActual(ProposalDto p, final ApiParams apiparams) {
		List<ProposalFinancialVO> fList;
		// Initialize unique List for present Vehicle Lines
		LinkedHashMap<String, String> presentVehicleLine = new LinkedHashMap<>();

		fList = getActualProposalFinancialList(p, true, apiparams);
		fList = getActualProposalFinanciaWithSaleslList(fList, p, true, false, false);
		if (fList != null && !(fList.isEmpty())) {
			for (ProposalFinancialVO o : fList) {
				presentVehicleLine.put(o.getModelYear() + " " + o.getVehicleLineDescription(),
						o.getModelYear() + " " + o.getVehicleLineDescription());
			}
		} else {
			fList = new ArrayList<>();
		}

		// add the prior version Proposal
		ProposalDto pv = proposalManager.identifyPriorProposals(p);
		if(pv!=null) {
		List<ProposalFinancialVO> pvList = getActualProposalFinancialList(pv, false, apiparams);
		pvList = getActualProposalFinanciaWithSaleslList(pvList, pv, false, true, false);
		proposalManager.addPriorVerProposal(fList, pvList);
		}

		Optional<ProposalDto> py_1 = proposalManager.identifyPriorPYProposals(p);
		if(py_1.isPresent()) {
		List<ProposalFinancialVO> pyList = getPriorYearActualProposalFinancialList(py_1.get(),apiparams);
		proposalManager.addPriorYearProposal(fList, pyList, py_1.get(), p);
		}

		Iterator pIter = presentVehicleLine.values().iterator();
		for (Iterator iter = pIter; iter.hasNext();) {
			String vlKey = (String) iter.next();
			for (ProposalFinancialVO o : fList) {
				if (vlKey.equalsIgnoreCase(o.getModelYear() + " " + o.getVehicleLineDescription())) {
					o.setPresentVehicleLine(true);
				}
			}
		}
		
		FbmsUtil.sort(fList, "modelYear");
		FbmsUtil.sort(fList, "vehicleLineDescription");
		return fList;
	}

	@LogAround
	private List<ProposalFinancialVO> getActualProposalFinancialList(ProposalDto proposal, boolean isPresent,
			final ApiParams apiparams) {

		List<ProposalFinancialVO> financialList = new ArrayList<>();
		// Initialize the List
		List<ProposalFinancialVO> targetList = getActualTargetFinancialList(proposal, isPresent, (!isPresent), false);
		// Get the proposal vehicleLine Incentives
		List<PerUnitExpandedViewDto> perUnitExpandedViewList = perUnitExpandedViewRepo
				.findPerUnitExpandedBodystylesByProposal(proposal.getProposalSaKey());
		long agg = proposalManager.getAggregateIncentiv(proposal);
		long manualBonus = proposalManager.getManualBonus(proposal);
		int proposalTier = (int) proposalManager.getProposalTier(proposal,
				proposalManager.isPresentVMbasedOnActualVolume(apiparams));
		int tTier = proposalManager.getTotalTier(proposal);
		if (tTier == 0) {
			tTier = 1; 
			}

		if (perUnitExpandedViewList != null && !(perUnitExpandedViewList.isEmpty())) {
			for (PerUnitExpandedViewDto record : perUnitExpandedViewList) {
				ProposalFinancialVO perUnit;

				long expandedBodyStyleSaKey = String.valueOf(record.getId().getExpandedBodyStyleSaKey()) != null
						? record.getId().getExpandedBodyStyleSaKey()
						: 0L;
				if (isPresent) {
					perUnit = new ProposalFinancialVO(expandedBodyStyleSaKey, 0L, 0L);
				} else {
					perUnit = new ProposalFinancialVO(0L, 0L, expandedBodyStyleSaKey);
				}
				if (null != record.getExpandedBodyStyleCode()) {
					perUnit.setPerUnitDescription(record.getExpandedBodyStyleCode());
				}
				perUnit.setModelYear(record.getModelYear());
				perUnit.setVehicleLineDescription(record.getVehicleLineDesc());
				perUnit.setVehLineCode(record.getVehicleLineCode());
				
				long cPA = 0L;
				if (proposalTier == 1) {
					cPA = String.valueOf(record.getTier1Incentive()) != null ? record.getTier1Incentive() : 0L; 
					}
				if (proposalTier == 2) {
					cPA = String.valueOf(record.getTier2Incentive()) != null ? record.getTier2Incentive() : 0L; 
					}
				if (proposalTier == 3) {
					cPA = String.valueOf(record.getTier3Incentive()) != null ? record.getTier3Incentive() : 0L; 
					}
				if (proposalTier == 4) {
					cPA = String.valueOf(record.getTier4Incentive()) != null ? record.getTier4Incentive() : 0L; 
					}
				if (proposalTier == 5) {
					cPA = String.valueOf(record.getTier5Incentive()) != null ? record.getTier5Incentive() : 0L; 
					}
				if (proposalTier == 6) {
					cPA = String.valueOf(record.getTier6Incentive()) != null ? record.getTier6Incentive() : 0L; 
					}

				long espValue = String.valueOf(record.geteSPIncentive()) != null ? record.geteSPIncentive() : 0L;
				long mlbValue = String.valueOf(record.getmLBIncentive()) != null ? record.getmLBIncentive() : 0L;
				double optionIncValue = String.valueOf(record.getOptionIncentive()) != null
						? record.getOptionIncentive()
						: 0L;
				
				if (isPresent) {
					perUnit.setProposalTier(proposalTier);
					perUnit.setAGG((agg + manualBonus) * (-1));
					perUnit.setCPA(cPA * (-1));
					perUnit.setESP(Math.round(((double)espValue / tTier)) * (-1));
					perUnit.setOPT((Math.round((mlbValue + optionIncValue) / tTier)) * (-1));
					perUnit.setVM((agg + manualBonus + cPA + Math.round((espValue + mlbValue + optionIncValue) / tTier))
							* (-1));
					perUnit.setVolume(record.getMlv());
					perUnit.setTier1(
							record.getTier1Incentive() != null ? record.getTier1Incentive() : 0L * (-1));
					perUnit.setTier2(
							record.getTier2Incentive() != null ? record.getTier2Incentive() : 0L * (-1));
					perUnit.setTier3(
							record.getTier3Incentive() != null ? record.getTier3Incentive() : 0L * (-1));
					perUnit.setTier4(
							record.getTier4Incentive() != null ? record.getTier4Incentive() : 0L * (-1));
					perUnit.setTier5(
							record.getTier5Incentive() != null ? record.getTier5Incentive() : 0L * (-1));
					perUnit.setTier6(
							record.getTier6Incentive() != null ? record.getTier6Incentive() : 0L * (-1));
				} else {
					perUnit.setPriorVerProposalTier(proposalTier);
					perUnit.setPriorVerAGG((agg + manualBonus) * (-1));
					perUnit.setPriorVerCPA(cPA * (-1));
					perUnit.setPriorVerESP(Math.round(((double)espValue / tTier)) * (-1));
					perUnit.setPriorVerOPT((Math.round((mlbValue + optionIncValue) / tTier)) * (-1));
					perUnit.setPriorVerVM(
							(agg + manualBonus + cPA + Math.round((espValue + mlbValue + optionIncValue) / tTier))
									* (-1));
					perUnit.setPriorVerVolume(record.getMlv());
					perUnit.setPriorVerTier1(
							record.getTier1Incentive() != null ? record.getTier1Incentive() : 0L * (-1));
					perUnit.setPriorVerTier2(
							record.getTier2Incentive() != null ? record.getTier2Incentive() : 0L * (-1));
					perUnit.setPriorVerTier3(
							record.getTier3Incentive() != null ? record.getTier3Incentive() : 0L * (-1));
					perUnit.setPriorVerTier4(
							record.getTier4Incentive() != null ? record.getTier4Incentive() : 0L * (-1));
					perUnit.setPriorVerTier5(
							record.getTier5Incentive() != null ? record.getTier5Incentive() : 0L * (-1));
					perUnit.setPriorVerTier6(
							record.getTier6Incentive() != null ? record.getTier6Incentive() : 0L * (-1));
				}
				ProposalFinancialVO tPerUnit;
				if (isPresent) {
					tPerUnit = new ProposalFinancialVO(expandedBodyStyleSaKey, 0L, 0L);
				} else {
					tPerUnit = new ProposalFinancialVO(0L, 0L, expandedBodyStyleSaKey);
				}
				if (targetList.contains(tPerUnit)) {
					tPerUnit = targetList.get(targetList.indexOf(tPerUnit));
					if (isPresent) {
						perUnit.setYoyTargetVM(tPerUnit.getYoyTargetVM());
						perUnit.setTier1Target(tPerUnit.getTier1Target());
						perUnit.setTier2Target(tPerUnit.getTier2Target());
						perUnit.setTier3Target(tPerUnit.getTier3Target());
						perUnit.setTier4Target(tPerUnit.getTier4Target());
						perUnit.setTier5Target(tPerUnit.getTier5Target());
						perUnit.setNewTargetVM(tPerUnit.getNewTargetVM());
						perUnit.setEstCC(tPerUnit.getEstCC());
						perUnit.setEstRevenue(tPerUnit.getEstRevenue());
						perUnit.setTargetEstCC(tPerUnit.getTargetEstCC());
						perUnit.setTargetEstRevenue(tPerUnit.getTargetEstRevenue());

					} else {
						perUnit.setPriorVerEstCC(tPerUnit.getPriorVerEstCC());
						perUnit.setPriorVerEstRevenue(tPerUnit.getPriorVerEstRevenue());
					}
				}
				financialList.add(perUnit);
			}

		}
		return financialList;
	}

	@LogAround
	private List<ProposalFinancialVO> getActualTargetFinancialList(ProposalDto p, boolean fillPresent,
			boolean fillPriorVer, boolean fillPriorYear) {

		int tBand = 0;
		// Initialize the List
		List<ProposalFinancialVO> targetFinancialList = new ArrayList<>();
		List<ExpandedBodyFinancialViewDto> expandedBodyFinancialViewList = expandedBodyFinancialViewRepo
				.findExpandedBodyFinancialbyProposal(p.getProposalSaKey());
		if (fillPresent) {
			tBand = proposalManager.getTargetBandLevel(p.getProposalSaKey());
		}

		if (expandedBodyFinancialViewList != null && !(expandedBodyFinancialViewList.isEmpty())) {
			for (final ExpandedBodyFinancialViewDto record : expandedBodyFinancialViewList) {
				if (record != null) {
					long expandedBodyStyle = (record.getId().getExpandedBodyStyle()) != null
							? record.getId().getExpandedBodyStyle()
							: 0L;
					long perUnitKey = fillPresent ? expandedBodyStyle : 0L;
					long pyPerUnitKey = fillPriorYear ? expandedBodyStyle : 0L;
					long pvPerUnitKey = fillPriorVer ? expandedBodyStyle : 0L;

					ProposalFinancialVO targetPerUnit = new ProposalFinancialVO(perUnitKey, pyPerUnitKey, pvPerUnitKey);
					if (fillPresent) {
						targetPerUnit.setYoyTargetVM(record.getYearOverYearTarget());
						targetPerUnit.setTier1Target(record.getTier1Target() * (-1));
						targetPerUnit.setTier2Target(record.getTier2Target() * (-1));
						targetPerUnit.setTier3Target(record.getTier3Target() * (-1));
						targetPerUnit.setTier4Target(record.getTier4Target() * (-1));
						targetPerUnit.setTier5Target(record.getTier5Target() * (-1));

						if (tBand == 1) {
							targetPerUnit.setNewTargetVM(targetPerUnit.getTier1Target()); 
							}
						if (tBand == 2) {
							targetPerUnit.setNewTargetVM(targetPerUnit.getTier2Target()); 
							}
						if (tBand == 3) {
							targetPerUnit.setNewTargetVM(targetPerUnit.getTier3Target()); 
							}
						if (tBand == 4) {
							targetPerUnit.setNewTargetVM(targetPerUnit.getTier4Target()); 
							}
						if (tBand == 5) {
							targetPerUnit.setNewTargetVM(targetPerUnit.getTier5Target()); 
							}

						targetPerUnit.setEstCC(record.getContributionCost() * (-1));
						targetPerUnit.setEstRevenue(record.getRevenue());
						targetPerUnit.setTargetEstCC(record.getContributionCost() * (-1));
						targetPerUnit.setTargetEstRevenue(record.getRevenue());
					}
					if (fillPriorVer) {
						targetPerUnit.setPriorVerEstCC(record.getContributionCost() * (-1));
						targetPerUnit.setPriorVerEstRevenue(record.getRevenue());
					}
					if (fillPriorYear) {
						targetPerUnit.setPriorYearEstCC(record.getContributionCost() * (-1));
						targetPerUnit.setPriorYearEstRevenue(record.getRevenue());
					}
					targetFinancialList.add(targetPerUnit);
				}
			}
		}

		return targetFinancialList;
	}

	@LogAround
	private List<ProposalFinancialVO> getActualProposalFinanciaWithSaleslList(List<ProposalFinancialVO> pList,
			ProposalDto p, boolean fillPresent, boolean fillPriorVer, boolean fillPriorYear) {

		if (pList == null || pList.isEmpty()) {
			return new ArrayList<ProposalFinancialVO>(); 
			}
		List<ProposalFinancialVO> sList = getActualSalesFinancialList(p, fillPresent, fillPriorVer, fillPriorYear);
		if (sList == null || sList.isEmpty()) {
			return new ArrayList<ProposalFinancialVO>();  
			}

		List<ProposalFinancialVO> resultList = new ArrayList<>();

		for (ProposalFinancialVO sPerUnit : sList) {
			ProposalFinancialVO pPerUnit;
			if ((sPerUnit != null)&&(pList.contains(sPerUnit))) {
					pPerUnit = pList.get(pList.indexOf(sPerUnit));
					ProposalFinancialVO copy = createPerUnit(pPerUnit, sPerUnit);
					if (copy != null) {
						resultList.add(copy); 
						}
			}
		}
		return resultList;
	}

	@LogAround
	private ProposalFinancialVO createPerUnit(ProposalFinancialVO proposalPerUnit, ProposalFinancialVO salesPerUnit) {
		if (proposalPerUnit == null || salesPerUnit == null) {
			return null; 
			}
		ProposalFinancialVO copy;
		copy = (ProposalFinancialVO) proposalPerUnit.clone();
		if (copy != null) { 			
			copy.setVolume(salesPerUnit.getVolume());
			copy.setActCC(salesPerUnit.getActCC());
			copy.setActRevenue(salesPerUnit.getActRevenue());
			copy.setPriorVerVolume(salesPerUnit.getPriorVerVolume());
			copy.setPriorVerActCC(salesPerUnit.getPriorVerActCC());
			copy.setPriorVerActRevenue(salesPerUnit.getPriorVerActRevenue());
			copy.setPriorYearVolume(salesPerUnit.getPriorYearVolume());
			copy.setPriorYearActCC(salesPerUnit.getPriorYearActCC());
			copy.setPriorYearActRevenue(salesPerUnit.getPriorYearActRevenue());
		}
		return copy;
	}

	@LogAround
	private List<ProposalFinancialVO> getActualSalesFinancialList(ProposalDto p, boolean fillPresent,
			boolean fillPriorVer, boolean fillPriorYear) {

		List<ProposalFinancialVO> salesFinancialList = new ArrayList<>();
		List<ActualSalesFinancialViewDto> actualSalesFinancialViewList = getActualSalesFinancialViewList(p);

		if (actualSalesFinancialViewList != null && !(actualSalesFinancialViewList.isEmpty())) {
			for (ActualSalesFinancialViewDto o : actualSalesFinancialViewList) {
				if (o != null) {
					long perUnitKey = fillPresent ? o.getId().getBodyStyle() : 0L;
					long pyPerUnitKey = fillPriorYear ? o.getId().getBodyStyle() : 0L;
					long pvPerUnitKey = fillPriorVer ? o.getId().getBodyStyle() : 0L;
					ProposalFinancialVO sPerUnit = new ProposalFinancialVO(perUnitKey, pyPerUnitKey, pvPerUnitKey);
					if (fillPresent) {
						sPerUnit.setActCC(o.getContributionCost() * (-1));
						sPerUnit.setActRevenue(o.getRevenue());
						sPerUnit.setVolume(o.getSoldToDate());
					}
					if (fillPriorVer) {
						sPerUnit.setPriorVerActCC(o.getContributionCost() * (-1));
						sPerUnit.setPriorVerActRevenue(o.getRevenue());
						sPerUnit.setPriorVerVolume(o.getSoldToDate());
					}
					if (fillPriorYear) {
						sPerUnit.setPriorYearActCC(o.getContributionCost() * (-1));
						sPerUnit.setPriorYearActRevenue(o.getRevenue());
						sPerUnit.setPriorYearVolume(o.getSoldToDate());
					}
					salesFinancialList.add(sPerUnit);
				}
			}
		}
		return salesFinancialList;
	}

	@LogAround
	private List<ActualSalesFinancialViewDto> getActualSalesFinancialViewList(ProposalDto p) {
		return actualSalesFinancialViewRepo
				.getSalesFinancialViewListByProposal(p.getProposalSaKey());
	}

	/**
	 * Builds the ProposalFinancials based EstVsEst, ActVsAct, ActVsFct
	 */
	@LogAround
	public List<FinancialDetailedVO> populateDetailedFinancialsForActual(ProposalDto proposal,
		List<ProposalFinancialVO> puFinanceList,long proposalTier,long totalTier) {
		List<FinancialDetailedVO> financialDetaiedList = new ArrayList<>();
		proposalManager.identifyPriorProposals(proposal);
		FinancialDetailedVO v = new FinancialDetailedVO();
		FinancialDetailedVO t = new FinancialDetailedVO();
		String lastDescription = " ";
		String lastVehLineCode = " ";
		Long lastModelYear = 0L;
		boolean isPresentVL = false;
		int PY = proposal.getPyDefinition().getProposalYearCode();
		if (puFinanceList != null && !(puFinanceList.isEmpty())) {
			for (int i = 0; i < puFinanceList.size(); i++) {
				ProposalFinancialVO f = puFinanceList.get(i);
				
				updateActualFinancial(t, f, PY, false, false, true);
				FinancialDetailedVO fdVO = getActualFinancial(FinancialDetailedVO.rowType.VehicleLine, f, PY, false, false,
						true);
				financialDetaiedList.add(fdVO);
				if (i == 0) {
					lastDescription = f.getVehicleLineDescription();
					lastModelYear = (long) f.getModelYear();
					lastVehLineCode = f.getVehLineCode();
					isPresentVL = f.isPresentVehicleLine();
				}
				if (f.getVehicleLineDescription().equals(lastDescription) && f.getModelYear() == lastModelYear) {
					updateActualFinancial(v, f, PY, false, false, true);
				} else {
					FinancialDetailedVO fdVO1 = getActualAverageFinancial(v);
					fdVO1.setModelYear(lastModelYear);
					fdVO1.setVehicleLine(lastDescription);
					fdVO1.setBodyStyle(" ");
					fdVO1.setVehicleLineCode(lastVehLineCode);
					fdVO1.setRecType(FinancialDetailedVO.rowType.LineTotal);
					fdVO1.setPresentProposal(isPresentVL);
					fdVO1.setVehDesc(lastDescription+"!"+lastModelYear);
					financialDetaiedList.add(fdVO1);
					// start next VL
					v = new FinancialDetailedVO();
					updateActualFinancial(v, f, PY, false, false, true);
				}
				if (i == puFinanceList.size() - 1) {
					// last record...so insert the VL record
					FinancialDetailedVO fdVO2 = getActualAverageFinancial(v);
					fdVO2.setVehicleLine(f.getVehicleLineDescription());
					fdVO2.setModelYear((long) f.getModelYear());
					fdVO2.setBodyStyle(" ");
					fdVO2.setVehicleLineCode(f.getVehLineCode());
					fdVO2.setRecType(FinancialDetailedVO.rowType.LineTotal);
					fdVO2.setPresentProposal(f.isPresentVehicleLine());
					fdVO2.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear());
					financialDetaiedList.add(fdVO2);
				}

				lastDescription = f.getVehicleLineDescription();
				lastModelYear = (long) f.getModelYear();
				lastVehLineCode = f.getVehLineCode();
				isPresentVL = f.isPresentVehicleLine();
			}
		}
		t.setIncludedInPriorProposal(proposalManager.showIncludedInPriorSection(financialDetaiedList));
	    t.setProposalTier(proposalTier);
	    long prevVerPropTier = proposalManager.showPriorVerProposalTier(financialDetaiedList);
	    t.setPriorVerProposalTier(prevVerPropTier);
	    long priorYearproposalTier = proposalManager.showPriorYearProposalTier(financialDetaiedList);
	    t.setPriorYearProposalTier(priorYearproposalTier);
	    boolean proposalTierChangedFlag=proposalManager.proposalTierChanged(proposalTier,prevVerPropTier,priorYearproposalTier);
	    t.setProposalTierChanged(proposalTierChangedFlag);
	    t.setTotalTier(totalTier);
	    long prevVerTotalTier = proposalManager.showPriorVerTotalTier(financialDetaiedList);
	    t.setPriorVerTotalTier(prevVerTotalTier);
	    long priorYearTotalTier = proposalManager.showPriorYearTotalTier(financialDetaiedList);
	    t.setPriorYearTotalTier(priorYearTotalTier);
	    boolean totalTierFlag=proposalManager.totalTierChanged(proposalTier,prevVerPropTier,priorYearproposalTier);
	    t.setTotalTierChanged(totalTierFlag);
		t = getActualAverageFinancial(t);
		if (t.getPresentVol() > 0) {
			t.setPresentProposal(true);
		}
		
		FbmsUtil.sort(financialDetaiedList, "recType");
	    FbmsUtil.sort(financialDetaiedList, "vehDesc");
	    
	    t.setRecType(FinancialDetailedVO.rowType.GrandTotal);
		financialDetaiedList.add(t);
		
		return financialDetaiedList;
	}

	@LogAround
	private void updateActualFinancial(FinancialDetailedVO o, ProposalFinancialVO f, int PY, boolean isEstVsEst,
			boolean isActVsFct, boolean isActVsAct) {
		if (o == null || f == null) {
			return; 
			}
		o.setPY(PY);
		if (f.getPerUnit() > 0L) {
			o.setPresentKey(f.getPerUnit()); 
			}
		if (f.getPriorVerPerUnit() > 0L) {
			o.setPrevVerKey(f.getPriorVerPerUnit()); 
			}
		if (f.getPriorYearPerUnit() > 0L) {
			o.setPriorKey(f.getPriorYearPerUnit()); 
			}

		o.setModelYear((long) f.getModelYear());
		o.setVehicleLine(f.getVehicleLineDescription());
		o.setBodyStyle(f.getPerUnitDescription());
		o.setPresentProposal(f.isPresentVehicleLine());

		double pV = f.getVolume();
		double pvV = f.getPriorVerVolume();
		double pyV = f.getPriorYearVolume();
		if (f.getPerUnit() != 0L) {
			pV = pV + 0.000001;
		}
		if (f.getPriorVerPerUnit() != 0L) {
			pvV = pvV + 0.000001;
		}
		if (f.getPriorYearPerUnit() != 0L) {
			pyV = pyV + 0.000001;
		}
		// set volume
		o.setPresentVol(o.getPresentVol() + pV);
		o.setPriorVol(o.getPriorVol() + pyV);
		o.setPrevVerVol(o.getPrevVerVol() + pvV);
		// set VM
		if(o.getRecType()!=null) {
		o.setPresentVM(f.getPerUnit()>0L?(o.getPresentVM() + (pV * f.getVM())):0L);
		}else {o.setPresentVM(o.getPresentVM() + (pV * f.getVM()));
		}
		if(o.getRecType()!=null) {
		o.setPriorPYVM(f.getPriorYearPerUnit()>0L?(o.getPriorPYVM() + (pyV * f.getPriorYearVM())):0L);
		}else {o.setPriorPYVM(o.getPriorPYVM() + (pyV * f.getPriorYearVM()));
		}
		o.setPrevVerVM(o.getPrevVerVM() + (pvV * f.getPriorVerVM()));
		o.setTargetVM(o.getTargetVM() + (pV * f.getTargetVM()));
		o.setPresentAGG(o.getPresentAGG() + (pV * f.getAGG()));
		o.setPresentESP(o.getPresentESP() + (pV * f.getESP()));
		o.setPresentOPT(o.getPresentOPT() + (pV * f.getOPT()));
		o.setPresentCPA(o.getPresentCPA() + (pV * f.getCPA()));
		updateActVsAct(o, f, true);

	}

	@LogAround
	private FinancialDetailedVO getActualFinancial(FinancialDetailedVO.rowType rowType, ProposalFinancialVO f, int PY,
			boolean isEstVsEst, boolean isActVsFct, boolean isActVsAct) {
		FinancialDetailedVO o = new FinancialDetailedVO();
		o.setPY(PY);
		o.setPresentKey(f.getPerUnit());
		o.setPrevVerKey(f.getPriorVerPerUnit());
		o.setPriorKey(f.getPriorYearPerUnit());
		o.setModelYear((long) f.getModelYear());
		o.setVehicleLine(f.getVehicleLineDescription());
		o.setBodyStyle(f.getPerUnitDescription());
		o.setVehicleLineCode(f.getVehLineCode());
		o.setRecType(rowType);
		o.setPresentProposal(f.isPresentVehicleLine());
		o.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear()+"!"+f.getPerUnitDescription());
		o.setPresentVol(f.getVolume());
		o.setPriorVol(f.getPriorYearVolume());
		o.setPrevVerVol(f.getPriorVerVolume());
		o.setProposalTier(f.getProposalTier());
	    o.setPriorVerProposalTier(f.getPriorVerProposalTier());
	    o.setPriorYearProposalTier(f.getPriorYearProposalTier());
		o.setTotalTier(f.getTotalTier());
	    o.setPriorVerTotalTier(f.getPriorVerTotalTier());
	    o.setPriorYearTotalTier(f.getPriorYearTotalTier());
		if(null!=o.getRecType()) {
		o.setPresentVM(f.getPerUnit() > 0L ? (f.getVM()):0L);
		} else {o.setPresentVM(f.getVM());
		}
		if(null!=o.getRecType()) {
		o.setPriorPYVM(f.getPriorYearPerUnit()> 0L ?(f.getPriorYearVM()):0L);
		}else {o.setPriorPYVM(f.getPriorYearVM());
		}
		o.setPrevVerVM(f.getPriorVerVM());
		o.setYoyTarget(f.getYoyTargetVM());
		o.setTargetVM(f.getTargetVM());
		// set Matrix Target VM from Maintain finance data screen
		o.setMatrixTargetVM(f.getNewTargetVM());
		// setIncentives
		o.setPresentAGG(f.getAGG());
		o.setPresentESP(f.getESP());
		o.setPresentOPT(f.getOPT());
		o.setPresentCPA(f.getCPA());
		updateActVsAct(o, f, false);
		// now calculate B(W)
		proposalManager.updateBW(o);
		return o;
	}

	private FinancialDetailedVO getActualAverageFinancial(FinancialDetailedVO o) {
		if (o.getPresentVol() > 0) {
			o.setPresentVM(o.getPresentVM() / o.getPresentVol());
			o.setPresentCC((o.getPresentCC() / o.getPresentVol()));
			o.setPresentRevenue((o.getPresentRevenue() / o.getPresentVol()));
			o.setPresentNR((o.getPresentNR() / o.getPresentVol()));
			o.setPresentCM((o.getPresentCM() / o.getPresentVol()));
			o.setTargetVM((o.getTargetVM() / o.getPresentVol()));
			o.setTargetCC((o.getTargetCC() / o.getPresentVol()));
			o.setTargetRevenue((o.getTargetRevenue() / o.getPresentVol()));
			o.setTargetNR((o.getTargetNR() / o.getPresentVol()));
			o.setTargetCM((o.getTargetCM() / o.getPresentVol()));
			// setIncentives
			o.setPresentAGG((o.getPresentAGG() / o.getPresentVol()));
			o.setPresentESP((o.getPresentESP() / o.getPresentVol()));
			o.setPresentOPT((o.getPresentOPT() / o.getPresentVol()));
			o.setPresentCPA((o.getPresentCPA() / o.getPresentVol()));
		}
		if (o.getPriorVol() > 0) {
			o.setPriorPYVM(o.getPriorPYVM() / o.getPriorVol());
			o.setPriorPYCC((o.getPriorPYCC() / o.getPriorVol()));
			o.setPriorPYRevenue((o.getPriorPYRevenue() / o.getPriorVol()));
			o.setPriorPYNR((o.getPriorPYNR() / o.getPriorVol()));
			o.setPriorPYCM((o.getPriorPYCM() / o.getPriorVol()));
		}
		if (o.getPrevVerVol() > 0) {
			o.setPrevVerVM(o.getPrevVerVM() / o.getPrevVerVol());
			o.setPrevVerCC(o.getPrevVerCC() / o.getPrevVerVol());
			o.setPrevVerRevenue(o.getPrevVerRevenue() / o.getPrevVerVol());
			o.setPrevVerNR(o.getPrevVerNR() / o.getPrevVerVol());
			o.setPrevVerCM(o.getPrevVerCM() / o.getPrevVerVol());
		}
		proposalManager.updateBW(o);
		return o;
	}

	@LogAround
	private void updateActVsAct(FinancialDetailedVO o, ProposalFinancialVO f, boolean isUpdate) {
		if (o == null || f == null) {
			return; 
			}
		double pV = 1;
		double pvV = 1;
		double pyV = 1;
		if (isUpdate) {
			pV = f.getVolume();
			pvV = f.getPriorVerVolume();
			pyV = f.getPriorYearVolume();
		}
		if (f.getPerUnit() != 0L) {
			pV = pV + 0.000001;
		}
		if (f.getPriorVerPerUnit() != 0L) {
			pvV = pvV + 0.000001;
		}
		if (f.getPriorYearPerUnit() != 0L) {
			pyV = pyV + 0.000001;
		}
		// set CC,Rev,NR and CM for present (Actual)
		if(o.getRecType()!=null) {
		o.setPresentCC(f.getPerUnit() > 0L ? (o.getPresentCC() + (pV * f.getActCC())):0L);
		} else {o.setPresentCC(o.getPresentCC() + (pV * f.getActCC()));
		}
		if(o.getRecType()!=null) {
		o.setPresentRevenue(f.getPerUnit() > 0L ? (o.getPresentRevenue() + (pV * f.getActRevenue())):0L);
		} else {o.setPresentRevenue(o.getPresentRevenue() + (pV * f.getActRevenue()));
		}
		if(o.getRecType()!=null) {
		o.setPresentNR(f.getPerUnit() > 0L ? (o.getPresentNR() + (pV *  (f.getActRevenue()+f.getVM()))):0L);
		} else {o.setPresentNR(o.getPresentNR() + (pV *  (f.getActRevenue()+f.getVM())));
		}
		if(o.getRecType()!=null) {
		o.setPresentCM(f.getPerUnit() > 0L ? (o.getPresentCM() + (pV *  (f.getActCC()+f.getActRevenue()+f.getVM()))):0L) ;
		} else {o.setPresentCM(o.getPresentCM() + (pV *  (f.getActCC()+f.getActRevenue()+f.getVM())));
		}
		// set CC,Rev,NR and CM for prior PY (Actual)
		if(o.getRecType()!=null) {
		o.setPriorPYCC(f.getPriorYearPerUnit() > 0L ? (o.getPriorPYCC() + (pyV * f.getPriorYearActCC())):0L);
		} else {o.setPriorPYCC(o.getPriorPYCC() + (pyV * f.getPriorYearActCC()));
		}
		if(o.getRecType()!=null) {
		o.setPriorPYRevenue(f.getPriorYearPerUnit() > 0L ? (o.getPriorPYRevenue() + (pyV * f.getPriorYearActRevenue())):0L);
		} else {o.setPriorPYRevenue(o.getPriorPYRevenue() + (pyV * f.getPriorYearActRevenue()));
		}
		if(o.getRecType()!=null) {
		o.setPriorPYNR(f.getPriorYearPerUnit() > 0L ? (o.getPriorPYNR() + (pyV *  (f.getPriorYearActRevenue() + f.getPriorYearVM()))):0L) ;
		} else {o.setPriorPYNR(o.getPriorPYNR() + (pyV *  (f.getPriorYearActRevenue() + f.getPriorYearVM())));
		}
		if(o.getRecType()!=null) {
		o.setPriorPYCM(f.getPriorYearPerUnit() > 0L ? (o.getPriorPYCM() + (pyV *  (f.getPriorYearActRevenue() + f.getPriorYearActCC() + f.getPriorYearVM()))):0L) ;
		} else {o.setPriorPYCM(o.getPriorPYCM() + (pyV *  (f.getPriorYearActRevenue() + f.getPriorYearActCC() + f.getPriorYearVM())));
		}
		// set CC,Rev,NR and CM for prior Ver(Forecast)
		if(o.getRecType()!=null) {
		o.setPrevVerCC(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerCC() + (pvV * f.getPriorVerActCC())):0L);
		} else {o.setPrevVerCC(o.getPrevVerCC() + (pvV * f.getPriorVerActCC()));
		}
		if(o.getRecType()!=null) {
		o.setPrevVerRevenue(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerRevenue() + (pvV * f.getPriorVerActRevenue())):0L);
		} else {o.setPrevVerRevenue(o.getPrevVerRevenue() + (pvV * f.getPriorVerActRevenue()));
		}
		if(o.getRecType()!=null) {
		o.setPrevVerNR(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerNR() + (pvV *  (f.getPriorVerActRevenue() + f.getPriorVerVM()))):0L);
		} else {o.setPrevVerNR(o.getPrevVerNR() + (pvV *  (f.getPriorVerActRevenue() + f.getPriorVerVM())));
		}
		if(o.getRecType()!=null) {
		o.setPrevVerCM(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerCM() + (pvV *  (f.getPriorVerActRevenue() + f.getPriorVerActCC() + f.getPriorVerVM()))):0L);
		} else {o.setPrevVerCM(o.getPrevVerCM() + (pvV *  (f.getPriorVerActRevenue() + f.getPriorVerActCC() + f.getPriorVerVM())));
		}
		o.setTargetCC(o.getTargetCC() + (pV * f.getTargetActCC()));
		o.setTargetRevenue(o.getTargetRevenue() + (pV * f.getTargetActRevenue()));
		o.setTargetNR(o.getTargetNR() + (pV * f.getTargetActNR()));
		o.setTargetCM(o.getTargetCM() + (pV * f.getTargetActCM()));
	}


	@LogAround
	protected List<ProposalFinancialVO> getPriorYearActualProposalFinancialList(ProposalDto pyProposal,ApiParams apiParams) {

		List<ProposalFinancialVO> sList = getActualSalesFinancialList(pyProposal, false, false, true);
		if (sList == null || sList.isEmpty() ) {
			return new ArrayList<ProposalFinancialVO>(); 
			}

		List<ProposalFinancialVO> resultList = new ArrayList<>();
		List<ProposalFinancialVO> targetList = getActualTargetFinancialList(pyProposal, false, false, true);

		List<PerUnitIncentiveNewViewDto> perUnitIncentiveNewViewList = perUnitIncNewViewRepo
				.findPerUnitNewViewByProposal(pyProposal.getProposalSaKey());

		long pyAgg = proposalManager.getAggregateIncentiv(pyProposal);
		long pyManualBonus = proposalManager.getManualBonus(pyProposal);
		int pyProposalTier = proposalManager.getProposalTier(pyProposal,proposalManager.isPriorYearVMbasedOnActualVolume(apiParams));

		int tTier = proposalManager.getTotalTier(pyProposal);
		if (tTier == 0) {
			tTier = 1; 
			}

		if (perUnitIncentiveNewViewList != null && !(perUnitIncentiveNewViewList.isEmpty())) {
			for (PerUnitIncentiveNewViewDto perUnitIncentiveNewViewDto : perUnitIncentiveNewViewList) {
				ProposalFinancialVO pyPerUnit;
				
				long newExpandedBodyStyle = perUnitIncentiveNewViewDto.getNewBodyStyleKey2()!=0L?perUnitIncentiveNewViewDto.getNewBodyStyleKey2():0L;
				long expandedBodyStyleSaKey = perUnitIncentiveNewViewDto.getId().getBodyStyleKey2();

				if (newExpandedBodyStyle != 0L) {
					pyPerUnit = new ProposalFinancialVO(newExpandedBodyStyle, newExpandedBodyStyle, 0L);
				} else {
					expandedBodyStyleSaKey = perUnitIncentiveNewViewDto.getId().getBodyStyleKey2();
					pyPerUnit = new ProposalFinancialVO(0L, expandedBodyStyleSaKey, 0L);
				}
				if (null != perUnitIncentiveNewViewDto.getBodyStyleCode_2()) {
					pyPerUnit.setPerUnitDescription(perUnitIncentiveNewViewDto.getBodyStyleCode_2());
				}
				pyPerUnit.setModelYear(perUnitIncentiveNewViewDto.getModelYear() + 1);
				pyPerUnit.setVehicleLineDescription(perUnitIncentiveNewViewDto.getVehicleLineDesc());
				pyPerUnit.setVehLineCode(perUnitIncentiveNewViewDto.getVehicleLineCode());
				pyPerUnit.setPriorYearProposalTier(pyProposalTier);
				long pyCPA = 0L;
				if (pyProposalTier == 1) {
					pyCPA = perUnitIncentiveNewViewDto.getTier1Incentive() != null
							? perUnitIncentiveNewViewDto.getTier1Incentive()
							: 0L; 
					}
				if (pyProposalTier == 2) {
					pyCPA = perUnitIncentiveNewViewDto.getTier2Incentive() != null
							? perUnitIncentiveNewViewDto.getTier2Incentive()
							: 0L; 
					}
				if (pyProposalTier == 3) {
					pyCPA = perUnitIncentiveNewViewDto.getTier3Incentive() != null
							? perUnitIncentiveNewViewDto.getTier3Incentive()
							: 0L; 
					}
				if (pyProposalTier == 4) {
					pyCPA = perUnitIncentiveNewViewDto.getTier4Incentive() != null
							? perUnitIncentiveNewViewDto.getTier4Incentive()
							: 0L; 
					}
				if (pyProposalTier == 5) {
					pyCPA = perUnitIncentiveNewViewDto.getTier5Incentive() != null
							? perUnitIncentiveNewViewDto.getTier5Incentive()
							: 0L; 
					}
				if (pyProposalTier == 6) {
					pyCPA = perUnitIncentiveNewViewDto.getTier6Incentive() != null
							? perUnitIncentiveNewViewDto.getTier6Incentive()
							: 0L; 
					}

				pyPerUnit.setPriorYearAGG((pyAgg + pyManualBonus) * (-1));
				pyPerUnit.setPriorYearCPA(pyCPA * (-1));
				pyPerUnit.setESP(perUnitIncentiveNewViewDto.geteSPIncentive());
				pyPerUnit.setmLBIncentive(perUnitIncentiveNewViewDto.getmLBIncentive());
				pyPerUnit.setOPT(perUnitIncentiveNewViewDto.getOptionIncentive());
				pyPerUnit.setPriorYearESP(Math.round(((double)perUnitIncentiveNewViewDto.geteSPIncentive() / (double)tTier)) * (-1));
				pyPerUnit.setPriorYearOPT((Math.round(
						(perUnitIncentiveNewViewDto.getmLBIncentive() + perUnitIncentiveNewViewDto.getOptionIncentive())
								/(double) tTier))
						* (-1));
				pyPerUnit.setPriorYearVM((pyAgg + pyManualBonus + pyCPA
						+ Math.round((perUnitIncentiveNewViewDto.geteSPIncentive()
								+ perUnitIncentiveNewViewDto.getmLBIncentive()
								+ perUnitIncentiveNewViewDto.getOptionIncentive()) / (double)tTier))
						* (-1));
				
				pyPerUnit.setPriorYearVolume(perUnitIncentiveNewViewDto.getMlvForecast());
				pyPerUnit.setPriorYearTier1((perUnitIncentiveNewViewDto.getTier1Incentive() != null
						? perUnitIncentiveNewViewDto.getTier1Incentive()
						: 0L) * (-1));
				pyPerUnit.setPriorYearTier2((perUnitIncentiveNewViewDto.getTier2Incentive() != null
						? perUnitIncentiveNewViewDto.getTier2Incentive()
						: 0L) * (-1));
				pyPerUnit.setPriorYearTier3((perUnitIncentiveNewViewDto.getTier3Incentive() != null
						? perUnitIncentiveNewViewDto.getTier3Incentive()
						: 0L) * (-1));
				pyPerUnit.setPriorYearTier4((perUnitIncentiveNewViewDto.getTier4Incentive() != null
						? perUnitIncentiveNewViewDto.getTier4Incentive()
						: 0L) * (-1));
				pyPerUnit.setPriorYearTier5((perUnitIncentiveNewViewDto.getTier5Incentive() != null
						? perUnitIncentiveNewViewDto.getTier5Incentive()
						: 0L) * (-1));
				pyPerUnit.setPriorYearTier6((perUnitIncentiveNewViewDto.getTier6Incentive() != null
						? perUnitIncentiveNewViewDto.getTier6Incentive()
						: 0L) * (-1));

				ProposalFinancialVO tPerUnit = new ProposalFinancialVO(0L, expandedBodyStyleSaKey, 0L);

				if (targetList != null && targetList.contains(tPerUnit)) {
					tPerUnit = targetList.get(targetList.indexOf(tPerUnit));
					pyPerUnit.setPriorYearEstCC(tPerUnit.getPriorYearEstCC());
					pyPerUnit.setPriorYearEstRevenue(tPerUnit.getPriorYearEstRevenue());
				}

				ProposalFinancialVO sPerUnit = new ProposalFinancialVO(0L, expandedBodyStyleSaKey, 0L);
				if (sList != null && sList.contains(sPerUnit)) {
					sPerUnit = sList.get(sList.indexOf(sPerUnit));

					ProposalFinancialVO copy = createPerUnit(pyPerUnit, sPerUnit);
					if (copy != null) {
						resultList.add(copy); 
						}
				}
			}
		}
		return resultList;
	}
}