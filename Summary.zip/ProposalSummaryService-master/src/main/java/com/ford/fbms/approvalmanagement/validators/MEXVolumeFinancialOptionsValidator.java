package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

/**
 * @author MKALLATA
 * @created 16/06/2021 - 11:10 PM
 */
@Service
@Slf4j
public class MEXVolumeFinancialOptionsValidator implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest,
                                                             final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).message("Inside VoulmeFinancialsOptionsValidator"));

    Map<String, String> sortedMap = new LinkedHashMap<String, String>();
    sortedMap.put(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE, ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_DESC);
    genericResponseWrapper.setDropDownMap(sortedMap);
    return new AsyncResult<>(genericResponseWrapper);
  }
}
