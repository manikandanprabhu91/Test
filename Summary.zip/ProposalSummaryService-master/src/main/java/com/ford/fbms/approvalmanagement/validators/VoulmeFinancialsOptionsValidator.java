package com.ford.fbms.approvalmanagement.validators;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.AccountSalesSummaryDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VoulmeFinancialsOptionsValidator implements Validator {

  @Autowired
  private  ResponseBuilder responseBuilder;
  @Autowired
  protected ProposalRepository proposalRepository;
  @Autowired
  protected AccountSalesSummaryRepository accountSalesSummaryRepository;
  @Autowired
  protected FordPersonRepository fordPersonRepository;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest,
                                                             final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).message("Inside VoulmeFinancialsOptionsValidator"));
    Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDtoOptional.isEmpty()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
      genericResponseWrapper.setGenericResponse(
          responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    } else {
      genericResponseWrapper.setProposalDataDto(proposalDtoOptional.get());
      Map<String, String> dropDownMap = getVolumeFinanicialOptions(apiParams, genericResponseWrapper);
      genericResponseWrapper.setDropDownMap(dropDownMap);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }

  public Map<String, String> getVolumeFinanicialOptions(final ApiParams apiParams, GenericResponseWrapper genericResponseWrapper) {
    boolean isPresentActualsAvailable = false;
    boolean isPriorYearActualsAvailable = false;
    Map<String, String> sortedMap = new LinkedHashMap<String, String>();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("getVolumeFinanicialOptions")
	        .message("Inside getVolumeFinanicialOptions"));
    if (getSales(apiParams.getProposalKey()) > 0) {
      isPresentActualsAvailable = true;
    }
    if(null!=getPriorYearProposal(genericResponseWrapper)) {
    ProposalDto priorYProposalDto = getPriorYearProposal(genericResponseWrapper);
    	if(getSales(priorYProposalDto.getProposalSaKey()) > 0) {
      isPriorYearActualsAvailable = true;
    	}
    }
    if (isPresentActualsAvailable) {    
      sortedMap.put(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE,
          ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_DESC);
      sortedMap.put(ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE,
          ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_DESC);
      sortedMap.put(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE, ApprovalConstants.PRIOR_ACT_CURR_ACT_DESC);
    }
    if (isPriorYearActualsAvailable) {  
      sortedMap.put(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE,
          ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_DESC);
      sortedMap.put(ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE,
          ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_DESC);
    }
    sortedMap.put(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE,
        ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_DESC);
    Optional<FordPersonDto> fordPerson = fordPersonRepository.findById(apiParams.getUserId());
    if(fordPerson.isPresent()) {
        String userRole =fordPerson.get().getReportLevel().getTitleCode();
    	if (userRole != null) {
    		if (isPriorYearActualsAvailable
    				&& (ApprovalConstants.NAM.equalsIgnoreCase(userRole) 
    						|| ApprovalConstants.RSM.equalsIgnoreCase(userRole) || ApprovalConstants.CTL.equalsIgnoreCase(userRole))) {
    			sortedMap.put("defaultValue", ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE);
    		} else {
    			sortedMap.put("defaultValue", ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
    		}
    	}
    }
    
    return sortedMap;
  }

  /**
   * @param proposalSaKey
   */
  private int getSales(Long proposalSaKey) {
    List<AccountSalesSummaryDto> accountSummary = this.accountSalesSummaryRepository
        .queryCalculatedOtdStdSummaryByProposal(proposalSaKey);
    int presentSales = 0;
    if (accountSummary != null && !accountSummary.isEmpty()) {
      presentSales = accountSummary.stream().findFirst().get().getVehiclesSoldMonthToDate();
    }
    return presentSales;
  }

  private ProposalDto getPriorYearProposal(GenericResponseWrapper genericResponseWrapper) {
    ProposalDto currentProposal = genericResponseWrapper.getProposalDataDto();
    ProposalDto pyProp = null;
    if (null != currentProposal.getPyDefinition() && null != currentProposal.getFinMasterKey()) {
      Optional<ProposalDto> pyProposalDto =proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster
              ((long)currentProposal.getPyDefinition().getProposalYearCode() - 1,
                  currentProposal.getFinMasterKey().getFinMasterKey());
      
      pyProp =  (pyProposalDto.isPresent()?pyProposalDto.get():null);
    }
    return pyProp;
  }
}
