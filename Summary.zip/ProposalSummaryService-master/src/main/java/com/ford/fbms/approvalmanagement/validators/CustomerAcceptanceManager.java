package com.ford.fbms.approvalmanagement.validators;

import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.CustomerAcceptanceS3Repository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

/**
 * A class to load fleet person details.
 *
 * @author SJAGATJO on 3/25/2021.
 */
@Service
@Slf4j
public class CustomerAcceptanceManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  private CustomerAcceptanceS3Repository customerAcceptanceS3Repository;
  @Autowired
  private ProposalRepository proposalRepository;

  @Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                           final Object approvalRequest, final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).country(apiParams.getCountryCd())
        .message("Inside CustomerAcceptanceManager"));
    Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
    System.out.println("proposalDTO.get().getSourceProposalCode() "+proposalDTO.get().getSourceProposalCode());
    final CustomerAcceptanceS3Dto customerAcceptanceS3DtoOptional =
        customerAcceptanceS3Repository.findCurrentProposal(proposalDTO.get().getSourceProposalCode());
    if(customerAcceptanceS3DtoOptional!=null) {
      genericResponseWrapper.setCustomerAcceptanceS3Dto(customerAcceptanceS3DtoOptional);
    } 
    return new AsyncResult<>(genericResponseWrapper);
  }
}