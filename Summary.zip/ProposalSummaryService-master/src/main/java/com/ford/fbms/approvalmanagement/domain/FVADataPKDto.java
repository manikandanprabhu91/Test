package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class FVADataPKDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME01_FIN_MASTER_K")
    private FinMasterDto finMaster;
    
    @ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME03_BDYSTL_K")
    private BodyStyleDto bodyStyle;
    
    @Column(name="FBME05_FVA_REC_EFF_Y")
	private Date effectiveDate;
    
    @ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD12_PROPOSAL_YEAR_C")
    private PyDefinitionDto proposalYearDefinition;



}
