package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;

/**
 * To encapsulate all common and qeury/path parameters from the session.
 *
 * @author MKALLATA on 3/02/2021.
 */
@Setter
@Getter
public class SubsidiaryResponse extends GenericResponse{
    List<ProposalSubsidiariesVO> subsidiariesVOList;
    List<ProposalSubsidiaryDto> subsidiaryDtoList;
}
