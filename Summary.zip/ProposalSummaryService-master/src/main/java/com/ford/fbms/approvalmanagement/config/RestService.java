package com.ford.fbms.approvalmanagement.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * A class for rest-service configuration properties.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Getter
@Setter
@ConfigurationProperties(prefix = "config-properties.rest-service")
public class RestService {

  private int connectTimeout;
  private int readTimeout;
  private int backoffLow;
  private int backoffHigh;
  private int backoffMaxInterval;
  private int backoffAttemptNum;
  private String subsidiariesServiceInternal;
  private String subsidiariesServiceExternal;
  private String notesServiceUrlInternal;
  private String notesServiceUrlExternal;
  private String proposalServiceInternal;
  private String proposalServiceExternal;
  private String vehicleServiceInternal;
  private String vehicleServiceExternal;
  private String proposalTermsInternal;
  private String proposalTermsExternal;
  private String proposalNotesInternal;
  private String proposalNotesExternal;
  private String multiYearPriceProtInternal;
  private String multiYearPriceProtExternal;
}
