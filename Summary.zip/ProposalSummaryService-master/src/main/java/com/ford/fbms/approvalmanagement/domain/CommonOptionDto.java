package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMD70_COMMON_OPTION database table.
 * 
 */
@Entity
@Table(name = CommonOptionDto.TABLE_NAME)
// @NamedQuery(name="CommonOption.findAll", query="SELECT m FROM CommonOption
// m")

public class CommonOptionDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD70_COMMON_OPTION";

	@Id
	@Column(name = "FBMD70_COMMON_OPTION_C")
	private String commonOptionCode;

	@Column(name = "FBMD07_FORD_REGION_C")
	private String fordRegionCode;

	@Column(name = "FBMD70_COMMON_OPTION_X")
	private String commonOptionDescription;

	@Column(name = "FBMD70_COMMON_OPTION_STATUS_F")
	private String commonOptionStatusFlag;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD70_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD70_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD70_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD70_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD70_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD70_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
