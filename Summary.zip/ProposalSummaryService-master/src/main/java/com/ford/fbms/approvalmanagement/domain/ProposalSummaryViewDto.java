package com.ford.fbms.approvalmanagement.domain;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for FBMS_PROP_SUMM_VIEW model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Entity
@Table(name = "FBMS_PROP_SUMM_VIEW")

public class ProposalSummaryViewDto extends GenericResponse implements Serializable {

  public long getProposalKey() {
		return proposalKey;
	}

	public void setProposalKey(long proposalKey) {
		this.proposalKey = proposalKey;
	}

	public String getPaymentRouting() {
		return paymentRouting;
	}

	public void setPaymentRouting(String paymentRouting) {
		this.paymentRouting = paymentRouting;
	}

	public long getMlv() {
		return mlv;
	}

	public void setMlv(long mlv) {
		this.mlv = mlv;
	}

	public Long getProposalTier() {
		return (proposalTier==null?0:proposalTier);
	}

	public void setProposalTier(Long proposalTier) {
		this.proposalTier = proposalTier;
	}

	public int getTotalTiers() {
		return totalTiers;
	}

	public void setTotalTiers(int totalTiers) {
		this.totalTiers = totalTiers;
	}

private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "FBMA01_PROPOSAL_K")
  private long proposalKey;

  @Column(name = "PAYMENT_ROUTING")
  private String paymentRouting;

  @Column(name = "FBMA01_PROPOSAL_MLV_Q")
  private long mlv;

  @Column(name = "PROPOSAL_TIER_R")
  private Long proposalTier;

  @Column(name = "TOTAL_TIERS_R")
  private int totalTiers;
}
