//******************************************************************************
//* Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   AssigneeBO.java  $
//* $Revision:   1.2  $
//* $Author:   RANAND8  $
//* $Date:   Feb 24 2010 08:15:38  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


/**
 * This Business Object represents Fin Profile info. <BR>
 * Refer <code>MFBME31_FIN_PROFILE</code>
 */
@Entity
@Table(name = "MFBME31_FIN_PROFILE")
@Getter
@Setter
public class FinProfileDto  implements Serializable {
    /**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;
    // Logging Setup
    private static final String CLASS_NAME = FinProfileDto.class.getName();

    
    
    @Column(name = "FBME31_TAX_ID_C")
    private String taxId;
    
    @Column(name = "FBME31_FLEET_RATING_C")
    private String fleetRating;
    
    @Column(name = "FBME31_PREFERRED_LANGUAGE_N")
    private String preferredLanguage;
    
    @Column(name = "FBME31_GENERIC_FIN_F")
    private boolean genericFin;
    
    @Column(name = "FBME31_AUTO_EST_F")
    private boolean autoEst;
	//private AddressBO address;
    
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FBME01_FIN_MASTER_K")
    private Long finMasterKey;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME50_ACCOUNT_CLASS_C")
    private AccountClassDto specialFinClassification;
    //Added for FOE Ph I

    //private PersistenceIndirection fleetCategory = PersistenceHelper.newIndirection(null);
    @Column(name = "FBME63_DLR_ASSGMT_TYPE_C")
    private String dealerAssignType;
    
    //currTemplateFin stores Current Template Fin Master Key
    
    @Column(name = "FBME31_CURR_TEMPLT_FIN_K")
    private Long currTemplateFin;
    //reqTemplateFin stores Requested Template Fin Master Key
    
    @Column(name = "FBME31_REQ_TEMPLT_FIN_K")
    private Long reqTemplateFin;
    
    @Column(name = "FBMD03_REQSTR_CDSID_C")
    private String requestedCdsid;
    
    @Column(name = "FBMD03_APRVR_CDSID_C")
    private String approverCdsid;
    
    @Column(name = "FBME31_REQUSTD_S")
    private Date requestedDate;
    
    @Column(name = "FBME31_APROVD_S")
    private Date approvedDate;
    
    @Column(name = "FBME31_TMPLT_CMT_X")
    private String templateComments;
    
    @Column(name = "FBME31_CORP_EMAIL_X")
    private String corporateEmail;
    

}

