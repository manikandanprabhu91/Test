package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;

/**
 * This class to manage the data between address and direction  model and table.
 *
 * @author SNITHY11 on 4/22/2021.
 */
@Repository
public interface CustomerAcceptanceS3Repository extends JpaRepository<CustomerAcceptanceS3Dto, Long> {

 /* @Query(value = "SELECT A13.*"
      + " from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13,"
      + " {h-schema}MFBME01_FIN_MASTER E01,{h-schema}MFBMA01_PROPOSAL A01"
      + " where A13.FBMD97_LETTER_APV_STATUS_C = 1 "
      + " AND E01.FBMD42_COUNTRY_ISO3_C = :countryCd "
      + " AND A13.FBMA01_PROPOSAL_K = A01.FBMA01_PROPOSAL_K"
      + " AND A13.FBMD11_PROPOSAL_STATUS_C = A01.FBMD11_PROPOSAL_STATUS_C "
      + " AND E01.FBME01_FIN_MASTER_K = A01.FBME01_FIN_MASTER_K "
      + " AND A13.FBMD88_LETTER_SOURCE_C = 'M'"
      + " AND A13.FBMD11_PROPOSAL_STATUS_C = 'APV'", nativeQuery = true)
  List<CustomerAcceptanceS3Dto> findCustomerAcceptanceByCountryCode(
      @Param("countryCd") String countryCd);*/


  @Query(value = "select A.*"
      + " from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A "
      + " join {h-schema}MFBMA01_PROPOSAL P ON A.FBMA01_PROPOSAL_K = P.FBMA01_PROPOSAL_K "
      + " join {h-schema}MFBME01_FIN_MASTER F ON P.FBME01_FIN_MASTER_K = F.FBME01_FIN_MASTER_K "
      + " join {h-schema}MFBME15_FIN_OP_UNT_MASTER OU ON F.FBME01_FIN_MASTER_K = OU.FBME01_FIN_MASTER_K AND OU.FBME15_OU_C='000' "
      + " join {h-schema}MFBMD97_LETTER_APPROVAL_STATUS S ON A.FBMD97_LETTER_APV_STATUS_C = S.FBMD97_LETTER_APV_STATUS_C "
      + " AND S.FBMD97_LETTER_APV_STATUS_X='In approval' AND F.FBMD42_COUNTRY_ISO3_C = :countryCd", nativeQuery = true)
  List<CustomerAcceptanceS3Dto> findCustomerAcceptanceByCountryCode(
      @Param("countryCd") String countryCd);


  @Query(value = "SELECT A13.*"
      + " from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13,"
      + " {h-schema}MFBME01_FIN_MASTER E01,{h-schema}MFBMA01_PROPOSAL A01"
      + " where A13.FBMD97_LETTER_APV_STATUS_C = 1 "
      + " AND E01.FBMD42_COUNTRY_ISO3_C = 'USA' "
      + " AND A13.FBMA01_PROPOSAL_K = A01.FBMA01_PROPOSAL_K"
      + " AND A13.FBMD11_PROPOSAL_STATUS_C = A01.FBMD11_PROPOSAL_STATUS_C "
      + " AND E01.FBME01_FIN_MASTER_K = A01.FBME01_FIN_MASTER_K "
      + " AND A13.FBMD88_LETTER_SOURCE_C = 'M'"
      + " AND A13.FBMD11_PROPOSAL_STATUS_C = 'APV'"
      + " AND A13.fbmd03_letter_upload_cdsid_c = :cdsid", nativeQuery = true)
  List<CustomerAcceptanceS3Dto> findCustomerAcceptanceByUploadId(@Param("cdsid") String cdsid);

  @Query(value = "SELECT A13.*"
      + " from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13,"
      + " {h-schema}MFBMD03_FORD_PERSON D03,{h-schema}MFBMD14_REPORT_LEVEL D14,"
      + " {h-schema}MFBMD03_FORD_PERSON D03_S,{h-schema}MFBME01_FIN_MASTER E01,"
      + " {h-schema}MFBMA01_PROPOSAL A01,{h-schema}MFBMD09_SEGMENT D09"
      + " where A13.FBMD97_LETTER_APV_STATUS_C = 1 "
      + " AND A13.FBMD03_LETTER_UPLOAD_CDSID_C = D03.FBMD03_CDSID_C"
      + " AND D03_S.FBMD03_CDSID_C = D03.FBMD03_SPRCDSID_X"
      + " AND D03_S.FBMD14_RPTLVL_K = D14.FBMD14_RPTLVL_K "
      + " AND A13.FBMA01_PROPOSAL_K =  A01.FBMA01_PROPOSAL_K "
      + " AND A01.FBME01_FIN_MASTER_K = E01.FBME01_FIN_MASTER_K"
      + " AND E01.FBMD09_SEG_C = D09.FBMD09_SEG_C"
      + " AND ( ( EXISTS "
      + " (SELECT 1 FROM {h-schema}MFBMD03_FORD_PERSON T_D03,"
      + " {h-schema}MFBMD14_REPORT_LEVEL T_D14"
      + " WHERE T_D03.FBMD14_RPTLVL_K = T_D14.FBMD14_RPTLVL_K"
      + " AND t_D03.FBMD03_CDSID_C = :cdsid"
      + "  AND T_D14.FBMD14_TITLE_C='ROM'"
      + " )"
      + " AND D09.FBMD99_SEGMENT_GROUP_TYPE_C='R'"
      + " ) OR("
      + " D09.FBMD99_SEGMENT_GROUP_TYPE_C < >'R'"
      + " AND D03_S.FBMD03_CDSID_C = :cdsid"
      + " )"
      + " )", nativeQuery = true)
  List<CustomerAcceptanceS3Dto> findCustomerAcceptanceListByApproverId(@Param("cdsid") String cdsid);

  @Query(value = "SELECT A13.*"
      + " from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13"
      + " WHERE A13.FBMA01_PROPOSAL_K = :proposalKey", nativeQuery = true)
  CustomerAcceptanceS3Dto findCurrentProposal(@Param("proposalKey") long proposalKey);

  /**
   * To find customerAcceptance view data
   *
   * @param finKey       finKey
   * @param proposalYear proposalYear
   * @return object
   */
  @Query(value = "SELECT A13.FBMA01_PROPOSAL_K,A01.FBMD12_PROPOSAL_YEAR_C,\n" +
      "A13.FBMA13_LETTER_GENERATE_Y,A01.FBMA01_CUST_SIGN_S,\n" +
      "A13.FBMD03_ACCEPTED_BY_CDSID_C,FBMD97_LETTER_APV_STATUS_C, A01.FBMD11_PROPOSAL_STATUS_C\n" +
      "from {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13\n" +
      "JOIN {h-schema}MFBMA01_PROPOSAL A01 ON A01.FBMA01_PROPOSAL_K = A13.FBMA01_PROPOSAL_K\n" +
      "       where A01.FBME01_FIN_MASTER_K=?1\n" +
      "       and A01.FBMD11_PROPOSAL_STATUS_C in ('APV')\n" +
      "       and A01.FBMD12_PROPOSAL_YEAR_C=?2\n" +
      "       and A01.FBMA01_VERNUM_R=(SELECT MAX(FBMA01_VERNUM_R) FROM FBMS.MFBMA01_PROPOSAL WHERE\n" +
      "       FBME01_FIN_MASTER_K=A01.FBME01_FIN_MASTER_K and FBMD12_PROPOSAL_YEAR_C=A01.FBMD12_PROPOSAL_YEAR_C\n" +
      "       AND A01.FBMD11_PROPOSAL_STATUS_C in ('APV')\n" +
      "       )\n" +
      "UNION\n" +
      "SELECT A13.FBMA01_PROPOSAL_K,A01.FBMD12_PROPOSAL_YEAR_C,\n" +
      "A13.FBMA13_LETTER_GENERATE_Y,A01.FBMA01_CUST_SIGN_S,\n" +
      "A13.FBMD03_ACCEPTED_BY_CDSID_C,FBMD97_LETTER_APV_STATUS_C, A01.FBMD11_PROPOSAL_STATUS_C\n" +
      "FROM {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13\n" +
      "JOIN {h-schema}MFBMA01_PROPOSAL A01 On A01.FBMA01_PROPOSAL_K = A13.FBMA01_PROPOSAL_K\n" +
      "       where A01.FBME01_FIN_MASTER_K=?1\n" +
      "       and A01.FBMD12_PROPOSAL_YEAR_C=?2\n" +
      "       and (A01.FBMD11_PROPOSAL_STATUS_C in ('EST','URV','DEC') or\n" +
      "       (A01.FBMD11_PROPOSAL_STATUS_C in ('TRM')\n" +
      "       and A01.FBMA01_SOURCE_VER_AT_TRM_R = A01.FBMA01_VERNUM_R))", nativeQuery = true)
  Object[][] findCustomerAcceptance(final Long finKey, final Integer proposalYear);

  @Query(value = " SELECT A13.* , A01.FBMD12_PROPOSAL_YEAR_C\n"
      + "FROM {h-schema}MFBMA13_CUSTOMER_ACCEPTANCE_S3 A13\n"
      +"JOIN {h-schema}MFBMA01_PROPOSAL A01 on A13.FBMA01_PROPOSAL_K = A01.FBMA01_PROPOSAL_K"
      + " WHERE A13.FBMA13_LETTER_ORIGINAL_X = :letterTemplateOriginal", nativeQuery = true)
  List<CustomerAcceptanceS3Dto> getAutoEarlyTemplates(@Param("letterTemplateOriginal") String letterTemplateOriginal);



}