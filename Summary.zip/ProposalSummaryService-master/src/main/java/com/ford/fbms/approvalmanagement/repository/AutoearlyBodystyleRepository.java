package com.ford.fbms.approvalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.AutoearlyBodystyle;
import com.ford.fbms.approvalmanagement.domain.AutoearlyBodystylePK;

/**
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface AutoearlyBodystyleRepository extends JpaRepository<AutoearlyBodystyle, AutoearlyBodystylePK> {


}
