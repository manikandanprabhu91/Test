package com.ford.fbms.approvalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.ProposalExtraInfoDto;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ProposalExtraInfoRepository extends JpaRepository<ProposalExtraInfoDto, Long>{

}