package com.ford.fbms.approvalmanagement.transport;


import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;
import com.ford.fbms.approvalmanagement.domain.TargetBandDto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.CustomerAcceptanceS3Dto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalViewDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.VehicleLineOptionDiscountVo;

import lombok.Getter;
import lombok.Setter;

/**
 * Reference lists for Address and direction model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Setter
@Getter
public class GenericResponseWrapper extends GenericResponse {

  private GenericResponse genericResponse;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private ProposalVo proposalVo;
  private List<ApprovalProcessDto> approvalProcessDtoList;
  //@JsonIgnore
  private FordPersonDto fordPersonDto;
  private List<ReportLevelDto> reportLevelDtoList;
  private List<FinancialDetailedVO> financialDetailedVOList;
  private List<FinancialMexDetailedVO> financialDetailedMexVOList;
  private List<ProposalFinancialVO> targetList;
  //@JsonIgnore
  private ApprovalResponseVo approvalResponseVo;
  //@JsonIgnore
  private ApprovalResponseVo approvalResponseNonFinancialVo;
  private List<ApprovalChainVO> approvalChainList;
  private Long financialDataStatus;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<ProposalViewDto> proposalNotesRetrival;
/*  @JsonIgnore
  private ProposalDto ProposalDto;*/
  @JsonIgnore
  private ProposalDto priorProposalDto;
  @JsonIgnore
  private ProposalDto proposalDataDto;
  @JsonIgnore
  private TargetBandDto targetBandDto;
  @JsonIgnore
  private ApprovalProcessDto updateRecalledQueue;
  @JsonIgnore
  private ApprovalProcessDto approvalProcessDto;
  @JsonIgnore
  private PyCountryDefinition pyCountryDefinition;
  @JsonIgnore
  private List<SubsidiariesVo> subsidiariesVos;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<VehicleLineOptionDiscountVo> vehicleLineOptionDiscountVos;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private List<ProposalCommentsVo> proposalCommentsVos;
  private Map<String, String> dropDownMap;
  private FinancialSummaryVO financialSummaryVO;
  private ValidateActionsVO actionsVO;
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String proposalDownload;
  @JsonIgnore
  private Boolean isAuthorized;
  @JsonIgnore
  private Boolean isProposalAssignee;
  @JsonIgnore
  private Boolean isEligibleFin;
  @JsonIgnore
  private Boolean isSDATierAllowed;
  @JsonIgnore
  private Boolean isValidSubFin;
  @JsonIgnore
  private Boolean isValidCPALetterMinQty;
  @JsonIgnore
  private Boolean isValidTierVolume;
  @JsonIgnore
  private Boolean isValidTierIncentive;
  @JsonIgnore
  private Boolean isValidESP;
  @JsonIgnore
  private Boolean isAllVehicleLineIncentivesValid;
  List<FinancialDetailedVO> financialDetailedList;
  private FinancialMexSummaryVO financialMexSummaryVO;
  private HashMap<Long,List<FinancialMexDetailedVO>> financialMexList;
  private boolean approvalNextDeal;
  private boolean noFutherDealsToApprove;
  private Long nextProposal;
  private CustomerAcceptanceS3Dto customerAcceptanceS3Dto;
}
