package com.ford.fbms.approvalmanagement.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * A class for Approval request.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Getter
@Setter
public class ApprovalRequest {
  private String status;
  private String segmentGroup;
}
