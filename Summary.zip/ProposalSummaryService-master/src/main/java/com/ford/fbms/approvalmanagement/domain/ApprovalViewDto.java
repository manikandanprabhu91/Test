//******************************************************************************
//* Copyright (c) 2010 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   ApprovalViewBO.java  $
//* $Revision:   1.2  $
//* $Author:   SHYDHATU  $
//* $Date:   Mar 17 2010 08:28:20  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;

import lombok.Getter;
import lombok.Setter;

/**
 * ApprovalViewBO
 */
@Entity
@Table(name = "FBMS_APPROVAL_VIEW")
@Getter
@Setter
public class ApprovalViewDto extends GenericResponse implements Serializable{
/**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 1L;



	@Column(name="FBMD14_RPTLVL_C")
    private int queueReportLevelCode;
	
	@Column(name="A09_FBMD14_RPTLVL_C")
	private int maxReportLevelCode;
	
	@Column(name="FBMA09_SUBMITTED_S")
	private Timestamp submittedDate;
	
	@Column(name="FBMD03_SUBMITTED_TO_CDSID_C")
	private String submittedToCdsid;
	
	@Column(name="FBMA01_PROPOSAL_MLV_Q")
	private int proposalMlv;
	
	@Column(name="FBMD14_MAX_RPTLVL_K")
	private int maxReportLevelKey;
	
	@Column(name="FBMA01_PROPOSAL_SUB_Y")
	private Date proposalSubmittedDate;
	
	@Column(name="FBMA01_STATUS_Y")
	private Date statusDate;
	
	@Column(name="FBMD11_PROPOSAL_STATUS_C")
	private String proposalStatus;
	
	@Column(name="FBMD03_CDSID_C")
	private String cdsid;
	
	@Column(name="FBME01_FIN_MASTER_K")
	private Long finMasterSaKey;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "FBMA01_PROPOSAL_K")
	private Long proposalSaKey;
	
	@Column(name="FBMD99_SEGMENT_GROUP_TYPE_C")
	private String segmentGroupType;
	
	@Column(name="FBME15_ACCT_N")
	private String accountName;
	
	@Column(name="FBME01_FIN_C")
	private String fin;
	
	@Column(name="FBMD12_PROPOSAL_YEAR_C")
	private int proposalYear;
	
	@Column(name="FBMA01_VERNUM_R")
	private int version;
	
	@Column(name="A09_FBMD14_TITLE_C")
	private String maxReportLevelTitle;
	
	@Column(name="FBMA01_CNTL_REQD_F")
	private boolean controllerRequiredFlag;


}
