package com.ford.fbms.approvalmanagement.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VehicleLineOptionDiscountVo {
    private Long bodyStyleKey;
    private String vehicleLineKey;
    private String vehicleLineDesc;
    private String bodyStyle;
    private Long modelYr;
    private Long mlv;
    private String tier1;
    private Long pviKey;
    private Long tier1Amt;
    private Long tier2Amt;
    private Long tier3Amt;
    private Long tier4Amt;
    private Long tier5Amt;
    private Long tier6Amt;
    private String optionDiscountCd;
    private String optionDiscountdesc;
    private Long optionDiscountAmt;
}
