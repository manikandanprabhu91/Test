package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.FVADataDto;
import com.ford.fbms.approvalmanagement.domain.FVADataPKDto;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface FVADataRepository extends JpaRepository<FVADataDto, FVADataPKDto> {

  @Query(value = "SELECT top 1 *"
  		+ "FROM {h-schema}MFBME05_FVA_DATA\r\n"
  		+ "WHERE  FBME01_FIN_MASTER_K = :finMaster\r\n"
  		+ "AND FBME03_BDYSTL_K = :bodyStyle\r\n"
  		+ "AND FBMD12_PROPOSAL_YEAR_C = :proposalYearDefinition "
  		, nativeQuery = true)
 List<FVADataDto> findFVADataByFinBdyStylePropYr(@Param("finMaster") final Long finMaster,@Param("bodyStyle")final Long bodyStyle,@Param("proposalYearDefinition")final int proposalYearDefinition);
	
	
}
