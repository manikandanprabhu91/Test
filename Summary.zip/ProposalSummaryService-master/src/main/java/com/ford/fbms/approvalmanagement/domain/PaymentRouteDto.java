package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA23_PAYMENT_ROUTE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = PaymentRouteDto.TABLE_NAME)
// @NamedQuery(name="PaymentRoute.findAll", query="SELECT m FROM PaymentRoute
// m")
public class PaymentRouteDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMA23_PAYMENT_ROUTE";

	@Id
	/*
	 * "MFBMA23_PAYMENT_ROUTE_FBMA23PAYMENTROUTEC_GENERATOR", sequenceName =
	 * "FBMS.MFBM_MFBMA23_PAYMENT_ROUTE_SQ")
	 * 
	 * @GeneratedValue(strategy = GenerationType.IDENTITY)
	 * "MFBMA23_PAYMENT_ROUTE_FBMA23PAYMENTROUTEC_GENERATOR")
	 */

	@Column(name = "FBMA23_PAYMENT_ROUTE_C")
	private String paymentRouteCode;

	@Column(name = "FBMA23_PAYMENT_ROUTE_N")
	private String paymentRouteDesc;

	/*
	 * //bi-directional many-to-one association to Mfbma05OptionIncentive
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<OptionIncentive>
	 * optionIncentives;
	 */
	/*
	 * //bi-directional many-to-one association to Mfbma24ViPaymentRoute
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<ViPaymentRoute>
	 * vIPaymentRoutes;
	 * 
	 * //bi-directional many-to-one association to Mfbma25PropPaymentRoute
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<ProposalPaymentRoute>
	 * propPaymentRoutes;
	 * 
	 * //bi-directional many-to-one association to Mfbma30BonusMgmt
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<BonusMgmt> bonusMgmts;
	 * 
	 * //bi-directional many-to-one association to Mfbma42TierIncePaymntRoute
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<TierIncePaymntRoute>
	 * tierIncePaymntRoutes;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma43BandingGroup
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<BandingGroup> bandingGroups;
	 * 
	 * //bi-directional many-to-one association to Mfbma45BandingPayeeDtl
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<BandingPayeeDtl>
	 * bandingPayeeDtls;
	 * 
	 * //bi-directional many-to-one association to Mfbma47PviBandPaymtDtl
	 * 
	 * @OneToMany(mappedBy="paymentRoute") private List<PviBandPaymtDtl>
	 * pviBandPaymtDtls;
	 */

	// bi-directional many-to-one association to Mfbmg03DftPaymtRouting
	/*
	 * @OneToMany(mappedBy="paymentRoute") private List<DefaultPaymentRouting>
	 * dftPaymtRoutings;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA23_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMA23_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMA23_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA23_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMA23_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMA23_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
