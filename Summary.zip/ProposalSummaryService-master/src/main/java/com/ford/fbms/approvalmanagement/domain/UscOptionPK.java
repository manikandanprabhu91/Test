package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The primary key class for the MFBME48_USC_OPTION database table.
 * 
 */
@Getter
@Setter
@Embeddable
@NoArgsConstructor
public class UscOptionPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	// bi-directional many-to-one association to Mfbme41PdMarket
	@OneToOne
	@JoinColumn(name = "FBME41_PD_MARKET_C")
	private PdMarketDto pdMarket;

	@Column(name = "FBME48_MODEL_C")
	private String modelCode;

	@Column(name = "FBME48_USC_C")
	private String uscCode;
	

	public UscOptionPK(PdMarketDto pdMarket, String modelCode, String uscOptionCode) {
		this.setPdMarket(pdMarket);
		this.setModelCode(modelCode);
		this.setUscCode(uscOptionCode);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((modelCode == null) ? 0 : modelCode.hashCode());
		result = prime * result + ((pdMarket == null) ? 0 : pdMarket.hashCode());
		result = prime * result + ((uscCode == null) ? 0 : uscCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true; }
		if (obj == null) {
			return false;}
		if (!(obj instanceof UscOptionPK)) {
			return false;}
		UscOptionPK other = (UscOptionPK) obj;
		if (modelCode == null) {
			if (other.modelCode != null) {
				return false;}
		} else if (!modelCode.equals(other.modelCode)) {
			return false;}
		if (pdMarket == null) {
			if (other.pdMarket != null) {
				return false;}
		} else if (!pdMarket.equals(other.pdMarket)) {
			return false;}
		if (uscCode == null) {
			if (other.uscCode != null) {
				return false;}
		} else if (!uscCode.equals(other.uscCode)) {
			return false;}
		return true;
	}

}