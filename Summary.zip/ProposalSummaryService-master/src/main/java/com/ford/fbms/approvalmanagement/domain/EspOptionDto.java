package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMD79_ESP_OPTION database table.
 * 
 */
@Entity
@Table(name = EspOptionDto.TABLE_NAME)
public class EspOptionDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD79_ESP_OPTION";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD79_EO_K")
	private long espOptionSaKey;

	@Column(name = "FBMD79_ESP_COST_A")
	private BigDecimal espCostA;

	@Column(name = "FBMD79_ESP_DEDUCTIBLE_A")
	private BigDecimal espDeductibleA;

	@Column(name = "FBMD79_ESP_DURATION_R")
	private BigDecimal espDurationR;

	@Column(name = "FBMD79_ESP_INACTIVE_S")
	private Timestamp espInactiveTS;

	@Column(name = "FBMD79_ESP_MILES_R")
	private BigDecimal espMilesR;

	@Column(name = "FBMD79_ESP_STATUS_F")
	private String espStatusFlag;

	// bi-directional many-to-one association to Mfbmd98EspContractType
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD98_ESP_CONTRACT_TYPE_C")
	private EspContractTypeDto espContractType;

	// bi-directional many-to-one association to Mfbme03BodyStyle
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME03_BDYSTL_K")
	private BodyStyleDto bodyStyle;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD79_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD79_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD79_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD79_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD79_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD79_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
