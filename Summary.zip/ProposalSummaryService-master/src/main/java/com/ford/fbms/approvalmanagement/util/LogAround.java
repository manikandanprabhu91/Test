package com.ford.fbms.approvalmanagement.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * An util interface to capture IN and OUT of the method.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface LogAround {

}