package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class FordPersonManager implements Validator {

  @Autowired
  private FordPersonRepository fordPersonRepository;
  @Autowired
  private ResponseBuilder responseBuilder;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").message("Inside ProposalAssignmentManager"));
    Optional<FordPersonDto> fordPersonDtoOptional = fordPersonRepository.findById(apiParams.getUserId());
    fordPersonDtoOptional.ifPresent(genericResponseWrapper::setFordPersonDto);
    return new AsyncResult<>(genericResponseWrapper);
  }
}