//******************************************************************************
//* Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   FVADataBO.java  $
//* $Revision:   1.1  $
//* $Author:   PSIRISIN  $
//* $Date:   Dec 15 2009 11:27:06  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Table;

import javax.persistence.Entity;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "MFBME05_FVA_DATA")
public class FVADataDto  implements Serializable {
    // Logging Setup

    private static final long serialVersionUID = 1L;
    
    @JsonIgnore
    @EmbeddedId
    private FVADataPKDto id;
    
    @Column(name="FBME05_AVG_CNTRB_CST_A")
    private long averageContributionCost;
    
    @Column(name="FBME05_AVG_REVENUE_CST_A")
	private long averageRevenue;
    

}
