package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



import lombok.Getter;
import lombok.Setter;

/**
 * A class for Approval Process model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Entity
@Table(name = "MFBMA09_APPROVAL_PROCESS")
@Getter
@Setter
public class ApprovalProcessDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBMA09_AP_K")
  private Long approvalKey;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMA01_PROPOSAL_K")
  private ProposalDto proposalKey;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD11_PROPOSAL_STATUS_C")
  private ProposalStatusDto proposalStatus;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD03_SUBMITTED_BY_CDSID_C")
  private FordPersonDto submittedById;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  @Column(name = "FBMA09_SUBMITTED_S")
  private Date submittedTime;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD03_SUBMITTED_TO_CDSID_C")
  private FordPersonDto submittedToId;

  
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD14_RPTLVL_K")
  private ReportLevelDto reportLevel;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD03_APPROVED_BY_CDSID_C")
  private FordPersonDto approvedById;

  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  @Column(name = "FBMA09_APPROVED_S")
  private Date approvedTime;
  
  	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA09_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMA09_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMA09_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA09_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMA09_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMA09_LAST_UPDT_USER_C")
	private String lastUpdatedUser;

}
