package com.ford.fbms.approvalmanagement.repository;


import com.ford.fbms.approvalmanagement.domain.MultiYearTermViewDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between direction model and table.
 *
 * @author NACHUTHA on 3/17/2021.
 */
@Repository
public interface MultiYearTermViewRepository extends JpaRepository<MultiYearTermViewDto, Long> {

@Query(value="Select * from {h-schema}FBMS_A15_IN_EFF_VIEW where FBMA01_PROPOSAL_K = :proposalKey ",nativeQuery = true)
MultiYearTermViewDto findByProposalKey(@Param("proposalKey")long proposalKey);
}
