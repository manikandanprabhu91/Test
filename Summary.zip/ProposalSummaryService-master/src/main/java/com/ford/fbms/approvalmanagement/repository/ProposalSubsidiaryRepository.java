package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryPK;

/**
 * 
 *
 * @author vvm on 4/27/2021.
 */
@Repository
public interface ProposalSubsidiaryRepository extends JpaRepository<ProposalSubsidiaryDto, ProposalSubsidiaryPK> {
	
	@Query(value = "select ps from ProposalSubsidiaryDto ps where ps.proposalSubsidiaryPK.proposal.proposalSaKey=:proposalKey")
	Optional<List<ProposalSubsidiaryDto>> findByProposalKey(@Param("proposalKey") Long proposalKey);
	
  }
