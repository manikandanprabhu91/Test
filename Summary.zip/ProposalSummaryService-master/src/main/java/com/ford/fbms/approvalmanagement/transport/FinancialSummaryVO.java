//******************************************************************************
//* Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   FinancialSummaryVO.java  $
//* $Revision:   1.2  $
//* $Author:   PSIRISIN  $
//* $Date:   Dec 27 2009 10:52:46  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * This Value Object holds Proposal Financial Summary. 
 */
public class FinancialSummaryVO {

    /**
     * Total Present Variable Marketing (K)
     */
    private int presentTotalVM;
    
    /**
     * Average Present Variable Marketing
     */
    private int presentAvgVM;
    
    private boolean priorPYApplicable;
    
    /**
     * Total B(W) Prior PY Variable Marketing (K)
     */
    private int bwPriorPYTotalVM;
    
    /**
     * Average B(W) Prior PY Variable Marketing
     */
    private int bwPriorPYAvgVM;
    
    private boolean prevVerApplicable;
    /**
     * Total B(W) Previous Version Variable Marketing (K)
     */
    private int bwPrevVerTotalVM;
    
    /**
     * Average B(W) Previous Version Variable Marketing
     */
    private int bwPrevVerAvgVM;
    
    /**
     * Total B(W) Target Variable Marketing (K)
     */
    private int bwTargetTotalVM;
    
    /**
     * Average B(W) Target Variable Marketing
     */
    private int bwTargetAvgVM;
    
    /**
     * Total B(W) Prior PY Contribution Margin (K)
     */
    private int bwPriorPYTotalCM;
    
    /**
     * Average B(W) Prior PY Contribution Margin
     */
    private int bwPriorPYAvgCM;
    
    /**
     * Total B(W) Target Contribution Margin (K)
     */
    private int bwTargetTotalCM;
    
    /**
     * Average B(W) Target Contribution Margin
     */
    private int bwTargetAvgCM;

        
    
}


