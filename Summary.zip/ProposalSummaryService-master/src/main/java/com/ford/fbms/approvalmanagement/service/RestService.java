package com.ford.fbms.approvalmanagement.service;


import static com.ford.fbms.approvalmanagement.util.Constants.HYPHEN;

import java.util.Arrays;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.SubsidiaryResponse;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.Constants;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;

import lombok.extern.slf4j.Slf4j;

/**
 * To make external calls.
 *
 * @author SJAGATJO on 5/18/2021.
 */
@Slf4j
@Service
public class RestService {

	@Autowired
	private ConfigProperties configProperties;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	protected ResponseBuilder responseBuilder;

	private static final String CDSID = "cdsId";
	
	private static final String COUNTRYCD = "countryCd";

	protected boolean checkResponseStatusforRetry(int statusCode) {
		boolean retryFlag = false;
		if (HttpStatus.FORBIDDEN.value() == statusCode || HttpStatus.NOT_FOUND.value() == statusCode
				|| HttpStatus.BAD_GATEWAY.value() == statusCode || HttpStatus.SERVICE_UNAVAILABLE.value() == statusCode
				|| HttpStatus.GATEWAY_TIMEOUT.value() == statusCode) {
			retryFlag = true;
		}
		return retryFlag;
	}

	/**
	 * This method implements thread wait based on retry count Information.
	 *
	 * @param retryCount : Number of simply retries for retreiveVehicle Service
	 *                   Connection
	 * @return This method returns void
	 */
	private void exponentialBackoffWait(int retryCount) {
		int low = configProperties.getRestService().getBackoffLow();
		int high = configProperties.getRestService().getBackoffHigh();
		long maxInterval = configProperties.getRestService().getBackoffMaxInterval();
		Random r = new Random();
		// Wait an indeterminate amount of time (range determined by the number of
		// retries)
		try {
			long thisInterval = (int) Math.round(Math.pow(2, retryCount)) * (long) 1000 + (r.nextInt(high - low) + low);
			Thread.sleep(((thisInterval < maxInterval) ? thisInterval : maxInterval));
		} catch (InterruptedException ignored) {
			// Ignoring interruptions in the Thread sleep so that
			// retries continue
			Thread.currentThread().interrupt();
		}
	}

	public HttpHeaders setHttpHeaders(HttpServletRequest request) {
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add(Constants.AUTHORIZATION_HEADER_NAME, request.getHeader(Constants.AUTHORIZATION_HEADER_NAME));
		httpHeaders.add(Constants.CORRELATION_ID_HEADER_NAME,
				(String) request.getAttribute(Constants.CORRELATION_ID_HEADER_NAME));
		httpHeaders.add(Constants.TRACE_ID_HEADER_NAME, request.getHeader(Constants.TRACE_ID_HEADER_NAME));
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		return httpHeaders;
	}

	protected String getObjectJsonAsString(GenericResponse object) {
		try {
			// Marshall the data
			return objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			log.error("Error while parsing Object to json in  getObjectJsonAsString method ",e);

		}
		return null;
	}

	public GenericResponse getSubsidiariesDetails(final ApiParams apiParams, final HttpServletRequest httpRequest) {
		String methodName = "getSubsidiariesDetails";
		ResponseEntity<SubsidiaryResponse> genericResponseEntity = null;
		GenericResponse genericResponse = null;
		String uriBuilderInternal;
		String uriBuilderExternal;
		HttpEntity<Object> headerEntity;
		final HttpHeaders headers = setHttpHeaders(httpRequest);
		headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		uriBuilderInternal = frameSubsServiceEndpoint(apiParams,
				configProperties.getRestService().getSubsidiariesServiceInternal());
		uriBuilderExternal = frameSubsServiceEndpoint(apiParams,
				configProperties.getRestService().getSubsidiariesServiceExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;
			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(methodName).subsidiariesServiceUrl(logUriBuilder));
				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity,
						SubsidiaryResponse.class);
			} catch (HttpStatusCodeException httpStatusCodeException) {
				try {
					genericResponse = objectMapper.readValue(httpStatusCodeException.getResponseBodyAsString(),
							SubsidiaryResponse.class);
					genericResponse.setHttpStatus(httpStatusCodeException.getStatusCode());
				} catch (Exception e) {
					log.error("Error occurred in getSubsidiariesDetails with user id" +apiParams.getUserId(),e);
				}
				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + HYPHEN
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));
				log.error("Error occurred in getSubsidiariesDetails 2 with user id" +apiParams.getUserId(),httpStatusCodeException);

			} catch (RestClientResponseException restClientResponseException) {
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + HYPHEN
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
				log.error("Error occurred in getSubsidiariesDetails3 with user id" +apiParams.getUserId(),restClientResponseException);
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				log.error("Error occurred in getSubsidiariesDetails4 with user id" +apiParams.getUserId(),resourceAccessException);
			} catch (Exception exception) {
				log.error("Error occurred in getSubsidiariesDetails5 with user id" +apiParams.getUserId(),exception);
			}	
			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}
		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}
		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
			GenericResponse logGenericResponse = genericResponse;
			String logUriBuilder = uriBuilder;
			LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).subsidiariesServiceUrl(logUriBuilder)
					.responseBody(getObjectJsonAsString(logGenericResponse)));
		}
		return genericResponse;
	}

	private String frameSubsidiariesServiceEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url).queryParam(CDSID, apiParams.getUserId())
				.queryParam(COUNTRYCD, apiParams.getCountryCd()).queryParam(ApprovalConstants.REST_API_FINKEY, apiParams.getFinKey());

		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

	private String frameSubsServiceEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url).queryParam(CDSID, apiParams.getUserId())
				.queryParam(COUNTRYCD, apiParams.getCountryCd()).queryParam(ApprovalConstants.REST_API_FINKEY, apiParams.getFinKey())
				.queryParam(ApprovalConstants.REST_API_PROPOSALYR, apiParams.getProposalYr())
				.queryParam(ApprovalConstants.REST_API_PROPOSALKEY, apiParams.getProposalKey())
				.queryParam(ApprovalConstants.REST_API_PROPOSAL_YR_VER, apiParams.getProposalYrVer());
		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

	private String frameServiceEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url).queryParam(CDSID, apiParams.getUserId())
				.queryParam(COUNTRYCD, apiParams.getCountryCd())
				.queryParam(ApprovalConstants.REST_API_PROPOSALKEY, apiParams.getProposalKey());

		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

	public GenericResponseWrapper getProposalComments(ApiParams apiParams, HttpServletRequest httpRequest) {
		String methodName = "getProposalComments";
		ResponseEntity<GenericResponseWrapper> genericResponseEntity = null;
		GenericResponseWrapper genericResponse = null;
		String uriBuilderInternal;
		String uriBuilderExternal;
		HttpEntity<Object> headerEntity;
		final HttpHeaders headers = setHttpHeaders(httpRequest);
		headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		uriBuilderInternal = frameSubsidiariesServiceEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlInternal());
		uriBuilderExternal = frameSubsidiariesServiceEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;
			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).notesServiceUrl(logUriBuilder));
				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity,
						GenericResponseWrapper.class);
			} catch (HttpStatusCodeException httpStatusCodeException) {
				log.error("Error occurred in getProposalComments 1with user id " +apiParams.getUserId(),httpStatusCodeException);
				try {
					genericResponse = objectMapper.readValue(httpStatusCodeException.getResponseBodyAsString(),
							GenericResponseWrapper.class);
					genericResponse.setHttpStatus(httpStatusCodeException.getStatusCode());
				} catch (Exception e) {
					LoggerBuilder.printError(log,
							logger -> logger.exceptionMessage(e.getMessage()).methodName("getProposalComments").userId(apiParams.getUserId())
									.message("Error occurred in getProposalComments"));
					log.error("Error occurred in getProposalComments 2with user id " +apiParams.getUserId(),e);
				}
				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + HYPHEN
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));

			} catch (RestClientResponseException restClientResponseException) {
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + HYPHEN
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
				log.error("Error occurred in getProposalComments 3 with user id " +apiParams.getUserId(),restClientResponseException);
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(resourceAccessException)
								.message(resourceAccessException.getMessage())
								.responseBody(resourceAccessException.getMessage()));
				log.error("Error occurred in getProposalComments 4 with user id " +apiParams.getUserId(),resourceAccessException);
			} catch (Exception e) {
				log.error("Error occurred in getProposalComments 5 with user id " +apiParams.getUserId(),e);
			}
			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}
		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}
		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
			genericResponse.setHttpStatus(genericResponseEntity.getStatusCode());
			GenericResponse logGenericResponse = genericResponse;
			String logUriBuilder = uriBuilder;
			LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).notesServiceUrl(logUriBuilder)
					.responseBody(getObjectJsonAsString(logGenericResponse)));
		}
		return genericResponse;
	}

	public GenericResponse getPerUnitIncentiveDetails(final ApiParams apiParams, final HttpServletRequest httpRequest) {
		String methodName = "getPerUnitIncentiveDetails";
		ResponseEntity<GenericResponseWrapper> genericResponseEntity = null;
		GenericResponseWrapper genericResponse = null;
		String uriBuilderInternal;
		String uriBuilderExternal;
		HttpEntity<Object> headerEntity;
		final HttpHeaders headers = setHttpHeaders(httpRequest);
		headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		uriBuilderInternal = frameServiceEndpoint(apiParams,
				configProperties.getRestService().getProposalServiceInternal());
		uriBuilderExternal = frameServiceEndpoint(apiParams,
				configProperties.getRestService().getProposalServiceExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;
			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).proposalServiceUrl(logUriBuilder));
				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity,
						GenericResponseWrapper.class);
			} catch (HttpStatusCodeException httpStatusCodeException) {
				try {
					genericResponse = objectMapper.readValue(httpStatusCodeException.getResponseBodyAsString(),
							GenericResponseWrapper.class);
					genericResponse.setHttpStatus(httpStatusCodeException.getStatusCode());
				} catch (Exception e) {
					log.error("Error occurred in getPerUnitIncentiveDetails 1 with user id" +apiParams.getUserId(),e);
				}
				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + HYPHEN
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));
				log.error("Error occurred in getPerUnitIncentiveDetails 2 with user id" +apiParams.getUserId(),httpStatusCodeException);

			} catch (RestClientResponseException restClientResponseException) {
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + HYPHEN
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
				log.error("Error occurred in getPerUnitIncentiveDetails 3 with user id" +apiParams.getUserId(),restClientResponseException);
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				log.error("Error occurred in getPerUnitIncentiveDetails 4 with user id" +apiParams.getUserId(),resourceAccessException);
			} catch (Exception exception) {
				log.error("Error occurred in getPerUnitIncentiveDetails 5 with user id" +apiParams.getUserId(),exception);
			}
			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}
		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}
		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
			genericResponse.setHttpStatus(genericResponseEntity.getStatusCode());
			GenericResponse logGenericResponse = genericResponse;
			String logUriBuilder = uriBuilder;
			LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).proposalServiceUrl(logUriBuilder)
					.responseBody(getObjectJsonAsString(logGenericResponse)));
		}
		return genericResponse;
	}

	public GenericResponse getVehicleIncentiveOptionsData(final ApiParams apiParams,
			final HttpServletRequest httpRequest) {
		String methodName = "getVehicleIncentiveOptionsData";
		ResponseEntity<GenericResponseWrapper> genericResponseEntity = null;
		GenericResponseWrapper genericResponse = null;
		String uriBuilderInternal;
		String uriBuilderExternal;
		HttpEntity<Object> headerEntity;
		final HttpHeaders headers = setHttpHeaders(httpRequest);
		headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		uriBuilderInternal = frameServiceEndpoint(apiParams,
				configProperties.getRestService().getVehicleServiceInternal());
		uriBuilderExternal = frameServiceEndpoint(apiParams,
				configProperties.getRestService().getVehicleServiceExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;
			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).vehicleServiceUrl(logUriBuilder));
				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity,
						GenericResponseWrapper.class);
				
			} catch (HttpStatusCodeException httpStatusCodeException) {
				try {
					genericResponse = objectMapper.readValue(httpStatusCodeException.getResponseBodyAsString(),
							GenericResponseWrapper.class);
					genericResponse.setHttpStatus(httpStatusCodeException.getStatusCode());
				} catch (Exception e) {
					log.error("Error occurred in getVehicleIncentiveOptionsData with user id" +apiParams.getUserId(),e);
				}
				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + HYPHEN
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));
				log.error("Error occurred in getVehicleIncentiveOptionsData 2 with user id" +apiParams.getUserId(),httpStatusCodeException);

			} catch (RestClientResponseException restClientResponseException) {
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + HYPHEN
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
				log.error("Error occurred in getVehicleIncentiveOptionsData 3 with user id" +apiParams.getUserId(),restClientResponseException);
			} catch (ResourceAccessException resourceAccessException) {
				log.error("Error occurred in getVehicleIncentiveOptionsData 4 with user id" +apiParams.getUserId(),resourceAccessException);
				retryFlag = true;
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(resourceAccessException)
								.message(resourceAccessException.getMessage())
								.responseBody(resourceAccessException.getMessage()));
			} catch (Exception exception) {
				log.error("Error occurred in getVehicleIncentiveOptionsData 5 with user id" +apiParams.getUserId(),exception);
			}
			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}
		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}
		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
			genericResponse.setHttpStatus(genericResponseEntity.getStatusCode());
			GenericResponse logGenericResponse = genericResponse;
			String logUriBuilder = uriBuilder;
			LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).vehicleServiceUrl(logUriBuilder)
					.responseBody(getObjectJsonAsString(logGenericResponse)));
		}
		return genericResponse;
	}

	public String getProposalTermsDetails(final ApiParams apiParams, HttpServletRequest httpRequest) {
		String methodName = "getProposalTermsDetails";
		ResponseEntity<String> genericResponseEntity = null;
		String genericResponse = null;
		HttpHeaders headers = setHttpHeaders(httpRequest);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		String uriBuilderInternal = frameProposalTermsEndpoint(apiParams,
				configProperties.getRestService().getProposalTermsInternal());
		String uriBuilderExternal = frameProposalTermsEndpoint(apiParams,
				configProperties.getRestService().getProposalTermsExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;

			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).proposalTermsUrl(logUriBuilder));
				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity, String.class);
			} catch (HttpStatusCodeException httpStatusCodeException) {
				
				log.error("Error occurred in getProposalTermsDetails 1" ,httpStatusCodeException);

				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + " - "
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));

			} catch (RestClientResponseException restClientResponseException) {
				log.error("Error occurred in getProposalTermsDetails 2" ,restClientResponseException);
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + " - "
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				log.error("Error occurred in getProposalTermsDetails 3" ,resourceAccessException);
			} catch (Exception exception) {
				log.error("Error occurred in getProposalTermsDetails 4" ,exception);
			}

			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}

		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}

		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
		}
		return genericResponse;
	}

	public GenericResponseWrapper getProposalNotesDetails(final ApiParams apiParams, HttpServletRequest httpRequest) {
		String methodName = "getProposalNotesDetails";
		ResponseEntity<GenericResponseWrapper> genericResponseEntity = null;
		GenericResponseWrapper genericResponse = null;
		HttpHeaders headers = setHttpHeaders(httpRequest);
		HttpEntity<String> headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		String uriBuilderInternal = frameSubsidiariesServiceEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlInternal());
		String uriBuilderExternal = frameSubsidiariesServiceEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlExternal());

		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;

			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).proposalNotesUrl(logUriBuilder));

				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity,
						GenericResponseWrapper.class);

			} catch (HttpStatusCodeException httpStatusCodeException) {
				log.error("Error occurred in getProposalNotesDetails 1" ,httpStatusCodeException);
				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + " - "
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));

			} catch (RestClientResponseException restClientResponseException) {
				log.error("Error occurred in getProposalNotesDetails 2" ,restClientResponseException);
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + " - "
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
			} catch (ResourceAccessException resourceAccessException) {
				log.error("Error occurred in getProposalNotesDetails 3" ,resourceAccessException);
				retryFlag = true;
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(resourceAccessException)
								.message(resourceAccessException.getMessage())
								.responseBody(resourceAccessException.getMessage()));
			} catch (Exception exception) {
				log.error("Error occurred in getProposalNotesDetails 4" ,exception);
			}

			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}

		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}

		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
		}
		return genericResponse;
	}

	public String getMultiYearPriceProtectionDetails(ApiParams apiParams, HttpServletRequest httpRequest) {
		String methodName = "getMultiYearPriceProtectionDetails";
		ResponseEntity<String> genericResponseEntity = null;
		String genericResponse = null;
		HttpHeaders headers = setHttpHeaders(httpRequest);
		HttpEntity<String> headerEntity = new HttpEntity<>(ApprovalConstants.PARAMETERS, headers);
		String uriBuilderInternal = frameMultiYearPriceProtEndpoint(apiParams,
				configProperties.getRestService().getMultiYearPriceProtInternal());
		String uriBuilderExternal = frameMultiYearPriceProtEndpoint(apiParams,
				configProperties.getRestService().getMultiYearPriceProtExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;

			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(methodName).multiYearIncentiveUrl(logUriBuilder));

				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.GET, headerEntity, String.class);

			} catch (HttpStatusCodeException httpStatusCodeException) {
				log.error("Error occurred in getMultiYearPriceProtectionDetails 1" ,httpStatusCodeException);

				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + " - "
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));

			} catch (RestClientResponseException restClientResponseException) {
				log.error("Error occurred in getMultiYearPriceProtectionDetails 2" ,restClientResponseException);
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + " - "
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				log.error("Error occurred in getMultiYearPriceProtectionDetails 3" ,resourceAccessException);
			} catch (Exception exception) {
				log.error("Error occurred in getMultiYearPriceProtectionDetails 4" ,exception);
			}

			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}

		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}

		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
		}
		return genericResponse;
	}

	private String frameProposalTermsEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder = null;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url + "/" + apiParams.getProposalKey())
				.queryParam(CDSID, apiParams.getUserId()).queryParam(COUNTRYCD, apiParams.getCountryCd())
				.queryParam(ApprovalConstants.REST_API_FINKEY, apiParams.getFinKey()).queryParam(ApprovalConstants.REST_API_PROPOSALYR, apiParams.getProposalYr())
				.queryParam(ApprovalConstants.REST_API_PROPOSAL_YR_VER, apiParams.getProposalYrVer());

		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

	private String frameMultiYearPriceProtEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder = null;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url).queryParam(CDSID, apiParams.getUserId())
				.queryParam("cntryCd", apiParams.getCountryCd()).queryParam(ApprovalConstants.REST_API_FINKEY, apiParams.getFinKey())
				.queryParam(ApprovalConstants.REST_API_PROPOSALKEY, apiParams.getProposalKey())
				.queryParam(ApprovalConstants.REST_API_PROPOSALYR, apiParams.getProposalYr())
				.queryParam(ApprovalConstants.REST_API_PROPOSAL_YR_VER, apiParams.getProposalYrVer());

		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

	public GenericResponse createProposalComments(final ApiParams apiParams, final Object requestObject,
			final HttpServletRequest httpRequest) {
		String methodName = "createProposalComments";
		ResponseEntity<GenericResponse> genericResponseEntity = null;
		final CreateProposalRequest createProposalRequest = (CreateProposalRequest) requestObject;
		GenericResponse genericResponse = null;
		HttpHeaders headers = setHttpHeaders(httpRequest);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<CreateProposalRequest> headerEntity = new HttpEntity<>(createProposalRequest, headers);
		String uriBuilderInternal = frameProposalCommentsEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlInternal());
		String uriBuilderExternal = frameProposalCommentsEndpoint(apiParams,
				configProperties.getRestService().getNotesServiceUrlExternal());
		String uriBuilder = uriBuilderInternal;
		int retryCount = 0;
		while (retryCount < configProperties.getRestService().getBackoffAttemptNum()) {
			boolean retryFlag = false;

			try {
				String logUriBuilder = uriBuilder;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(methodName).notesServiceUrl(logUriBuilder));

				genericResponseEntity = restTemplate.exchange(uriBuilder, HttpMethod.POST, headerEntity,
						GenericResponse.class);

			} catch (HttpStatusCodeException httpStatusCodeException) {
				try {
					genericResponse = objectMapper.readValue(httpStatusCodeException.getResponseBodyAsString(),
							GenericResponse.class);
					genericResponse.setHttpStatus(httpStatusCodeException.getStatusCode());
				} catch (Exception e) {
					log.error("Error occurred in createProposalComments 5" ,e);

				}

				retryFlag = checkResponseStatusforRetry(httpStatusCodeException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(httpStatusCodeException)
								.message(httpStatusCodeException.getMessage())
								.responseStatus(httpStatusCodeException.getRawStatusCode() + " - "
										+ httpStatusCodeException.getStatusText())
								.responseBody(httpStatusCodeException.getResponseBodyAsString()));
				log.error("Error occurred in createProposalComments 4" ,httpStatusCodeException);
			} catch (RestClientResponseException restClientResponseException) {
				retryFlag = checkResponseStatusforRetry(restClientResponseException.getRawStatusCode());
				LoggerBuilder.printError(log,
						logger -> logger.methodName(methodName).exception(restClientResponseException)
								.message(restClientResponseException.getMessage())
								.responseStatus(restClientResponseException.getRawStatusCode() + " - "
										+ restClientResponseException.getStatusText())
								.responseBody(restClientResponseException.getResponseBodyAsString()));
				log.error("Error occurred in createProposalComments 3" ,restClientResponseException);
			} catch (ResourceAccessException resourceAccessException) {
				retryFlag = true;
				log.error("Error occurred in createProposalComments 2" ,resourceAccessException);
			} catch (Exception exception) {
				log.error("Error occurred in createProposalComments 1" ,exception);
			}

			if (retryFlag) {
				uriBuilder = uriBuilderExternal;
				retryCount++;
				final int logAttempt = retryCount;
				LoggerBuilder.printDebug(log, logger -> logger.methodName(methodName)
						.message(String.format(ApprovalConstants.REST_API_ATTEMPT, logAttempt)));
				exponentialBackoffWait(retryCount);
			} else {
				break;
			}
		}

		if (retryCount >= configProperties.getRestService().getBackoffAttemptNum()) {
			LoggerBuilder.printError(log,
					logger -> logger.methodName(methodName).message(ApprovalConstants.REST_API_ALL_FAILED));
		}

		if (genericResponseEntity != null) {
			genericResponse = genericResponseEntity.getBody();
			genericResponse.setHttpStatus(genericResponseEntity.getStatusCode());
		}
		return genericResponse;
	}

	private String frameProposalCommentsEndpoint(ApiParams apiParams, String url) {
		UriComponentsBuilder builder = null;
		String uriBuilder = null;
		builder = UriComponentsBuilder.fromUriString(url).queryParam(CDSID, apiParams.getUserId())
				.queryParam(COUNTRYCD, apiParams.getCountryCd());
		if (null != builder) {
			uriBuilder = builder.build().toUriString();
		}
		return uriBuilder;
	}

}
