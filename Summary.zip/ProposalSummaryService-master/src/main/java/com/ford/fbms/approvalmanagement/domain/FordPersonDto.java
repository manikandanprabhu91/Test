package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for FordPerson model.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Entity
@Getter
@Setter
@Table(name = "MFBMD03_FORD_PERSON")
public class FordPersonDto implements Serializable{
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBMD03_CDSID_C")
  private String cdsid;

  @Column(name = "FBMD42_COUNTRY_ISO3_C")
  private String countryCode;

  @Column(name = "FBMD03_FNAME_N")
  private String firstName;

  @Column(name = "FBMD03_GENERIC_NAM_CDSID_C")
  private String genericNamCdsid;

  @Column(name = "FBMD03_LNAME_N")
  private String lastName;

  @Lob
  @Column(name = "FBMD03_SIGNATURE_L")
  private byte[] signatureLogo;

  @Column(name = "FBMD03_SPRCDSID_X")
  private String sprcdsidDescription;

  @Column(name = "FBMD03_STATUS_F")
  private String statusFlag;

  @Column(name = "FBMD03_UNASSIGNED_FINS_F")
  private String unassignedFinsFlag;

  @Column(name = "FBMC12_ADDR_K")
  private String address;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD14_RPTLVL_K")
  private ReportLevelDto reportLevel;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMD03_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBMD03_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBMD03_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMD03_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBMD03_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBMD03_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}
