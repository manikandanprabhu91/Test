package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.PriceProtectionYearOverYearDto;
import com.ford.fbms.approvalmanagement.domain.PriceProtectionYearOverYearPk;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between direction model and table.
 *
 * @author GILNAGOV on 2/15/2021.
 */
@Repository
public interface PriceProtectionYearOverYearRepository
    extends JpaRepository<PriceProtectionYearOverYearDto, PriceProtectionYearOverYearPk> {
  /**
   * To get list of PriceProtectionYearOverYear for a Proposal Key.
   */
  @Query(" select yoy from PriceProtectionYearOverYearDto yoy " +
      "where yoy.priceProtectionYearOverYearPk.proposalKey = :proposalKey")
  List<PriceProtectionYearOverYearDto> findByProposalKey(final long proposalKey);

  /**
   * To get list of PriceProtectionYearOverYear for a Proposal Key.
   */
  @Query(" select yoy from PriceProtectionYearOverYearDto yoy " +
      "where yoy.priceProtectionYearOverYearPk.proposalKey = :proposalKey " +
      "and yoy.priceProtectionYearOverYearPk.modelYear = :modelYear")
  Optional<PriceProtectionYearOverYearDto> findById(final long proposalKey, final long modelYear);

}
