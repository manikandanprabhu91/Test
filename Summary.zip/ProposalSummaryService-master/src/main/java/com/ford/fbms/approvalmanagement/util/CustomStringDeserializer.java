package com.ford.fbms.approvalmanagement.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import java.io.IOException;

/**
 * A custom string deserializer class for string deserializing while request receive.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public class CustomStringDeserializer extends JsonDeserializer<String> {

  @Override
  public String deserialize(
      final JsonParser jsonParser, final DeserializationContext deserializationContext)
      throws IOException {
    if (jsonParser.getCurrentToken() == JsonToken.VALUE_NUMBER_INT
        || jsonParser.getCurrentToken() == JsonToken.VALUE_NUMBER_FLOAT) {
      throw deserializationContext
          .invalidTypeIdException(deserializationContext.getContextualType(),
              JsonToken.VALUE_STRING.asString(),
              "Attempted to parse int to string but this is forbidden");
    } else if (jsonParser.getCurrentToken() == JsonToken.VALUE_TRUE) {
      throw deserializationContext
          .invalidTypeIdException(deserializationContext.getContextualType(),
              JsonToken.VALUE_TRUE.asString(),
              "Attempted to parse string to boolean true but this is forbidden");
    } else if (jsonParser.getCurrentToken() == JsonToken.VALUE_FALSE) {
      throw deserializationContext
          .invalidTypeIdException(deserializationContext.getContextualType(),
              JsonToken.VALUE_FALSE.asString(),
              "Attempted to parse string to boolean false but this is forbidden");
    }
    return jsonParser.getValueAsString();
  }
}
