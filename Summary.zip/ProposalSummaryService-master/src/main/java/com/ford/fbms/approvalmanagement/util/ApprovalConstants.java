package com.ford.fbms.approvalmanagement.util;

public class ApprovalConstants {

  // Proposal Status values (codes).
  public static final String NEW = "NEW";
  public static final String SUBMITTED = "SUB";
  public static final String APPROVED = "APV";
  public static final String TERMINATED = "TRM";
  public static final String ESTABLISHED = "EST";
  public static final String UNDER_REVIEW = "URV";
  public static final String REJECTED = "REJ";
  public static final String DECLINED = "DEC";
  public static final String REVISED = "REV";
  public static final String RECALLED = "XXX";
  public static final String INCOMPLETE = "INC";
  public static final String CUSTOMER_ACCEPTED_PROPOSAL = "ACC";
  public static final String ROM ="ROM";
  public static final String RSM = "RSM";
  public static final String CTL = "CTL";
  public static final String AUTOAPV = "AUTOAPV";
  public static final String RENTAL = "R";

  //Approval constants
  public static final int FIRST_LEVEL_APPROVER_RL_CODE = 6;
  public static final int ACCOUNT_MANAGER_RL_CODE = 7;
  public static final int CONTROLLER_RL_CODE = 8;
  public static final int GVP_RL_CODE = 2;
  public static final int FIRST_LEVEL_APPROVER_RL_CODE_MEX = 9;
  public static final int FNA_RL_CODE=9;
  public static final int FNM_RL_CODE=10;
  public static final String ACCOUNT_MANAGER_RL_TITLE = "Account Manager";
  public static final String DEFAULT_CONTROLLER = "FBMSCTL";
  public static final String DEFAULT_FSM = "FBMSFSM";
  public static final String DEFAULT_DFO = "FBMSDFO";
  public static final String DEFAULT_GVP = "FBMSGVP";
  public static final String ANY_DESCRIPTION = "Any";
  public static final String DEFAULT_ROM = "FBMSROM";
  public static final String CONTROLLER_CODE = "CTL";
  public static final String SDA = "SDA";
  public static final String USA = "USA";
  public static final String INACTIVE_CODE = "I";
  public static final String MEX = "MEX";
  //Controller Constants
  public static final String TOTAL_BW_PRIOR_VER_VM_LIMIT = "TOTAL_BW_PRIOR_VER_VM_LIMIT";
  public static final String NEW_PU_BW_TARGET_VM_LIMIT = "NEW_PU_BW_TARGET_VM_LIMIT";
  public static final String CTL_ROUTING_LIMIT = "CTL_ROUTING_LIMIT";
  public static final String PU_BW_PRIOR_VER_VM_LIMIT = "PU_BW_PRIOR_VER_VM_LIMIT";
  public static final String PU_BW_TARGET_VM_LIMIT = "PU_BW_TARGET_VM_LIMIT";
  public static final String TOTAL_BW_TARGET_VM_LIMIT = "TOTAL_BW_TARGET_VM_LIMIT";
  public static final String TOTAL_VM_LIMIT = "TOTAL_VM_LIMIT";
  

  //FBMS Constants
  public static final String PENDING = "Pending";
  public static final String NOT_REQUIRED = "Not Required";
  public static final String RENTAL_MRENTAL = "MRental";

  public static final String PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE = "1_pact_mvm_vs_cact_mvm";
  public static final String PRIOR_ACT_CURR_ACT_MLV_VM_CODE = "2_pact_svm_vs_cact_mvm";
  public static final String PRIOR_ACT_CURR_ACT_CODE = "3_pact_svm_vs_cact_svm";
  public static final String PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE = "4_pact_mvm_vs_cfct_mvm";
  public static final String PRIOR_ACT_CURR_FCT_MLV_VM_CODE = "5_pact_svm_vs_cfct_mvm";
  public static final String PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE = "6_pest_mvm_vs_cest_mvm";
  public static final String FBMSNG = "FBMSNG";
  public static final long TOT_DEAL_MLV = 50;
  public static final String FLEETRATING_CCC="CCC";


 public static final String PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_DESC = "Prior PY Actuals  - Current PY Actuals";
 public static final String PRIOR_ACT_CURR_ACT_MLV_VM_DESC = "Prior PY Actuals (Sales VM) - Current PY Actuals";
  public static final String PRIOR_ACT_CURR_ACT_DESC = "Prior PY Actuals (Sales VM) - Current PY Actuals (Sales VM)";
  public static final String PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_DESC ="Prior PY Actuals - Current PY Estimates";
  public static final String PRIOR_ACT_CURR_FCT_MLV_VM_DESC ="Prior PY Actuals (Sales VM) - Current PY Estimates";
  public static final String PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_DESC ="Prior PY Estimates  - Current PY Estimates";
  public static final String SUBMIT_PROPOSAL="SUBMIT_PROPOSAL";
  public static final String SAVE_PROPOSAL="SAVE_PROPOSAL";
  public static final String APPROVE_PROPOSAL="APPROVE_PROPOSAL";
  public static final String RECALL_PROPOSAL="RECALL_PROPOSAL";
  public static final String REJECT_PROPOSAL="REJECT_PROPOSAL";
  public static final String REVISE_PROPOSAL="REVISE_PROPOSAL";
  public static final String SENDBACK_PROPOSAL="SENDBACK_PROPOSAL";
  public static final String NEXTDEAL_APPROVE="NEXTDEAL_APPROVE";

  public static final String DEFAULT_FNA = "FBMSFNA";
  public static final String RAM = "RAM";
  public static final String NAM = "NAM";
  public static final String FNA = "FNA";
  public static final String GVP = "GVP";
  public static final String CEO = "CEO";
  public static final String SAM = "SAM";
  public static final String CBM = "CBM";
  public static final String FSM = "FSM";
  public static final String DFO = "DFO";
  public static final String GAM = "GAM";
  public static final String GOM = "GOM";
  public static final String FRD = "FRD";
  public static final String FRM = "FRM";
  public static final String MPM = "MPM";
  public static final String ADM = "ADM";
  public static final String FIM = "FIM";
  public static final String FID = "FID";
  public static final String FIA = "FIA";
  public static final String FNM = "FNM";
  public static final String NAC = "NAC";

  public static final String FLEET_TYPE_A = "AAA";
  public static final String FLEET_TYPE_B = "BBB";
  public static final String FLEET_TYPE_C = "CCC";
  public static final String BUSINESS_CASE = "BC";
  
  public static final String LINE_TOTAL = "LineTotal";
  public static final String GRAND_TOTAL = "GrandTotal";
  

  public static final String DEFAULT_CONTROLLER_MEX = "FOMCTL";
  
  public static final String PROC_PROPOSAL_KEY = "i_nProposalKey";
  
  public static final String PROC_OK = "o_nOk";
  
  public static final String PROC_ERROR_MSG = "o_sErrmsg";
  
  public static final String JAVA_STRING = "java.lang.String";
  
  public static final String COMP_TOTAL_VM = "getTotalVarMktgAbsouluteAmt";
  
  public static final String FONT_END_TAG = "&nbsp;</font>";
  
  public static final String FONT_BEGIN_GREEN = "<font color='green'>";
  
  public static final String FONT_BEGIN_RED = "<font color='red'>(";
  
  public static final String FONT_END_TAG1 = "</font>";
  
  public static final String FONT_BEGIN_BRACE = "(";
  
  public static final String FONT_END_BRACE = ")";
  
  public static final String FONT_BEGIN_TAG = "<font>";
  
  public static final String VALIDATE_METHOD = "validateAndConstruct";
  
  public static final String CONSUMER_TOKEN = "ConsumerAccessToken";
  
  public static final String PROPOSAL = "Proposal";
  
  public static final String NON_FINANCIAL_STATUS = "getNonFinancialSubmitStatus";
  
  public static final String RULE_ENGINE_FOUND = "Found service rule engines : ";
  
  public static final String VALIDATION_FAILED = "Validation failed";
  
  public static final String VALIDATION_PASS = "All the validations are passed";
  
  public static final String COMPLETED_DB = "Completed DB processes";
  
  public static final String RULE_ENGINE_NOT_AVAILABLE = "Rule engine is not available for given country Code";
  
  public static final String PARAMETERS = "parameters";
  
  public static final String REST_API_ATTEMPT = "Tried Rest Api Call Attempt: %d";
  
  public static final String REST_API_ALL_FAILED = "All Retry-Rest Api Call Attempts Failed!";
  
  public static final String REST_API_FINKEY = "finKey";
  
  public static final String REST_API_PROPOSALYR = "proposalYr";
  
  public static final String REST_API_PROPOSALKEY = "proposalKey";
  
  public static final String REST_API_PROPOSAL_YR_VER = "proposalYrVer";
  
  public static final String URV_EXISTS = "URVEXISTS";
  
  private ApprovalConstants() {
    throw new IllegalStateException("Utility class");
  }

}

