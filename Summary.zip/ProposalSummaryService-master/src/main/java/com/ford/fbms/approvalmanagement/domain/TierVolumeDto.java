package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMA03_TIER_VOLUME database table.
 *
 */
@Entity
@Table(name = TierVolumeDto.TABLE_NAME)
// @NamedQuery(name="TierVolume.findAll", query="SELECT m FROM TierVolume m")
public class TierVolumeDto implements Serializable {

  private static final long serialVersionUID = 1L;
  public static final String TABLE_NAME = "MFBMA03_TIER_VOLUME";
  @EmbeddedId
  private TierVolumePk tierVolumePk;

  @Column(name = "FBMA03_TIER_VOLUME_Q")
  private long tierVolume;
  

  /*
   * //bi-directional many-to-one association to Mfbma01Proposal
   *
   * @ManyToOne(fetch=FetchType.LAZY)
   *
   * @JoinColumn(name="FBMA01_PROPOSAL_K") private Proposal proposal;
   */

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA03_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBMA03_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBMA03_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA03_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBMA03_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBMA03_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}
