package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.AccountSaleSummaryPK;
import com.ford.fbms.approvalmanagement.domain.AccountSalesSummaryDto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface AccountSalesSummaryRepository extends JpaRepository<AccountSalesSummaryDto, AccountSaleSummaryPK> {
  @Query(value = "WITH\r\n" +
      "	SUBFIN\r\n" +
      "AS\r\n" +
      "(\r\n" +
      "SELECT\r\n" +
      "	A01.FBMA01_PROPOSAL_K, \r\n" +
      "	A01.FBMD12_PROPOSAL_YEAR_C,\r\n" +
      "	A01.FBME01_FIN_MASTER_K,\r\n" +
      "	A01.FBME01_FIN_MASTER_K FBME01_SUBS_FIN_K\r\n" +
      "FROM\r\n" +
      "	{h-schema}MFBMA01_PROPOSAL A01 WHERE A01.FBMA01_PROPOSAL_K =:proposalKey \r\n" +
      "UNION \r\n" +
      "SELECT\r\n" +
      "	A01.FBMA01_PROPOSAL_K,\r\n" +
      "	A01.FBMD12_PROPOSAL_YEAR_C,\r\n" +
      "  	A01.FBME01_FIN_MASTER_K,\r\n" +
      "	A07.FBME01_SUBS_FIN_K\r\n" +
      "FROM\r\n" +
      "	{h-schema}MFBMA01_PROPOSAL A01,\r\n" +
      "	{h-schema}MFBMA07_PROPOSAL_SUBSIDIARY A07\r\n" +
      "WHERE\r\n" +
      "	A01.FBMA01_PROPOSAL_K = A07.FBMA01_PROPOSAL_K\r\n" +
      "  AND A01.FBMA01_PROPOSAL_K = :proposalKey \r\n" +
      ")\r\n" +
      "SELECT SUBFIN.FBME01_FIN_MASTER_K, \r\n" +
      "       E22.FBMD12_PROPOSAL_YEAR_C,\r\n" +
      "       'O' FBMD09_SEG_C,\r\n" +
      "       '9999' FBME03_BDYSTL_K, \r\n" +
      "       E22.FBME22_INCTV_TYP_C , \r\n"+
      "       SUM(FBME22_ORDRD_MTD_R) FBME22_ORDRD_MTD_R ,\r\n" +
      "       SUM(FBME22_SLD_MTD_R) FBME22_SLD_MTD_R, \r\n" +
      "		  SUM(FBME22_UNSCHEDD_R)  FBME22_UNSCHEDD_R, \r\n " +
      "       SUM(FBME22_SCHEDD_R)   FBME22_SCHEDD_R, \r\n" +
      "       SUM(FBME22_SUBMTD_R)   FBME22_SUBMTD_R, \r\n"+
      "       SUM(FBME22_BUCKD_R) FBME22_BUCKD_R, \r\n"+
      "		  SUM(FBME22_PRODD_R) FBME22_PRODD_R , \r\n"+
      "       SUM(FBME22_RELD_R)  FBME22_RELD_R,  \r\n"+
      "       SUM(FBME22_CNCLD_MTD_R)   FBME22_CNCLD_MTD_R,  \r\n "+
      " 	  SUM(FBME22_STK_R)   FBME22_STK_R,   "+
      "       SUM(FBME22_OTHR_R)   FBME22_OTHR_R" +
      "  FROM " +
      "  SUBFIN,{h-schema}MFBME22_ACCT_SALES_SUMMARY E22\r\n" +
      "WHERE \r\n" +
      "      SUBFIN.FBME01_SUBS_FIN_K = E22.FBME01_FIN_MASTER_K AND \r\n" +
      "      SUBFIN.FBMD12_PROPOSAL_YEAR_C=E22.FBMD12_PROPOSAL_YEAR_C\r\n" +
      "      AND      E22.FBME22_INCTV_TYP_C='C'\r\n" +
      "GROUP BY SUBFIN.FBME01_FIN_MASTER_K, E22.FBMD12_PROPOSAL_YEAR_C,E22.FBME22_INCTV_TYP_C", nativeQuery = true)
  List<AccountSalesSummaryDto> queryCalculatedOtdStdSummaryByProposal(@Param("proposalKey") final Long proposalKey);
}
