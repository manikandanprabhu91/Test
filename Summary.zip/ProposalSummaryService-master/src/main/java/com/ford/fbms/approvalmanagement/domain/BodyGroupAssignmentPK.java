package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;



/**
 * The primary key class for the MFBMD65_BODY_GROUP_ASSIGNMENT database table.
 * 
 */
@Embeddable
@Getter
@Setter
public class BodyGroupAssignmentPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME03_BDYSTL_K")
	private BodyStyleDto bodystyleSaKey;

	// bi-directional many-to-one association to Mfbme03BodyStyle
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME03_BDYGRP_K")
	private BodyStyleDto mfbme03BodyStyle;


	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true; }
		if (obj == null) {
			return false; }
		if (!(obj instanceof BodyGroupAssignmentPK)) {
			return false; }
		BodyGroupAssignmentPK other = (BodyGroupAssignmentPK) obj;
		if (bodystyleSaKey != other.bodystyleSaKey) {
			return false; }
		if (mfbme03BodyStyle == null) {
			if (other.mfbme03BodyStyle != null) {
				return false; }
		} else if (!mfbme03BodyStyle.equals(other.mfbme03BodyStyle)) {
			return false; }
		return true;
	}

}