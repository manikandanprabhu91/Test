package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The primary key class for the MFBME18_BODY_FINANCIAL database table.
 * 
 */
@Embeddable
public class BodyFinancialPKDto implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME18_EFFECTIVE_S")
	private java.util.Date fbme18EffectiveS;

	// bi-directional many-to-one association to Mfbmd09Segment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD09_SEG_C")
	private SegmentDto segment;

	// bi-directional many-to-one association to Mfbme03BodyStyle
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME03_BDYSTL_K")
	private BodyStyleDto bodyStyle;

	// bi-directional many-to-one association to Mfbme50AccountClass

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bodyStyle == null) ? 0 : bodyStyle.hashCode());
		result = prime * result + ((fbme18EffectiveS == null) ? 0 : fbme18EffectiveS.hashCode());
		result = prime * result + ((segment == null) ? 0 : segment.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;}
		if (obj == null) {
			return false;}
		if (!(obj instanceof BodyFinancialPKDto)) {
			return false;}
		BodyFinancialPKDto other = (BodyFinancialPKDto) obj;
		if (bodyStyle == null) {
			if (other.bodyStyle != null)
				return false;
		} else if (!bodyStyle.equals(other.bodyStyle))
			return false;
		if (fbme18EffectiveS == null) {
			if (other.fbme18EffectiveS != null)
				return false;
		} else if (!fbme18EffectiveS.equals(other.fbme18EffectiveS)) {
			return false;}
		if (segment == null) {
			if (other.segment != null) {
				return false;}
		} else if (!segment.equals(other.segment)) {
			return false;}
		return true;
	}


}