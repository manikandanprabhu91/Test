package com.ford.fbms.approvalmanagement.domain;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for FBMS_A12_AGG_VIEW model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Entity
@Table(name = "FBMS_A12_AGG_VIEW")
@Getter
@Setter
public class AggregateIncentiveViewDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "FBMA01_PROPOSAL_K")
  private Long proposalKey;

  @Column(name = "FBMA12_AGGREGATE_INCT_A")
  private Long incentive;
}
