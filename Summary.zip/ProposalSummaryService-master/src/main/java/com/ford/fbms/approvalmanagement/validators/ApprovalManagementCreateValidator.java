package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ApprovalRequest;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate Addresses.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class ApprovalManagementCreateValidator implements Validator {

  @Autowired
  protected  ApprovalProcessRepository approvalProcessRepository;

  @Autowired
  protected  FordPersonRepository fordPersonRepository;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(
      final ApiParams apiParams, final Object obj,
      final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

    ApprovalRequest approvalRequest = (ApprovalRequest) obj;
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .message("Inside Approval Management validator"));

    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();

    FordPersonDto fordPersonDto = new FordPersonDto();

    if ("C".equals(approvalRequest.getSegmentGroup())) {
      fordPersonDto = fordPersonRepository.findIdAndKey(apiParams.getUserId());
    }
    if (!fordPersonDto.equals(null)) {
      genericResponseWrapper.setFordPersonDto(fordPersonDto);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}