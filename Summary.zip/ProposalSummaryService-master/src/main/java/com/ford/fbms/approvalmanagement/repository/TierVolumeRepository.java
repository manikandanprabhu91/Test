package com.ford.fbms.approvalmanagement.repository;


import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between direction model and table.
 *
 * @author NACHUTHA on 3/17/2021.
 */
@Repository
public interface TierVolumeRepository extends JpaRepository<TierVolumeDto, Long> {
  @Query(value="Select * from {h-schema}MFBMA03_TIER_VOLUME tier " +
      "where tier.FBMA01_PROPOSAL_K = :proposalKey",nativeQuery = true)
  List<TierVolumeDto> findAllByProposalKey(@Param("proposalKey")long proposalKey);
}
