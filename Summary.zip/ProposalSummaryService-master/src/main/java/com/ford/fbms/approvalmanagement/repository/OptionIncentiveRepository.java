package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.OptionIncentiveDto;

public interface OptionIncentiveRepository extends JpaRepository<OptionIncentiveDto, Long> {
	
	
	@Query(value="SELECT A05.* FROM {h-schema}MFBMA05_OPTION_INCENTIVE A05"
			+ " WHERE A05.FBMA04_PVI_K=:pviKey"
			+ " AND Isnull(A05.FBMD70_COMMON_OPTION_C, 'VALID') NOT IN ('ABS', 'UTC', 'LOY', 'CHNG', 'UTD', 'MSC', 'EOI' )",nativeQuery = true)
	Optional<List<OptionIncentiveDto>> findByValidOptionIncentiveByVehicleLineIncentive(@Param("pviKey") Long pviKey);
}
