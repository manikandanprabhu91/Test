package com.ford.fbms.approvalmanagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.ServiceDefinition;
import com.ford.fbms.approvalmanagement.domain.ServiceDefinitionPK;

public interface ServiceDefinitionRepository extends JpaRepository<ServiceDefinition, ServiceDefinitionPK> {
	
	
	@Query("select sd from ServiceDefinition sd where sd.serviceDefinitionPK.mfbme15FinOpUntMaster.finOpUnitMasterSaKey=:fouMasterSakey")
	Optional<List<ServiceDefinition>> findByFinOpUnitMasterSaKey(@Param("fouMasterSakey") Long fouMasterSakey);
}
