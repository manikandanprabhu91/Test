package com.ford.fbms.approvalmanagement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.PyCountryDefinition;

/**
 *
 *
 * @author vvm on 4/27/2021.
 */
@Repository
public interface PyCountryDefinitionRepository extends JpaRepository<PyCountryDefinition, Long> {
	
	@Query(value = "select pcd from PyCountryDefinition pcd where pcd.pyDefinition.proposalYearCode=:proposalYear and pcd.country.countryIso3Code=:countryCode")
	Optional<PyCountryDefinition> findByPyAndCountryCode(@Param("proposalYear") int proposalYear,@Param("countryCode") String countryCode);
	
  }
