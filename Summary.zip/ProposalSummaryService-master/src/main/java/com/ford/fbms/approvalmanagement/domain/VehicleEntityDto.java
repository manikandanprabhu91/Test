package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME49_VEHICLE_ENTITY database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = VehicleEntityDto.TABLE_NAME)
// @NamedQuery(name="VehicleEntity.findAll", query="SELECT m FROM VehicleEntity
// m")
public class VehicleEntityDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME49_VEHICLE_ENTITY";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME49_VEHICLE_ENTITY_K")
	private long vehicleEntitySaKey;

	@Column(name = "FBME49_BODY_STYLE_C")
	private String bodyStyleCode;

	@Column(name = "FBME49_DERIVATIVE_C")
	private String derivativeCode;

	@Column(name = "FBME49_ENGINE_C")
	private String engineCode;

	@Column(name = "FBME49_EXCLUDE_F")
	private String excludeFlag;

	@Column(name = "FBME49_EXCLUDE_S")
	private Timestamp excludeTS;

	@Column(name = "FBME49_LOCAL_SVP_C")
	private String localSvpCode;

	@Column(name = "FBME49_MODEL_C")
	private String modelCode;

	@Column(name = "FBME49_MODEL_YEAR_C")
	private String modelYearCode;

	@Column(name = "FBME49_PAYLOAD_C")
	private String payloadCode;

	@Column(name = "FBME49_RT4_F")
	private String rt4Flag;

	@Column(name = "FBME49_TRANSMISSION_C")
	private String transmissionCode;

	@Column(name = "FBME49_VEHICLE_ENTITY_C")
	private String vehicleEntityCode;

	// bi-directional many-to-one association to Mfbma04ProposalVehlnInctv
	/*
	 * @OneToMany(mappedBy="vehicleEntity") private List<ProposalVehlnInctv>
	 * proposalVehlnInctvs;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma06PropExclusion
	 * 
	 * @OneToMany(mappedBy="vehicleEntity") private List<ProposalExclusion>
	 * propExclusions;
	 */

	// bi-directional many-to-one association to Mfbme41PdMarket
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME41_PD_MARKET_C")
	private PdMarketDto pdMarket;

	// bi-directional many-to-one association to Mfbme51UscStatus
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME51_USC_STATUS_C")
	private UscStatusDto uscStatus;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME49_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME49_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME49_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME49_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME49_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME49_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
