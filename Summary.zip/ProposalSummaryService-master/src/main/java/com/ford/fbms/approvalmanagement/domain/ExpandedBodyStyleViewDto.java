package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME03_BODY_STYLE database table.
 *
 */
@Setter
@Getter
@Entity
@Table(name = ExpandedBodyStyleViewDto.TABLE_NAME)
// @NamedQuery(name="BodyStyle.findAll", query="SELECT m FROM BodyStyle m")
public class ExpandedBodyStyleViewDto implements Serializable {

  private static final long serialVersionUID = 1L;
  public static final String TABLE_NAME = "FBMS_E03_EXPANDED_VIEW";
  
  @EmbeddedId
  private ExpandedBodyStyleViewPK id;
  
  
  
  @Column(name = "FBME03_BODY_GROUP_IND_F")
  private String bodyGroupIndFlag;
  
  @Column(name = "TYPE")
  private String type;
  
 


  }
