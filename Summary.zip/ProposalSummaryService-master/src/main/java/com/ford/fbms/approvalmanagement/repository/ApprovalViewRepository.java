package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.ApprovalViewDto;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ApprovalViewRepository extends JpaRepository<ApprovalViewDto, String> {
  @Query(value = "SELECT TOP 1 * FROM (SELECT APP_VIEW.* FROM FBMS.FBMS_APPROVAL_VIEW APP_VIEW ,FBMS.MFBMD13_PY_COUNTRY_DEFINITION D13\r\n"
  		+ "WHERE  D13.FBMD42_COUNTRY_ISO3_C = :countryCode  "
  		+ "AND APP_VIEW.FBMD12_PROPOSAL_YEAR_C = D13.FBMD12_PROPOSAL_YEAR_C  "
  		+ "AND D13.FBMD13_ARCHIVE_F = 'N'  "
  		+ "AND APP_VIEW.A09_FBMD11_PROPOSAL_STATUS_C='SUB' "
  		+ "AND APP_VIEW.FBMD03_SUBMITTED_TO_CDSID_C = :cdsidCode  "
  		+ ") STAGE \r\n"
  		+ "ORDER BY FBMA01_PROPOSAL_SUB_Y DESC", nativeQuery = true)
  ApprovalViewDto queryApprovalNextDealUSAByCountryCodeCdsidCode(@Param("countryCode") final String countryCode ,@Param("cdsidCode") final String cdsidCode);
  
  
  @Query(value ="SELECT TOP 1 * FROM (SELECT APP_VIEW1.* FROM (SELECT APP_VIEW.* FROM FBMS.FBMS_APPROVAL_VIEW APP_VIEW ,FBMS.MFBMD13_PY_COUNTRY_DEFINITION D13  "
  		+ "WHERE D13.FBMD42_COUNTRY_ISO3_C = :countryCode "
		+  "AND APP_VIEW.FBMD12_PROPOSAL_YEAR_C = D13.FBMD12_PROPOSAL_YEAR_C "
  		+  "AND D13.FBMD13_ARCHIVE_F = 'N'  "
		+  "AND APP_VIEW.A09_FBMD11_PROPOSAL_STATUS_C='SUB' "
  		+ ")APP_VIEW1, FBMS.MFBME01_FIN_MASTER E01,FBMS.MFBMD14_REPORT_LEVEL D14 "
		+ "WHERE  E01.FBMD42_COUNTRY_ISO3_C = :countryCode "
  		+  "AND E01.FBME01_FIN_MASTER_K =APP_VIEW1.FBME01_FIN_MASTER_K "
		+ "AND D14.FBMD14_RPTLVL_C = APP_VIEW1.A09_FBMD14_RPTLVL_C "
  		+ "AND D14.FBMD42_COUNTRY_ISO3_C = :countryCode   "
		+ "AND D14.FBMD14_TITLE_C = :titleCode  "
  		+ ")STAGE  "
		+ "ORDER BY FBMA01_PROPOSAL_SUB_Y DESC ",nativeQuery = true)
  ApprovalViewDto queryApprovalNextDealUSACTLByCountryCodeTitleCode(@Param("countryCode") final String countryCode ,@Param("titleCode") final String titleCode);	   
		  		
}
