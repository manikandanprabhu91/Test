package com.ford.fbms.approvalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.NewBodyStylePKDto;
import com.ford.fbms.approvalmanagement.domain.NewBodyStyleViewDtO;

@Repository
public interface NewBodyStyleRepository extends JpaRepository<NewBodyStyleViewDtO, NewBodyStylePKDto>{
	
		@Query(value = "select * from {h-schema}FBMS_NEW_BODYSTYLE_VIEW where FBME03_NEW_BDYSTL_K=:oldBodyStyle", nativeQuery = true)
		<Optional>NewBodyStyleViewDtO findNewBodystyleByOldBodyStyle(@Param("oldBodyStyle") final Long oldBodyStyle);
	}



