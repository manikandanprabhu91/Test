package com.ford.fbms.approvalmanagement.repository;


import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ProposalStatusRepository extends JpaRepository<ProposalStatusDto, String> {
  
}
