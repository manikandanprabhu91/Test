package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME22_ACCT_SALES_SUMMARY database table.
 *
 */
@SuppressWarnings("serial")
@Getter
@Setter
@Entity
@Table(name = AccountSalesSummaryDto.TABLE_NAME)
public class AccountSalesSummaryDto implements Serializable{

  public static final String TABLE_NAME = "MFBME22_ACCT_SALES_SUMMARY";

  @EmbeddedId
  private AccountSaleSummaryPK id;


  @Column(name = "FBME22_BUCKD_R")
  private BigDecimal bucketed;

  @Column(name = "FBME22_CNCLD_MTD_R")
  private BigDecimal vehiclesCancelledMonthToDate;

  @Column(name = "FBME22_INCTV_TYP_C")
  private String incentiveType;

  @Column(name = "FBME22_ORDRD_MTD_R")
  private BigDecimal vehiclesOrderedMonthToDate;

  @Column(name = "FBME22_OTHR_R")
  private BigDecimal other;

  @Column(name = "FBME22_PRODD_R")
  private BigDecimal produced;

  @Column(name = "FBME22_RELD_R")
  private BigDecimal released;

  @Column(name = "FBME22_SCHEDD_R")
  private BigDecimal scheduledVehiclesMonthToDate;

  @Column(name = "FBME22_SLD_MTD_R")
  private int vehiclesSoldMonthToDate;

  @Column(name = "FBME22_STK_R")
  private BigDecimal stocked;

  @Column(name = "FBME22_SUBMTD_R")
  private BigDecimal vehicleOrdersSubmittedMonthToDate;

  @Column(name = "FBME22_UNSCHEDD_R")
  private BigDecimal unscheduledVehiclesMonthToDate;

}
