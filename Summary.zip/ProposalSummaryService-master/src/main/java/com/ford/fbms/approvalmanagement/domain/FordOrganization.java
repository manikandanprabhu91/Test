package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD21_FORD_ORGANIZATION database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = FordOrganization.TABLE_NAME)
// @NamedQuery(name="FordOrganization.findAll", query="SELECT m FROM
// FordOrganization m")

public class FordOrganization implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD21_FORD_ORGANIZATION";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD21_FORG_C")
	private String fordOrgCode;

	@Column(name = "FBMD21_FORG_X")
	private String fordOrgDescription;

	/*
	 * //bi-directional many-to-one association to Mfbmc03Direction
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<Direction>
	 * directions;
	 * 
	 * //bi-directional many-to-one association to Mfbmc07FleetPerson
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<FleetPerson>
	 * fleetPersons;
	 * 
	 * //bi-directional many-to-one association to Mfbmc14AccountNote
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<AccountNote>
	 * accountNotes;
	 * 
	 * //bi-directional many-to-one association to Mfbmc17SentEmail
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<SentEmail>
	 * sentEmails;
	 * 
	 * //bi-directional many-to-one association to Mfbmc18ReceivedEmail
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<ReceivedEmail>
	 * receivedEmails;
	 * 
	 * //bi-directional many-to-one association to Mfbmd03FordPerson
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private List<FordPerson>
	 * fordPersons;
	 * 
	 * //bi-directional many-to-one association to Mfbmd19AcctPreferenceType
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private
	 * List<AcctPreferenceType> acctPreferenceTypes;
	 * 
	 * //bi-directional many-to-one association to Mfbmd22PersPreferenceType
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private
	 * List<PersonPreferenceType> persPreferenceTypes;
	 * 
	 * //bi-directional many-to-one association to Mfbmd76BulletinOrganization
	 * 
	 * @OneToMany(mappedBy="mfbmd21FordOrganization") private
	 * List<BulletinOrganization> bulletinOrganizations;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD21_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD21_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD21_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD21_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD21_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD21_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
