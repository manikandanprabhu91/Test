package com.ford.fbms.approvalmanagement.util;

/**
 * A class for constants.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public final class Constants {

  public static final String SUCCESS_TEXT = "SUCCESS";
  public static final String SUCCESS_CREATE = "Success : Resource Created";
  public static final String SUCCESS_UPDATE = "Success : Resource Updated";
  public static final String FAILURE_TEXT = "FAILURE";
  public static final String MULTI_STATUS =
      "Multi String : Part of the request succeeded but " + "other parts did not.";
  public static final String NOT_FOUND = "Not Found:The requested resource could not be found but "
      + "may be available in the future.(System Generated error)";
  public static final String BAD_REQUEST = "Bad Request:The server cannot or will not process "
      + "the request due to an apparent client error.Header and Input Validation";
  public static final String UNAUTHORIZED = "Unauthorized:User might not have the necessary "
      + "credentials.Indicates an expired or otherwise invalid token.Indicates that a token is "
      + "required but was not submitted";
  public static final String SERVER_ERROR = "Internal Server Error:A generic error message, "
      + "given when an unexpected condition was encountered ";
  public static final String FORBIDDEN =
      "Forbidden: No permission for the resource being " + "requested. (System Generated error)";
  public static final String HTTP_REQUEST_METHOD_NOT_SUPPORTED =
      "Not Supported: HTTP Method " + "not allowed";
  public static final String HTTP_412_API_MSG =
      "Required Field(s) is/are missing:Required fields " + "are not in the request";
  public static final String HTTP_415_API_MSG = "The server refuses to accept the request because"
      + " the payload format is in an unsupported format";
  public static final String HTTP_417_API_MSG = "Invalid field(s) is/are entered:Invalid Fields "
      + "are in the request or No data is available to be returned";
  public static final String HTTP_429_API_MSG = "user has sent too many requests in a given "
      + "amount of time";
  public static final String HTTP_503_API_MSG = "Service Unavailable:Service  is currently "
      + "unavailable (because it is overloaded or down for maintenance)";
  public static final String HTTP_4XX_API_MSG = "Client Side Exception occured"
      + "Either the client service has been moved or unavailable at the moment";
  // Thread statics
  public static final String SERVICE_GROUP_NAME = "FBMSServices";
  public static final String REQUEST_SERVICE_ID = "serviceId";
  public static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-ID";
  public static final String VCAP_REQUEST_HEADER_NAME = "X-Vcap-Request-Id";
  public static final String BUILD_VERSION_HEADER_NAME = "X-Build-Version";
  public static final String SPAN_ID_HEADER_NAME = "X-B3-SpanId";
  public static final String TRACE_ID_HEADER_NAME = "X-B3-TraceId";
  public static final String AUTHORIZATION_HEADER_NAME = "Authorization";
  // Messages
  public static final String UNABLE_TO_GET_NOT_NULL_FIELDS = "Unable to get not null fields";
  // Common variables
  public static final String COLON_SLASHES = "://";
  public static final String COLON = ":";
  public static final String DOLLAR = "$";
  public static final String BLANK = "";
  public static final String SPACE = " ";
  public static final String SLASH = "/";
  public static final String COMMA = ",";
  public static final String PLUS = "+";
  public static final String TABLE = "Table";
  public static final String QUESTION_MARK = "?";
  public static final String DASH = "--";
  public static final String HYPHEN = "-";
  public static final String SERVICE_FIELD_NAME = "service";
  public static final String Y = "Y";
  public static final String ZERO = "0";

  //Notification Constants
  public static final String POST = "POST";
  public static final String PUT = "PUT";
  public static final String ORGANIZATION_INFO = "Unknown";
  public static final String EVENT_INITIATOR_NAME = "eventInitiatorName";
  public static final String EVENT_TYPE = "eventType";
  public static final String EVENT_REQUEST_TIMESTAMP = "evenRequestTimeStamp";
  public static final String EVENT_NAME = "eventName";
  // Request Contstants
  public static final String REQUEST_CORRELATION_ID_HEADER = "X-Correlation-ID";

  public static final String REQUEST_FIELD_NAME = "Request";
  public static final String RESPONSE_FIELD_NAME = "Response";
  public static final String REQUEST_STATUS_NEW = "New";
  public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
  public static final String REQUEST_STATUS_FAILURE = "FAILURE";
  public static final String DATE_FORMAT_YYYY_MM_DD_HR_MIN_SEC = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  public static final String CREATE_APPROVAL = "createApproval";
  public static final String GET_APPROVAL = "getApproval";
  public static final String DELETE_APPROVAL = "deleteApproval";
  public static final String GET_VOLUME_FINANCIAL_OPTIONS = "getVolumeFinancialOptions";
  public static final String GET_FINANCIAL_LIST = "getFinancialList";
  public static final String GET_TOTAL_AVG_FINANCIAL = "getTotalAvgFinancials";
  public static final String VALIDATE_ACTIONS = "validateActions";
    public static final String APPROVE_PROPOSAL = "approveProposal";
  public static final String GET_ACTUAL_LIST ="getActualList";
  public static final String GET_FORECAST_LIST ="getForecastList";
  public static final String SUBMIT_PROPOSAL = "submitProposal";
  public static final String SUBMIT_NON_FINANCIAL_PROPOSAL = "submitNonFinancialProposal";
  public static final String SENDBACK_PROPOSAL = "sendBackProposal";

  public static final String REQUESTER_ID = "Requester ID.";
  public static final String INVALID_REQUESTID = "Invalid Requester ID";
  public static final String INVALID_LETTER_SOURCE = "Invalid Letter Source";
  public static final String COUNTRY_CODE = "Country Code.";
  public static final String INVALID_COUNTRYCODE = "Invalid Country Code";
  public static final String INVALID_LENGTH_COUNTRYCODE = "Invalid length of Country Code";
  public static final String REQUESTERID_REGEX = "^[A-Za-z0-9]{1,30}$";
  public static final String COUNTRYCODE_REGEX = "^[A-Za-z]{3}$";
  public static final String DEFAULT_ALPHA_NUMERIC_REGEX="^[a-zA-Z0-9]+$";
  public static final String DEFAULT_ALPHA_REGEX="^[a-zA-Z]+$";

  public static final String MAINTAIN_FINANCIAL_DATA_SP = "maintainFinancialDataSp";
  public static final String RECALL_PROPOSAL = "recallProposal";
  public static final String SAVE_PROPOSAL = "saveProposal";
  public static final String APPROVAL_CHAIN = "approvalChain";
  public static final String REJECT_PROPOSAL = "rejectProposal";
  public static final String REVISE_PROPOSAL = "reviseProposal";
  public static final String PROCESS_SUMMARY_AND_SUBMIT = "processSummaryAndSubmit";

  public static final String INVALID_REQUESTER_ID_LENGTH = "Invalid length of Requester ID";
  public static final String INVALID_REQUESTER_ID="Invalid Requester ID";
  public static final String INVALID_COUNTRY_CODE_LENGTH="Invalid length of Country Code";
  public static final String INVALID_COUNTRY_CODE="Invalid Country Code";
  public static final String INVALID_FIN_KEY_LENGTH="Invalid length of Fin Key";
  public static final String INVALID_PROPOSAL_KEY_LENGTH="Invalid length of Proposal Key";

  public static final String PROPOSAL_TO_EXCEL_COMMENTS_DTL_LOCATION = "/Templates/ProposalCommentsDetailCell.xml";
  public static final String PROPOSAL_TO_EXCEL_SUMMARY_DTL_LOCATION = "/Templates/ProposalSummayDetailCell.xml";
  public static final String PROPOSAL_TO_EXCEL_SUBSID_ROW_LOCATION = "/Templates/ProposalToExcelSubRow.xml";
  public static final String PROPOSAL_TO_EXCEL_TMPLT_LOCATION = "/Templates/ProposalToExcelTmplt.xml";
  public static final String PROPOSAL_TO_EXCEL_VOL_INC_ROW_LOCATION = "/Templates/ProposalToExcelVolIncRow.xml";

  public static final String TOKEN_REGEX =
      "^[Bb]earer [A-Za-z0-9-_=]+.[A-Za-z0-9-_=]+.?[A-Za-z0-9-_.+/=]*$";

  private Constants() {
    throw new IllegalStateException("Utility class");
  }
}
