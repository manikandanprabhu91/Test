package com.ford.fbms.approvalmanagement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.PyVehicleDefinition;

/**
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface PyVehicleDefinitionRepository extends JpaRepository<PyVehicleDefinition, Long> {


	@Query("select PVD from PyVehicleDefinition PVD where PVD.vehicleLine.vehlnSaKey=:saKey and PVD.pyDefinition.proposalYearCode=:proposalYear")
	Optional<PyVehicleDefinition> findByProposalYearVehicleLine(@Param("proposalYear") int proposalYear,@Param("saKey") Long saKey);
}
