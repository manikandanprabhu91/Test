package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMD73_SERVICE_OPTION database table.
 * 
 */
@Entity
@Table(name = ServiceOption.TABLE_NAME)
// @NamedQuery(name="ServiceOption.findAll", query="SELECT m FROM ServiceOption
// m")
public class ServiceOption implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD73_SERVICE_OPTION";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD73_SERVICE_OPT_C")
	private String serviceOptCode;

	@Column(name = "FBMD73_SERVICE_OPT_X")
	private String serviceOptDescription;

	/*
	 * //bi-directional many-to-one association to Mfbmd74ServiceAttrOption
	 * 
	 * @OneToMany(mappedBy="serviceOption") private List<ServiceAttributeOption>
	 * serviceAttrOptions;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD73_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD73_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD73_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD73_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD73_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD73_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
