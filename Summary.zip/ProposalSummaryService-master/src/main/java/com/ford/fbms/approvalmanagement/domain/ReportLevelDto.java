package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD14_REPORT_LEVEL database table.
 *
 */
@Setter
@Getter
@Entity
@Table(name = "MFBMD14_REPORT_LEVEL")
public class ReportLevelDto implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBMD14_RPTLVL_K")
  private long saKey;

  @Column(name = "FBMD14_COMMENT_X")
  private String commentDesc;

  @Column(name = "FBMD14_MAX_APPROVAL_A")
  private BigDecimal maxApprovalAmount;

  @Column(name = "FBMD14_MIN_APPROVAL_A")
  private BigDecimal minApprovalAmount;

  @Column(name = "FBMD14_RPTLVL_C")
  private int code;

  @Column(name = "FBMD14_TITLE_C")
  private String titleCode;

  @Column(name = "FBMD14_TITLE_X")
  private String titleDesc;

  @Column(name = "FBMD42_COUNTRY_ISO3_C")
  private String country;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMD14_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBMD14_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBMD14_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMD14_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBMD14_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBMD14_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}
