package com.ford.fbms.approvalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;


@Repository
public interface PviExtraInfoRepository extends JpaRepository<PviExtraInfoDto, Long> {
	

}