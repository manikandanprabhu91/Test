package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * The persistent class for the MFBMD65_BODY_GROUP_ASSIGNMENT database table.
 * 
 */
@Entity
@Table(name = "MFBMD65_BODY_GROUP_ASSIGNMENT")
public class BodyGroupAssignment implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BodyGroupAssignmentPK id;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD65_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD65_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMD65_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD65_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD65_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMD65_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
