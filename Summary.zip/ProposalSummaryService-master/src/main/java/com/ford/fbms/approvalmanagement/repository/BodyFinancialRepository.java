package com.ford.fbms.approvalmanagement.repository;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.BodyFinancialDto;



public interface BodyFinancialRepository extends JpaRepository<BodyFinancialDto, Long>{ 

	 @Query(value="SELECT BF.*\r\n"
	 		+ "FROM {h-schema}MFBME18_BODY_FINANCIAL BF,\r\n"
	 		+ "      (SELECT FBME03_BDYSTL_K,\r\n"
	 		+ "             FBMD09_SEG_C,\r\n"
	 		+ "             FBME50_ACCOUNT_CLASS_C,\r\n"
	 		+ "             MAX(FBME18_EFFECTIVE_S) FBME18_EFFECTIVE_S\r\n"
	 		+ "      FROM {h-schema}MFBME18_BODY_FINANCIAL\r\n"
	 		+ "      WHERE FBMD09_SEG_C = :segment AND\r\n"
	 		+"		 FBME50_ACCOUNT_CLASS_C = :accountClass  AND\r\n"
	 		+ "            FBME03_BDYSTL_K = :bodyStyle AND\r\n"
	 		+ "            CONVERT(VARCHAR(25),FBME18_EFFECTIVE_S,101) <= :effectiveDate\r\n"
	 		+ "      GROUP BY FBME03_BDYSTL_K,\r\n"
	 		+ "               FBMD09_SEG_C,\r\n"
	 		+ " FBME50_ACCOUNT_CLASS_C\r\n"
	 		+ "      ) MAXBF\r\n"
	 		+ " WHERE  MAXBF.FBME03_BDYSTL_K = BF.FBME03_BDYSTL_K  AND\r\n"
	 		+ "        MAXBF.FBMD09_SEG_C = BF.FBMD09_SEG_C  AND\r\n"
	 		+ "        MAXBF.FBME18_EFFECTIVE_S =  BF.FBME18_EFFECTIVE_S AND\r\n"
	 		+ "       MAXBF. FBME50_ACCOUNT_CLASS_C =  BF. FBME50_ACCOUNT_CLASS_C"+
			  "",nativeQuery = true)
		  Optional<BodyFinancialDto> findBodyFinancialByBodyStyleSegmentMaxEffectiveDate(@Param("bodyStyle")long bodyStyle,@Param("segment")String segment,@Param("effectiveDate")Date effectiveDate,@Param("accountClass")String accountClass );
}