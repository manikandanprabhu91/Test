package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for Approval Process model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Entity
@Table(name = "MFBME28_CTL_THRESHOLD")
@Getter
@Setter
public class ControllerThresholdDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBME28_CTL_THRESHOLD_K")
  private long thresholdKey;

  @Column(name = "FBME28_CTL_THRESHOLD_C")
  private String thresholdCode;

  @Column(name = "FBME28_EFFECTIVE_S")
  private Date effectiveDate;

  @Column(name = "FBME28_PART_OF_EXCEPTION_F")
  private String partOfException;

  @Column(name = "FBME28_THRESHOLD_A")
  private long thresholdAmount;

  @Column(name = "FBME28_USAGE_X")
  private String usage;

  @Column(name = "FBME28_COMMENT_X")
  private String comment;

}
