package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMD28_FLEET_CATEGORY database table.
 * 
 */
@Entity
@Table(name = FleetCategory.TABLE_NAME)

public class FleetCategory implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD28_FLEET_CATEGORY";

	@Id
	@Column(name = "FBMD28_FLEET_CATEGORY_C")
	private String fleetCategoryCode;

	@Column(name = "FBMD28_FLEET_CATEGORY_X")
	private String fleetCategoryDescription;

	/*
	 * // bi-directional many-to-one association to Mfbmd29CountryVi
	 * 
	 * @OneToMany(mappedBy = "mfbmd28FleetCategory") private List<CountryVi>
	 * countryVis;
	 * 
	 * // bi-directional many-to-one association to Mfbme31FinProfile
	 * 
	 * @OneToMany(mappedBy = "mfbmd28FleetCategory") private List<FinProfile>
	 * finProfiles;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD28_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD28_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD28_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD28_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD28_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD28_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
