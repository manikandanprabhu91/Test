package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.repository.MaintainFinancialDataRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to execute and validate the maintain financial data stored procedures.
 *
 * @author SCHAN115 on 5/7/2021.
 */
@Service
@Slf4j
public class MaintainFinancialDataValidator implements Validator {

  @Autowired
  protected MaintainFinancialDataRepository maintainFinancialDataRepository;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(
      final ApiParams apiParams, final Object approvalRequest,
      final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .message("Inside Maintain Financial Data Validator"));

    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();

    if (apiParams.getProposalKey() != null) {
      Long responseMessage =
          maintainFinancialDataRepository.maintainFinancialData(apiParams.getProposalKey());
      genericResponseWrapper.setFinancialDataStatus(responseMessage);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}