package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import java.util.concurrent.Future;
import org.springframework.scheduling.annotation.Async;

import javax.servlet.http.HttpServletRequest;

/**
 * A validator interface to define activity of all validators.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public interface Validator {

  /**
   * To validate according to the provided validator.
   *
   * @param apiParams        {@link ApiParams}
   * @param masterRuleEngine {@link MasterRuleEngine}
   * @param httpRequest
   * @return {@link GenericResponse}
   */
  @Async("taskExecutor")
  Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                      final Object approvalRequest,
                                                      final MasterRuleEngine masterRuleEngine, final HttpServletRequest httpRequest);
}
