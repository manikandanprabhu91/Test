package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.OptionIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.repository.OptionIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class ESPManager implements Validator {

  
  @Autowired
  private ProposalRepository proposalRepository;
  @Autowired
  protected TierIncentiveRepository tierIncentiveRepo;
  @Autowired
  protected ProposalVehicleLineIncentiveRepository propsalVlRepo;
  @Autowired
  protected TierVolumeRepository tierVolumeRepo;
  @Autowired
  protected OptionIncentiveRepository optionIncentiveRepository;
  

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").message("Inside ProposalAssignmentManager"));
    Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
    boolean validESP =this.validateESP(proposalDTO.get());
    genericResponseWrapper.setIsValidESP(validESP);
    return new AsyncResult<>(genericResponseWrapper);
  }
  
  
	private boolean validateESP(ProposalDto proposal) {
		boolean validESP = true;
		List<ProposalVehicleLineIncentiveDto> lineIncentiveDtos = getVehicleLineIncentiveList(proposal);
		if (null != lineIncentiveDtos && !lineIncentiveDtos.isEmpty()) {

			for (ProposalVehicleLineIncentiveDto sourceVehicleLineIncentive : lineIncentiveDtos) {

				if (sourceVehicleLineIncentive != null) { 
					Optional<ProposalVehicleLineIncentiveDto> sVehicleLineIncentiveRO = this.propsalVlRepo
							.findById(sourceVehicleLineIncentive.getPviSaKey());

					if (sVehicleLineIncentiveRO.isPresent()) {

						List<OptionIncentiveDto> sourceOptionIncentiveList = getOptionIncentiveList(
								sourceVehicleLineIncentive);
						if (sourceOptionIncentiveList != null && !sourceOptionIncentiveList.isEmpty()) {
							for (OptionIncentiveDto sourceOptionIncentiveRO : sourceOptionIncentiveList) {
								if ((sourceOptionIncentiveRO.getEspOption() != null)&&(ApprovalConstants.INACTIVE_CODE
										.equals(sourceOptionIncentiveRO.getEspOption().getEspStatusFlag()))) {
										validESP = false;

									}
							}

						}

					}

				}
			}

		}
		return validESP;
	}
	
	private List<ProposalVehicleLineIncentiveDto> getVehicleLineIncentiveList(
			ProposalDto proposal){
		List<ProposalVehicleLineIncentiveDto> vehLineList = null;
		Optional<List<ProposalVehicleLineIncentiveDto>> vehLineList_Final = propsalVlRepo.findByProposal(proposal);
		if(vehLineList_Final.isPresent()) {
		return vehLineList_Final.get();
		}
		return vehLineList;
	}
	
	public List<OptionIncentiveDto> getOptionIncentiveList(
			ProposalVehicleLineIncentiveDto vlIncentive) {

		Optional<List<OptionIncentiveDto>> oList = this.optionIncentiveRepository
				.findByValidOptionIncentiveByVehicleLineIncentive(vlIncentive.getPviSaKey());

		if (oList.isPresent()) {
			return oList.get();
		} else {
			return new ArrayList<OptionIncentiveDto>();
		}
	}

	
}