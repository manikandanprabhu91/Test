package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.FordPersonDto;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface FordPersonRepository extends JpaRepository<FordPersonDto, String> {
  @Query(value="select * from {h-schema}MFBMD03_FORD_PERSON person "
      + "where person.cdsid = "
      + "(select sprcdsidDescription from FordPersonDto "
      + "where FBMD03_CDSID_C = :cdsid)",nativeQuery = true)
  FordPersonDto findIdAndKey(@Param("cdsid")final String cdsid);
  
  
  @Query(value="SELECT * FROM {h-schema}MFBMD03_FORD_PERSON   "+
  "WHERE FBMD03_UNASSIGNED_FINS_F='Y'  AND FBMD03_GENERIC_NAM_CDSID_C IS NOT NULL AND  FBMD03_CDSID_C = :cdsid",nativeQuery=true)
  FordPersonDto queryFordPersonDealAuthoringByCdsid(@Param("cdsid") final String cdsid);
  
  
  
  @Query(value="SELECT * FROM {h-schema}MFBMD03_FORD_PERSON P,    {h-schema}MFBMD14_REPORT_LEVEL RL \n"
  		+ "WHERE P.FBMD14_RPTLVL_K = RL.FBMD14_RPTLVL_K  \n"
  		+ "AND RL.FBMD14_TITLE_C IN ('CTL','FID','FIM')\n"
  		+ "AND P.FBMD03_STATUS_F = 'A'  order by FBMD03_CDSID_C",nativeQuery=true)
  List<FordPersonDto>  queryEligibleFordPersonAsController();
}
