package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * The persistent class for the MFBMD74_SERVICE_ATTR_OPTION database table.
 * 
 */
@Entity
@Table(name = ServiceAttributeOption.TABLE_NAME)
public class ServiceAttributeOption implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD74_SERVICE_ATTR_OPTION";
	@Id
	@Column(name = "FBMD74_SERVICE_ATTR_OPT_C")
	private String serviceAttrOptCode;

	// bi-directional many-to-one association to Mfbmd72ServiceAttribute
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD72_SERVICE_ATTR_C")
	private ServiceAttribute serviceAttribute;

	// bi-directional many-to-one association to Mfbmd73ServiceOption
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD73_SERVICE_OPT_C")
	private ServiceOption serviceOption;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD74_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD74_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD74_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD74_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD74_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD74_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
