package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

/**
 * To encapsulate all common and query/path parameters from the session.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Setter
@Getter
public class ApiParams {

  private String userId;
  private String countryCd;
  private Long proposalKey;
  private String orgCd;
  private Long reportLevel;
  private Integer proposalYr;
  private String resourceUri;
  private String volumeFinancialDataSource;
  private boolean highPriority;
  private boolean isComplete;
  private Integer proposalYrVer;
  private Long finKey;
  private String fleetRating;
  private Long ouUnitKey;
  private String action;
  private CreateProposalRequest comments;

}