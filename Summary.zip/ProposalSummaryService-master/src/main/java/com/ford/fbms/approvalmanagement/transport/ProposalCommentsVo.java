package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class ProposalCommentsVo implements Serializable {

	private static final long serialVersionUID = 1L;

	private String proposalYear;
	private String proposalVersion;
	private String commentedBy;
	private Date dateSubmitted;
	private String proposalComments;
}