package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.*;

/**
 * Class containing request for account notes.
 *
 * @author APARAMA2
 */
@Setter
@Getter
public class CreateProposalRequest {

  @NotNull
  @Min(value = 1L, message = "Invalid length of Proposal Key")
  @Max(value = 999999999L, message = "Invalid length of Proposal Key")
  private long proposalKey;

  private String proposalNoteDescription;

  @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message =
      "Invalid Requester ID")
  @Size(min = 1, max = 30, message = "Invalid length of Requester ID")
  @NotBlank
  private String cdsid;

  @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message =
      "Invalid Requester ID")
  @Size(min = 1, max = 30, message = "Invalid length of Requester ID")
  @NotBlank
  private String statusCd;

  @Pattern(regexp = "^[A-Za-z]{1}$", message = "Invalid Process code")
  @Size(min = 1, max = 1, message = "Invalid length of Process code")
  @NotBlank
  @NotNull
  private String inProcess;
}