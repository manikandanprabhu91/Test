package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA04_PROPOSAL_VEHLN_INCTV database table.
 *
 */
@Entity
@Table(name = ProposalVehicleLineIncentiveDto.TABLE_NAME)
// @NamedQuery(name="ProposalVehlnInctv.findAll", query="SELECT m FROM
// ProposalVehlnInctv m")
public class ProposalVehicleLineIncentiveDto implements Serializable {

	public long getPviSaKey() {
		return pviSaKey;
	}

	public void setPviSaKey(long pviSaKey) {
		this.pviSaKey = pviSaKey;
	}

	public String getApprovedFlag() {
		return approvedFlag;
	}

	public void setApprovedFlag(String approvedFlag) {
		this.approvedFlag = approvedFlag;
	}

	public Date getEndYear() {
		return endYear;
	}

	public void setEndYear(Date endYear) {
		this.endYear = endYear;
	}

	public String getMlsUscCombinedDescription() {
		return mlsUscCombinedDescription;
	}

	public void setMlsUscCombinedDescription(String mlsUscCombinedDescription) {
		this.mlsUscCombinedDescription = mlsUscCombinedDescription;
	}

	public Long getMlvForecast() {
		return (mlvForecast==null?0:mlvForecast);
	}

	public void setMlvForecast(Long mlvForecast) {
		this.mlvForecast = mlvForecast;
	}

	public Long getMlv() {
		return (mlv==null?0:mlv);
	}

	public void setMlv(Long mlv) {
		this.mlv = mlv;
	}

	public BigDecimal getRepurchase() {
		return repurchase;
	}

	public void setRepurchase(BigDecimal repurchase) {
		this.repurchase = repurchase;
	}

	public Date getStartYear() {
		return startYear;
	}

	public void setStartYear(Date startYear) {
		this.startYear = startYear;
	}

	public String getSysAddedEarlyFlag() {
		return sysAddedEarlyFlag;
	}

	public void setSysAddedEarlyFlag(String sysAddedEarlyFlag) {
		this.sysAddedEarlyFlag = sysAddedEarlyFlag;
	}

	public Timestamp getSysAddedEarlyTS() {
		return sysAddedEarlyTS;
	}

	public void setSysAddedEarlyTS(Timestamp sysAddedEarlyTS) {
		this.sysAddedEarlyTS = sysAddedEarlyTS;
	}

	public BigDecimal getTierVolumeValue() {
		return tierVolumeValue;
	}

	public void setTierVolumeValue(BigDecimal tierVolumeValue) {
		this.tierVolumeValue = tierVolumeValue;
	}

	public String getTier1InctvToDlrFlag() {
		return tier1InctvToDlrFlag;
	}

	public void setTier1InctvToDlrFlag(String tier1InctvToDlrFlag) {
		this.tier1InctvToDlrFlag = tier1InctvToDlrFlag;
	}

	public String getUscCombinedDescription() {
		return uscCombinedDescription;
	}

	public void setUscCombinedDescription(String uscCombinedDescription) {
		this.uscCombinedDescription = uscCombinedDescription;
	}

	public BigDecimal getMlsVehicleEntitySaKey() {
		return mlsVehicleEntitySaKey;
	}

	public void setMlsVehicleEntitySaKey(BigDecimal mlsVehicleEntitySaKey) {
		this.mlsVehicleEntitySaKey = mlsVehicleEntitySaKey;
	}

	public ProposalDto getProposal() {
		return proposal;
	}

	public void setProposal(ProposalDto proposal) {
		this.proposal = proposal;
	}

	public BodyStyleDto getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(BodyStyleDto bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public VehicleEntityDto getVehicleEntity() {
		return vehicleEntity;
	}

	public void setVehicleEntity(VehicleEntityDto vehicleEntity) {
		this.vehicleEntity = vehicleEntity;
	}

	public WERSVehicleEntityDto getWersvehicleEntity() {
		return wersvehicleEntity;
	}

	public void setWersvehicleEntity(WERSVehicleEntityDto wersvehicleEntity) {
		this.wersvehicleEntity = wersvehicleEntity;
	}

	public List<OptionIncentiveDto> getOptionIncentives() {
		return optionIncentives;
	}

	public void setOptionIncentives(List<OptionIncentiveDto> optionIncentives) {
		this.optionIncentives = optionIncentives;
	}

	public ProposalFinancialDto getProposalFinancial() {
		return proposalFinancial;
	}

	public void setProposalFinancial(ProposalFinancialDto proposalFinancial) {
		this.proposalFinancial = proposalFinancial;
	}

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMA04_PROPOSAL_VEHLN_INCTV";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMA04_PVI_K")
	private long pviSaKey;

	@Column(name = "FBMA04_APRVD_F")
	private String approvedFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA04_END_Y")
	private Date endYear;

	@Column(name = "FBMA04_MLS_USC_COMBINED_X")
	private String mlsUscCombinedDescription;

	@Column(name = "FBMA04_MLV_FORECAST_Q")
	private Long mlvForecast;

	@Column(name = "FBMA04_MLV_Q")
	private Long mlv;

	@Column(name = "FBMA04_REPURCHASE_Q")
	private BigDecimal repurchase;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMA04_START_Y")
	private Date startYear;

	@Column(name = "FBMA04_SYS_ADDED_EARLY_F")
	private String sysAddedEarlyFlag;

	@Column(name = "FBMA04_SYS_ADDED_EARLY_S")
	private Timestamp sysAddedEarlyTS;

	@Column(name = "FBMA04_TIER_VOLUME_VALUE_Q")
	private BigDecimal tierVolumeValue;

	@Column(name = "FBMA04_TIER1_INCTV_TO_DLR_F")
	private String tier1InctvToDlrFlag;

	@Column(name = "FBMA04_USC_COMBINED_X")
	private String uscCombinedDescription;

	@Column(name = "FBME49_MLS_VEHICLE_ENTITY_K")
	private BigDecimal mlsVehicleEntitySaKey;

	// bi-directional many-to-one association to Mfbma01Proposal
	@JsonManagedReference
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMA01_PROPOSAL_K")
	private ProposalDto proposal;
	/*
	 * //bi-directional many-to-one association to Mfbma01Proposal
	 *
	 * @ManyToOne(fetch=FetchType.LAZY)
	 *
	 * @JoinColumn(name="FBMA01_BASE_PROPOSAL_K") private Proposal proposal2;
	 */
	// bi-directional many-to-one association to Mfbme03BodyStyle
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME03_BDYSTL_K")
	private BodyStyleDto bodyStyle;

	// bi-directional many-to-one association to Mfbme49VehicleEntity
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME49_VEHICLE_ENTITY_K")
	private VehicleEntityDto vehicleEntity;
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME79_VEHICLE_ENTITY_K")
	private WERSVehicleEntityDto wersvehicleEntity;

	
	  //bi-directional many-to-one association to Mfbma05OptionIncentive
	  @OneToMany(mappedBy="proposalVehicleLineIncentive",fetch=FetchType.LAZY,cascade=CascadeType.ALL) 
	  private List<OptionIncentiveDto> optionIncentives;
	 
	/*
	 * //bi-directional many-to-one association to Mfbma11TierIncentive
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<TierIncentive>
	 * tierIncentives;
	 */

	
	 //bi-directional one-to-one association to Mfbma18ProposalFinancial
	  
	 @OneToOne(mappedBy="proposalVehlnInctv", fetch=FetchType.LAZY,cascade=CascadeType.ALL) 
	 private ProposalFinancialDto proposalFinancial;
	 
	 
	 /* 
	 * //bi-directional many-to-one association to Mfbma19AutoearlyErrorLog
	 *
	 * @OneToMany(mappedBy="mfbma04ProposalVehlnInctv") private
	 * List<AutoearlyErrorLog> autoearlyErrorLogs;
	 */
	/*
	 * //bi-directional one-to-one association to Mfbma22PviExtraInfo
	 *
	 * @OneToOne(mappedBy="proposalVehlnInctv", fetch=FetchType.LAZY) private
	 * PviExtraInfo pviExtraInfo;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma24ViPaymentRoute
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<ViPaymentRoute>
	 * viPaymentRoutes;
	 *
	 * //bi-directional many-to-one association to Mfbma27ViPurchaseMethod
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<ViPurchaseMethod>
	 * viPurchaseMethods;
	 *
	 * //bi-directional many-to-one association to Mfbma30BonusMgmt
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<BonusMgmt> bonusMgmts;
	 *
	 * //bi-directional one-to-one association to Mfbma37PviFinCosting
	 *
	 * @OneToOne(mappedBy="proposalVehlnInctv", fetch=FetchType.LAZY) private
	 * PviFinCosting pviFinCosting;
	 *
	 * //bi-directional many-to-one association to Mfbma42TierIncePaymntRoute
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<TierIncePaymntRoute>
	 * tierIncePaymntRoutes;
	 *
	 * //bi-directional many-to-one association to Mfbma46VehlnInctvBandGrp
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<VehlnInctvBandGrp>
	 * vehlnInctvBandGrps;
	 */
	/*
	 * //bi-directional many-to-one association to Mfbma47PviBandPaymtDtl
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<PviBandPaymtDtl>
	 * pviBandPaymtDtls;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma48PviBonusCosting
	 *
	 * @OneToMany(mappedBy="proposalVehlnInctv") private List<PviBonusCosting>
	 * pviBonusCostings;
	 */
	/*
	 * //bi-directional one-to-one association to Mfbmd30EntityVi
	 *
	 * @OneToOne(mappedBy="proposalVehlnInctv", fetch=FetchType.LAZY) private
	 * EntityVi entityVi;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA04_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMA04_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMA04_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA04_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMA04_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMA04_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
