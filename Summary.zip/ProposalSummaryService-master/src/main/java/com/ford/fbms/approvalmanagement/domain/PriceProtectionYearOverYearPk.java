package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * A class for primary keys of direction model.
 *
 * @author GILNAGOV on 2/15/2021.
 */

@Getter
@Setter
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class PriceProtectionYearOverYearPk extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonIgnore
  @Column(name = "FBMA01_PROPOSAL_K")
  private long proposalKey;

  @Column(name = "FBMA16_YOY_MODELYEAR_C")
  private long modelYear;
}
