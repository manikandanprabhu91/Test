//******************************************************************************
//* Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   FinancialSummaryVO.java  $
//* $Revision:   1.2  $
//* $Author:   PSIRISIN  $
//* $Date:   Dec 27 2009 10:52:46  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.transport;

import java.util.Date;

import com.ford.fbms.approvalmanagement.util.FbmsUtil;

import lombok.Getter;
import lombok.Setter;

/**
 * This Value Object holds Proposal Financial Summary. 
 */

@Getter
@Setter
public class FinancialMexSummaryVO  {
    
    /**
     * Total Proposed Fleet Incentive  Variable Marketing
     */
    private long propsFleetIncetTotVM;
    
    /**
     * Average Proposed Fleet Incentive  Variable Marketing
     */
    private long propsFleetIncetAvgVM;
    
    
    private long proposedTotalCM;
    /**
     * Average Proposed Contribution Margin    
     * 
    */
    private long proposedAvgCM;
    private long bwFleetTargetTotalVM;
    
    /**
     * Average B(W) Fleet Target Variable Marketing
     */
    private long bwFleetTargetAvgVM;
    
    /**
     * Total B(W) CCC Target Variable Marketing    
     * 
    */
    private long bwCCCTargetTotalVM;
    
    /**
     * Average B(W) CCC Target Variable Marketing
     */
    private long bwCCCTargetAvgVM;
    
    private long bwFleetTargetTotalCM;
    
    /**
     * Average B/(W) Fleet Target Contribution Margin    
     * 
    */
    private long bwFleetTargetAvgCM;
    
    /**
     * Total B/(W) Fleet Target Percentage Contribution Margin    
     * 
    */
    private float bwFleetTargetPrectTotalCM;
    
    /**
     * Average B/(W) Fleet Target Percentage Contribution Margin
     */
    private float bwFleetTargetPrectAvgCM;
   
    /**
     * Total B/(W) CCC Target Contribution Margin    
     * 
    */
    private long bwCCCTargetTotalCM;
    
    /**
     * Average B/(W) CCC Target Contribution Margin    
     * 
    */
    private long bwCCCTargetAvgCM;
    
    /**
     * Total B/(W) CCC Target Percentage  Contribution Margin    
     * 
    */
    private float bwCCCTargetPrectTotalCM;
    
    /**
     * Average B/(W) CCC Target Percentage  Contribution Margin    
     * 
    */
    private float  bwCCCTargetPrectAvgCM;



       
}


