package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD87_TEMPLATE_NAME database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = TemplateNamesDto.TABLE_NAME)
public class TemplateNamesDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD87_TEMPLATE_NAME";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD87_TEMPLATE_K")
	private Long templateKey;

	@Column(name = "FBMD87_TEMPLATE_C")
	private String templateCode;

	@Column(name = "FBMD42_COUNTRY_ISO3_C")
	private String countryCode;

	@Column(name = "FBMD87_TEMPLATE_X")
	private String templateDesc;

	/*@JsonIgnore
	@Column(name = "FBMD87_TEMPLATE_K")
	private Long templateKey;
*/
	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD87_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD87_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMD87_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD87_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMD87_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMD87_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}