package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD54_ESP_FUEL_TYPE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = EspFuelTypeDto.TABLE_NAME)
// @NamedQuery(name="EspFuelType.findAll", query="SELECT m FROM EspFuelType m")
public class EspFuelTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD54_ESP_FUEL_TYPE";

	@Id
	@Column(name = "FBMD54_ESP_FUEL_TYPE_C")
	private String espFuelTypeCode;

	@Column(name = "FBMD54_ESP_FUEL_TYPE_N")
	private String espFuelTypeDesc;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD54_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD54_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD54_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD54_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD54_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD54_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
