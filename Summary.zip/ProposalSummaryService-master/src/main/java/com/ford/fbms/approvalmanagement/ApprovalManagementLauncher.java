package com.ford.fbms.approvalmanagement;

import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.Constants;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.AllowableRangeValues;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.Contact;
import springfox.documentation.service.GrantType;
import springfox.documentation.service.ImplicitGrant;
import springfox.documentation.service.LoginEndpoint;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.SecurityScheme;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Main launcher class.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@SpringBootApplication
@EnableSwagger2
@EnableCaching
@EntityScan("com.ford.fbms")
@Import(BeanValidatorPluginsConfiguration.class)
public class ApprovalManagementLauncher {

  @Value("${token_url}")
  private String tokenUrl;

  @Value("${swagger.contact.name}")
  private String name;

  @Value("${swagger.contact.email}")
  private String email;

  @Value("${swagger.contact.url}")
  private String url;

  @Value("${swagger.version}")
  private String version;

  /**
   * To launch this application through SpringBoot.
   *
   * @param args args
   */
  public static void main(final String[] args) {
    SpringApplication.run(ApprovalManagementLauncher.class, args);
  }

  /**
   * To create OAuth2 header section in the swagger API.
   */

  @Bean
  public Docket newsApi() {
    return new Docket(DocumentationType.SWAGGER_2).select()
        .apis(RequestHandlerSelectors.basePackage("com.ford.fbms"))
        .paths(PathSelectors.regex("/*.*")).build()
        .globalOperationParameters(Arrays.asList(new ParameterBuilder().name("Authorization")
            .description("OAuth2 bearer token").modelRef(new ModelRef("string"))
            .parameterType("header").required(true)
            .allowableValues(new AllowableRangeValues("1", "4500"))
            .pattern(Constants.TOKEN_REGEX).build()))
        .securitySchemes(Arrays.asList(consumerAccessTokenSecurityScheme()))
        .securityContexts(Arrays.asList(securityContext()))
        .protocols(Stream.of("https").collect(Collectors.toCollection(HashSet::new)))
        .apiInfo(apiInfo());
  }



  private SecurityScheme consumerAccessTokenSecurityScheme() {
    final GrantType grantType = new ImplicitGrant(new LoginEndpoint(tokenUrl),
        ApprovalConstants.CONSUMER_TOKEN);
    final AuthorizationScope authorizationScope1 = new AuthorizationScope("scope", "description");
    final List<AuthorizationScope> authorizationScopeList = new ArrayList<>();
    authorizationScopeList.add(authorizationScope1);
    return new OAuthBuilder().name(ApprovalConstants.CONSUMER_TOKEN).grantTypes(Arrays.asList(grantType))
        .scopes(authorizationScopeList).build();
  }


  // Security
  private AuthorizationScope[] emptyScopes() {
    return Collections.emptyList().toArray(new AuthorizationScope[0]);
  }

  // Security
  private SecurityContext securityContext() {
    return SecurityContext.builder()
        .securityReferences(Arrays.asList(
            SecurityReference.builder().reference(ApprovalConstants.CONSUMER_TOKEN).scopes(emptyScopes())
                .build()))
        .build();
  }

  /**
   * To create API information.
   */
  private ApiInfo apiInfo() {
    return new ApiInfoBuilder()
        .title("ProposalSummaryService")
        .description("A service to manage approval chain details")
        .version(version)
        .contact(contact())
        .build();
  }

  /**
   * To get the contact information of the service.
   */
  private Contact contact() {
    return new Contact(name, url, email);
  }
}