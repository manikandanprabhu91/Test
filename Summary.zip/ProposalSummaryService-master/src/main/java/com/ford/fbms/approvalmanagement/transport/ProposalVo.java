package com.ford.fbms.approvalmanagement.transport;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProposalVo extends GenericResponse implements Serializable {
  private static final long serialVersionUID = 1L;

  private Long finKey;
  private String finCd;
  private String accountName;
  private String status;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
  private Date statusYear;
  private Integer proposalYr;
  private Integer version;
  private String address1;
  private String address2;
  private String city;
  private String state;
  private String zipcode;
  private String country;
  private String yoyCd;
  private String yoyDesc;
  private String sellingDealerFlag;
  private Long letterMinQty;
  private String paymentType;
  private Long multiYearMinQ;
  private Long multiYearStart;
  private Long multiYearEnd;
  private String firstName;
  private String lastName;
  private Long tierVolume1;
  private Long tierVolume2;
  private Long tierVolume3;
  private Long tierVolume4;
  private Long tierVolume5;
  private Long tierVolume6;
  private Long aggregateIncentiveCd1;
  private String aggregateIncentiveDesc1;
  private Long aggregateIncentiveCd2;
  private String aggregateIncentiveDesc2;
}
