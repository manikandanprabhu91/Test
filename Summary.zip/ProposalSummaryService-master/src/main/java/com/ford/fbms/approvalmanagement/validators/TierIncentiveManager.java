package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.TierIncentive;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class TierIncentiveManager implements Validator {

  
  @Autowired
  private ProposalRepository proposalRepository;
  @Autowired
  protected TierIncentiveRepository tierIncentiveRepo;
  @Autowired
  protected ProposalVehicleLineIncentiveRepository propsalVlRepo;
  @Autowired
  protected TierVolumeRepository tierVolumeRepo;
  @Autowired
  private  ResponseBuilder responseBuilder;
  

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").message("Inside ProposalAssignmentManager"));
    Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
    genericResponseWrapper =this.validateTierIncentives(proposalDTO.get(),genericResponseWrapper);
    return new AsyncResult<>(genericResponseWrapper);
  }
  
  
	private GenericResponseWrapper validateTierIncentives(ProposalDto proposal,
			GenericResponseWrapper genericResponseWrapper) {

		int noOfTiersDefined = -1;
		List<ProposalVehicleLineIncentiveDto> vehicleLineIncentiveList = getVehicleLineIncentiveList(proposal);
		if(vehicleLineIncentiveList.isEmpty()) {
			genericResponseWrapper
			.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_PERUNIT_INCENTIVES));
			} else {
		List<TierVolumeDto> tierVolumes = this.tierVolumeRepo.findAllByProposalKey(proposal.getProposalSaKey());
		if (tierVolumes != null && !tierVolumes.isEmpty()) {
			noOfTiersDefined = tierVolumes.size();
		}
		boolean isTierIncentivesValid = true;
		if (noOfTiersDefined > 0) {

				for (ProposalVehicleLineIncentiveDto vlIncentive : vehicleLineIncentiveList) {

					Optional<List<TierIncentive>> tierIncentiveListOpt = this.tierIncentiveRepo
							.findAllByProposalKey(vlIncentive.getPviSaKey());
					if (tierIncentiveListOpt.isEmpty()) {
						isTierIncentivesValid = false;
					} else {
						List<TierIncentive> tierIncentiveList = tierIncentiveListOpt.get();
						if (tierIncentiveList.size() < noOfTiersDefined) {
							// not all tiers are defined with VL incentives
							isTierIncentivesValid = false;
						}
						// ignoring the condition if tier incentive size is
						// greater than no of tiers defined
						TierIncentive priorIncentive = null;
						for (TierIncentive tIncentive : tierIncentiveList) {

							if (priorIncentive != null) {

								if (tIncentive.getTierIncentivePK().getTierLevel() > priorIncentive.getTierIncentivePK()
										.getTierLevel()) {
									if (tIncentive.getTierInctvAmount().intValue() < priorIncentive.getTierInctvAmount()
											.intValue()) {
										// Error...Tier Incentive can't be
										// less than
										// prior tier
										isTierIncentivesValid = false;
									}

								} else {
									if (tIncentive.getTierInctvAmount().intValue() <= 0) {
										log.info("...first value is not valied");
										// Error...Incentive Can't be -ve
										isTierIncentivesValid = false;
									}
								}
								priorIncentive = tIncentive;
								if (!isTierIncentivesValid) {
									break; 
								}
							}
						}
						if (!isTierIncentivesValid) {
							break; 
						}
					}
				}

			if (!isTierIncentivesValid) {

				genericResponseWrapper
						.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_INCENTIVES));
			}
		}
		}
		
		return genericResponseWrapper;
	}
	
	private List<ProposalVehicleLineIncentiveDto> getVehicleLineIncentiveList(
			ProposalDto proposal){
		List<ProposalVehicleLineIncentiveDto> vehLineList = new ArrayList<ProposalVehicleLineIncentiveDto>();
		Optional<List<ProposalVehicleLineIncentiveDto>> vehLineList_Final = propsalVlRepo.findByProposal(proposal);
		if(vehLineList_Final.isPresent()) {
		return vehLineList_Final.get();
		}
		return vehLineList;
	}
	
}