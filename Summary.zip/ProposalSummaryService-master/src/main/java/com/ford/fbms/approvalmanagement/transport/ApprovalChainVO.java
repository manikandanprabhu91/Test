package com.ford.fbms.approvalmanagement.transport;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApprovalChainVO {

	/* Submitted to Report Level */
	private int role;

	/* Approver Role Title */
	private String title;

	/* CDSID of Approver */
	private String cdsid;

	/* Status */
	private String status;

	/* Status Date */
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	private Date statusDate;

	private int orderChain;

	public ApprovalChainVO(String title, String cdsid, String status) {
		this.title = title;
		this.cdsid = cdsid;
		this.status = status;
	}

	public ApprovalChainVO(int role, String title, String cdsid, String status, Date statusDate) {
		super();
		this.role = role;
		this.title = title;
		this.cdsid = cdsid;
		this.status = status;
		this.statusDate = statusDate;
	}

}


