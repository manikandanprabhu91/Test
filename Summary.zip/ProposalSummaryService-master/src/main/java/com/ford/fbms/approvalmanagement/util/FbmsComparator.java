//******************************************************************************
//* Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
//* Original author:  Ford Motor Company - FBMS
//*
//* $Workfile:   FbmsComparator.java  $
//* $Revision:   1.7  $
//* $Author:   PANKIT  $
//* $Date:   Dec 13 2011 05:37:26  $
//*
//******************************************************************************
package com.ford.fbms.approvalmanagement.util;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;

/**
 * FBMS Comparator which constructs Comparator object , comparing single entity
 * of an object or double entity of an object , tries to sort.
 */
@Slf4j
public class FbmsComparator implements Comparator, Serializable {
	// Logging Setup

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String method;
	private int sortValue;

	private static final int EQUAL = 0;
	private static final int LESS = -1;
	private static final int GREATER = 1;

	/**
	 * Construct a FbmsComparator instance
	 *
	 * @param method
	 */
	public FbmsComparator(String method) {
		this.method = buildMethodName(method);
		// always sort ASC
		this.sortValue = 1;
	}

	/**
	 * Construct a FbmsComparator instance
	 *
	 * @param method
	 * @param sortAsc
	 */
	public FbmsComparator(String method, boolean sortAsc) {
		this.method = buildMethodName(method);
		// set to -1 for DSC sort
		this.sortValue = sortAsc ? 1 : -1;
	}

	private static final String buildMethodName(String name) {
		StringBuilder methodName = new StringBuilder("get");
		methodName.append(name.substring(0, 1).toUpperCase());
		methodName.append(name.substring(1));
		return methodName.toString();
	}

	private static final Method getMethod(Object obj, String methodName) throws NoSuchMethodException {
		Class[] parms = null;
		return obj.getClass().getMethod(methodName, parms);
	}

	private static final Object invoke(Object obj, Method method)
			throws IllegalAccessException, InvocationTargetException {
		Object[] parms = null;
		return method.invoke(obj, parms);
	}

	/**
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	@LogAround
	public int compare(Object o1, Object o2) {
		try {
			Method getValue = getMethod(o1, this.method);
			final String returnType = getValue.getReturnType().getName();
			if (returnType.equals(ApprovalConstants.JAVA_STRING)) {
				final String f1 = (String) invoke(o1, getValue);
				final String f2 = (String) invoke(o2, getValue);
				if (f1 != null && f2 != null) {
					return f1.compareTo(f2) * this.sortValue;
				} else if (f1 == null && f2 != null) {
					return LESS * this.sortValue;
				} else if (f1 != null && f2 == null) {
					return GREATER * this.sortValue;
				} else if (f1 == null && f2 == null) {
					return EQUAL * this.sortValue;
				}
			} else if ("java.lang.Integer".equals(returnType)) {
				return compareIntValue(o1, o2, getValue);

			} else if ("int".equals(returnType)) {
				return compareIntValue(o1, o2, getValue);

			} else if (("float").equals(returnType)) {
				return compareFloatValue(o1, o2, getValue);

			} else if ("java.lang.Float".equals(returnType)) {
				return compareFloatValue(o1, o2, getValue);

			} else if ("double".equals(returnType)) {
				double f1 = 0, f2 = 0;
				f1 = ((Double) invoke(o1, getValue)).doubleValue();

				f2 = ((Double) invoke(o2, getValue)).doubleValue();

				if ((int) f1 == (int) f2) {
					return EQUAL * this.sortValue;
				} else if (f1 < f2) {
					return LESS * this.sortValue;
				} else if (f1 > f2) {
					return GREATER * this.sortValue;
				}

			} else if ("long".equals(returnType)) {
				long f1 = 0, f2 = 0;
				f1 = ((Long) invoke(o1, getValue)).longValue();

				f2 = ((Long) invoke(o2, getValue)).longValue();

				if ((int) f1 == (int) f2) {
					return EQUAL * this.sortValue;
				} else if (f1 < f2) {
					return LESS * this.sortValue;
				} else if (f1 > f2) {
					return GREATER * this.sortValue;
				}

			} else if ("java.util.Date".equals(returnType)) {
				Date f1 = null, f2 = null;
				f1 = ((Date) invoke(o1, getValue));

				f2 = ((Date) invoke(o2, getValue));

				if (f1.equals(f2)) {
					return EQUAL * this.sortValue;
				} else if (f1.before(f2)) {
					return LESS * this.sortValue;
				} else if (f1.after(f2)) {
					return GREATER * this.sortValue;
				}

			} else if ("java.sql.Timestamp".equals(returnType)) {
				Date f1 = null, f2 = null;
				f1 = ((java.sql.Timestamp) invoke(o1, getValue));

				f2 = ((java.sql.Timestamp) invoke(o2, getValue));

				if (f1.equals(f2)) {
					return EQUAL * this.sortValue;
				} else if (f1.before(f2)) {
					return GREATER * this.sortValue;
				} else if (f1.after(f2)) {
					return LESS * this.sortValue;
				}

			}
			throw new RuntimeException("FbmsComparator does not currently support '" + returnType + "'!!!!!");

		} catch (Exception e) {
			log.error("Error occurred in FbmsComparator", e);
			return LESS;
		}

	}

	private int compareIntValue(Object o1, Object o2, Method getValue)
			throws IllegalAccessException, InvocationTargetException {
		int f1 = invokeValue(o1, getValue);
		int f2 = invokeValue(o2, getValue);

		if (f1 == f2) {
			return EQUAL * this.sortValue;
		} else if (f1 < f2) {
			return LESS * this.sortValue;
		} else if (f1 > f2) {
			return GREATER * this.sortValue;
		}
		return f2;
	}

	private int compareFloatValue(Object o1, Object o2, Method getValue)
			throws IllegalAccessException, InvocationTargetException {
		float f1 = 0, f2 = 0;
		f1 = ((Float) invoke(o1, getValue)).floatValue();

		f2 = ((Float) invoke(o2, getValue)).floatValue();

		if ((int) f1 == (int) f2) {
			return EQUAL * this.sortValue;
		} else if (f1 < f2) {
			return LESS * this.sortValue;
		} else if (f1 > f2) {
			return GREATER * this.sortValue;
		}
		return sortValue;
	}

	private int invokeValue(Object o2, Method getValue) throws IllegalAccessException, InvocationTargetException {
		int f2;
		f2 = ((Integer) invoke(o2, getValue)).intValue();
		return f2;
	}

}
