package com.ford.fbms.approvalmanagement.validators;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ExpandedBodyStyleViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.VehicleLineDto;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyStyleViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.VehicleLineRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to get proposal details.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class ForecastManager implements Validator {

	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected ProposalManager prop;
	@Autowired
	protected ActualsManager actualManager;
	@Autowired
	protected VehicleLineRepository vehLineRepo;
	@Autowired
	protected ExpandedBodyStyleViewRepository expandedBodyStyleViewRepo;

	@Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest, final MasterRuleEngine masterRuleEngine,
																														 HttpServletRequest httpRequest) {

		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside forecast"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();

			int proposalTier =  proposalManager.getProposalTier(proposal,proposalManager.isPresentVMbasedOnActualVolume(apiParams));
			int tTier = proposalManager.getTotalTier(proposal);
			List<ProposalFinancialVO> puFinanceList = buildProposalFinancialsForecast(apiParams, proposal);
			List<FinancialDetailedVO> financialDetailedVOList = this.populateDetailedFinancialsForForcast(apiParams,
					proposal, puFinanceList,proposalTier,tTier);
			genericResponseWrapper.setFinancialDetailedVOList(financialDetailedVOList);

		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	public List<ProposalFinancialVO> buildProposalFinancialsForecast(final ApiParams apiParams, ProposalDto p) {
		List<ProposalFinancialVO> fList;
		// Initialize unique List for present Vehicle Lines
		LinkedHashMap<String, String> presentVehicleLine = new LinkedHashMap<String, String>();
		fList = proposalManager.getProposalFinancialList(apiParams, p, true);
		if (fList != null && !(fList.isEmpty())) {
			for (ProposalFinancialVO o : fList) {
				List<VehicleLineDto> vehicleLineList = vehLineRepo
						.vehicleLineListByVehicleLineDesc(o.getVehicleLineDescription());
				String vehicleCode = " ";
				if (vehicleLineList != null && !(vehicleLineList.isEmpty())) {
					vehicleCode = vehicleLineList.get(0).getVehlnCode();
				}
				presentVehicleLine.put(o.getModelYear() + " " + vehicleCode, o.getVehicleLineDescription());
			}
		} else {
			fList = new ArrayList<>();
		}
		// add the prior version Proposal
		ProposalDto pv = proposalManager.identifyPriorProposals(p);
		if (null != pv) {
			List<ProposalFinancialVO> pvList = proposalManager.getProposalFinancialList(apiParams, pv, false);
			proposalManager.addPriorVerProposal(fList, pvList);
		}
		// add the prior year Proposal
		Optional<ProposalDto> py = proposalManager.identifyPriorPYProposals(p);
		if (py.isPresent()) {
			List<ProposalFinancialVO> pyList = actualManager.getPriorYearActualProposalFinancialList(
					py.get(),apiParams);
			proposalManager.addPriorYearProposal(fList, pyList, py.get(), p);
		}
		updateFinancialsForGroupOrALL(p, fList, apiParams);
		Iterator pIter = presentVehicleLine.keySet().iterator();
		for (Iterator iter = pIter; iter.hasNext();) {
			String vlKey = (String) iter.next();
			for (ProposalFinancialVO o : fList) {
				List<VehicleLineDto> vehicleLineList = vehLineRepo
						.vehicleLineListByVehicleLineDesc(o.getVehicleLineDescription());

				String vehicleCode = " ";
				if (vehicleLineList != null && !(vehicleLineList.isEmpty())) {
					vehicleCode = vehicleLineList.get(0).getVehlnCode();
				}

				if (vlKey.equalsIgnoreCase(o.getModelYear() + " " + vehicleCode)) {
					o.setPresentVehicleLine(true);
					if (presentVehicleLine.get(vlKey) != null) {
						o.setVehicleLineDescription(presentVehicleLine.get(vlKey));
					}
				}
			}
		}
		FbmsUtil.sort(fList, "modelYear");
		FbmsUtil.sort(fList, "vehicleLineDescription");
		return fList;
	}

	@LogAround
	private List<ProposalFinancialVO> updateFinancialsForGroupOrALL(ProposalDto p, List<ProposalFinancialVO> fList,
			ApiParams apiParams) {

		List<ProposalFinancialVO> actList = actualManager.buildProposalFinancialsActual(p, apiParams);
		for (ProposalFinancialVO financialVO : fList) {
			boolean isGroup = false;
			Long bgKey = null;
			if (financialVO.isBodyGroup() || "ALL".equalsIgnoreCase(financialVO.getPerUnitDescription())) {
				isGroup = true;
				if (financialVO.getPerUnit() > 0L) {
					bgKey = financialVO.getPerUnit();
				} else if (financialVO.getPriorVerPerUnit() > 0L) {
					bgKey = financialVO.getPriorVerPerUnit();
				}
				if (financialVO.getPerUnit() > 0L) {
					bgKey = financialVO.getPerUnit();
				} else if (financialVO.getPriorVerPerUnit() > 0L) {
					bgKey = financialVO.getPriorVerPerUnit();
				}
				if (isGroup && bgKey != null) {
					Optional<List<ExpandedBodyStyleViewDto>> eList = expandedBodyStyleViewRepo
							.findByIdBodyStyleSaKey(financialVO.getPerUnit());

					ProposalFinancialVO t = new ProposalFinancialVO(financialVO.getPerUnit(),
							financialVO.getPriorYearPerUnit(), financialVO.getPriorVerPerUnit());
					if (eList.isPresent()) {
						for (ExpandedBodyStyleViewDto styleRO : eList.get()) {
							Long puKey = styleRO.getId().getBodyStyleSaKey();

							// now get the data from Act vs.Act list
							ProposalFinancialVO pf = findPerUnitInList(actList, puKey);
							if (pf != null) {
								t.setPriorYearVolume(t.getPriorYearVolume() + pf.getPriorYearVolume());
								t.setPriorVerEstCC(
										t.getPriorVerEstCC() + (pf.getPriorVerFctCC() * pf.getPriorYearVolume()));
								t.setPriorVerEstRevenue(t.getPriorVerEstRevenue()
										+ (pf.getPriorVerFctRevenue() * pf.getPriorYearVolume()));

							} 
						}
						if (t.getPriorYearVolume() > 0L) {
							if (financialVO.getPerUnit() > 0L) {
								financialVO.setEstCC(financialVO.getEstCC());
								financialVO.setEstRevenue(financialVO.getEstRevenue());
								financialVO.setTargetEstCC(financialVO.getEstCC());
								financialVO.setTargetEstRevenue(financialVO.getEstRevenue());
							}
							if (financialVO.getPriorVerPerUnit() > 0L) {
								financialVO.setPriorVerEstCC(t.getPriorVerEstCC() / t.getPriorYearVolume());
								financialVO.setPriorVerEstRevenue(t.getPriorVerEstRevenue() / t.getPriorYearVolume());
							}
						} 
					}
				} else {
					log.info("Group flag is ON but not got any key...Need to look into this");
				}

			}
		}
		return fList;
	}

	@LogAround
	private ProposalFinancialVO findPerUnitInList(List<ProposalFinancialVO> actList, Long puKey) {
		ProposalFinancialVO pf = null;
		ProposalFinancialVO o = null;
		boolean foundInList = false;

		if (actList == null || actList.isEmpty()) {
			return o;
		}
		if (puKey == 0L) {
			return o;
		}

		pf = new ProposalFinancialVO(0L, puKey, 0L);
		if (actList.contains(pf)) {
			foundInList = true;
		}

		if (!foundInList) {
			pf = new ProposalFinancialVO(puKey, puKey, puKey);
			if (actList.contains(pf)) {
				foundInList = true;
			}
		}
		if (!foundInList) {
			pf = new ProposalFinancialVO(0L, puKey, puKey);
			if (actList.contains(pf)) {
				foundInList = true;
			}
		}
		if (!foundInList) {
			pf = new ProposalFinancialVO(puKey, puKey, 0L);
			if (actList.contains(pf)) {
				foundInList = true;
			}
		}
		if (foundInList) {
			o = actList.get(actList.indexOf(pf));
		}
		return o;
	}

	/**
	 * 
	 * Builds the ProposalFinancials based EstVsEst, ActVsAct, ActVsFct
	 */
	@LogAround
	public List<FinancialDetailedVO> populateDetailedFinancialsForForcast(final ApiParams apiParams,
			ProposalDto proposal, List<ProposalFinancialVO> puFinanceList,long proposalTier,long totalTier) {
		List<FinancialDetailedVO> financialDetaiedList = new ArrayList<FinancialDetailedVO>();
		proposalManager.identifyPriorProposals(proposal);

		FinancialDetailedVO v = new FinancialDetailedVO();
		FinancialDetailedVO t = new FinancialDetailedVO();
		String lastDescription = " ";
		Long lastModelYear = 0L;
		String lastVehLineCode = "";
		boolean isPresentVL = false;
		int PY = proposal.getPyDefinition().getProposalYearCode();
		if (puFinanceList != null && !(puFinanceList.isEmpty())) {
			for (int i = 0; i < puFinanceList.size(); i++) {
				ProposalFinancialVO f = puFinanceList.get(i);
				updateForecastFinancial(t, f, PY, false, true, false);
				FinancialDetailedVO fdVO = getForecastFinancial(FinancialDetailedVO.rowType.VehicleLine, f, PY, false, true,
						false);

				financialDetaiedList.add(fdVO);

				if (i == 0) {
					lastDescription = f.getVehicleLineDescription();
					lastModelYear = (long) f.getModelYear();
					lastVehLineCode = f.getVehLineCode();
					isPresentVL = f.isPresentVehicleLine();
					
				}
				if (f.getVehicleLineDescription().equals(lastDescription) && f.getModelYear() == lastModelYear) {
					updateForecastFinancial(v, f, PY, false, true, false);

				} else {
					FinancialDetailedVO fdVO1 = proposalManager.getAverageFinancials(v);
					// insert prior vl details as

					fdVO1.setModelYear(lastModelYear);
					fdVO1.setVehicleLine(lastDescription);
					fdVO1.setVehicleLineCode(lastVehLineCode);
					fdVO1.setBodyStyle(" ");
					fdVO1.setRecType(FinancialDetailedVO.rowType.LineTotal);
					fdVO1.setPresentProposal(isPresentVL);
					fdVO1.setVehDesc(lastDescription+"!"+lastModelYear);

					financialDetaiedList.add(fdVO1);
					// start next VL
					v = new FinancialDetailedVO();
					updateForecastFinancial(v, f, PY, false, true, false);
				}
				if (i == puFinanceList.size() - 1) {
					// last record...so insert the VL record
					FinancialDetailedVO fdVO2 = proposalManager.getAverageFinancials(v);
					fdVO2.setVehicleLine(f.getVehicleLineDescription());
					fdVO2.setModelYear((long) f.getModelYear());
					fdVO2.setBodyStyle(" ");
					fdVO2.setVehicleLineCode(f.getVehLineCode());
					fdVO2.setRecType(FinancialDetailedVO.rowType.LineTotal);
					fdVO2.setPresentProposal(f.isPresentVehicleLine());
					 fdVO2.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear());

					financialDetaiedList.add(fdVO2);
				}

				lastDescription = f.getVehicleLineDescription();
				lastModelYear = (long) f.getModelYear();
				lastVehLineCode = f.getVehLineCode();
				isPresentVL = f.isPresentVehicleLine();
			}
		}
	    t.setProposalTier(proposalTier);
	    long prevVerPropTier = proposalManager.showPriorVerProposalTier(financialDetaiedList);
	    t.setPriorVerProposalTier(prevVerPropTier);
	    long priorYearproposalTier = proposalManager.showPriorYearProposalTier(financialDetaiedList);
	    t.setPriorYearProposalTier(priorYearproposalTier);
	    boolean proposalTierChangedflag=proposalManager.proposalTierChanged(proposalTier,prevVerPropTier,priorYearproposalTier);
	    t.setProposalTierChanged(proposalTierChangedflag);
	    t.setTotalTier(totalTier);
	    long prevVerTotalTier = proposalManager.showPriorVerTotalTier(financialDetaiedList);
	    t.setPriorVerTotalTier(prevVerTotalTier);
	    long priorYearTotalTier = proposalManager.showPriorYearTotalTier(financialDetaiedList);
	    t.setPriorYearTotalTier(priorYearTotalTier);
	    boolean totalTierChanged=proposalManager.proposalTierChanged(proposalTier,prevVerPropTier,priorYearproposalTier);
	    t.setTotalTierChanged(totalTierChanged);
		t.setIncludedInPriorProposal(proposalManager.showIncludedInPriorSection(financialDetaiedList));
		t = getAverageForecastFinancial(t);
		if (t.getPresentVol() > 0) {
			t.setPresentProposal(true);
		}
		FbmsUtil.sort(financialDetaiedList, "recType");
	    FbmsUtil.sort(financialDetaiedList, "vehDesc");
		
		
		t.setRecType(FinancialDetailedVO.rowType.GrandTotal);
		financialDetaiedList.add(t);
		return financialDetaiedList;

	}

	@LogAround
	private void updateForecastFinancial(FinancialDetailedVO o, ProposalFinancialVO f, int PY, boolean isEstVsEst,
			boolean isActVsFct, boolean isActVsAct) {

		if (o == null || f == null) {
			return;
		}
		o.setPY(PY);
		if (f.getPerUnit() > 0L) {
			o.setPresentKey(f.getPerUnit());
		}
		if (f.getPriorVerPerUnit() > 0L) {
			o.setPrevVerKey(f.getPriorVerPerUnit());
		}
		if (f.getPriorYearPerUnit() > 0L) {
			o.setPriorKey(f.getPriorYearPerUnit());
		}

		o.setModelYear((long) f.getModelYear());
		o.setVehicleLine(f.getVehicleLineDescription());
		o.setBodyStyle(f.getPerUnitDescription());
		o.setPresentProposal(f.isPresentVehicleLine());

		double pV = f.getVolume();
		double pvV = f.getPriorVerVolume();
		double pyV = f.getPriorYearVolume();
		if (f.getPerUnit() != 0L) {
			pV = pV + 0.000001;
		}
		if (f.getPriorVerPerUnit() != 0L) {
			pvV = pvV + 0.000001;
		}
		if (f.getPriorYearPerUnit() != 0L) {
			pyV = pyV + 0.000001;
		}
		// set volume
		o.setPresentVol(o.getPresentVol() + pV);
		o.setPriorVol(o.getPriorVol() + pyV);
		o.setPrevVerVol(o.getPrevVerVol() + pvV);
		// set VM

		if (o.getRecType() != null) {
			o.setPresentVM(f.getPerUnit() > 0L ? (o.getPresentVM() + (pV * f.getVM())) : 0L);
		} else {
			o.setPresentVM((o.getPresentVM() + (pV * f.getVM())));
		}
		if (o.getRecType() != null) {
			o.setPriorPYVM(
					f.getPriorYearPerUnit() > 0L ? (o.getPriorPYVM() + (pyV * f.getPriorYearVM())) : 0L);
		} else {
			o.setPriorPYVM(o.getPriorPYVM() + (pyV * f.getPriorYearVM()));
		}
		if (o.getRecType() != null) {
			o.setPrevVerVM(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerVM() + (pvV * f.getPriorVerVM())) : 0L);
		} else {
			o.setPrevVerVM(o.getPrevVerVM() + (pvV * f.getPriorVerVM()));
		}
		o.setTargetVM(o.getTargetVM() + (pV * f.getTargetVM()));

		// setIncentives
		o.setPresentAGG(o.getPresentAGG() + (pV * f.getAGG()));
		o.setPresentESP(o.getPresentESP() + (pV * f.getESP()));
		o.setPresentOPT(o.getPresentOPT() + (pV * f.getOPT()));
		o.setPresentCPA(o.getPresentCPA() + (pV * f.getCPA()));

		updateActVsFct(o, f, true);
		updateBW(o);

	}

	@LogAround
	private FinancialDetailedVO getForecastFinancial(FinancialDetailedVO.rowType rowType, ProposalFinancialVO f, int PY,
			boolean isEstVsEst, boolean isActVsFct, boolean isActVsAct) {
		FinancialDetailedVO o = new FinancialDetailedVO();
		o.setPY(PY);
		o.setPresentKey(f.getPerUnit());
		o.setPrevVerKey(f.getPriorVerPerUnit());
		o.setPriorKey(f.getPriorYearPerUnit());
		o.setModelYear((long) f.getModelYear());
		o.setVehicleLine(f.getVehicleLineDescription());
		o.setBodyStyle(f.getPerUnitDescription());
		o.setVehicleLineCode(f.getVehLineCode());
		o.setRecType(rowType);
		o.setPresentProposal(f.isPresentVehicleLine());
		o.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear()+"!"+f.getPerUnitDescription());
		o.setProposalTier(f.getProposalTier());
	    o.setPriorVerProposalTier(f.getPriorVerProposalTier());
	    o.setPriorYearProposalTier(f.getPriorYearProposalTier());
	    o.setTotalTier(f.getTotalTier());
	    o.setPriorVerTotalTier(f.getPriorVerTotalTier());
	    o.setPriorYearTotalTier(f.getPriorYearTotalTier());
		// set Volume
		o.setPresentVol(f.getVolume());
		o.setPriorVol(f.getPriorYearVolume());
		o.setPrevVerVol(f.getPriorVerVolume());
		// set VM
		o.setPresentVM(f.getVM());
		o.setPriorPYVM(f.getPriorYearVM());
		o.setPrevVerVM(f.getPriorVerVM());
		o.setYoyTarget(f.getYoyTargetVM());
		o.setTargetVM(f.getTargetVM());

		// set Matrix Target VM from Maintain finance data screen
		o.setMatrixTargetVM(f.getNewTargetVM());
		// setIncentives
		o.setPresentAGG(f.getAGG());
		o.setPresentESP(f.getESP());
		o.setPresentOPT(f.getOPT());
		o.setPresentCPA(f.getCPA());

		updateActVsFct(o, f, false);

		updateBW(o);
		return o;
	}

	@LogAround
	private void updateActVsFct(FinancialDetailedVO o, ProposalFinancialVO f, boolean isUpdate) {

		double pV = 1;
		double pvV = 1;
		double pyV = 1;
		if (isUpdate) {
			pV = f.getVolume();
			pvV = f.getPriorVerVolume();
			pyV = f.getPriorYearVolume();
		}
		if (f.getPerUnit() != 0L) {
			pV = pV + 0.000001;
		}
		if (f.getPriorVerPerUnit() != 0L) {
			pvV = pvV + 0.000001;
		}
		if (f.getPriorYearPerUnit() != 0L) {
			pyV = pyV + 0.000001;
		}
		// set CC,Rev,NR and CM for present (Forecast)
		if (o.getRecType() != null) {
			o.setPresentCC(f.getPerUnit() > 0L ? (o.getPresentCC() + (pV * f.getEstCC())) : 0L);
		} else {
			o.setPresentCC(o.getPresentCC() + (pV * f.getEstCC()));
		}
		if (o.getRecType() != null) {
			o.setPresentRevenue(
					f.getPerUnit() > 0L ? (o.getPresentRevenue() + (pV * f.getEstRevenue())) : 0L);
		} else {
			o.setPresentRevenue(o.getPresentRevenue() + (pV * f.getEstRevenue()));
		}
		if (o.getRecType() != null) {
			o.setPresentNR(f.getPerUnit() > 0L ? o.getPresentNR() + (pV * (f.getEstRevenue() + f.getVM())) : 0L);
		} else {
			o.setPresentNR(o.getPresentNR() + (pV * (f.getEstRevenue() + f.getVM())));
		}
		if (o.getRecType() != null) {
			o.setPresentCM(f.getPerUnit() > 0L
					? (o.getPresentCM() + (pV * (f.getEstRevenue() + f.getEstCC() + f.getVM())))
					: 0L);
		} else {
			o.setPresentCM(o.getPresentCM() + (pV * (f.getEstRevenue() + f.getEstCC() + f.getVM())));
		}

		// set CC,Rev,NR and CM for prior PY (Actual)
		if (o.getRecType() != null) {
			o.setPriorPYCC(
					f.getPriorYearPerUnit() > 0L ? (o.getPriorPYCC() + (pyV * f.getPriorYearActCC())) : 0L);
		} else {
			o.setPriorPYCC(o.getPriorPYCC() + (pyV * f.getPriorYearActCC()));
		}
		if (o.getRecType() != null) {
			o.setPriorPYRevenue(f.getPriorYearPerUnit() > 0L
					? (o.getPriorPYRevenue() + (pyV * f.getPriorYearActRevenue()))
					: 0L);
		} else {
			o.setPriorPYRevenue(o.getPriorPYRevenue() + (pyV * f.getPriorYearActRevenue()));
		}
		if (o.getRecType() != null) {
			o.setPriorPYNR(f.getPriorYearPerUnit() > 0L
					? (o.getPriorPYNR() + (pyV * (f.getPriorYearActRevenue() + f.getPriorYearVM())))
					: 0L);
		} else {
			o.setPriorPYNR(o.getPriorPYNR() + (pyV * (f.getPriorYearActRevenue() + f.getPriorYearVM())));
		}
		if (o.getRecType() != null) {
			o.setPriorPYCM(
					f.getPriorYearPerUnit() > 0L
							? (o.getPriorPYCM()
									+ (pyV * (f.getPriorYearActRevenue() + f.getPriorYearActCC() + f.getPriorYearVM())))
							: 0L);
		} else {
			o.setPriorPYCM(o.getPriorPYCM()
					+ (pyV * (f.getPriorYearActRevenue() + f.getPriorYearActCC() + f.getPriorYearVM())));
		}
		// set CC,Rev,NR and CM for prior Ver(Forecast)
		if (o.getRecType() != null) {
			o.setPrevVerCC(
					f.getPriorVerPerUnit() > 0L ? (o.getPrevVerCC() + (pvV * f.getPriorVerFctCC())) : 0L);
		} else {
			o.setPrevVerCC(o.getPrevVerCC() + (pvV * f.getPriorVerFctCC()));
		}
		if (o.getRecType() != null) {
			o.setPrevVerRevenue(
					f.getPriorVerPerUnit() > 0L ? (o.getPrevVerRevenue() + (pvV * f.getPriorVerFctRevenue()))
							: 0L);
		} else {
			o.setPrevVerRevenue(o.getPrevVerRevenue() + (pvV * f.getPriorVerFctRevenue()));
		}
		if (o.getRecType() != null) {
			o.setPrevVerNR(
					f.getPriorVerPerUnit() > 0L ? (o.getPrevVerNR() + (pvV * f.getPriorVerFctNR())) : 0L);
		} else {
			o.setPrevVerNR(o.getPrevVerNR() + (pvV * f.getPriorVerFctNR()));
		}
		if (o.getRecType() != null) {
			o.setPrevVerCM(
					f.getPriorVerPerUnit() > 0L ? (o.getPrevVerCM() + (pvV * f.getPriorVerFctCM())) : 0L);
		} else {
			o.setPrevVerCM(o.getPrevVerCM() + (pvV * f.getPriorVerFctCM()));
		}

		// set CC,Rev,NR and CM for Target
		o.setTargetCC(o.getTargetCC() + (pV * f.getTargetFctCC()));
		o.setTargetRevenue(o.getTargetRevenue() + (pV * f.getTargetFctRevenue()));
		o.setTargetNR(o.getTargetNR() + (pV * f.getTargetFctNR()));
		o.setTargetCM(o.getTargetCM() + (pV * f.getTargetFctCM()));
	}

	@LogAround
	private FinancialDetailedVO getAverageForecastFinancial(FinancialDetailedVO o) {
		o.setVehicleLine(" ");
		o.setBodyStyle(" ");
		if (o.getPresentVol() > 0) {
			o.setPresentVM(o.getPresentVM() / o.getPresentVol());
			o.setPresentCC((o.getPresentCC() / o.getPresentVol()));
			o.setPresentRevenue((o.getPresentRevenue() / o.getPresentVol()));
			o.setPresentNR((o.getPresentNR() / o.getPresentVol()));
			o.setPresentCM((o.getPresentCM() / o.getPresentVol()));

			o.setTargetVM((o.getTargetVM() / o.getPresentVol()));
			o.setTargetCC((o.getTargetCC() / o.getPresentVol()));
			o.setTargetRevenue((o.getTargetRevenue() / o.getPresentVol()));
			o.setTargetNR((o.getTargetNR() / o.getPresentVol()));
			o.setTargetCM((o.getTargetCM() / o.getPresentVol()));
			// setIncentives
			o.setPresentAGG((o.getPresentAGG() / o.getPresentVol()));
			o.setPresentESP((o.getPresentESP() / o.getPresentVol()));
			o.setPresentOPT((o.getPresentOPT() / o.getPresentVol()));
			o.setPresentCPA((o.getPresentCPA() / o.getPresentVol()));
		}
		if (o.getPriorVol() > 0) {
			o.setPriorPYVM(o.getPriorPYVM() / o.getPriorVol());
			o.setPriorPYCC((o.getPriorPYCC() / o.getPriorVol()));
			o.setPriorPYRevenue((o.getPriorPYRevenue() / o.getPriorVol()));
			o.setPriorPYNR((o.getPriorPYNR() / o.getPriorVol()));
			o.setPriorPYCM((o.getPriorPYCM() / o.getPriorVol()));
		}
		if (o.getPrevVerVol() > 0) {
			o.setPrevVerVM(o.getPrevVerVM() / o.getPrevVerVol());
			o.setPrevVerCC(o.getPrevVerCC() / o.getPrevVerVol());
			o.setPrevVerRevenue(o.getPrevVerRevenue() / o.getPrevVerVol());
			o.setPrevVerNR(o.getPrevVerNR() / o.getPrevVerVol());
			o.setPrevVerCM(o.getPrevVerCM() / o.getPrevVerVol());
		}
		updateBW(o);
		return o;
	}

	@LogAround
	private void updateBW(FinancialDetailedVO o) {
		
		o.setBwVol((o.getPresentVol() - o.getPriorVol()));
		o.setBwPrevVerVol((o.getPresentVol() - o.getPrevVerVol()));
		o.setBwPriorPYVM((o.getPresentVM() - o.getPriorPYVM()));
		o.setBwPrevVerVM((o.getPresentVM() - o.getPrevVerVM()));
		o.setBwTargetVM((o.getPresentVM() - o.getTargetVM()));
		o.setBwPriorPYNR(o.getPresentNR() - o.getPriorPYNR());
		o.setBwTargetNR(o.getPresentNR() - o.getTargetNR());
		o.setBwPriorPYCM(o.getPresentCM() - o.getPriorPYCM());
		o.setBwTargetCM(o.getPresentCM() - o.getTargetCM());
		
		
	}

}
