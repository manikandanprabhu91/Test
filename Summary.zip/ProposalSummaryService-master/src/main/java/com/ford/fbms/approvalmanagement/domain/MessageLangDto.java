package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for messageLang model.
 *
 * @author GILNAGOV on 2/15/2021.
 */

@Entity
@Table(name = "[MFBMD101_ERROR_LIST]")
@Getter
@Setter
public class MessageLangDto implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @Column(name = "[FBMD101_ERROR_CODE_K]")
  private String messageCode;

  @Column(name = "[FBMD101_ERROR_X]")
  private String messageDesc;

}