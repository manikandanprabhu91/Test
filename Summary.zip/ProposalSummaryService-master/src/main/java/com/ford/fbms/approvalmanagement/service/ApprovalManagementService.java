package com.ford.fbms.approvalmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ProposalViewDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MxRuleEngine;
import com.ford.fbms.approvalmanagement.ruleengines.NaRuleEngine;
import com.ford.fbms.approvalmanagement.ruleengines.RuleEngineInterface;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalCommentsVo;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.CacheUtil;
import com.ford.fbms.approvalmanagement.util.Constants;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementCreateValidator;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementValidator;
import com.ford.fbms.approvalmanagement.validators.UserIdValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to trigger appropriate activities of rule engines in order.
 *
 * @author NACHUTHA on 3/01/2021.
 */
@Slf4j
@Service
public class ApprovalManagementService {

  private final  List<RuleEngineInterface> ruleEngineInterfaces = new ArrayList<>();
  private final  ResponseBuilder responseBuilder;

  @Autowired
  protected UserIdValidator userIdValidator;
  @Autowired
  private final RestService restService;
  @Autowired
  protected ApprovalManagementValidator approvalManagementValidator;
  @Autowired
  protected ApprovalManagementCreateValidator approvalManagementCreateValidator;
  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;
  @Autowired
  protected ControllerThresholdRepository controllerThresholdRepository;
  @Autowired
  protected MultiYearBonusRepository multiYearBonusRepository;
  @Autowired
  protected PerUnitOptViewRepository perUnitOptViewRepository;
  @Autowired
  protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
  @Autowired
  protected TierVolumeRepository tierVolumeRepository;
  @Autowired
  protected ProposalSummaryViewRepository proposalSummaryViewRepository;
  @Autowired
  protected AccountSalesSummaryRepository accountSalesSummaryRepository;
  @Autowired
  protected BodyFinancialRepository bodyFinancialRepo;
  @Autowired
  protected PerUnitIncentiveNewViewRepository perUnitIncentiveNewViewRepo;
  @Autowired
  protected ProposalBodyFinancialViewRepository proposalBodyFinancialViewRepo;
  @Autowired
  protected TargetBandRepository targetBandRepo;
  @Autowired
  protected NewBodyStyleRepository newBodyStyleRepo;
  @Autowired
  protected ReportLevelRepository reportLevelRepo;
  @Autowired
  protected FordPersonRepository fordPersonRepo;
  @Autowired
  private ProcedureRepository procedureRepository;
  @Autowired
  protected ProposalRepository proposalRepository;

  /**
   * Constructor to do dependency injection and adding appropriate service
   * implementations.
   */
  @Autowired
  public ApprovalManagementService(final NaRuleEngine naRuleEngine, final MxRuleEngine mxRuleEngine,
                                   final ResponseBuilder responseBuilder, final CacheUtil cacheUtil,
                                   final RestService restService) {
    this.responseBuilder = responseBuilder;
    this.restService = restService;
    // Add tenant implementations here
    ruleEngineInterfaces.add(naRuleEngine);
    ruleEngineInterfaces.add(mxRuleEngine);
  }

  /**
   * To encapsulate required query and path params.
   *
   * @param cdsId     A requester of the request
   * @param countryCd A requester country code
   * @return {@link ApiParams}
   */
  public ApiParams buildApiParams(final String cdsId, final String countryCd, final Long proposalKey,
                                  final String volumeFinancialDataSource,final String fleetRating) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId(cdsId);
    apiParams.setCountryCd(countryCd);
    apiParams.setProposalKey(proposalKey);
    apiParams.setVolumeFinancialDataSource(volumeFinancialDataSource);
    apiParams.setFleetRating(fleetRating);
    return apiParams;
  }

  public ApiParams buildApiParams(final String cdsId, final String countryCd, final Long proposalKey,
                                  final Integer proposalYr, final Integer proposalYrVer, final Long finKey,
                                  final String volumeFinancialDataSource,final String fleetRating) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId(cdsId);
    apiParams.setCountryCd(countryCd);
    apiParams.setProposalKey(proposalKey);
    apiParams.setFinKey(finKey);
    apiParams.setProposalYr(proposalYr);
    apiParams.setProposalYrVer(proposalYrVer);
    apiParams.setVolumeFinancialDataSource(volumeFinancialDataSource);
    apiParams.setFleetRating(fleetRating);
    return apiParams;
  }

  public ApiParams buildApiParams(final String cdsId, final String countryCd, final Long proposalKey) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId(cdsId);
    apiParams.setCountryCd(countryCd);
    apiParams.setProposalKey(proposalKey);
    return apiParams;
  }

  public ApiParams buildApiParams(final String cdsId, final String countryCd, final Long finKey, final Long proposalKey, final Integer proposalYr, final Integer proposalYrVer, final String orgCode, final Long ouUnitKey) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId(cdsId);
    apiParams.setCountryCd(countryCd);
    apiParams.setFinKey(finKey);
    apiParams.setProposalKey(proposalKey);
    apiParams.setProposalYr(proposalYr);
    apiParams.setProposalYrVer(proposalYrVer);
    apiParams.setOrgCd(orgCode);
    apiParams.setOuUnitKey(ouUnitKey);
    return apiParams;
  }

  public ApiParams buildApiParams(final String cdsId, final String countryCd,
                                  final Long proposalKey, final Integer proposalYr,
                                  final Integer proposalYrVer, final Long finKey,
                                  final boolean isComplete, final String volumeFinancialDataSource) {
    final ApiParams apiParams = new ApiParams();
    apiParams.setUserId(cdsId);
    apiParams.setCountryCd(countryCd);
    apiParams.setProposalKey(proposalKey);
    apiParams.setProposalYr(proposalYr);
    apiParams.setProposalYrVer(proposalYrVer);
    apiParams.setFinKey(finKey);
    apiParams.setComplete(isComplete);
    apiParams.setVolumeFinancialDataSource(volumeFinancialDataSource);
    return apiParams;
  }
  
  public ApiParams buildApiParams(final String cdsId, final String countryCd,final CreateProposalRequest comments,final Long proposalKey,final String action,boolean highPriorityFlag) {
	    final ApiParams apiParams = new ApiParams();
	    apiParams.setUserId(cdsId);
	    apiParams.setCountryCd(countryCd);
	    apiParams.setComments(comments);
	    apiParams.setProposalKey(proposalKey);
	    apiParams.setAction(action);
	    apiParams.setHighPriority(highPriorityFlag);
	    
	    return apiParams;
	  }

 

  public GenericResponse processSummaryAndSubmit(final ApiParams apiParams, final HttpServletRequest httpRequest,
                                                 final RequestMode requestMode,final HttpServletResponse response) {
    GenericResponse genericResponse = null;
    final CreateProposalRequest createProposalRequest = apiParams.getComments();
    try {
      final Optional<RuleEngineInterface> serviceImpl = ruleEngineInterfaces.stream()
          .filter(impl -> impl.isRequestBehalfOfThisImpl(apiParams.getCountryCd())).findAny();

      if (serviceImpl.isPresent()) {
        LoggerBuilder.printInfo(log,
            logger -> logger.methodName(Constants.PROCESS_SUMMARY_AND_SUBMIT).userId(apiParams.getUserId())
                .message(ApprovalConstants.RULE_ENGINE_FOUND + serviceImpl.get()));

        final List<GenericResponseWrapper> genericResponseWrapper = serviceImpl.get().validate(apiParams, null,
            requestMode, httpRequest);

        final GenericResponseWrapper consolidatedValidationResp = filterRequiredDtos(genericResponseWrapper);
        if ((null != consolidatedValidationResp.getGenericResponse())) {
          LoggerBuilder.printError(log, logger -> logger.methodName(Constants.PROCESS_SUMMARY_AND_SUBMIT)
              .userId(apiParams.getUserId()).message(ApprovalConstants.VALIDATION_FAILED));
          
          genericResponse =consolidatedValidationResp.getGenericResponse();
        } else {
          LoggerBuilder.printInfo(log, logger -> logger.methodName(Constants.PROCESS_SUMMARY_AND_SUBMIT)
              .userId(apiParams.getUserId()).message(ApprovalConstants.VALIDATION_PASS));
          switch (requestMode) {
            case APPROVAL_CHAIN:
              genericResponse = serviceImpl.get().getApprovalChain(consolidatedValidationResp);
              break;
            case SUBMIT_PROPOSAL:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
            	genericResponse = serviceImpl.get().createApproval(apiParams, consolidatedValidationResp, requestMode);
                procedureRepository.updateFinancialData(apiParams.getProposalKey());
            	break;
            case SAVE_PROPOSAL:
            	genericResponse = serviceImpl.get().saveProposal(apiParams, consolidatedValidationResp);
              break;
            case SENDBACK_PROPOSAL:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
            	genericResponse = serviceImpl.get().sendBackProposal(apiParams, consolidatedValidationResp, requestMode,httpRequest,response,createProposalRequest);
              break;
            case RECALL_PROPOSAL:
              genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
              genericResponse = serviceImpl.get().recallProposal(apiParams, consolidatedValidationResp);
              break;
            case REVISE_PROPOSAL:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
            	genericResponse = serviceImpl.get().reviseProposal(apiParams, consolidatedValidationResp);
              break;
            case GET_TOTALS_AVG_FINANICIALS:
              genericResponse = serviceImpl.get().getTotalAvgFinancials(apiParams, consolidatedValidationResp);
              break;
            case REJECT_PROPOSAL:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
            	genericResponse = serviceImpl.get().rejectProposal(apiParams, consolidatedValidationResp, requestMode,httpRequest,response,createProposalRequest);
              break;
            case GET_VOLUME_FINANCIAL_OPTIONS:
              genericResponse = serviceImpl.get().getVolumeFinancials(consolidatedValidationResp);
              break;
            case VALIDATE_ACTIONS:
              genericResponse = serviceImpl.get().validateAction(apiParams,consolidatedValidationResp);
              break;
            case DOWNLOAD_PROPOSAL:
              genericResponse = serviceImpl.get().downloadProposal(apiParams, consolidatedValidationResp);
              break;
            case GET_FINANCIAL_LIST:
            	genericResponse = serviceImpl.get().populateFinancialList(consolidatedValidationResp);
            	break;
            case GET_ACTUAL_LIST:
            case GET_FORECAST_LIST:
              genericResponse = serviceImpl.get().populateFinancialList(consolidatedValidationResp);
              break;
            case APPROVE_PROPOSAL:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
            	genericResponse = serviceImpl.get().approveProposal(apiParams, consolidatedValidationResp, requestMode,httpRequest,response,createProposalRequest);
                break; 
            case NEXTDEAL_APPROVE:
            	genericResponse = serviceImpl.get().createProposalComments(apiParams,createProposalRequest,httpRequest,genericResponse);
                genericResponse = serviceImpl.get().approveProposal(apiParams, consolidatedValidationResp, requestMode,httpRequest,response,createProposalRequest);
                genericResponse = serviceImpl.get().findNextDeal(apiParams, consolidatedValidationResp );
                break;    
            default:
              break;
          }
          
          
          LoggerBuilder.printInfo(log, logger -> logger.methodName(Constants.PROCESS_SUMMARY_AND_SUBMIT)
              .userId(apiParams.getUserId()).message(ApprovalConstants.COMPLETED_DB));
        }
      } else {
        LoggerBuilder.printError(log, logger -> logger.methodName(Constants.PROCESS_SUMMARY_AND_SUBMIT)
            .userId(apiParams.getUserId()).message(ApprovalConstants.RULE_ENGINE_NOT_AVAILABLE));
        return responseBuilder.generateResponse(ResponseCodes.UNEXPECTED_BEHAVIOR);
      }
    } catch (Exception e) {
      LoggerBuilder.printError(log, logger ->
          logger.exceptionMessage(e.getMessage()).exception(e).userId(apiParams.getUserId())
              .country(apiParams.getCountryCd()).methodName("approval chain")
              .message("Exception in creating approval chain"));
    }
    return genericResponse;
  }

  

  
/**
   * To get approval information.
   *
   * @param apiParams   {@link ApiParams}
   * @param httpRequest {@link HttpServletRequest}
   * @return {@link GenericResponse}
   */
  public GenericResponse financialDataStoredProcedure(final ApiParams apiParams, final HttpServletRequest httpRequest,
                                                      final RequestMode requestMode) {

    GenericResponse genericResponse;

    // 1. Find appropriate implementation
    final Optional<RuleEngineInterface> serviceImpl = ruleEngineInterfaces.stream()
        .filter(impl -> impl.isRequestBehalfOfThisImpl(apiParams.getCountryCd())).findAny();

    // If service rule engines instance found, proceed with that
    if (serviceImpl.isPresent()) {
      LoggerBuilder.printInfo(log,
          logger -> logger.methodName(Constants.GET_APPROVAL).userId(apiParams.getUserId())
              .message(ApprovalConstants.RULE_ENGINE_FOUND + serviceImpl.get().toString()));

      // 2. Do the validations
      final List<GenericResponseWrapper> genericResponseWrapper = serviceImpl.get().validate(apiParams, null,
          requestMode, httpRequest);

      final GenericResponseWrapper consolidatedValidationResp = filterRequiredDtos(genericResponseWrapper);

      if (null != consolidatedValidationResp.getGenericResponse()) {
        LoggerBuilder.printError(log, logger -> logger.methodName(Constants.GET_APPROVAL)
            .userId(apiParams.getUserId()).message(ApprovalConstants.VALIDATION_FAILED));
        genericResponse = consolidatedValidationResp.getGenericResponse();
      } else {
        LoggerBuilder.printInfo(log, logger -> logger.methodName(Constants.GET_APPROVAL)
            .userId(apiParams.getUserId()).message(ApprovalConstants.VALIDATION_PASS));

        // 4. Do the DB operations
        genericResponse = financialDataResponse(apiParams, consolidatedValidationResp, serviceImpl.get());
        LoggerBuilder.printInfo(log, logger -> logger.methodName(Constants.GET_APPROVAL)
            .userId(apiParams.getUserId()).message(ApprovalConstants.COMPLETED_DB));

        // 5. Trigger post DB operations if any
      }
      return genericResponse;
    } else {
      LoggerBuilder.printError(log, logger -> logger.methodName(Constants.GET_APPROVAL)
          .userId(apiParams.getUserId()).message(ApprovalConstants.RULE_ENGINE_NOT_AVAILABLE));
      return responseBuilder.generateResponse(ResponseCodes.UNEXPECTED_BEHAVIOR);
    }
  }

  /**
   * This is to set response for financial data stored procedure.
   *
   * @param apiParams Input parameters for db
   * @return {@link ApprovalProcessDto}
   */
  private GenericResponse financialDataResponse(final ApiParams apiParams,
                                                final GenericResponseWrapper validationResponse, final RuleEngineInterface ruleEngine) {

    if (validationResponse.getFinancialDataStatus() == null || validationResponse.getFinancialDataStatus() == 0) {
      return responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED);
    } else {
      return responseBuilder.generateResponse(ResponseCodes.SUCCESS_UPDATE);
    }
  }




  public GenericResponseWrapper getProposalNotesDetails(ApiParams apiParams, HttpServletRequest httpRequest,
                                                        RequestMode getProsalNotes) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    List<ProposalCommentsVo> proposalCommentsVos;
    GenericResponseWrapper genericResponse = restService.getProposalNotesDetails(apiParams, httpRequest);

    if (genericResponse instanceof GenericResponseWrapper) {
      genericResponseWrapper = genericResponse;
      if (null != genericResponseWrapper.getProposalNotesRetrival()) {
        proposalCommentsVos = filterProposalComments(genericResponseWrapper.getProposalNotesRetrival(), apiParams); //completed
        genericResponseWrapper.setProposalCommentsVos(proposalCommentsVos);
      }
    }
    return genericResponse;
  }

  private List<ProposalCommentsVo> filterProposalComments(List<ProposalViewDto> proposalNotesRetrival, final ApiParams apiParams) {
    return proposalNotesRetrival.stream()
        .filter(p -> p.getProposalYear().equals(String.valueOf(apiParams.getProposalYr())))
        .filter(p -> p.getProposalVersion().equals(String.valueOf(apiParams.getProposalYrVer())))
        .map(p -> {
          ProposalCommentsVo commentsVo = new ProposalCommentsVo();
          commentsVo.setProposalComments(p.getProposalComments());
          commentsVo.setCommentedBy(p.getCommentedBy());
          commentsVo.setProposalVersion(p.getProposalVersion());
          commentsVo.setProposalYear(p.getProposalYear());
          commentsVo.setDateSubmitted(p.getDateSubmitted());
          return commentsVo;
        })
        .collect(Collectors.toList());
  }

  public String getMultiYearPriceProtectionDetails(ApiParams apiParams, HttpServletRequest httpRequest,
                                                   RequestMode getMultiyrPp) {
    return restService.getMultiYearPriceProtectionDetails(apiParams, httpRequest);
  }

	private GenericResponseWrapper filterRequiredDtos(final List<GenericResponseWrapper> genericResponseWrapper) {
		final GenericResponseWrapper consolidatedValidationResp = new GenericResponseWrapper();
		for (final GenericResponseWrapper grw : genericResponseWrapper) {
			// If Generic response is available, then its a error response
			if (null != grw.getGenericResponse())  {
				consolidatedValidationResp.setGenericResponse(grw.getGenericResponse());
				return consolidatedValidationResp;
			}
			
			if (null != grw.getApprovalProcessDtoList()) {
				consolidatedValidationResp.setApprovalProcessDtoList(grw.getApprovalProcessDtoList());
			}
			if (null != grw.getTargetList()) {
				consolidatedValidationResp.setTargetList(grw.getTargetList());
			}
			if (null != grw.getFinancialDetailedVOList()) {
				consolidatedValidationResp.setFinancialDetailedVOList(grw.getFinancialDetailedVOList());
			}
			if (null != grw.getApprovalResponseVo()) {
				consolidatedValidationResp.setApprovalResponseVo(grw.getApprovalResponseVo());
			}
			if (null != grw.getApprovalChainList()) {
				consolidatedValidationResp.setApprovalChainList(grw.getApprovalChainList());
			}
			if (null != grw.getFinancialDataStatus()) {
				consolidatedValidationResp.setFinancialDataStatus(grw.getFinancialDataStatus());
			}
			if (null != grw.getProposalDataDto()) {
				consolidatedValidationResp.setProposalDataDto(grw.getProposalDataDto());
			}
			if (null != grw.getApprovalResponseNonFinancialVo()) {
				consolidatedValidationResp.setApprovalResponseNonFinancialVo(grw.getApprovalResponseNonFinancialVo());
			}
			if (null != grw.getDropDownMap()) {
				consolidatedValidationResp.setDropDownMap(grw.getDropDownMap());
			}
			if (null != grw.getActionsVO()) {
				consolidatedValidationResp.setActionsVO(grw.getActionsVO());
			}
			if (null != grw.getApprovalProcessDto()) {
				consolidatedValidationResp.setApprovalProcessDto(grw.getApprovalProcessDto());
			}
			if (null != grw.getFordPersonDto()) {
				consolidatedValidationResp.setFordPersonDto(grw.getFordPersonDto());
			}
			if (null != grw.getIsAuthorized()) {
				consolidatedValidationResp.setIsAuthorized(grw.getIsAuthorized());
			}
			if (null != grw.getIsProposalAssignee()) {
				consolidatedValidationResp.setIsProposalAssignee(grw.getIsProposalAssignee());
			}
			if (null != grw.getPyCountryDefinition()) {
				consolidatedValidationResp.setPyCountryDefinition(grw.getPyCountryDefinition());
			}
			if (null != grw.getUpdateRecalledQueue()) {
				consolidatedValidationResp.setUpdateRecalledQueue(grw.getUpdateRecalledQueue());
			}
			if (null != grw.getPriorProposalDto()) {
				consolidatedValidationResp.setPriorProposalDto(grw.getPriorProposalDto());
			}
			if (null != grw.getTargetBandDto()) {
				consolidatedValidationResp.setTargetBandDto(grw.getTargetBandDto());
			}
			if (null != grw.getVehicleLineOptionDiscountVos()) {
				consolidatedValidationResp.setVehicleLineOptionDiscountVos(grw.getVehicleLineOptionDiscountVos());
			}
			if (null != grw.getProposalCommentsVos()) {
				consolidatedValidationResp.setProposalCommentsVos(grw.getProposalCommentsVos());
			}
			if (null != grw.getProposalVo()) {
				consolidatedValidationResp.setProposalVo(grw.getProposalVo());
			}
			if (null != grw.getSubsidiariesVos()) {
				consolidatedValidationResp.setSubsidiariesVos(grw.getSubsidiariesVos());
			}
			if (null != grw.getFinancialDetailedMexVOList()) {
				consolidatedValidationResp.setFinancialDetailedMexVOList(grw.getFinancialDetailedMexVOList());
			}
			if (null != grw.getCustomerAcceptanceS3Dto()) {
				consolidatedValidationResp.setCustomerAcceptanceS3Dto(grw.getCustomerAcceptanceS3Dto());
			}
		}
		return consolidatedValidationResp;
	}

}
