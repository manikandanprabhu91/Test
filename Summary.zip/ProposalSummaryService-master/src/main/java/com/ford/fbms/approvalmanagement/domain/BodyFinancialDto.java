package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBME18_BODY_FINANCIAL database table.
 * 
 */
@Entity
@Table(name = "MFBME18_BODY_FINANCIAL")
public class BodyFinancialDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BodyFinancialPKDto id;

	@Column(name = "FBME18_BASE_INCENTIVE_R")
	private BigDecimal baseIncentiveR;

	@Column(name = "FBME18_BDY_STYL_THRSHLD_P")
	private BigDecimal bodyStylThrshldP;

	@Column(name = "FBME18_CONTRIBUTION_COST_R")
	private BigDecimal contributionCostR;

	@Column(name = "FBME18_EMAIL_TRGR_F")
	private String emailTrgrF;

	@Column(name = "FBME18_EST_CURT_YR_CONTB_CST_A")
	private BigDecimal estCurtYrContbCstA;

	@Column(name = "FBME18_EST_CURT_YR_REVN_CHNG_A")
	private BigDecimal estCurtYrRevnChngA;

	@Column(name = "FBME18_MY_OVER_MY_TARGET_R")
	private BigDecimal myOverMyTargetR;

	@Column(name = "FBME18_REVENUE_R")
	private BigDecimal revenueR;

	@Column(name = "FBME18_TIER1_TARGET_R")
	private BigDecimal tier1TargetR;

	@Column(name = "FBME18_TIER2_TARGET_R")
	private BigDecimal tier2TargetR;

	@Column(name = "FBME18_TIER3_TARGET_R")
	private BigDecimal tier3TargetR;

	@Column(name = "FBME18_TIER4_TARGET_R")
	private BigDecimal tier4TargetR;

	@Column(name = "FBME18_TIER5_TARGET_R")
	private BigDecimal tier5TargetR;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME18_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBME18_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBME18_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME18_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBME18_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBME18_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
