package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.FinProfileDto;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface FinProfileRepository extends JpaRepository<FinProfileDto, Long> {
 
	@Query(value="select * from {h-schema}MFBME31_FIN_PROFILE  "
      + "where  FBME01_FIN_MASTER_K= :finMasterKey "
      + "AND FBME50_ACCOUNT_CLASS_C = 'MRental'",nativeQuery = true)
	Optional<FinProfileDto> findIdAndAccountClass(@Param("finMasterKey")long finMasterKey);
}
