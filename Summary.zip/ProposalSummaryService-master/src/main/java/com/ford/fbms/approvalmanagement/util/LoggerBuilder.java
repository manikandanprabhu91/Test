package com.ford.fbms.approvalmanagement.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import io.swagger.models.HttpMethod;
import java.lang.reflect.Field;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import javax.servlet.http.HttpServletRequest;
import lombok.Setter;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

/**
 * A class for holding logger attributes.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Slf4j
@Setter
@Accessors(fluent = true)
public final class LoggerBuilder {

  //Application statics
  private static ObjectMapper objectMapper = new ObjectMapper();
  private String serviceGroup = Constants.SERVICE_GROUP_NAME;

  //Thread statics
  private String serviceId;
  private String correlationId;
  private String vcapRequestId;
  private String buildVersion;
  private String traceId;

  /**
   * ****Variables - Strictly no primitives****
   * .
   */
  
  private String className;
  private String methodName;
  private String action;
  private String userId;
  private String country;
  private String message;
  private String exceptionMessage;
  private Exception exception;
  private String responseStatus;
  private String responseBody;
  private Long responseTime;
  private String request;
  private String mqName;
  private String dateTime;
  private String httpMethod;
  private String json;
  private String resourceUri;
  private String subsidiariesServiceUrl;
  private String notesServiceUrl;
  private String proposalServiceUrl;
  private String vehicleServiceUrl;
  private String proposalTermsUrl;
  private String proposalNotesUrl;
  private String multiYearIncentiveUrl;
  
  private LoggerBuilder(final String serviceId, final String correlationId,
      final String vcapRequestId, final String buildVersion, final String traceId) {
    this.serviceId = serviceId;
    this.correlationId = correlationId;
    this.vcapRequestId = vcapRequestId;
    this.buildVersion = buildVersion;
    this.traceId = traceId;
  }

  /**
   * To log in INFO mode for given class and consumer.
   *
   * @param declaringType class name of the caller
   * @param consumer      required LoggerBuilder statements
   */
  public static void printInfo(final Class declaringType, final Consumer<LoggerBuilder> consumer) {
     final Logger logger = LoggerFactory.getLogger(declaringType);
    if (logger.isInfoEnabled()) {
      final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
          MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
      CompletableFuture.runAsync(() -> {
        consumer.accept(loggerBuilder);
        loggerBuilder.info(logger);
      });
    }
  }

  /**
   * To log in INFO mode for given logger and consumer.
   *
   * @param logger   logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printInfo(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    if (logger.isInfoEnabled()) {
      final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
          MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
      CompletableFuture.runAsync(() -> {
        consumer.accept(loggerBuilder);
        loggerBuilder.info(logger);
      });
    }
  }

  /**
   * To log in DEBUG mode for given logger and consumer.
   *
   * @param logger   logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printDebug(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    if (logger.isDebugEnabled()) {
      final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
          MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
          MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
      CompletableFuture.runAsync(() -> {
        consumer.accept(loggerBuilder);
        loggerBuilder.debug(logger);
      });
    }
  }

  /**
   * To log in ERROR mode for given class and consumer.
   *
   * @param declaringType class name of the caller
   * @param consumer      required LoggerBuilder statements
   */
  public static void printError(final Class declaringType, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      final Logger logger = LoggerFactory.getLogger(declaringType);
      consumer.accept(loggerBuilder);
      loggerBuilder.error(logger);
    });
  }

  /**
   * To log in ERROR mode for given logger and consumer.
   *
   * @param logger   logger instance to log
   * @param consumer required LoggerBuilder statements
   */
  public static void printError(final Logger logger, final Consumer<LoggerBuilder> consumer) {
    final LoggerBuilder loggerBuilder = new LoggerBuilder(MDC.get(Constants.REQUEST_SERVICE_ID),
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME), MDC.get(Constants.VCAP_REQUEST_HEADER_NAME),
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME), MDC.get(Constants.TRACE_ID_HEADER_NAME));
    CompletableFuture.runAsync(() -> {
      consumer.accept(loggerBuilder);
      loggerBuilder.error(logger);
    });
  }

  /**
   * To log request/response asynchronously.
   */
  public static void logApiRequestResponse(final ApiParams apiParams, final Object data,
      final HttpServletRequest request, final HttpMethod requestType) {
    final Map<String, String> webContextMap = MDC.getCopyOfContextMap();
    // Trigger asynchronously
    CompletableFuture.runAsync(() -> {
      MDC.setContextMap(webContextMap);
      try {
        // Marshal the data
        final String json;
        if (null != data) {
          json = objectMapper.writeValueAsString(data);
        } else {
          json = "";
        }
        LoggerBuilder.printInfo(log, logger -> logger.resourceUri(apiParams.getResourceUri())
            .httpMethod(requestType.name()).json(json));
      } catch (JsonProcessingException e) {
        LoggerBuilder.printError(log, logger -> logger.resourceUri(apiParams.getResourceUri())
            .message("Error while parsing the request/response").httpMethod(requestType.name()));
      }
    });
  }

  /**
   * To log in INFO mode.
   */
  private void info(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName().substring(logger.getName().lastIndexOf(".")+1);
      try {
        logger.info(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.info(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in DEBUG mode.
   */
  private void debug(final Logger logger) {
    if (null != logger) {
      this.className = logger.getName().substring(logger.getName().lastIndexOf(".")+1);
      try {
        logger.debug(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.debug(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To log in ERROR mode.
   */
  private void error(final Logger logger) {
    if (null != logger && logger.isErrorEnabled()) {
      this.className = logger.getName().substring(logger.getName().lastIndexOf(".")+1);
      try {
        logger.error(getNotNullFields());
      } catch (IllegalAccessException e) {
        logger.error(Constants.UNABLE_TO_GET_NOT_NULL_FIELDS, e);
      }
    }
  }

  /**
   * To get not null fields of this class.
   */
  private String getNotNullFields() throws IllegalAccessException {
    final StringBuilder stringBuilder = new StringBuilder();
    for (final Field f : getClass().getDeclaredFields()) {
      if ("objectMapper".equals(f.getName()) || "log".equals(f.getName())) {
        continue;
      }
      if (f.get(this) != null) {
        stringBuilder.append(f.getName()).append('=').append(f.get(this)).append(',');
      }
    }
    return stringBuilder.toString();
  }
}