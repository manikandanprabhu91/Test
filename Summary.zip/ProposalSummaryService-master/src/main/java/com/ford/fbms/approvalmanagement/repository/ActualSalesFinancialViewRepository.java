package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.AccountSaleSummaryPK;
import com.ford.fbms.approvalmanagement.domain.ActualSalesFinancialViewDto;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ActualSalesFinancialViewRepository extends JpaRepository<ActualSalesFinancialViewDto, AccountSaleSummaryPK> {
  @Query(value = "WITH\r\n"
  		+ "	SUBFIN\r\n"
  		+ "AS\r\n"
  		+ "(\r\n"
  		+ "SELECT\r\n"
  		+ "	A01.FBMA01_PROPOSAL_K,\r\n"
  		+ "	A01.FBMD12_PROPOSAL_YEAR_C,\r\n"
  		+ "	A01.FBME01_FIN_MASTER_K,\r\n"
  		+ "	A01.FBME01_FIN_MASTER_K FBME01_SUBS_FIN_K\r\n"
  		+ "FROM\r\n"
  		+ "	{h-schema}MFBMA01_PROPOSAL A01\r\n"
  		+ "  WHERE A01.FBMA01_PROPOSAL_K=:proposalSaKey\r\n"
  		+ "UNION\r\n"
  		+ "SELECT\r\n"
  		+ "	A01.FBMA01_PROPOSAL_K,\r\n"
  		+ "	A01.FBMD12_PROPOSAL_YEAR_C,\r\n"
  		+ "  	A01.FBME01_FIN_MASTER_K,\r\n"
  		+ "	A07.FBME01_SUBS_FIN_K\r\n"
  		+ "FROM\r\n"
  		+ "	{h-schema}MFBMA01_PROPOSAL A01,\r\n"
  		+ "	{h-schema}MFBMA07_PROPOSAL_SUBSIDIARY A07\r\n"
  		+ "WHERE\r\n"
  		+ "	A01.FBMA01_PROPOSAL_K = A07.FBMA01_PROPOSAL_K\r\n"
  		+ "  AND A01.FBMA01_PROPOSAL_K=:proposalSaKey\r\n"
  		+ "),\r\n"
  		+ "D80_SUBFIN\r\n"
  		+ "AS\r\n"
  		+ "(\r\n"
  		+ "SELECT\r\n"
  		+ "	SUBFIN.FBMA01_PROPOSAL_K,\r\n"
  		+ "	SUBFIN.FBME01_FIN_MASTER_K,\r\n"
  		+ "	SUBFIN.FBME01_SUBS_FIN_K,\r\n"
  		+ "	SUBFIN.FBMD12_PROPOSAL_YEAR_C,\r\n"
  		+ "	D80.FBME03_BDYSTL_K,\r\n"
  		+ "	D80.FBMD80_AVG_REVENUE_R,\r\n"
  		+ "	D80.FBMD80_AVG_CNTRB_COST_R\r\n"
  		+ "FROM\r\n"
  		+ "	SUBFIN,\r\n"
  		+ "	{h-schema}MFBMD80_ACTUAL_FINANCIAL D80\r\n"
  		+ "WHERE\r\n"
  		+ "	SUBFIN.FBME01_FIN_MASTER_K = D80.FBME01_FIN_MASTER_K\r\n"
  		+ "  AND	SUBFIN.FBMD12_PROPOSAL_YEAR_C=D80.FBMD12_PROPOSAL_YEAR_C\r\n"
  		+ ")\r\n"
  		+ "SELECT\r\n"
  		+ "	D80_SUBFIN.FBMA01_PROPOSAL_K FBMA01_PROPOSAL_K,\r\n"
  		+ "	D80_SUBFIN.FBME01_FIN_MASTER_K FBME01_FIN_MASTER_K,\r\n"
  		+ "	D80_SUBFIN.FBMD12_PROPOSAL_YEAR_C FBMD12_PROPOSAL_YEAR_C,\r\n"
  		+ "	D80_SUBFIN.FBME03_BDYSTL_K FBME03_BDYSTL_K,\r\n"
  		+ "	MIN(D80_SUBFIN.FBMD80_AVG_REVENUE_R)		FBMD80_AVG_REVENUE_R,\r\n"
  		+ "	MIN(D80_SUBFIN.FBMD80_AVG_CNTRB_COST_R) 	FBMD80_AVG_CNTRB_COST_R,\r\n"
  		+ "	SUM(E22.FBME22_SLD_MTD_R) 			FBME22_SLD_MTD_R\r\n"
  		+ "FROM\r\n"
  		+ "	D80_SUBFIN,\r\n"
  		+ "	{h-schema}MFBME22_ACCT_SALES_SUMMARY E22\r\n"
  		+ "WHERE\r\n"
  		+ "	D80_SUBFIN.FBME01_SUBS_FIN_K 		= E22.FBME01_FIN_MASTER_K\r\n"
  		+ "  AND	D80_SUBFIN.FBMD12_PROPOSAL_YEAR_C	= E22.FBMD12_PROPOSAL_YEAR_C\r\n"
  		+ "  AND	D80_SUBFIN.FBME03_BDYSTL_K 		= E22.FBME03_BDYSTL_K\r\n"
  		+ "  AND	E22.FBME22_INCTV_TYP_C 			= 'C'  \r\n"
  		+ " GROUP BY\r\n"
  		+ "	D80_SUBFIN.FBMA01_PROPOSAL_K,\r\n"
  		+ "	D80_SUBFIN.FBME01_FIN_MASTER_K,\r\n"
  		+ "	D80_SUBFIN.FBMD12_PROPOSAL_YEAR_C,\r\n"
  		+ "	D80_SUBFIN.FBME03_BDYSTL_K", nativeQuery = true)
 List<ActualSalesFinancialViewDto> getSalesFinancialViewListByProposal(@Param("proposalSaKey") final Long proposalSaKey);
}
