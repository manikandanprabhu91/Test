package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMC19_SERVICE_DEFINITION database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = ServiceDefinition.TABLE_NAME)
public class ServiceDefinition implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMC19_SERVICE_DEFINITION";

	@EmbeddedId
	private ServiceDefinitionPK serviceDefinitionPK;

	@Column(name = "FBMC19_SERVICE_DEF_VALUE_R")
	private BigDecimal serviceDefValue;

	/*
	 * // bi-directional many-to-one association to Mfbmd74ServiceAttrOption
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBMD74_SERVICE_ATTR_OPT_C") private
	 * ServiceAttributeOption serviceAttributeOption;
	 * 
	 * // bi-directional many-to-one association to Mfbme15FinOpUntMaster
	 * 
	 * @ManyToOne(fetch = FetchType.LAZY)
	 * 
	 * @JoinColumn(name = "FBME15_FOU_K") private FinOpUnitMaster
	 * mfbme15FinOpUntMaster;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC19_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMC19_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMC19_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC19_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMC19_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMC19_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
