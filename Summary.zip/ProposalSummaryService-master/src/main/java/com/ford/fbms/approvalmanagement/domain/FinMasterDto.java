package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME01_FIN_MASTER database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = FinMasterDto.TABLE_NAME)
public class FinMasterDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBME01_FIN_MASTER";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME01_FIN_MASTER_K")
	private Long finMasterKey;

	@Column(name = "FBME01_CUPID_UPDATABLE_F")
	private String cupidUpdatableFlag;

	@Column(name = "FBME01_FIN_C")
	private String finCode;

	// bi-directional many-to-one association to Mfbmd09Segment
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD09_SEG_C")
	private SegmentDto segment;

	// bi-directional many-to-one association to Mfbmd42Country
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD42_COUNTRY_ISO3_C")
	//@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
	private CountryDto country;

	@Column(name = "FBME10_SICC_C")
	private String stdIndustrialCode;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME01_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME01_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME01_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME01_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME01_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME01_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
