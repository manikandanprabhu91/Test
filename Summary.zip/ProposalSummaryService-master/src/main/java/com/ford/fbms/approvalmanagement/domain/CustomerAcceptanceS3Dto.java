package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the MFBMA13_CUSTOMER_ACCEPTANCE_S3 database table.
 *
 * @author APARAMA2.
 */
@Getter
@Setter
@Entity
@Table(name = CustomerAcceptanceS3Dto.TABLE_NAME)
public class CustomerAcceptanceS3Dto implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBMA13_CUSTOMER_ACCEPTANCE_S3";

  @Id
  @Column(name = "FBMA01_PROPOSAL_K")
  private long proposalKey;

/*  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMA01_PROPOSAL_K",insertable = false, updatable = false)
  private ProposalDto proposal;*/

  @Column(name = "FBMA13_CUSTOMER_NOTE_X")
  private String customerNoteDesc;

  @Column(name = "FBMA13_LETTER_APPROVED_F")
  private String letterApprovedFlag;

  @Column(name = "FBMA13_LETTER_APV_NOTE_X")
  private String LetterApvNoteDesc;

  @Column(name = "FBMA13_LETTER_CUST_DIG_SIGN_X")
  private String letterCustDigitialSignature;

  @Column(name = "FBMA13_LETTER_CUST_PHY_SIGN_X")
  private String letterCustPhysicalSignature;

  @Column(name = "FBMA13_LETTER_DIG_SIGN_X")
  private String fbma13LetterDigSignatureDesc;

  @Column(name = "FBMA13_LETTER_EXPIRE_DAYS_R")
  private Long letterExpireDaysR;

  //@Temporal(TemporalType.DATE)
  @Column(name = "FBMA13_LETTER_GENERATE_Y")
  //@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  private String letterGenerateYear;

  @Column(name = "FBMA13_LETTER_MODIFIED_X")
  private String letterModifiedL;

  @Temporal(TemporalType.DATE)
  @Column(name = "FBMA13_LETTER_OFFER_Y")
  private Date letterOfferYear;

  @Column(name = "FBMA13_LETTER_ORIGINAL_X")
  private String letterOriginalL;

  @Column(name = "FBMA13_MAIL_SENT_TO_X")
  private String mailSentToDesc;
  // bi-directional many-to-one association to Mfbmd85LetterTemplate
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMD85_LETTER_TEMPLATE_K")
  private LetterTemplateDto letterTemplate;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA13_CREATE_S")
  private Date createdTimeStamp;

  @Column(name = "FBMA13_CREATE_PROCESS_C")
  private String createdProcess;

  @Column(name = "FBMA13_CREATE_USER_C")
  private String createdUser;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA13_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @Column(name = "FBMA13_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @Column(name = "FBMA13_LAST_UPDT_USER_C")
  private String lastUpdatedUser;

  @Column(name = "FBMD88_LETTER_SOURCE_C")
  private String letterSource;

  @Column(name = "FBMD11_PROPOSAL_STATUS_C")
  private String proposalStatus;

  @Column(name = "FBMD03_ACCEPTED_BY_CDSID_C")
  private String acceptedByCdsid;

  @Column(name = "FBMC07_ACCEPTED_BY_FP_K")
  private String acceptedByFPK;

  @Column(name = "FBMD03_LETTER_GEN_CDSID_C")
  private String letterGenCdsis;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA13_LETTER_ACCEPTED_Y")
  private Date letterAcceptedY;

  @Column(name = "FBMD03_LETTER_UPLOAD_CDSID_C")
  private String letterUploadCdisd;

  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA13_LETTER_UPLOAD_Y")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  private Date letterUploadY;

  @Column(name = "FBMD03_LETTER_APV_CDSID_C")
  private String letterApvCdisd;

  @Column(name = "FBMD97_LETTER_APV_STATUS_C")
  private Integer letterStatus;

}