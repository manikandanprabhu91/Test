package com.ford.fbms.approvalmanagement.ruleengines;

import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.RequestMode;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * An interface to define all rule engines activity.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public interface RuleEngineInterface {

  /**
   * To identify appropriate implementation for given request.
   *
   * @return TRUE if the request behalf of that ruleengines Else FALSE
   */
  boolean isRequestBehalfOfThisImpl(String groupType);

  /**
   * To get appropriate Locale of the rule engine.
   *
   * @return {@link Locale}
   */
  Locale getLocale();

  /**
   * To checkAndConstruct given request in its identified implementation for appropriate mode.
   *
   * @param apiParams   All required API params
   * @param requestMode {@link RequestMode}
   * @param httpRequest
   * @return An optional value of {@link GenericResponse}
   */
  List<GenericResponseWrapper> validate(final ApiParams apiParams, Object approvalRequest,
                                        RequestMode requestMode, HttpServletRequest httpRequest);


  /**
   * To trigger any post DB operations if any.
   */
  void triggerPostDbProcesses(ApiParams apiParams);

  GenericResponse getApprovalChain(GenericResponseWrapper consolidatedValidationResp);

  GenericResponse createApproval(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp, RequestMode requestMode);

  GenericResponse saveProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp);

  GenericResponse sendBackProposal(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp,RequestMode requestMode,HttpServletRequest httpRequest,HttpServletResponse response,CreateProposalRequest createProposalRequest);

  GenericResponse recallProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp);

  GenericResponse reviseProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp);

  GenericResponse getTotalAvgFinancials(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp);

  GenericResponse rejectProposal(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp,RequestMode requestMode,HttpServletRequest httpRequest,HttpServletResponse response,CreateProposalRequest createProposalRequest);

  GenericResponse validateAction(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp);

  GenericResponse getVolumeFinancials(GenericResponseWrapper consolidatedValidationResp);

  GenericResponse downloadProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp);
  
  GenericResponse approveProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp, RequestMode requestMode,HttpServletRequest request,final HttpServletResponse response,CreateProposalRequest createProposalRequest);

  GenericResponse populateFinancialList(GenericResponseWrapper consolidatedValidationResp);
  
  GenericResponse createProposalComments(ApiParams apiParams,CreateProposalRequest createProposalRequest,HttpServletRequest httpRequest,GenericResponse genericResponse);
  
  GenericResponse findNextDeal(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp);

}
