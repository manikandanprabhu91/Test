package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for Direction model.
 *
 * @author GILNAGOV on 2/15/2021.
 */

@Entity
@Table(name = "MFBMA16_PRICE_PROTECTION_YOY")
@Getter
@Setter
public class PriceProtectionYearOverYearDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @EmbeddedId
  private com.ford.fbms.approvalmanagement.domain.PriceProtectionYearOverYearPk priceProtectionYearOverYearPk;

  @Column(name = "FBMA16_YOY_INCREASE_P")
  private double percentageIncrease;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA16_CREATE_S")
  protected Date createdTime;

  @JsonIgnore
  @Column(name = "FBMA16_CREATE_PROCESS_C")
  protected String createdProcessCode;

  @JsonIgnore
  @Column(name = "FBMA16_CREATE_USER_C")
  protected String createdUserCode;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA16_LAST_UPDT_S")
  protected Date updatedTime;

  @JsonIgnore
  @Column(name = "FBMA16_LAST_UPDT_USER_C")
  protected String lastUpdateUserCode;

  @JsonIgnore
  @Column(name = "FBMA16_LAST_UPDT_PROCESS_C")
  protected String lastUpdatedProcessCode;

}
