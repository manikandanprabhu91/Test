package com.ford.fbms.approvalmanagement.ruleengines;

import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_ACT_DESC;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_DESC;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_DESC;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_DESC;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_DESC;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE;
import static com.ford.fbms.approvalmanagement.util.ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_DESC;
import static com.ford.fbms.approvalmanagement.util.Constants.BLANK;
import static com.ford.fbms.approvalmanagement.util.Constants.COMMA;
import static com.ford.fbms.approvalmanagement.util.Constants.DASH;
import static com.ford.fbms.approvalmanagement.util.Constants.DOLLAR;
import static com.ford.fbms.approvalmanagement.util.Constants.HYPHEN;
import static com.ford.fbms.approvalmanagement.util.Constants.PLUS;
import static com.ford.fbms.approvalmanagement.util.Constants.PROPOSAL_TO_EXCEL_COMMENTS_DTL_LOCATION;
import static com.ford.fbms.approvalmanagement.util.Constants.PROPOSAL_TO_EXCEL_SUBSID_ROW_LOCATION;
import static com.ford.fbms.approvalmanagement.util.Constants.PROPOSAL_TO_EXCEL_SUMMARY_DTL_LOCATION;
import static com.ford.fbms.approvalmanagement.util.Constants.PROPOSAL_TO_EXCEL_TMPLT_LOCATION;
import static com.ford.fbms.approvalmanagement.util.Constants.PROPOSAL_TO_EXCEL_VOL_INC_ROW_LOCATION;
import static com.ford.fbms.approvalmanagement.util.Constants.SPACE;
import static com.ford.fbms.approvalmanagement.util.Constants.TABLE;
import static com.ford.fbms.approvalmanagement.util.Constants.Y;
import static com.ford.fbms.approvalmanagement.util.Constants.ZERO;
import static java.util.stream.Collectors.toList;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.ApprovalViewDto;
import com.ford.fbms.approvalmanagement.domain.FinOpUnitMaster;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalAssignAttributeDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.ActualSalesFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalViewRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.CustomerAcceptanceS3Repository;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ExpandedBodyStyleViewRepository;
import com.ford.fbms.approvalmanagement.repository.FVADataRepository;
import com.ford.fbms.approvalmanagement.repository.FinOpUnitMasterRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearTermRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitExpandedViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProcedureRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalAssignAttributeRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.PyCountryDefinitionRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.repository.VehicleLineRepository;
import com.ford.fbms.approvalmanagement.service.RestService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalProcessResponse;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.EmailRequest;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedBaseVO;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedBaseVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexDetailedVO;
import com.ford.fbms.approvalmanagement.transport.FinancialMexSummaryVO;
import com.ford.fbms.approvalmanagement.transport.FinancialSummaryVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.FileUtils;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.MqUtil;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.ActionValidator;
import com.ford.fbms.approvalmanagement.validators.ActualsManager;
import com.ford.fbms.approvalmanagement.validators.ApprovalChainValidator;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementCreateValidator;
import com.ford.fbms.approvalmanagement.validators.ApprovalManagementValidator;
import com.ford.fbms.approvalmanagement.validators.ApprovalProcessByStatusManager;
import com.ford.fbms.approvalmanagement.validators.ApprovalProcessManager;
import com.ford.fbms.approvalmanagement.validators.ApprovalProcessMexValidator;
import com.ford.fbms.approvalmanagement.validators.CPALetterMinQtyManager;
import com.ford.fbms.approvalmanagement.validators.CustomerAcceptanceManager;
import com.ford.fbms.approvalmanagement.validators.ESPManager;
import com.ford.fbms.approvalmanagement.validators.FordPersonAccessManager;
import com.ford.fbms.approvalmanagement.validators.FordPersonManager;
import com.ford.fbms.approvalmanagement.validators.ForecastManager;
import com.ford.fbms.approvalmanagement.validators.GetProposalManager;
import com.ford.fbms.approvalmanagement.validators.MEXVolumeFinancialOptionsValidator;
import com.ford.fbms.approvalmanagement.validators.MaintainFinancialDataValidator;
import com.ford.fbms.approvalmanagement.validators.MexApprovalChainValidator;
import com.ford.fbms.approvalmanagement.validators.MexProposalManager;
import com.ford.fbms.approvalmanagement.validators.PerUnitIncentiveManager;
import com.ford.fbms.approvalmanagement.validators.PriorProposalManager;
import com.ford.fbms.approvalmanagement.validators.ProposalCommentsManager;
import com.ford.fbms.approvalmanagement.validators.ProposalManager;
import com.ford.fbms.approvalmanagement.validators.QuotationExpirationDateManager;
import com.ford.fbms.approvalmanagement.validators.RecallProcessMexValidator;
import com.ford.fbms.approvalmanagement.validators.RecallProcessValidator;
import com.ford.fbms.approvalmanagement.validators.SDATier1Manager;
import com.ford.fbms.approvalmanagement.validators.SubfinManager;
import com.ford.fbms.approvalmanagement.validators.SubmitNonFinancialProcessValidator;
import com.ford.fbms.approvalmanagement.validators.SubmitProcessMexValidator;
import com.ford.fbms.approvalmanagement.validators.SubmitProcessValidator;
import com.ford.fbms.approvalmanagement.validators.SubsidiaryManager;
import com.ford.fbms.approvalmanagement.validators.TargetBandManager;
import com.ford.fbms.approvalmanagement.validators.TierIncentiveManager;
import com.ford.fbms.approvalmanagement.validators.TierVolumeManager;
import com.ford.fbms.approvalmanagement.validators.UserIdValidator;
import com.ford.fbms.approvalmanagement.validators.Validator;
import com.ford.fbms.approvalmanagement.validators.VechileLineManager;
import com.ford.fbms.approvalmanagement.validators.VehicleLineBodyStyleEligibilityManager;
import com.ford.fbms.approvalmanagement.validators.VoulmeFinancialsOptionsValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * A parent rule engine to define and do the common activities of all other rule engines.
 *
 * @author NACHUTHA on 3/01/2021.
 */
@Slf4j
@Service
public abstract class MasterRuleEngine implements RuleEngineInterface {

	@Autowired
	protected UserIdValidator userIdValidator;
	@Autowired
	protected ApprovalManagementValidator approvalManagementValidator;
	@Autowired
	protected ApprovalManagementCreateValidator approvalManagementCreateValidator;
	@Autowired
	protected ResponseBuilder responseBuilder;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected ProposalBodyFinancialViewRepository proposalBodyFinancialViewRepo;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected VoulmeFinancialsOptionsValidator volumeFinancialsOptionsValidator;
	@Autowired
	protected ActionValidator actionValidator;
	@Autowired
	protected Validator propApprovalValidator;
	@Autowired
	protected ActualsManager actualsManager;
	@Autowired
	protected ForecastManager forecastManager;
	@Autowired
	protected SubmitProcessValidator submitProcessValidator;
	@Autowired
	protected RecallProcessValidator recallProcessValidator;
	@Autowired
	protected SubmitNonFinancialProcessValidator submitNonFinancialProcessValidator;
	@Autowired
	protected ApprovalChainValidator approvalChainValidator;
	@Autowired
	protected MaintainFinancialDataValidator maintainFinancialDataValidator;
	@Autowired
	protected PerUnitIncentiveManager perUnitIncentiveManager;
	@Autowired
	protected ProposalCommentsManager proposalCommentsManager;
	@Autowired
	protected SubsidiaryManager subsidiaryManager;
	@Autowired
	protected VechileLineManager vechileLineManager;
	@Autowired
	protected MexProposalManager mexProposalManager;
	@Autowired
	protected GetProposalManager getProposalManager;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected ProposalStatusRepository proposalStatusRepo;
	@Autowired
	protected ProcedureRepository procedureRepository;
	@Autowired
	protected ApprovalProcessManager approvalProcessManager;
	@Autowired
	protected FordPersonManager fordPersonManager;
	@Autowired
	protected FordPersonAccessManager fordPersonAccessManager;
	@Autowired
	protected PyCountryDefinitionRepository pyCountryDefinitionRepository;
	@Autowired
	protected ApprovalProcessByStatusManager approvalProcessByStatusManager;
	@Autowired
	protected TargetBandRepository targetBandRepo;
	@Autowired
	protected PerUnitOptViewRepository perUnitOptViewRepository;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepository;
	@Autowired
	protected MultiYearBonusRepository multiYearBonusRepository;
	@Autowired
	protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
	@Autowired
	protected TierVolumeRepository tierVolumeRepository;
	@Autowired
	protected ProposalSummaryViewRepository proposalSummaryViewRepository;
	@Autowired
	protected AccountSalesSummaryRepository accountSalesSummaryRepository;
	@Autowired
	protected BodyFinancialRepository bodyFinancialRepo;
	@Autowired
	protected PerUnitIncentiveNewViewRepository perUnitIncentiveNewViewRepo;
	@Autowired
	protected NewBodyStyleRepository newBodyStyleRepo;
	@Autowired
	protected FVADataRepository fvaDataRepo;
	@Autowired
	protected PerUnitNewViewRepository perUnitNewViewRepo;
	@Autowired
	protected FinProfileRepository finProfileRepo;
	@Autowired
	protected ProposalManager prop;
	@Autowired
	protected ActualsManager actualManager;
	@Autowired
	protected VehicleLineRepository vehLineRepo;
	@Autowired
	protected ExpandedBodyStyleViewRepository expandedBodyStyleViewRepo;
	@Autowired
	protected PerUnitExpandedViewRepository perUnitExpandedViewRepo;
	@Autowired
	protected ExpandedBodyFinancialViewRepository expandedBodyFinancialViewRepo;
	@Autowired
	protected ActualSalesFinancialViewRepository actualSalesFinancialViewRepo;
	@Autowired
	protected PerUnitIncentiveNewViewRepository perUnitIncNewViewRepo;
	@Autowired
	protected PriorProposalManager priorProposalManager;
	@Autowired
	protected TargetBandManager targetBandManager;
	@Autowired
	protected SDATier1Manager sdaTier1Manager;
	@Autowired
	protected SubfinManager subfinManager;
	@Autowired
	protected CPALetterMinQtyManager cpaLetterMinQtyManager;
	@Autowired
	protected TierVolumeManager tierVolumeManager;
	@Autowired
	protected TierIncentiveManager tierIncentiveManager;
	@Autowired
	protected ESPManager espManager;
	@Autowired
	protected VehicleLineBodyStyleEligibilityManager vehicleLineBodyStyleEligibilityManager;
	@Autowired
	protected SubmitProcessMexValidator submitProcessMexValidator;
	@Autowired
	protected RecallProcessMexValidator recallProcessMexValidator;
	@Autowired
	private RestService restService;
	@Autowired
	protected MEXVolumeFinancialOptionsValidator mexVolumeFinancialOptionsValidator;
	@Autowired
	protected ApprovalProcessMexValidator approvalProcessMexValidator;
	@Autowired
	private MqUtil mqUtil;
	@Autowired
	protected ProposalAssignAttributeRepository proposalAssignAttributeRepository;
	@Autowired
	protected MexApprovalChainValidator mexApprovalChainValidator;
	@Autowired
	protected FinOpUnitMasterRepository finOpUnitMasterRepository;
	@Autowired
	protected ApprovalViewRepository approvalViewRepo;
	@Autowired
	protected QuotationExpirationDateManager quotationExpirationDateManager;
	@Autowired
	protected CustomerAcceptanceManager customerAcceptanceManager;
	@Autowired
	protected CustomerAcceptanceS3Repository customerAcceptanceS3Repository;
	@Autowired
	protected MultiYearTermRepository multiYearTermRepository;
	@Autowired
	protected ProposalSubsidiaryRepository proposalSubsidiaryRepository;

	/**
	 * To get list of required validators for appropriate implementation.
	 *
	 * @param requestMode mode of request
	 */
	protected abstract List<Validator> getValidators(final RequestMode requestMode, final ApiParams apiParams);

	/**
	 * To get the country code of the RuleEngine.
	 *
	 * @return countryCode
	 */
	protected abstract String getCountryCd();

	/**
	 * To check given group type matching tenant's group type.
	 *
	 * @param countryCd rule engine type
	 * @return TRUE if matching else FALSE
	 */
	@Override
	public boolean isRequestBehalfOfThisImpl(final String countryCd) {
		return getCountryCd().equalsIgnoreCase(countryCd);
	}

	/**
	 * To invoke all required validator implementations asynchronously.
	 *
	 * @return GenericResponseWrapper
	 */
	@Override
	@LogAround
	public List<GenericResponseWrapper> validate(final ApiParams apiParams, final Object approvalRequest,
			final RequestMode requestMode, HttpServletRequest httpRequest) {

		final List<Future<GenericResponseWrapper>> validationResponses = new ArrayList<>();

		getValidators(requestMode, apiParams).stream().forEach(validator -> validationResponses
				.add(validator.validateAndConstruct(apiParams, approvalRequest, this, httpRequest)));

		return validationResponses.stream().map(cfResp -> parseValidationResponse(apiParams, cfResp)).collect(toList());
	}

	public GenericResponse downloadProposal(final ApiParams apiParams,
			GenericResponseWrapper consolidatedValidationResp)  {
		getTotalAvgFinancials(apiParams, consolidatedValidationResp);
		StringBuilder templateBuilder = new StringBuilder();
		try {
			templateBuilder = FileUtils.readFile(PROPOSAL_TO_EXCEL_TMPLT_LOCATION);
		} catch (IOException e) {
			log.error("Error occurred in downloading proposal details with user id" +apiParams.getUserId(),e);
			
		}
		Map<String, Object> tagMap = new HashMap<>();
		populateTags(tagMap, consolidatedValidationResp, apiParams);
		String replacedTemplate = replaceTemplateTags(consolidatedValidationResp, templateBuilder, tagMap, apiParams);
		consolidatedValidationResp.setProposalDownload(replacedTemplate);
		consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
		return consolidatedValidationResp;
	}

	/*
	 * Case 1 :- Remove xx_ string with value, if value not present then remove the
	 * respective tag. Case 2 :- If xx_ contains table, replace that tag with a
	 * table.
	 *
	 */
	private String replaceTemplateTags(final GenericResponseWrapper consolidatedValidationResp,
			StringBuilder templateBuilder, final Map<String, Object> tagMap, final ApiParams apiParams) {
		String tag;
		int end, start = 0;
		while (start != -1) {
			start = templateBuilder.indexOf("xx_", start);
			if (start != -1) {
				end = templateBuilder.indexOf("_xx", start);
				if (end != -1) {
					end = end + 3;
					tag = templateBuilder.substring(start, end);
					if (tag.contains(TABLE)) {
						insertTable(consolidatedValidationResp, templateBuilder, tag, end, start, apiParams);
					} else {
						end = insertText(templateBuilder, tagMap, tag, end, start);
					}
					start = end;
				}
			}
		}
		return templateBuilder.toString();
	}

	private int insertText(final StringBuilder templateBuilder, final Map<String, Object> tagMap, final String tag,
			int end, final int start) {
		if (tagMap.containsKey(tag)) {
			Object value = tagMap.get(tag);
			if (value instanceof String) {
				String tagValue = (String) value;
				templateBuilder.replace(start, end, tagValue);
				if (tag.length() > tagValue.length()) {
					end += tagValue.length() - tag.length();
				}
			}
		}
		return end;
	}

	private void insertTable(final GenericResponseWrapper consolidatedValidationResp,
			final StringBuilder templateBuilder, final String tag, final int end, final int start,
			final ApiParams apiParams) {
		List<String> list = null;
		if (("xx_VolIncExcl_Table_xx").equalsIgnoreCase(tag)) {
			list = populateVolIncExclTable(consolidatedValidationResp);
		} else if ("xx_SubsExcl_Table_xx".equalsIgnoreCase(tag)) {
			list = populateSubsidaryTable(consolidatedValidationResp);
		} else if ("xx_ProposalComments_Table_xx".equalsIgnoreCase(tag)){
			list = populateProposalCommentsTable(consolidatedValidationResp);
		} else if (("xx_Summary_Table_xx".equalsIgnoreCase(tag)) && apiParams.isComplete()&& null != consolidatedValidationResp.getFinancialDetailedVOList()) { 
			list = populateFinanceTable(consolidatedValidationResp);
		}
		if (list != null) {
			templateBuilder.replace(start, end, String.join(SPACE, list));
		}
	}

	private List<String> populateFinanceTable(GenericResponseWrapper consolidatedValidationResp) {
		List<String> tableList = new ArrayList<>();
		if (null != consolidatedValidationResp.getFinancialDetailedVOList()) {
			List<String[]> financeList = populateFinanceData(consolidatedValidationResp); 																							// data!!!
			URL url = getClass().getResource(PROPOSAL_TO_EXCEL_SUMMARY_DTL_LOCATION);
			File tableRow = new File(url.getPath());
			for (String[] finance : financeList) {
				try {
					tableList.add(FbmsUtil.populateRow(FbmsUtil.getRow(tableRow), finance, 19));
				} catch (IOException e) {
					
					log.error("Error occurred in populate financial table in method populateFinancialTable",e);

				}
			}
		}
		return tableList;
	}

	private List<String[]> populateFinanceData(GenericResponseWrapper consolidatedValidationResp) {
		List<String[]> financeList = new LinkedList<>();
		for (FinancialDetailedVO financialVo : consolidatedValidationResp.getFinancialDetailedVOList()) {
			String[] finArr = new String[19];
			finArr[0] = financialVo.getVehicleLine();
			finArr[1] = financialVo.getBodyStyle();
			finArr[2] = getFormattedModelYear(financialVo);
			finArr[3] = getFormattedPresentVol(financialVo);
			finArr[4] = getFormattedPriorVol(financialVo);
			finArr[5] = getFormattedBwVol(financialVo);
			finArr[6] = getFormattedPresentCPA(financialVo);
			finArr[7] = getFormattedPresentESP(financialVo);
			finArr[8] = getFormattedPresentOPT(financialVo);
			finArr[9] = getFormattedPresentAGG(financialVo);
			finArr[10] = getFormattedPresentVM(financialVo);
			finArr[11] = getFormattedBwPriorPYVM(financialVo);
			finArr[12] = getFormattedBwPrevVerVM(financialVo);
			finArr[13] = getFormattedBwTargetVM(financialVo);
			finArr[14] = getFormattedPresentNR(financialVo);
			finArr[15] = (int)financialVo.getPriorVol() != 0 ? getFormattedBwPriorPYNR(financialVo) : ZERO;
			finArr[16] = getFormattedPresentCM(financialVo);
			finArr[17] = (int)financialVo.getPriorVol() != 0 ? getFormattedBwPriorPYCM(financialVo) : ZERO;
			finArr[18] = getFormattedBwTargetCM(financialVo);
			if (financialVo.getRecType().equals(FinancialDetailedVO.rowType.VehicleLine)) {
				finArr[0] = BLANK;
				finArr[2] = BLANK;
			} else if (financialVo.getRecType().equals(FinancialDetailedVO.rowType.LineTotal)) {
				finArr[1] = BLANK;
			} else if (financialVo.getRecType().equals(FinancialDetailedVO.rowType.GrandTotal)) {
				finArr[0] = "Total";
				finArr[1] = BLANK;
				finArr[2] = BLANK;
			}
			financeList.add(finArr);
		}
		return financeList;
	}

	private String getFormattedBwTargetCM(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			return (financialVo.getBwTargetCM() >= 0
					? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetCM()), 0, true, false)
					: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetCM()), 0, true, false));
		}
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetCM()), 0, true, false)
				: BLANK;
	}

	private String getFormattedBwPriorPYCM(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			if (((int) Math.round(financialVo.getPresentVol())) > 0
					&& ((int) Math.round(financialVo.getPriorVol())) > 0) {
				return (financialVo.getBwPriorPYCM() >= 0
						? FbmsUtil.currencyFormat(Math.round(financialVo.getBwPriorPYCM()), 0, false)
						: FbmsUtil.currencyFormat(Math.round(financialVo.getBwPriorPYCM()), 0, true));
			}
		} else {
			return (financialVo.getPresentKey() > 0L && financialVo.getPriorKey() > 0L)
					? FbmsUtil.currencyFormat(Math.round(financialVo.getBwPriorPYCM()), 0)
					: BLANK;
		}
		return BLANK;
	}

	private String getFormattedPresentCM(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentCM()), 0, false)
				: BLANK;
	}

	private String getFormattedBwPriorPYNR(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			if (((int) Math.round(financialVo.getPresentVol())) > 0
					&& ((int) Math.round(financialVo.getPriorVol())) > 0) {
				return (financialVo.getBwPriorPYNR() >= 0
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYNR()), 0, true, false)
						: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYNR()), 0, true, false));
			}
		} else {
			return (financialVo.getPresentKey() > 0L && financialVo.getPriorKey() > 0L)
					? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYNR()), 0, true, false)
					: BLANK;
		}
		return BLANK;
	}

	private String getFormattedPresentNR(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentNR()), 0, false)
				: BLANK;
	}

	private String getFormattedBwTargetVM(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			return (financialVo.getBwTargetVM() >= 0
					? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetVM()), 0, true, false)
					: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetVM()), 0, true, false));
		}
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwTargetVM()), 0, true, false)
				: BLANK;
	}

	private String getFormattedBwPriorPYVM(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			if (((int) Math.round(financialVo.getPresentVol())) > 0
					&& ((int) Math.round(financialVo.getPriorVol())) > 0) {
				return (financialVo.getBwPriorPYVM() >= 0
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYVM()), 0, true, false)
						: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYVM()), 0, true, false));
			}
		} else {
			if (FinancialDetailedVO.rowType.LineTotal.toString()
					.equalsIgnoreCase(financialVo.getRecType().toString())) {
				return (financialVo.getPresentKey() > 0L && financialVo.getPriorKey() > 0L)
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYVM()), 0, true, true)
						: BLANK;
			} else if (FinancialDetailedVO.rowType.VehicleLine.toString()
					.equalsIgnoreCase(financialVo.getRecType().toString())) {
				return (financialVo.getPresentKey() > 0L && financialVo.getPriorKey() > 0L)
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPriorPYVM()), 0, true, false)
						: BLANK;
			}
		}
		return BLANK;
	}

	private String getFormattedPresentVM(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentVM()), 0, false)
				: BLANK;
	}

	private String getFormattedPresentAGG(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentAGG()), 0, false)
				: BLANK;
	}

	private String getFormattedPresentESP(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentESP()), 0, false)
				: BLANK;
	}

	private String getFormattedPresentOPT(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentOPT()), 0, false)
				: BLANK;
	}

	private String getFormattedBwPrevVerVM(final FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			if (((int) Math.round(financialVo.getPresentVol())) > 0
					&& ((int) Math.round(financialVo.getPrevVerVol())) > 0) {
				return (financialVo.getBwPrevVerVM() >= 0
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPrevVerVM()), 0, true, false)
						: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPrevVerVM()), 0, true, false));
			}
		} else {
			if (FinancialDetailedVO.rowType.LineTotal.toString()
					.equalsIgnoreCase(financialVo.getRecType().toString())) {
				return (financialVo.getPresentKey() > 0L && financialVo.getPrevVerKey() > 0L)
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPrevVerVM()), 0, true, true)
						: BLANK;
			} else if (FinancialDetailedVO.rowType.VehicleLine.toString()
					.equalsIgnoreCase(financialVo.getRecType().toString())) {
				return (financialVo.getPresentKey() > 0L && financialVo.getPrevVerKey() > 0L)
						? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwPrevVerVM()), 0, true, false)
						: BLANK;
			}
		}
		return BLANK;
	}

	private String getFormattedPresentCPA(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentCPA()), 0, false)
				: BLANK;
	}

	private String getFormattedPriorVol(FinancialDetailedVO financialVo) {
		return (financialVo.getPriorKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPriorVol()), 0, false)
				: BLANK;
	}

	private String getFormattedBwVol(FinancialDetailedVO financialVo) {
		if (FinancialDetailedVO.rowType.GrandTotal.toString().equalsIgnoreCase(financialVo.getRecType().toString())) {
			return (financialVo.getBwVol() >= 0
					? FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwVol()), 0, true, false)
					: FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwVol()), 0, true, false));
		}
		return FbmsUtil.currencyFormatforDwnload(Math.round(financialVo.getBwVol()), 0, true, false);
	}

	private String getFormattedModelYear(FinancialDetailedVO financialVo) {
		String my = BLANK + financialVo.getModelYear();
		if ((!financialVo.isPresentProposal())&&(financialVo.getPrevVerKey() == 0L && financialVo.getPriorKey() > 0L)) {
				my = BLANK + (financialVo.getModelYear() - 1);
				if (financialVo.getPY() < financialVo.getModelYear()) {
					my = my + "*";
				}
		}
		return my;
	}

	private String getFormattedPresentVol(FinancialDetailedVO financialVo) {
		return (financialVo.getPresentKey() > 0L)
				? FbmsUtil.currencyFormat(Math.round(financialVo.getPresentVol()), 0, false)
				: BLANK;
	}

	private List<String> populateProposalCommentsTable(GenericResponseWrapper consolidatedValidationResp) {
		List<String> tableList = new ArrayList<>();
		if (null != consolidatedValidationResp.getProposalCommentsVos()) {
			List<String[]> commentsList = populateProposalComments(consolidatedValidationResp); // populate
																								// subsidiaryList table
																								// data!!!
			URL url = getClass().getResource(PROPOSAL_TO_EXCEL_COMMENTS_DTL_LOCATION);
			File tableRow = new File(url.getPath());
			for (String[] comments : commentsList) {
				try {
					tableList.add(FbmsUtil.populateRow(FbmsUtil.getRow(tableRow), comments, 5));
				} catch (IOException e) {
					log.error("Error occurred in populating proposal comments in method populateProposalComments" ,e);
				}
			}
		}
		return tableList;
	}

	private List<String[]> populateProposalComments(final GenericResponseWrapper consolidatedValidationResp) {
		return( consolidatedValidationResp.getProposalCommentsVos().stream().map(c -> {
			String[] subsArr = new String[5];
			subsArr[0] = null != c.getProposalYear() ? String.valueOf(c.getProposalYear()) : BLANK;
			subsArr[1] = null != c.getProposalVersion() ? String.valueOf(c.getProposalVersion()) : BLANK;
			subsArr[2] = null != c.getCommentedBy() ? String.valueOf(c.getCommentedBy()) : BLANK;
			subsArr[3] = covertUtcTime(c.getDateSubmitted(), "MM/dd/yyyy");
			subsArr[4] = null != c.getProposalComments() ? String.valueOf(c.getProposalComments()) : BLANK;
			return subsArr;
		}).collect(Collectors.toList()));
		 
	}

	private List<String> populateVolIncExclTable(final GenericResponseWrapper consolidatedValidationResp) {
		List<String> tableList = new ArrayList<>();
		if (null != consolidatedValidationResp.getVehicleLineOptionDiscountVos()) {
			List<String[]> volIncList = populateVolIncData(consolidatedValidationResp); 
			URL url = getClass().getResource(PROPOSAL_TO_EXCEL_VOL_INC_ROW_LOCATION);
			File tableRow = new File(url.getPath());
			for (String[] volInc : volIncList) {
				try {
					tableList.add(FbmsUtil.populateRow(FbmsUtil.getRow(tableRow), volInc, 14));
				} catch (IOException e) {
					log.error("Error occurred in populate vol inc table in method populateVolIncExclTable" ,e);
				}
			}
		}
		return tableList;
	}

	private List<String> populateSubsidaryTable(final GenericResponseWrapper consolidatedValidationResp) {
		List<String> tableList = new ArrayList<>();
		if (null != consolidatedValidationResp.getSubsidiariesVos()) {
			List<String[]> subsidiaryList = populateSubsidaryData(consolidatedValidationResp); 
			URL url = getClass().getResource(PROPOSAL_TO_EXCEL_SUBSID_ROW_LOCATION);
			File tableRow = new File(url.getPath());
			for (String[] subsidiary : subsidiaryList) {
				try {
					tableList.add(FbmsUtil.populateRow(FbmsUtil.getRow(tableRow), subsidiary, 3));
				} catch (IOException e) {
					log.error("Error occurred in populating subsidiary details in method populateSubsidiaryTable" ,e);
				}
			}
		}
		return tableList;
	}

	private List<String[]> populateSubsidaryData(final GenericResponseWrapper consolidatedValidationResp) {
		return( consolidatedValidationResp.getSubsidiariesVos().stream().map(s -> {
			String[] subsArr = new String[3];
			subsArr[0] = null != s.getAccountName() ? s.getAccountName() : BLANK;
			subsArr[1] = s.getCity().concat(COMMA).concat(s.getStateCode());
			subsArr[2] = null != s.getFin() ? s.getFin() : BLANK;
			return subsArr;
		}).collect(Collectors.toList()));
	}

	private List<String[]> populateVolIncData(final GenericResponseWrapper consolidatedValidationResp) {
		return( consolidatedValidationResp.getVehicleLineOptionDiscountVos().stream().map(v -> {
			String[] subsArr = new String[14];
			subsArr[0] = null != v.getVehicleLineDesc() ? v.getVehicleLineDesc() : BLANK;
			subsArr[1] = null != v.getBodyStyle() ? v.getBodyStyle() : BLANK;
			subsArr[2] = null != v.getModelYr() ? String.valueOf(v.getModelYr()) : BLANK;
			subsArr[3] = null != v.getTier1Amt() ? DOLLAR + v.getTier1Amt() : BLANK;
			subsArr[4] = null != v.getTier2Amt() ? DOLLAR + v.getTier2Amt() : BLANK;
			subsArr[5] = null != v.getTier3Amt() ? DOLLAR + v.getTier3Amt() : BLANK;
			subsArr[6] = null != v.getTier4Amt() ? DOLLAR + v.getTier4Amt() : BLANK;
			subsArr[7] = null != v.getTier5Amt() ? DOLLAR + v.getTier5Amt() : BLANK;
			subsArr[8] = null != v.getTier6Amt() ? DOLLAR + v.getTier6Amt() : BLANK;
			subsArr[9] = null != v.getTier1() ? v.getTier1() : BLANK;
			subsArr[10] = null != v.getMlv() ? String.valueOf(v.getMlv()) : BLANK;
			subsArr[11] = null != v.getOptionDiscountCd() ? v.getOptionDiscountCd() : BLANK;
			subsArr[12] = null != v.getOptionDiscountdesc() ? v.getOptionDiscountdesc() : BLANK;
			subsArr[13] = null != v.getOptionDiscountAmt() ? DOLLAR + v.getOptionDiscountAmt() : BLANK;
			return subsArr;
		}).collect(Collectors.toList()));
		
	}

	private void populateTags(Map<String, Object> tagMap, GenericResponseWrapper consolidatedValidationResp,
			final ApiParams apiParams) {
		String firstname, lastname;
		String address1, address2;
		int commentsTabSize = 3;
		int summaryTabSize = 100;
		if (null != consolidatedValidationResp.getProposalCommentsVos()) {
			commentsTabSize += consolidatedValidationResp.getProposalCommentsVos().size();
			summaryTabSize += consolidatedValidationResp.getProposalCommentsVos().size();
		}
		if (null != consolidatedValidationResp.getVehicleLineOptionDiscountVos()) {
			summaryTabSize += consolidatedValidationResp.getVehicleLineOptionDiscountVos().size();
		}
		if (null != consolidatedValidationResp.getSubsidiariesVos()) {
			summaryTabSize += consolidatedValidationResp.getSubsidiariesVos().size();
		}
		if (null != consolidatedValidationResp.getFinancialDetailedVOList()) {
			summaryTabSize += consolidatedValidationResp.getFinancialDetailedVOList().size();
		}
		tagMap.put("xx_Sh1Count_xx", String.valueOf(summaryTabSize));
		tagMap.put("xx_proposalCommentsCount_xx", String.valueOf(commentsTabSize));
		// header
		if (null != consolidatedValidationResp.getProposalVo()) {
			tagMap.put("xx_PY_xx",
					null != consolidatedValidationResp.getProposalVo().getProposalYr()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getProposalYr())
							: BLANK);
			tagMap.put("xx_ver_xx",
					null != consolidatedValidationResp.getProposalVo().getVersion()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getVersion())
							: BLANK);
			tagMap.put("xx_PropStatus_xx",
					null != consolidatedValidationResp.getProposalVo().getStatus()
							? consolidatedValidationResp.getProposalVo().getStatus()
							: BLANK);
			tagMap.put("xx_StatusDate_xx",
					covertUtcTime(consolidatedValidationResp.getProposalVo().getStatusYear(), "MM/dd/yyyy"));
			firstname = null != consolidatedValidationResp.getProposalVo().getFirstName()
					? consolidatedValidationResp.getProposalVo().getFirstName()
					: BLANK;
			lastname = null != consolidatedValidationResp.getProposalVo().getLastName()
					? consolidatedValidationResp.getProposalVo().getLastName()
					: BLANK;
			tagMap.put("xx_AcctMgr_xx", firstname + SPACE + lastname);
			tagMap.put("xx_AcctName_xx",
					null != consolidatedValidationResp.getProposalVo().getAccountName()
							? consolidatedValidationResp.getProposalVo().getAccountName()
							: BLANK);
			tagMap.put("xx_FINCode_xx",
					null != consolidatedValidationResp.getProposalVo().getFinCd()
							? consolidatedValidationResp.getProposalVo().getFinCd()
							: BLANK);
			address1 = null != consolidatedValidationResp.getProposalVo().getAddress1()
					? consolidatedValidationResp.getProposalVo().getAddress1()
					: BLANK;
			address2 = null != consolidatedValidationResp.getProposalVo().getAddress2()
					? consolidatedValidationResp.getProposalVo().getAddress2()
					: BLANK;
			tagMap.put("xx_FINAddressLine1_xx", address1 + SPACE + address2);
			tagMap.put("xx_FINAddressLine2_xx", consolidatedValidationResp.getProposalVo().getCity() + COMMA
					+ consolidatedValidationResp.getProposalVo().getState());
			tagMap.put("xx_FINCityStateZip_xx",
					null != consolidatedValidationResp.getProposalVo().getZipcode()
							? consolidatedValidationResp.getProposalVo().getZipcode()
							: BLANK);
			tagMap.put("xx_PaymentType_xx",
					null != consolidatedValidationResp.getProposalVo().getPaymentType()
							? consolidatedValidationResp.getProposalVo().getPaymentType()
							: BLANK);
			deriveTireLevel(consolidatedValidationResp, tagMap);
			tagMap.put("xx_CPAMinVol_xx",
					null != consolidatedValidationResp.getProposalVo().getLetterMinQty()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getLetterMinQty())
							: BLANK);
			tagMap.put("xx_IntroPP_xx",
					null != consolidatedValidationResp.getProposalVo().getYoyDesc()
							? consolidatedValidationResp.getProposalVo().getYoyDesc()
							: BLANK);
			tagMap.put("xx_AggrIncDesc1_xx",
					null != consolidatedValidationResp.getProposalVo().getAggregateIncentiveDesc1()
							? consolidatedValidationResp.getProposalVo().getAggregateIncentiveDesc1()
							: BLANK);
			tagMap.put("xx_AIAmount1_xx",
					null != consolidatedValidationResp.getProposalVo().getAggregateIncentiveCd1()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getAggregateIncentiveCd1())
							: BLANK);
			tagMap.put("xx_AggrIncDesc2_xx",
					null != consolidatedValidationResp.getProposalVo().getAggregateIncentiveDesc2()
							? consolidatedValidationResp.getProposalVo().getAggregateIncentiveDesc2()
							: BLANK);
			tagMap.put("xx_AIAmount2_xx",
					null != consolidatedValidationResp.getProposalVo().getAggregateIncentiveCd2()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getAggregateIncentiveCd2())
							: BLANK);
			tagMap.put("xx_StartYr_xx",
					null != consolidatedValidationResp.getProposalVo().getMultiYearStart()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getMultiYearStart())
							: BLANK);
			tagMap.put("xx_StopYr_xx",
					null != consolidatedValidationResp.getProposalVo().getMultiYearEnd()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getMultiYearEnd())
							: BLANK);
			tagMap.put("xx_FIMPSMLBMinVol_xx",
					null != consolidatedValidationResp.getProposalVo().getMultiYearMinQ()
							? String.valueOf(consolidatedValidationResp.getProposalVo().getMultiYearMinQ())
							: BLANK);
			tagMap.put("xx_SDA_xx",
					Y.equalsIgnoreCase(consolidatedValidationResp.getProposalVo().getSellingDealerFlag()) ? "Yes"
							: "No");
			if (null != consolidatedValidationResp.getFinancialSummaryVO() && apiParams.isComplete()) {
				populateVolumnDataSource(tagMap, consolidatedValidationResp.getFinancialSummaryVO(), apiParams);
			} else {
				resetVolumnDataSource(tagMap);
			}
		}
	}

	private String covertUtcTime(Date value, String format) {
		String dateFormatted;
		SimpleDateFormat df = new SimpleDateFormat(format);
		df.setTimeZone(TimeZone.getTimeZone("GMT+04:00"));
		dateFormatted = df.format(value.getTime());
		return dateFormatted;
	}

	protected void populateVolumnDataSource(Map<String, Object> tagMap, FinancialSummaryVO financialSummaryVo,
			final ApiParams apiParams) {
		tagMap.put("xx_VolDataSource_xx", deriveDataSource(apiParams));
		tagMap.put("xx_PresentVMTotal_xx", getTagPresentVMTotal(financialSummaryVo));
		tagMap.put("xx_PresentVMAvg_xx", getPresentVMAvg(financialSummaryVo));
		tagMap.put("xx_PriorPYVMBWTotal_xx", getTagPriorPYVMBWTotal(financialSummaryVo));
		tagMap.put("xx_PriorPYVMBWAvg_xx", getPriorPYVMBWAvg(financialSummaryVo));
		tagMap.put("xx_PrevVerVMBWTotal_xx", getTagPrevVerVMBWTotal(financialSummaryVo));
		tagMap.put("xx_PrevVerVMBWAvg_xx", getPrevVerVMBWAvg(financialSummaryVo));
		tagMap.put("xx_TargetVMBWTotal_xx", getBWVMTargetTotal(financialSummaryVo));
		tagMap.put("xx_TargetBWVMAvg_xx", getBWVMTargetAvg(financialSummaryVo));
		tagMap.put("xx_PriorPYCMBWTotal_xx", getPriorPYCMBWTotal(financialSummaryVo));
		tagMap.put("xx_PriorPYCMBWAvg_xx", getPriorPYCMBWAvg(financialSummaryVo));
		tagMap.put("xx_TargetCMBWTotal_xx", getBWCMTargetTotal(financialSummaryVo));
		tagMap.put("xx_TargetCMBWAvg_xx", getBWCMTargetAvg(financialSummaryVo));
	}

	private String getBWCMTargetAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.getBwTargetAvgCM() != 0) {
			ret = BLANK + FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwTargetAvgCM(), 0, true,
					true);
		} else if (financialSummaryVo.getBwTargetAvgCM() == 0) {
			ret = ZERO;
		}
		return ret;
	}

	private String getBWCMTargetTotal(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.getBwTargetTotalCM() != 0) {
			ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwTargetTotalCM(), 0, true, true);
		} else if (financialSummaryVo.getBwTargetTotalCM() == 0) {
			ret = ZERO;
		}
		return ret;
	}

	private String getPriorPYCMBWAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPriorPYApplicable()) {
			if (financialSummaryVo.getBwPriorPYAvgCM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPriorPYAvgCM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPriorPYAvgCM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String getPriorPYCMBWTotal(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPriorPYApplicable()) {
			if (financialSummaryVo.getBwPriorPYTotalCM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPriorPYTotalCM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPriorPYTotalCM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String getBWVMTargetAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.getBwTargetAvgVM() != 0) {
			ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwTargetAvgVM(), 0, true, true);
		} else if (financialSummaryVo.getBwTargetAvgVM() == 0) {
			ret = ZERO;
		}
		return ret;
	}

	private String getBWVMTargetTotal(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.getBwTargetTotalVM() != 0) {
			ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwTargetTotalVM(), 0, true, true);
		} else if (financialSummaryVo.getBwTargetTotalVM() == 0) {
			ret = ZERO;
		}
		return ret;
	}

	private String getPrevVerVMBWAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPrevVerApplicable()) {
			if (financialSummaryVo.getBwPrevVerAvgVM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPrevVerAvgVM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPrevVerAvgVM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String getTagPrevVerVMBWTotal(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPrevVerApplicable()) {
			if (financialSummaryVo.getBwPrevVerTotalVM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPrevVerTotalVM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPrevVerTotalVM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String getTagPresentVMTotal(final FinancialSummaryVO financialSummaryVo) {
		String value = BLANK;
		if (financialSummaryVo.getPresentTotalVM() != 0) {
			value = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getPresentTotalVM(), 0, true,
					true);
		} else if (financialSummaryVo.getPresentTotalVM() == 0) {
			value = ZERO;
		}
		return value;
	}

	public String getPriorPYVMBWAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPriorPYApplicable()) {
			if (financialSummaryVo.getBwPriorPYAvgVM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPriorPYAvgVM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPriorPYAvgVM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String getPresentVMAvg(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.getPresentAvgVM() != 0) {
			ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getPresentAvgVM(), 0, false, true);
		} else if (financialSummaryVo.getPresentAvgVM() == 0) {
			ret = ZERO;
		}
		return ret;
	}

	private String getTagPriorPYVMBWTotal(final FinancialSummaryVO financialSummaryVo) {
		String ret = BLANK;
		if (financialSummaryVo.isPriorPYApplicable()) {
			if (financialSummaryVo.getBwPriorPYTotalVM() != 0) {
				ret = FbmsUtil.currencyFormatforDwnload(financialSummaryVo.getBwPriorPYTotalVM(), 0, true,
						true);
			} else if (financialSummaryVo.getBwPriorPYTotalVM() == 0) {
				ret = ZERO;
			}
		} else {
			ret = "N/A";
		}
		return ret;
	}

	private String deriveDataSource(final ApiParams apiParams) {
		String value = BLANK;
		switch (apiParams.getVolumeFinancialDataSource()) {
		case PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE:
			value = PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_DESC;
			break;
		case PRIOR_ACT_CURR_ACT_MLV_VM_CODE:
			value = PRIOR_ACT_CURR_ACT_MLV_VM_DESC;
			break;
		case PRIOR_ACT_CURR_ACT_CODE:
			value = PRIOR_ACT_CURR_ACT_DESC;
			break;
		case PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE:
			value = PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_DESC;
			break;
		case PRIOR_ACT_CURR_FCT_MLV_VM_CODE:
			value = PRIOR_ACT_CURR_FCT_MLV_VM_DESC;
			break;
		case PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE:
			value = PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_DESC;
			break;
		default:
			break;
		}
		return value;
	}

	protected void resetVolumnDataSource(final Map<String, Object> tagMap) {
		tagMap.put("xx_VolDataSource_xx", BLANK);
		tagMap.put("xx_PresentVMTotal_xx", BLANK);
		tagMap.put("xx_PriorPYVMBWTotal_xx", BLANK);
		tagMap.put("xx_PrevVerVMBWTotal_xx", BLANK);
		tagMap.put("xx_TargetVMBWTotal_xx", BLANK);
		tagMap.put("xx_PriorPYCMBWTotal_xx", BLANK);
		tagMap.put("xx_TargetCMBWTotal_xx", BLANK);
		tagMap.put("xx_PresentVMAvg_xx", BLANK);
		tagMap.put("xx_PriorPYVMBWAvg_xx", BLANK);
		tagMap.put("xx_PrevVerVMBWAvg_xx", BLANK);
		tagMap.put("xx_TargetBWVMAvg_xx", BLANK);
		tagMap.put("xx_PriorPYCMBWAvg_xx", BLANK);
		tagMap.put("xx_TargetCMBWAvg_xx", BLANK);
	}

	private void deriveTireLevel(GenericResponseWrapper consolidatedValidationResp, Map<String, Object> tagMap) {
		String tierVol1 = DASH, tierVol2 = DASH, tierVol3 = DASH, tierVol4 = DASH, tierVol5 = DASH, tierVol6 = DASH;
		Long tierVolume1 = consolidatedValidationResp.getProposalVo().getTierVolume1();
		Long tierVolume2 = consolidatedValidationResp.getProposalVo().getTierVolume2();
		Long tierVolume3 = consolidatedValidationResp.getProposalVo().getTierVolume3();
		Long tierVolume4 = consolidatedValidationResp.getProposalVo().getTierVolume4();
		Long tierVolume5 = consolidatedValidationResp.getProposalVo().getTierVolume5();
		Long tierVolume6 = consolidatedValidationResp.getProposalVo().getTierVolume6();
		if (consolidatedValidationResp.getProposalVo().getTierVolume6() != 0) {
			tierVol1 = tierVolume1 + HYPHEN + (tierVolume2 - 1);
			tierVol2 = tierVolume2 + HYPHEN + (tierVolume3 - 1);
			tierVol3 = tierVolume3 + HYPHEN + (tierVolume4 - 1);
			tierVol4 = tierVolume4 + HYPHEN + (tierVolume5 - 1);
			tierVol5 = tierVolume5 + HYPHEN + (tierVolume6 - 1);
			tierVol6 = tierVolume6 + PLUS;
		} else if (consolidatedValidationResp.getProposalVo().getTierVolume5() != 0) {
			tierVol1 = tierVolume1 + HYPHEN + (tierVolume2 - 1);
			tierVol2 = tierVolume2 + HYPHEN + (tierVolume3 - 1);
			tierVol3 = tierVolume3 + HYPHEN + (tierVolume4 - 1);
			tierVol4 = tierVolume4 + HYPHEN + (tierVolume5 - 1);
			tierVol5 = tierVolume5 + PLUS;
		} else if (consolidatedValidationResp.getProposalVo().getTierVolume4() != 0) {
			tierVol1 = tierVolume1 + HYPHEN + (tierVolume2 - 1);
			tierVol2 = tierVolume2 + HYPHEN + (tierVolume3 - 1);
			tierVol3 = tierVolume3 + HYPHEN + (tierVolume4 - 1);
			tierVol4 = tierVolume4 + PLUS;
		} else if (consolidatedValidationResp.getProposalVo().getTierVolume3() != 0) {
			tierVol1 = tierVolume1 + HYPHEN + (tierVolume2 - 1);
			tierVol2 = tierVolume2 + HYPHEN + (tierVolume3 - 1);
			tierVol3 = tierVolume3 + PLUS;
		} else if (consolidatedValidationResp.getProposalVo().getTierVolume2() != 0) {
			tierVol1 = tierVolume1 + HYPHEN + (tierVolume2 - 1);
			tierVol2 = tierVolume2 + PLUS;
		} else if (consolidatedValidationResp.getProposalVo().getTierVolume1() != 0) {
			tierVol1 = tierVolume1 + PLUS;
		}
		tagMap.put("xx_TierLevel1_xx", tierVol1);
		tagMap.put("xx_TierLevel2_xx", tierVol2);
		tagMap.put("xx_TierLevel3_xx", tierVol3);
		tagMap.put("xx_TierLevel4_xx", tierVol4);
		tagMap.put("xx_TierLevel5_xx", tierVol5);
		tagMap.put("xx_TierLevel6_xx", tierVol6);
	}

	public GenericResponse getApprovalChain(final GenericResponseWrapper genericResponseWrapper) {
		if (genericResponseWrapper.getApprovalChainList().isEmpty()) {
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
		} else {
			final ApprovalProcessResponse approvalResponse = new ApprovalProcessResponse();
			ApprovalResponseVo vo = new ApprovalResponseVo();
			vo.setApprovalChainVOList(genericResponseWrapper.getApprovalChainList());
			approvalResponse.setApprovalResponseVoList(Collections.singletonList(vo));
			approvalResponse.setHttpStatus(HttpStatus.OK);
			return approvalResponse;
		}
	}


	public GenericResponse getTotalAvgFinancials(final ApiParams apiParams,
			GenericResponseWrapper consolidatedValidationResp) {
		if ((consolidatedValidationResp.getFinancialDetailedVOList() != null)
				&& (!(consolidatedValidationResp.getFinancialDetailedVOList().isEmpty()))) {
			List<FinancialDetailedVO> financialDetailedVOs = consolidatedValidationResp.getFinancialDetailedVOList();
			Optional<FinancialDetailedVO> avgDetailedVO = financialDetailedVOs.stream()
					.filter(vo -> vo.getRecType().equals(FinancialDetailedVO.rowType.GrandTotal)).findAny();
			if (avgDetailedVO.isEmpty()) {
				return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
			} else {
				consolidatedValidationResp.setFinancialSummaryVO(updateSummaryDetails(avgDetailedVO.get()));
				consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
			}
		} else if ((consolidatedValidationResp.getFinancialDetailedMexVOList() != null)
				&& (!(consolidatedValidationResp.getFinancialDetailedMexVOList().isEmpty()))) {
			List<FinancialMexDetailedVO> financialmexDetailedVOs = consolidatedValidationResp
					.getFinancialDetailedMexVOList();
			Optional<FinancialMexDetailedVO> avgDetailedVO = financialmexDetailedVOs.stream().filter(
					vo -> vo.getRecType().toString().equals(FinancialMexDetailedVO.rowType.GrandTotal.toString()))
					.findAny();
			if (avgDetailedVO.isEmpty()) {
				return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
			} else {
				consolidatedValidationResp.setFinancialMexSummaryVO(updateMexSummaryDetails(avgDetailedVO.get()));
				consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
			}
		} else {
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
		}
		return consolidatedValidationResp;
	}

	private FinancialMexSummaryVO updateMexSummaryDetails(FinancialMexDetailedVO o) {
		FinancialMexSummaryVO s = new FinancialMexSummaryVO();
		double pfiVM = o.getProposedFleetInventiveVM() * o.getVolume();
		double bwFtVM = o.getBwFleetTargetVM() * o.getVolume();
		double bwCcctVM = o.getBwCCCTargetVM() * o.getVolume();
		double pCM = o.getProposedCM() * o.getVolume();
		double bwFtCM = o.getBwFleetTargetCM() * o.getVolume();
		double bwCcctCM = o.getBwCCCTargetCM() * o.getVolume();
		o.setBwFleetTargetPrectCM(
				(float) (((int)o.getFleetTargetCM() == 0) ? 0 : (o.getBwFleetTargetCM() / o.getFleetTargetCM() * 100)));

		float ftPrectCM = (float) (((int)o.getFleetTargetCM() == 0) ? 0
				: ((bwFtCM / (o.getFleetTargetCM() * o.getVolume())) * 100));
		float cccPrectCM = (float) (((int)o.getCccTargetCM() == 0) ? 0
				: ((bwCcctCM / (o.getCccTargetCM() * o.getVolume())) * 100));

		s.setPropsFleetIncetTotVM(Math.round(pfiVM));
		s.setPropsFleetIncetAvgVM(Math.round(o.getProposedFleetInventiveVM()));

		s.setBwFleetTargetTotalVM(Math.round(bwFtVM));
		s.setBwFleetTargetAvgVM(Math.round(o.getBwFleetTargetVM()));

		s.setBwCCCTargetTotalVM(Math.round(bwCcctVM));
		s.setBwCCCTargetAvgVM(Math.round(o.getBwCCCTargetVM()));

		s.setProposedTotalCM(Math.round(pCM));
		s.setProposedAvgCM(Math.round(o.getProposedCM()));

		s.setBwFleetTargetTotalCM(Math.round(bwFtCM));
		s.setBwFleetTargetAvgCM(Math.round(o.getBwFleetTargetCM()));

		s.setBwFleetTargetPrectTotalCM(ftPrectCM);
		s.setBwFleetTargetPrectAvgCM(o.getBwFleetTargetPrectCM());

		s.setBwCCCTargetTotalCM(Math.round(bwCcctCM));
		s.setBwCCCTargetAvgCM(Math.round(o.getBwCCCTargetCM()));

		s.setBwCCCTargetPrectTotalCM(cccPrectCM);
		s.setBwCCCTargetPrectAvgCM(o.getBwCCCTargetPrectCM());

		return s;
	}

	private FinancialSummaryVO updateSummaryDetails(final FinancialDetailedVO o) {
		FinancialSummaryVO s = new FinancialSummaryVO();
		double ptVM = (o.getPresentVM() * o.getPresentVol()) / 1000;
		double bpyVM = o.getPresentVM() - o.getPriorPYVM();
		double bpvVM = o.getPresentVM() - o.getPrevVerVM();
		double btVM = o.getPresentVM() - o.getTargetVM();
		double bpyCM = o.getPresentCM() - o.getPriorPYCM();
		double btCM = o.getPresentCM() - o.getTargetCM();

		s.setPresentTotalVM((int) Math.round(ptVM));
		s.setPresentAvgVM((int) Math.round(o.getPresentVM()));

		if (Math.round(o.getPresentVM()) != 0L && Math.round(o.getPriorPYVM()) != 0L) {
			s.setPriorPYApplicable(true);
			s.setBwPriorPYTotalVM((int) Math.round(((bpyVM * o.getPresentVol()) / 1000)));
			s.setBwPriorPYAvgVM((int) Math.round(bpyVM));
		}
		if (Math.round(o.getPresentVM()) != 0L && Math.round(o.getPrevVerVM()) != 0L) {
			s.setPrevVerApplicable(true);
			s.setBwPrevVerTotalVM((int) Math.round(((bpvVM * o.getPresentVol()) / 1000)));
			s.setBwPrevVerAvgVM((int) Math.round(bpvVM));
		}
		if (Math.round(o.getPresentVM()) != 0L) {
			s.setBwTargetTotalVM((int) Math.round(((btVM * o.getPresentVol()) / 1000)));
			s.setBwTargetAvgVM((int) Math.round(btVM));
		}
		if (Math.round(o.getPresentCM()) != 0L && Math.round(o.getPriorPYCM()) != 0L) {
			s.setPriorPYApplicable(true);

			s.setBwPriorPYTotalCM((int) Math.round(((bpyCM * o.getPresentVol()) / 1000)));
			s.setBwPriorPYAvgCM((int) Math.round(bpyCM));
		}
		if (Math.round(o.getPresentCM()) != 0L) {
			s.setBwTargetTotalCM((int) Math.round(((btCM * o.getPresentVol()) / 1000)));
			s.setBwTargetAvgCM((int) Math.round(btCM));
		}
		return s;
	}

	public GenericResponse rejectProposal(final ApiParams apiParams,
			final GenericResponseWrapper consolidatedValidationResp, final RequestMode requestMode,final HttpServletRequest request,final HttpServletResponse response,final CreateProposalRequest createProposalRequest) {
		ApprovalProcessDto presentQueue = consolidatedValidationResp.getApprovalProcessDto();
		Optional<ProposalStatusDto> rejectStatus = proposalStatusRepo.findById(ApprovalConstants.REJECTED); 
		Optional<FordPersonDto> aUser = fordPersonRepo.findById(apiParams.getUserId()); 
																						
																						
		Date updatedDate = new Date();
		presentQueue.setApprovedById(aUser.get());
		presentQueue.setApprovedTime(updatedDate);
		presentQueue.setProposalStatus(rejectStatus.get());
		presentQueue.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
		presentQueue.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
		presentQueue.setLastUpdatedUser(ApprovalConstants.FBMSNG);
		approvalProcessRepository.save(presentQueue);
		ProposalDto updateProposal = consolidatedValidationResp.getProposalDataDto();
		updateProposal.setProposalStatus(rejectStatus.get());
		updateProposal.setStatusYear(updatedDate);
		updateProposal.setFordApproveYear(updatedDate);
		updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
		updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
		updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
		proposalRepository.save(updateProposal);
		sendMail(apiParams, requestMode, updateProposal, request, response, createProposalRequest);
		GenericResponse genericResponse= responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REJECTED_SUCCESSFULLY);	
		genericResponse.setMsgDesc(MessageFormat.format(genericResponse.getMsgDesc(),getProposalAssignee(updateProposal)));
		return genericResponse;
		
	}

	public GenericResponse saveProposal(final ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp) {
		ProposalDto updateProposal = consolidatedValidationResp.getProposalDataDto();
		if (null != updateProposal && apiParams.isHighPriority() != updateProposal.isApprovalPriorityFlag()) {
			updateProposal.setApprovalPriorityFlag(apiParams.isHighPriority()); 
			updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			proposalRepository.save(updateProposal);
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_CREATE);
		}
		return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);

		
	}

	public GenericResponse recallProposal(final ApiParams apiParams,
			final GenericResponseWrapper genericResponseWrapper) {
		try {
			FordPersonDto recalledUser = genericResponseWrapper.getFordPersonDto(); 
			ProposalDto updateProposal = genericResponseWrapper.getProposalDataDto();
			if (null != updateProposal) {
				if (genericResponseWrapper.getApprovalResponseVo().getApprovalChain() != null
						&& !(genericResponseWrapper.getApprovalResponseVo().getApprovalChain().isEmpty())) {
					for (ApprovalProcessDto processDto : genericResponseWrapper.getApprovalResponseVo()
							.getApprovalChain()) {
						approvalProcessRepository.deleteById(processDto.getApprovalKey());
					}
				}
				if (genericResponseWrapper.getApprovalResponseVo().isAccountManagerFlag()) {
					Optional<ProposalStatusDto> newStatus = proposalStatusRepo.findById(ApprovalConstants.NEW);
					updateProposal.setProposalStatus(newStatus.get());
					updateProposal.setFordPerson(recalledUser);
					updateProposal.setStatusYear(new Date());
					updateProposal.setCntlApproveYear(null);
					updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
					updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
					updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
					proposalRepository.save(updateProposal);
				} else {
					Optional<ProposalStatusDto> submitStatus = proposalStatusRepo.findById(ApprovalConstants.SUBMITTED);
					ApprovalProcessDto updateRecalledQueue = genericResponseWrapper.getUpdateRecalledQueue();
					updateRecalledQueue.setApprovedById(null);
					updateRecalledQueue.setSubmittedToId(recalledUser);
					updateRecalledQueue.setProposalStatus(submitStatus.get());
					updateRecalledQueue.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
					updateRecalledQueue.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
					updateRecalledQueue.setLastUpdatedUser(ApprovalConstants.FBMSNG);
					approvalProcessRepository.save(updateRecalledQueue);
					if (genericResponseWrapper.getApprovalResponseVo()
							.getReportlevel() == ApprovalConstants.CONTROLLER_RL_CODE
							|| genericResponseWrapper.getApprovalResponseVo()
									.getReportlevel() == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE) {
						updateProposal.setCntlApproveYear(null);
						proposalRepository.save(updateProposal);
					}
				}
				
				if ("SUB".equals(updateProposal.getProposalStatus().getProposalStatusCode()) && updateProposal.getCntlReqdFlag()&& updateProposal.getCntlApproveYear()== null){
			    	  if(genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel()!=null &&   genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel().getCode() == 5) {
			    		 return (responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL));
			    	  }
			    	  if(genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel()!=null && genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel().getCode() == 4) {
			    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL);
			    	  }
			    	  if(genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel()!=null &&genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel().getCode() == 2) {
			    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL);
			    	  }
			    }
			}
			return responseBuilder.generateResponse(ResponseCodes.PROPOSAL_RECALLED_SUCCESSFULLY);
		} catch (Exception exception) {
			log.error("Error occurred in recalling proposal details in method recallProposalDetails" ,exception);
			return responseBuilder.generateResponse(ResponseCodes.UNEXPECTED_BEHAVIOR);
		}
	}

	public GenericResponse sendBackProposal(final ApiParams apiParams,
			final GenericResponseWrapper genericResponseWrapper, final RequestMode requestMode,final HttpServletRequest request,final HttpServletResponse response,final CreateProposalRequest createProposalRequest) {
		Optional<ProposalStatusDto> newStatus = proposalStatusRepo.findById(ApprovalConstants.NEW);
		ProposalDto updateProposal = genericResponseWrapper.getProposalDataDto();
		ApprovalResponseVo approvalResponseVo = sendBackProposal(updateProposal, genericResponseWrapper);
		genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		updateProposal.setProposalStatus(newStatus.get());
		updateProposal.setStatusYear(new Date());
		updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
		updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
		updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
		proposalRepository.save(updateProposal);
		sendMail(apiParams,requestMode,genericResponseWrapper.getProposalDataDto(),request,response,createProposalRequest);
		GenericResponse genericResponse= responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SENT_BACK_SUCCESSFULLY);	
		genericResponse.setMsgDesc(MessageFormat.format(genericResponse.getMsgDesc(),getProposalAssignee(updateProposal)));
		return genericResponse;
	}

	private ApprovalResponseVo sendBackProposal(ProposalDto proposal,
			final GenericResponseWrapper genericResponseWrapper) {
		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
		List<ApprovalProcessDto> approvalProcessList = genericResponseWrapper.getApprovalProcessDtoList();
		if (!(approvalProcessList.isEmpty())) {
			approvalProcessRepository.deleteByProposalKey(proposal);
			approvalResponseVo.setSendBackProcessFlag(true);
		}
		return approvalResponseVo;
	}


	public GenericResponse reviseProposal(ApiParams apiParams, GenericResponseWrapper consolidatedValidationResp) {
		Optional<ProposalStatusDto> reviseStatus = proposalStatusRepo.findById(ApprovalConstants.REVISED);
		ProposalDto updateProposal = consolidatedValidationResp.getProposalDataDto();
		updateProposal.setProposalStatus(reviseStatus.get());
		updateProposal.setStatusYear(new Date());
		updateProposal.setApprovalPriorityFlag(apiParams.isHighPriority());
		updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
		updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
		updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
		proposalRepository.save(updateProposal);
		return responseBuilder.generateResponse(ResponseCodes.PROPOSAL_REVISED_SUCCESSFULLY);
	}

	/**
	 * To parse validation response from each validator.
	 *
	 * @param apiParams API parameters
	 * @param cfResp    Validation response
	 * @return Parsed validation response
	 * @throws Exception 
	 */
	private GenericResponseWrapper parseValidationResponse(final ApiParams apiParams,
			final Future<GenericResponseWrapper> cfResp)  {
		GenericResponseWrapper genericResponseWrapper;
		try {
			genericResponseWrapper = cfResp.get();
		} catch (Exception e) {
			log.error("Error occurred in parseValidationResponse in method parseValidationResponse" ,e);
			Thread.currentThread().interrupt();
			genericResponseWrapper = new GenericResponseWrapper();
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INTERNAL_SERVER_ERROR));
		}
		return genericResponseWrapper;
	}

	/**
	 * To trigger post DB process if any.
	 *
	 * @param apiParams Given API Params
	 */
	@Override
	@LogAround
	public void triggerPostDbProcesses(final ApiParams apiParams) {
		LoggerBuilder.printInfo(log,
				logger -> logger.methodName("triggerPostDBProcesses").message("Executing post DB process!"));
		final Map<String, String> webThreadContext = MDC.getCopyOfContextMap();
		CompletableFuture.runAsync(() -> {
			MDC.setContextMap(webThreadContext);
			LoggerBuilder.printInfo(log,
					logger -> logger.methodName("triggerPostDBProcesses").message("Triggering POST DB actions"));
		});
	}

	public GenericResponse getVolumeFinancials(GenericResponseWrapper consolidatedValidationResp) {
		if (consolidatedValidationResp.getDropDownMap() == null) {
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
		} else {
			consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
			return consolidatedValidationResp;
		}
	}

	public GenericResponse populateFinancialList(GenericResponseWrapper consolidatedValidationResp) {
		
			final ApprovalProcessResponse approvalResponse = new ApprovalProcessResponse();
			ApprovalResponseVo vo = new ApprovalResponseVo();

			if ((consolidatedValidationResp.getFinancialDetailedVOList() != null)
					&& !(consolidatedValidationResp.getFinancialDetailedVOList().isEmpty())) {
				vo.setFinancialDetailedList(consolidatedValidationResp.getFinancialDetailedVOList());
				approvalResponse.setApprovalResponseVoList(Collections.singletonList(vo));
				buildResponseData(approvalResponse.getApprovalResponseVoList());
				approvalResponse.setHttpStatus(HttpStatus.OK);
				return approvalResponse;
			} else if ((consolidatedValidationResp.getFinancialDetailedMexVOList() != null)
					&& !(consolidatedValidationResp.getFinancialDetailedMexVOList().isEmpty())) {
				vo.setFinancialDetailedMexList(consolidatedValidationResp.getFinancialDetailedMexVOList());
				approvalResponse.setApprovalResponseVoList(Collections.singletonList(vo));
				buildMexResponseData(approvalResponse.getApprovalResponseVoList());
				approvalResponse.setHttpStatus(HttpStatus.OK);
				return approvalResponse;
			} else {
				return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
			}

		}
	
	
	 @LogAround
		private void buildResponseData(List<ApprovalResponseVo> appResEntityList) {
			ApprovalResponseVo responseData = appResEntityList.get(0);
			List<FinancialDetailedVO> financialList = responseData.getFinancialDetailedList();
			List<FinancialDetailedVO> vehicleList = new ArrayList<>();
			for (FinancialDetailedVO eachFinaDetaEntity : financialList) {
				if (eachFinaDetaEntity.getRecType().toString().equals(ApprovalConstants.LINE_TOTAL)) {
					vehicleList.add(eachFinaDetaEntity);
				}
			}
			for (FinancialDetailedVO eachVehicle : vehicleList) {
				List<FinancialDetailedBaseVO> bodyList = new ArrayList<>();
				for (FinancialDetailedVO eachFinaDetaEntity : financialList) {
					if (eachVehicle.getVehicleLineCode().equalsIgnoreCase(eachFinaDetaEntity.getVehicleLineCode())
							&& (eachFinaDetaEntity.getBodyStyle() != " ") && (eachVehicle.getModelYear().equals(eachFinaDetaEntity.getModelYear()))) {
						FinancialDetailedBaseVO baseBodyStyleVo = new FinancialDetailedBaseVO();
						baseBodyStyleVo.setPresentKey(eachFinaDetaEntity.getPresentKey());
						baseBodyStyleVo.setPriorKey(eachFinaDetaEntity.getPriorKey());
						baseBodyStyleVo.setPrevVerKey(eachFinaDetaEntity.getPrevVerKey());
						baseBodyStyleVo.setModelYear(eachFinaDetaEntity.getModelYear());
						baseBodyStyleVo.setPY(eachFinaDetaEntity.getPY()); 
						baseBodyStyleVo.setVehicleLine(eachFinaDetaEntity.getVehicleLine());
						baseBodyStyleVo.setPresentVol(eachFinaDetaEntity.getPresentVol());
						baseBodyStyleVo.setPriorVol(eachFinaDetaEntity.getPriorVol());
						baseBodyStyleVo.setPrevVerVol(eachFinaDetaEntity.getPrevVerVol());
						baseBodyStyleVo.setBwVol(eachFinaDetaEntity.getBwVol());
						baseBodyStyleVo.setBwPrevVerVol(eachFinaDetaEntity.getBwPrevVerVol());
						baseBodyStyleVo.setPresentVM(eachFinaDetaEntity.getPresentVM());
						baseBodyStyleVo.setPresentCPA(eachFinaDetaEntity.getPresentCPA());
						baseBodyStyleVo.setPresentESP(eachFinaDetaEntity.getPresentESP());
						baseBodyStyleVo.setPresentOPT(eachFinaDetaEntity.getPresentOPT());
						baseBodyStyleVo.setPresentAGG(eachFinaDetaEntity.getPresentAGG());
						baseBodyStyleVo.setPriorPYVM(eachFinaDetaEntity.getPriorPYVM());
						baseBodyStyleVo.setPrevVerVM(eachFinaDetaEntity.getPrevVerVM());
						baseBodyStyleVo.setTargetVM(eachFinaDetaEntity.getTargetVM());
						baseBodyStyleVo.setBwPriorPYVM(eachFinaDetaEntity.getBwPriorPYVM());
						baseBodyStyleVo.setBwPrevVerVM(eachFinaDetaEntity.getBwPrevVerVM());
						baseBodyStyleVo.setBwTargetVM(eachFinaDetaEntity.getBwTargetVM());
						baseBodyStyleVo.setPresentCC(eachFinaDetaEntity.getPresentCC());
						baseBodyStyleVo.setPriorPYCC(eachFinaDetaEntity.getPriorPYCC());
						baseBodyStyleVo.setPrevVerCC(eachFinaDetaEntity.getPrevVerCC());
						baseBodyStyleVo.setPresentRevenue(eachFinaDetaEntity.getPresentRevenue());
						baseBodyStyleVo.setPriorPYRevenue(eachFinaDetaEntity.getPriorPYRevenue());
						baseBodyStyleVo.setPrevVerRevenue(eachFinaDetaEntity.getPrevVerRevenue());
						baseBodyStyleVo.setPresentNR(eachFinaDetaEntity.getPresentNR());
						baseBodyStyleVo.setPriorPYNR(eachFinaDetaEntity.getPriorPYNR());
						baseBodyStyleVo.setPrevVerNR(eachFinaDetaEntity.getPrevVerNR());
						baseBodyStyleVo.setBwPriorPYNR(eachFinaDetaEntity.getBwPriorPYNR());
						baseBodyStyleVo.setBwPrevVerNR(eachFinaDetaEntity.getBwPrevVerNR());
						baseBodyStyleVo.setBwTargetNR(eachFinaDetaEntity.getBwTargetNR());
						baseBodyStyleVo.setPresentCM(eachFinaDetaEntity.getPresentCM());
						baseBodyStyleVo.setPriorPYCM(eachFinaDetaEntity.getPriorPYCM());
						baseBodyStyleVo.setPrevVerCM(eachFinaDetaEntity.getPrevVerCM());
						baseBodyStyleVo.setBwPriorPYCM(eachFinaDetaEntity.getBwPriorPYCM());
						baseBodyStyleVo.setBwPrevVerCM(eachFinaDetaEntity.getBwPrevVerCM());
						baseBodyStyleVo.setTargetRevenue(eachFinaDetaEntity.getTargetRevenue());
						baseBodyStyleVo.setTargetCC(eachFinaDetaEntity.getTargetCC());
						baseBodyStyleVo.setTargetNR(eachFinaDetaEntity.getTargetNR());
						baseBodyStyleVo.setTargetCM(eachFinaDetaEntity.getTargetCM());
						baseBodyStyleVo.setBwTargetRevenue(eachFinaDetaEntity.getBwTargetRevenue());
						baseBodyStyleVo.setBwTargetCC(eachFinaDetaEntity.getBwTargetCC());
						baseBodyStyleVo.setBwTargetCM(eachFinaDetaEntity.getBwTargetCM());
						baseBodyStyleVo.setIncludedInPriorProposal(eachFinaDetaEntity.isIncludedInPriorProposal());
						baseBodyStyleVo.setPresentProposal(eachFinaDetaEntity.isPresentProposal());
						baseBodyStyleVo.setVehDesc(eachFinaDetaEntity.getVehDesc());
						baseBodyStyleVo.setVehicleLineCode(eachFinaDetaEntity.getVehicleLineCode());
						baseBodyStyleVo.setBodyStyle(eachFinaDetaEntity.getBodyStyle());
						bodyList.add(baseBodyStyleVo);
					}
				}

				eachVehicle.setFinancialDetailedBaseVOList(bodyList);
			}
			for (FinancialDetailedVO eachFinaDetaEntity : financialList) {
				if (eachFinaDetaEntity.getRecType().toString().equals(ApprovalConstants.GRAND_TOTAL)) {
					vehicleList.add(eachFinaDetaEntity);
				}
			}
			responseData.setFinancialDetailedList(vehicleList);
		}
	 
	 
	 @LogAround
		private void buildMexResponseData(List<ApprovalResponseVo> appResEntityList) {
			ApprovalResponseVo responseData = appResEntityList.get(0);
			List<FinancialMexDetailedVO> financialList = responseData.getFinancialDetailedMexList();
			List<FinancialMexDetailedVO> vehicleList = new ArrayList<>();
			for (FinancialMexDetailedVO eachFinaDetaEntity : financialList) {
				if (eachFinaDetaEntity.getRecType().toString().equals(ApprovalConstants.LINE_TOTAL)) {
					vehicleList.add(eachFinaDetaEntity);
				}
			}
			for (FinancialMexDetailedVO eachVehicle : vehicleList) {
				List<FinancialMexDetailedBaseVO> bodyList = new ArrayList<>();
				for (FinancialMexDetailedVO eachFinaDetaEntity : financialList) {
					if (eachVehicle.getVehicleLineCode().equalsIgnoreCase(eachFinaDetaEntity.getVehicleLineCode())
							&& (eachFinaDetaEntity.getBodyStyle() != " ")) {
						FinancialMexDetailedBaseVO baseBodyStyleVo = new FinancialMexDetailedBaseVO();
						baseBodyStyleVo.setBodyStyle(eachFinaDetaEntity.getBodyStyle());
						baseBodyStyleVo.setBwCCCTargetCM(eachFinaDetaEntity.getBwCCCTargetCM());
						baseBodyStyleVo.setBwCCCTargetPrectCM(eachFinaDetaEntity.getBwCCCTargetPrectCM());
						baseBodyStyleVo.setBwCCCTargetVM(eachFinaDetaEntity.getBwCCCTargetVM());
						baseBodyStyleVo.setBwFleetTargetCM(eachFinaDetaEntity.getBwFleetTargetCM());
						baseBodyStyleVo.setBwFleetTargetPrectCM(eachFinaDetaEntity.getBwFleetTargetPrectCM());
						baseBodyStyleVo.setBwFleetTargetVM(eachFinaDetaEntity.getBwFleetTargetVM());
						baseBodyStyleVo.setCccTargetCM(eachFinaDetaEntity.getCccTargetCM());
						baseBodyStyleVo.setCccTargetVM(eachFinaDetaEntity.getCccTargetVM());
						baseBodyStyleVo.setDealerMargin(eachFinaDetaEntity.getDealerMargin());
						baseBodyStyleVo.setDealerMarginPrect(eachFinaDetaEntity.getDealerMarginPrect());
						baseBodyStyleVo.setFleetPrice(eachFinaDetaEntity.getFleetPrice());
						baseBodyStyleVo.setFleetTargetCM(eachFinaDetaEntity.getFleetTargetCM());
						baseBodyStyleVo.setFleetTargetVM(eachFinaDetaEntity.getFleetTargetVM());
						baseBodyStyleVo.setFleetType(eachFinaDetaEntity.getFleetType());
						baseBodyStyleVo.setFloorPlan(eachFinaDetaEntity.getFloorPlan());
						baseBodyStyleVo.setMarketingProgram(eachFinaDetaEntity.getMarketingProgram());
						baseBodyStyleVo.setModelYear(eachFinaDetaEntity.getModelYear());
						baseBodyStyleVo.setPresentVM(eachFinaDetaEntity.getPresentVM());
						baseBodyStyleVo.setProposedCM(eachFinaDetaEntity.getProposedCM());
						baseBodyStyleVo.setProposedFleetInventiveVM(eachFinaDetaEntity.getProposedFleetInventiveVM());
						baseBodyStyleVo.setVehDesc(eachFinaDetaEntity.getVehDesc());
						baseBodyStyleVo.setVehicleLine(eachFinaDetaEntity.getVehicleLine());
						baseBodyStyleVo.setVehicleLineKey(eachFinaDetaEntity.getVehicleLineKey());
						baseBodyStyleVo.setVolume(eachFinaDetaEntity.getVolume());
						bodyList.add(baseBodyStyleVo);
					}
				}

				eachVehicle.setFinancialDetailedBaseVOList(bodyList);
			}
			for (FinancialMexDetailedVO eachFinaDetaEntity : financialList) {
				if (eachFinaDetaEntity.getRecType().toString().equals(ApprovalConstants.GRAND_TOTAL)) {
					vehicleList.add(eachFinaDetaEntity);
				}
			}
			responseData.setFinancialDetailedMexList(vehicleList);
		}

	
	 
	public GenericResponse approveProposal(final ApiParams apiParams,
			final GenericResponseWrapper genericResponseWrapper, final RequestMode approvalRequest,final HttpServletRequest request,final HttpServletResponse response,final CreateProposalRequest createProposalRequest) {
		ProposalDto updateProposal = this.proposalRepository.findById(apiParams.getProposalKey()).get();
		if (genericResponseWrapper.getApprovalResponseVo().isProposalApproved()
				|| genericResponseWrapper.getApprovalResponseVo().isControllerApprovalRequired()
				|| genericResponseWrapper.getApprovalResponseVo().isProposalInRevise()) {
			updateProposal.setApprovalPriorityFlag(false);
			if (genericResponseWrapper.getApprovalResponseVo().isProposalInRevise()) {
				// update the status from Revise to Submit
				Optional<ReportLevelDto> aMaxReportLevel = this.reportLevelRepo
						.findById(genericResponseWrapper.getApprovalResponseVo().getMaxReportLevel().getSaKey());
				updateProposal.setProposalStatus(this.proposalStatusRepo.findById(ApprovalConstants.SUBMITTED).get());
				updateProposal.setReportLevel(aMaxReportLevel.get());
				updateProposal
						.setCntlReqdFlag(genericResponseWrapper.getApprovalResponseVo().isControllerApprovalRequired());
				updateProposal.setStatusYear(new Timestamp(new Date().getTime()));
			}
			if (genericResponseWrapper.getApprovalResponseVo().isProposalApproved()) {
				updateProposal.setProposalStatus(this.proposalStatusRepo.findById(ApprovalConstants.APPROVED).get());
				updateProposal.setFordApproveYear(new Date());
				updateProposal.setStatusYear(new Date());
			}
			if (genericResponseWrapper.getApprovalResponseVo().isControllerApproved() && genericResponseWrapper.getApprovalResponseVo().getControllerApprovalYear()!=null){
				// update controller approval details
				updateProposal.setCntlApproveYear(new Date());

			}
			updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			proposalRepository.save(updateProposal);
		} else {
			updateProposal.setApprovalPriorityFlag(false);
			updateProposal.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			updateProposal.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			updateProposal.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			proposalRepository.save(updateProposal);
		}

		Optional<ProposalStatusDto> proposalStatus = proposalStatusRepo.findById(ApprovalConstants.SUBMITTED);
		final Optional<ApprovalProcessDto> approvalProcessDto = this.approvalProcessRepository
				.findByProposalKeyAndProposalStatus(genericResponseWrapper.getProposalDataDto(), proposalStatus.get());
		if (approvalProcessDto.isPresent()) {
			ApprovalProcessDto approvalProcessDto_final = approvalProcessDto.get();
			approvalProcessDto_final.setProposalKey(genericResponseWrapper.getProposalDataDto());
			approvalProcessDto_final
					.setProposalStatus(this.proposalStatusRepo.findById(ApprovalConstants.APPROVED).get());
			approvalProcessDto_final
					.setApprovedById(genericResponseWrapper.getApprovalResponseVo().getApprovedByFordPerson());
			approvalProcessDto_final.setApprovedTime(new Timestamp(new Date().getTime()));
			approvalProcessDto_final.setCreatedProcess(ApprovalConstants.FBMSNG);
			approvalProcessDto_final.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
			approvalProcessDto_final.setCreatedUser(ApprovalConstants.FBMSNG);
			approvalProcessDto_final.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			approvalProcessDto_final.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			approvalProcessDto_final.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			approvalProcessRepository.save(approvalProcessDto_final);
			procedureRepository.updateFinancialData(apiParams.getProposalKey());
		}

		if (!(genericResponseWrapper.getApprovalResponseVo().isProposalApproved())) {
			ApprovalProcessDto createQueue = new ApprovalProcessDto();
			createQueue.setProposalKey(updateProposal);
			createQueue.setProposalStatus(this.proposalStatusRepo.findById(ApprovalConstants.SUBMITTED).get());
			createQueue.setSubmittedById(genericResponseWrapper.getApprovalResponseVo().getApprovedByFordPerson());
			createQueue.setSubmittedToId(this.fordPersonRepo
					.findById(genericResponseWrapper.getApprovalResponseVo().getNextApproverCdsid()).get());
			createQueue.setSubmittedTime(new Date());
			Optional<FordPersonDto> nextApprover = this.fordPersonRepo
					.findById(genericResponseWrapper.getApprovalResponseVo().getNextApproverCdsid());
			createQueue.setReportLevel(nextApprover.get().getReportLevel());
			createQueue.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
			createQueue.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
			createQueue.setLastUpdatedUser(ApprovalConstants.FBMSNG);
			createQueue.setCreatedUser(ApprovalConstants.FBMSNG);
			createQueue.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
			createQueue.setCreatedProcess(ApprovalConstants.FBMSNG);
			this.approvalProcessRepository.save(createQueue);
		}
		
		if(updateProposal.getProposalStatus().getProposalStatusCode().equals(ApprovalConstants.APPROVED)) {
			sendMail(apiParams,approvalRequest,genericResponseWrapper.getProposalDataDto(),request,response,createProposalRequest);
		}
		
		if (ApprovalConstants.SUBMITTED .equals(updateProposal.getProposalStatus().getProposalStatusCode()) && updateProposal.getCntlReqdFlag()&& updateProposal.getCntlApproveYear()== null){
	    	  if(updateProposal.getReportLevel().getCode() == 5) {
	    		 return (responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_LL5CONTROLLER_APPROVAL));
	    	  }
	    	  if(updateProposal.getReportLevel().getCode() == 4) {
	    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_MS_CONTROLLER_APPROVAL);
	    	  }
	    	  if(updateProposal.getReportLevel().getCode() == 2) {
	    		  return responseBuilder.generateResponse(ResponseCodes.THIS_PROPOSAL_REQUIRES_GLOBALCONTROLLER_APPROVAL);
	    	  }
	    }
		GenericResponse genericResponse=new GenericResponse();
		if(ApprovalConstants.SUBMITTED.equals(updateProposal.getProposalStatus().getProposalStatusCode())){
			genericResponse = responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_SUCCESSFULLY);
		} else if(ApprovalConstants.APPROVED.equals(updateProposal.getProposalStatus().getProposalStatusCode())) {
		 genericResponse= responseBuilder.generateResponse(ResponseCodes.PROPOSAL_APPROVED_FULLY);	
		genericResponse.setMsgDesc(MessageFormat.format(genericResponse.getMsgDesc(),getProposalAssignee(updateProposal)));
		}
		return genericResponse;
	}
	
	private GenericResponse sendMail(ApiParams apiParams, RequestMode request, ProposalDto proposal,
			final HttpServletRequest httpRequest, final HttpServletResponse response,
			CreateProposalRequest createProposalRequest) {
		EmailRequest emailRequest = new EmailRequest();
		StringBuilder subject = new StringBuilder();
		StringBuilder msgDesc = new StringBuilder();
		String accountName = getAccountName(proposal.getFinMasterKey().getFinMasterKey());
		String receiver = getProposalAssignee(proposal);
		emailRequest.setFrom(apiParams.getUserId());
		emailRequest.setSender(apiParams.getUserId()+"@ford.com");
		emailRequest.setTo(receiver + "@ford.com");
		if(accountName!=null) {
			subject=subject.append(accountName);
		}
		if (request.toString().equals(ApprovalConstants.APPROVE_PROPOSAL)) {
			subject = subject.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode())
					.append("-")
					.append(proposal.getVersionNumber()).append(" proposal has been fully approved by ")
					.append(apiParams.getUserId());
			msgDesc = msgDesc.append(subject)
					.append(".  Please proceed with Customer Acceptance processing of this version. Thank you!");
} else if (request.toString().equals(ApprovalConstants.NEXTDEAL_APPROVE)) {
			subject = subject.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode())
					.append("-")
					.append(proposal.getVersionNumber()).append(" proposal has been fully approved by ")
					.append(apiParams.getUserId());
			msgDesc = msgDesc.append(subject)
					.append(".  Please proceed with Customer Acceptance processing of this version. Thank you!");
		} else if (request.toString().equals(ApprovalConstants.REJECT_PROPOSAL)) {
			subject = subject.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode()).append("-")
					.append(proposal.getVersionNumber()).append(" proposal has been returned by ")
					.append(apiParams.getUserId());
			msgDesc = msgDesc.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode()).append(proposal.getVersionNumber())
					.append("proposal has been returned with following comments by ").append(apiParams.getUserId())
					.append(":\n\"").append(createProposalRequest.getProposalNoteDescription()).append("\"")
					.append("\n\nPlease contact your Regional Manager if you have any concerns.");
		} else if (request.toString().equalsIgnoreCase(ApprovalConstants.SENDBACK_PROPOSAL)) {
			subject = subject.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode()).append("-")
					.append(proposal.getVersionNumber()).append(" proposal has been Sent  Back by ")
					.append(apiParams.getUserId());
			msgDesc = msgDesc.append(" (").append(proposal.getFinMasterKey().getFinCode()).append(") ")
					.append(proposal.getPyDefinition().getProposalYearCode()).append(proposal.getVersionNumber())
					.append("proposal has been sent back with following comments by ").append(apiParams.getUserId())
					.append(":\n\"").append(createProposalRequest.getProposalNoteDescription()).append("\"")
					.append("\n\nPlease contact your Regional Manager if you have any concerns.");
		}
		emailRequest.setSubject(subject.toString());
		emailRequest.setContent(msgDesc.toString());
		emailRequest.setContentType("text/html");

		boolean isEmailPushed = mqUtil.putEmailInMq(emailRequest);
		GenericResponse genericResponse = new GenericResponse();
		if (isEmailPushed) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("sendMail")
	    	          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("email with message" + " " + "is sent successfully"));
			return responseBuilder.generateResponse(ResponseCodes.MAIL_SENT_SUCCESSFULLY);
		} else {
			genericResponse.setMsgDesc("Email object not pushed to MQ. Check logs!");
			response.setStatus(HttpStatus.FAILED_DEPENDENCY.value());
		}
		return genericResponse;

	}

	public GenericResponse createProposalComments(final ApiParams apiParams,final CreateProposalRequest createProposalRequest,final HttpServletRequest httpRequest,
			GenericResponse genericResponse) {
		
		if((!createProposalRequest.getProposalNoteDescription().isEmpty())){
              genericResponse = restService.createProposalComments(apiParams,
              		createProposalRequest, httpRequest);
          }
		return genericResponse;
		
	}
	
	public String getProposalAssignee(ProposalDto p) {
		String proposalAssignee = "";
		Optional<List<ProposalAssignAttributeDto>> oList;
		oList = proposalAssignAttributeRepository
				.findProposalAssignAttributeByFinMasterActive(p.getFinMasterKey().getFinMasterKey());

		if ((oList.isPresent())&&(!(oList.get().isEmpty()))) {
				for (ProposalAssignAttributeDto o : oList.get()) {
					if (o != null) {
						proposalAssignee = o.getAccountAssignment().getFordPerson().getCdsid();
						break;
					}
			}
		}
		return proposalAssignee;
	}
	
	private String getAccountName(Long key) {
		String accountName = null;
		Optional<FinOpUnitMaster> finOpUnitMaster =  finOpUnitMasterRepository.findByFinMasterFinOpUnit(key,"000");
		if (finOpUnitMaster.isPresent()) {
			accountName = finOpUnitMaster.get().getAccountName();
		}
		return accountName;
	}
	
	public GenericResponse findNextDeal(ApiParams apiParams,GenericResponseWrapper consolidatedResp) {
		ApprovalViewDto approvalViewRO;

		if (consolidatedResp.getApprovalResponseVo().getPresentReportLevelTitle()
				.equalsIgnoreCase(ApprovalConstants.CTL)) {

			approvalViewRO = approvalViewRepo
					.queryApprovalNextDealUSACTLByCountryCodeTitleCode(apiParams.getCountryCd(), ApprovalConstants.CTL);

			if (approvalViewRO != null) {
				Long proposalSakey = approvalViewRO.getProposalSaKey();

				consolidatedResp.setNextProposal(proposalSakey);
				consolidatedResp.setNoFutherDealsToApprove(false);
				consolidatedResp.setApprovalNextDeal(true);
				consolidatedResp.setHttpStatus(HttpStatus.OK);
			} else {
				consolidatedResp.setNoFutherDealsToApprove(true);
				consolidatedResp.setHttpStatus(HttpStatus.OK);
				consolidatedResp.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.NO_FURTHER_DEALS_TO_APPROVE));
			}
		} else {
			approvalViewRO = approvalViewRepo.queryApprovalNextDealUSAByCountryCodeCdsidCode(apiParams.getCountryCd(),
					apiParams.getUserId());

			if (approvalViewRO != null) {
				Long proposalSakey = approvalViewRO.getProposalSaKey();
				consolidatedResp.setNextProposal(proposalSakey);
				consolidatedResp.setNoFutherDealsToApprove(false);
				consolidatedResp.setApprovalNextDeal(true);
				consolidatedResp.setHttpStatus(HttpStatus.OK);

			} else {
				consolidatedResp.setNoFutherDealsToApprove(true);
				consolidatedResp.setHttpStatus(HttpStatus.OK);
				consolidatedResp.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.NO_FURTHER_DEALS_TO_APPROVE));
			}
		}
		return consolidatedResp;
	}

}
