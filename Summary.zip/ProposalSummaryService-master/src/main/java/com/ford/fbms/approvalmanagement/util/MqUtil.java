package com.ford.fbms.approvalmanagement.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ford.fbms.approvalmanagement.transport.EmailRequest;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageDeliveryMode;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * An util class for Rabbit Message Queue.
 *
 * @author SNITHY11 on 6/4/2021.
 */
@Slf4j
@Service
public class MqUtil {
  
  @Autowired
  private ObjectMapper objectMapper;

  @Autowired
  private RabbitTemplate rabbitTemplate;

  /**
   * This method sends a message to the rabbit Queue.
   *
   * @param messageObject is the message object to be sent
   */
  public void send(final MqDetails mqDetails, final Message messageObject) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("send")
        .message("Sending to rabbit queue !"));
    if (mqDetails != null && messageObject != null) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("send").mqName(mqDetails.name())
          .message("Sending to rabbit queue !"));
      rabbitTemplate.send(mqDetails.getExchangeNm(), mqDetails.getRoutingKeyNm(), messageObject);
      LoggerBuilder.printInfo(log, logger -> logger.methodName("send").mqName(mqDetails.name())
          .message("Message Sent to rabbit queue!"));
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("send")
          .message("Both MQDetails and Message are required!"));
    }
  }

  /**
   * To put email to be send in rabbit message queue.
   */
  @LogAround
  public boolean putEmailInMq(EmailRequest emailRequest) {
    String message;
    boolean isEmailPushed = false;
    try {
      message = objectMapper.writeValueAsString(emailRequest);
      MessageProperties messageProperties = new MessageProperties();
      messageProperties.setDeliveryMode(MessageDeliveryMode.PERSISTENT);
      Message messageObject =
          new Message(message.getBytes(StandardCharsets.UTF_8), messageProperties);
      send(MqDetails.EMAIL, messageObject);
      isEmailPushed = true;
      LoggerBuilder.printInfo(log, logger -> logger.message("Published email request"));
    } catch (JsonProcessingException e) {
      log.error("Failed marshalling email request" ,e);
    } catch (Exception e) {
      log.error("Failed publishing email request" ,e);
    }
    return isEmailPushed;
  }
}
