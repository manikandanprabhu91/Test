package com.ford.fbms.approvalmanagement.repository; 

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ford.fbms.approvalmanagement.domain.TargetBandDto;
import com.ford.fbms.approvalmanagement.domain.TargetBandPKDto;

public interface TargetBandRepository extends JpaRepository<TargetBandDto, TargetBandPKDto>{
	
	@Query(value="SELECT E06.* "
		      + "FROM {h-schema}MFBME06_TARGET_BAND E06  "
		      + "WHERE E06.FBMD09_SEG_C=:segment  "
		      +"AND E06.FBME06_EFFECTIVE_Y =  "
		      +"(SELECT MAX(E06A.FBME06_EFFECTIVE_Y)" 
              +"FROM {h-schema}MFBME06_TARGET_BAND E06A " 
              +"WHERE CONVERT(VARCHAR(25),E06A.FBME06_EFFECTIVE_Y,101) <= :effectiveYear " 
              +"AND  E06A.FBMD09_SEG_C=:segment)",nativeQuery = true)
		  TargetBandDto findTargetBandBySegEffDt(@Param("segment") String segment,@Param("effectiveYear") java.util.Date effectiveYear);

}
