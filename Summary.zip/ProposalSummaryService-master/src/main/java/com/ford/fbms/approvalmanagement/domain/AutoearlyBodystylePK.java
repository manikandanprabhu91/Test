package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * The primary key class for the MFBMD82_AUTOEARLY_BODYSTYLE database table.
 * 
 */
@Embeddable
public class AutoearlyBodystylePK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD16_PYVD_K")
	private PyVehicleDefinition pyVehicleDefinition;

	// bi-directional many-to-one association to Mfbme03BodyStyle
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME03_BDYSTL_K")
	private BodyStyleDto bodyStyle;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bodyStyle == null) ? 0 : bodyStyle.hashCode());
		result = prime * result + ((pyVehicleDefinition == null) ? 0 : pyVehicleDefinition.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;}
		if (!(obj instanceof AutoearlyBodystylePK)) {
			return false;}
		AutoearlyBodystylePK other = (AutoearlyBodystylePK) obj;
		if (bodyStyle == null) {
			if (other.bodyStyle != null)
				return false; 
		} else if (!bodyStyle.equals(other.bodyStyle)) {
			return false;}
		if (pyVehicleDefinition == null) {
			if (other.pyVehicleDefinition != null)
				return false; 
		} else if (!pyVehicleDefinition.equals(other.pyVehicleDefinition)) {
			return false; }
		return true;
	}

}