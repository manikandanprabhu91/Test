package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * The persistent class for the MFBME69_WERS_CATALOG_DATA database table.
 *
 */
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Setter
@Getter
@Entity
@Table(name = "MFBME69_WERS_CATALOG_DATA")

public class CatalogDataDto implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "E69SeqGenerator ", sequenceName = "MFBM_E69_SQ", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "E69SeqGenerator ")
	@Column(name = "FBME69_WERS_CATALOG_DATA_K")
	private long saKey;

	@Column(name = "FBMD42_WERS_MKT_C")
	private String wersMarketCode;

	@Column(name = "FBME69_WERS_CATALOG_ID")
	private String catalogDataId;

	@Column(name = "FBME69_WERS_NAMEPLATE_ID")
	private String namePlateId;

	@Column(name = "FBME69_WERS_NAMEPLATE_DESC")
	private String namePlateDesc;

	@Column(name = "FBME69_WERS_MODEL_YEAR_C")
	private String modelYearCode;

	@Column(name = "FBME69_SEGMENT_C")
	private String segmentCode;

	@Column(name = "FBME69_SEGMENT_X")
	private String segmentDesc;

	@Column(name = "FBME69_PTVL_C")
	private String ptvlCode;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	@Column(name = "FBME69_TIMING_POINT_Y")
	private Date timingPointYear;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME69_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME69_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME69_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME69_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME69_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME69_LAST_UPDT_USER_C")
	private String lastUpdatedUser;

}
