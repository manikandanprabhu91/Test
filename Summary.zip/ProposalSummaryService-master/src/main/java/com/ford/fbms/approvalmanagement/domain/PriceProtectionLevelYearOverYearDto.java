package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author VSHANMU8
 *
 */
@Builder(toBuilder = true)
@AllArgsConstructor(access = AccessLevel.PACKAGE)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@Setter
@Getter
@Entity
@Table(name = PriceProtectionLevelYearOverYearDto.TABLE_NAME)
@AttributeOverrides({ @AttributeOverride(name = "createdUserCode", column = @Column(name = "FBMD95_CREATE_USER_C")),
		@AttributeOverride(name = "createdTime", column = @Column(name = "FBMD95_CREATE_S")),
		@AttributeOverride(name = "createdProccessCode", column = @Column(name = "FBMD95_CREATE_PROCESS_C")),
		@AttributeOverride(name = "lastUpdateUserCode", column = @Column(name = "FBMD95_LAST_UPDT_USER_C")),
		@AttributeOverride(name = "lastUpdatedTime", column = @Column(name = "FBMD95_LAST_UPDT_S")),
		@AttributeOverride(name = "lastUpdatedProcessCode", column = @Column(name = "FBMD95_LAST_UPDT_PROCESS_C")) })
public class PriceProtectionLevelYearOverYearDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMD95_PPL_YOY";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD95_PPL_YOY_C")
	private String priceProLevYrOverYearCode;

	@Column(name = "FBMD95_PPL_YOY_X")
	private String priceProLevYrOverYearDesc;

}
