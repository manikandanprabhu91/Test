package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD98_ESP_CONTRACT_TYPE database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = EspContractTypeDto.TABLE_NAME)
// @NamedQuery(name = "EspContractType.findAll", query = "SELECT m FROM
// EspContractType m")
public class EspContractTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD98_ESP_CONTRACT_TYPE";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD98_ESP_CONTRACT_TYPE_C")
	private String espContractTypeCode;

	@Column(name = "FBMD98_ESP_CONTRACT_TYPE_X")
	private String espContractTypeDesc;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD98_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD98_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD98_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD98_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD98_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD98_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
