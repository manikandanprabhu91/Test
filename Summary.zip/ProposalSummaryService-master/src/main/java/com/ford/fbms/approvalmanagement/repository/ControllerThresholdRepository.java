package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.ControllerThresholdDto;
import java.util.Date;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Repository
public interface ControllerThresholdRepository extends JpaRepository<ControllerThresholdDto, Long> {
  @Query(value = "SELECT T1.* FROM {h-schema}MFBME28_CTL_THRESHOLD T1\n" +
      "INNER JOIN (\n" +
      "SELECT FBME28_CTL_THRESHOLD_C, MAX(FBME28_EFFECTIVE_S) AS FBME28_EFFECTIVE_S FROM {h-schema}MFBME28_CTL_THRESHOLD \n" +
      "WHERE FBME28_CTL_THRESHOLD_C = :code AND FBME28_EFFECTIVE_S < :effectiveDate   \n" +
      "GROUP BY FBME28_CTL_THRESHOLD_C\n" +
      ")STG ON T1.FBME28_CTL_THRESHOLD_C =STG.FBME28_CTL_THRESHOLD_C AND T1.FBME28_EFFECTIVE_S =STG.FBME28_EFFECTIVE_S", nativeQuery = true)
  ControllerThresholdDto controllerThresholdByCodeEffectiveDate(@Param("code") String code,@Param("effectiveDate") Date  effectiveDate);
}
