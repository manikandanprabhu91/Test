package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.config.ConfigProperties;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.StoredProcedureQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between model and table.
 *
 * @author SCHAN115 on 5/7/2021.
 */
@Transactional
@Repository
public class MaintainFinancialDataRepository {

  @PersistenceContext
  private EntityManager entityManager;
  
  @Autowired
  ConfigProperties configProperties;


  /**
   * This method to trigger the stored procedure for the proposal.
   *
   * @param proposalKey the proposal key
   * @return financialDataStatus
   */
  public Long maintainFinancialData(Long proposalKey) {
    StoredProcedureQuery query = entityManager
        .createStoredProcedureQuery(configProperties.getSchema() + ".FBMS_MAINTAIN_FINANCIAL_DATA");

    query.registerStoredProcedureParameter("i_nProposalKey", Long.class,
        ParameterMode.IN);
    query.registerStoredProcedureParameter("o_nOk", Long.class,
        ParameterMode.OUT);
    query.registerStoredProcedureParameter("o_sErrmsg", String.class,
        ParameterMode.OUT);
    query.setParameter("i_nProposalKey", proposalKey);
    query.execute();

    return (Long) query.getOutputParameterValue("o_nOk");
  }
}