package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class NewBodyStylePKDto extends GenericResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="FBME03_NEW_BDYSTL_K")
    private long newBodyStyle;
    
    @Column(name="FBME03_OLD_BDYSTL_K")
    private long oldBodyStyle;

}
