package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the MFBMC19_SERVICE_DEFINITION database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class ServiceDefinitionPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	// bi-directional many-to-one association to Mfbmd74ServiceAttrOption
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD74_SERVICE_ATTR_OPT_C")
	private ServiceAttributeOption serviceAttributeOption;

	// bi-directional many-to-one association to Mfbme15FinOpUntMaster
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME15_FOU_K")
	private FinOpUnitMaster mfbme15FinOpUntMaster;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mfbme15FinOpUntMaster == null) ? 0 : mfbme15FinOpUntMaster.hashCode());
		result = prime * result + ((serviceAttributeOption == null) ? 0 : serviceAttributeOption.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true; }
		if (obj == null) {
			return false; }
		if (!(obj instanceof ServiceDefinitionPK)) {
			return false; }
		ServiceDefinitionPK other = (ServiceDefinitionPK) obj;
		if (mfbme15FinOpUntMaster == null) {
			if (other.mfbme15FinOpUntMaster != null) {
				return false; }
		} else if (!mfbme15FinOpUntMaster.equals(other.mfbme15FinOpUntMaster)) {
			return false; }
		if (serviceAttributeOption == null) {
			if (other.serviceAttributeOption != null) {
				return false; }
		} else if (!serviceAttributeOption.equals(other.serviceAttributeOption)) {
			return false; }
		return true;
	}

}