package com.ford.fbms.approvalmanagement.validators;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.FinMasterDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.repository.FinMasterRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to load fleet person details.
 *
 * @author SJAGATJO on 3/25/2021.
 */
@Service
@Slf4j
public class SubfinManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  private ProposalRepository proposalRepository;
  @Autowired
  private ProposalSubsidiaryRepository proposalSubsidiaryRepository;
  @Autowired
  private FinMasterRepository finMasterRepository;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
   LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
        .userId(apiParams.getUserId()).country(apiParams.getCountryCd())
        .message("Inside SubsidiaryManager"));
   
   Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
   if (proposalDtoOptional.isEmpty()) {
     LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
         .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("proposalDtoOptional is Empty()"));
     genericResponseWrapper
         .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
   } else {
     ProposalDto proposal = proposalDtoOptional.get();
     genericResponseWrapper.setProposalDataDto(proposal);
     genericResponseWrapper=this.validateSubfin(proposal,genericResponseWrapper,apiParams);
     
      }
   return new AsyncResult<>(genericResponseWrapper);
    }
  
  

  private GenericResponseWrapper validateSubfin(ProposalDto proposal,GenericResponseWrapper genericResponseWrapper, ApiParams apiParams) {
	  boolean validSubFin = true;
	  List<ProposalSubsidiaryDto> maxList = new ArrayList<ProposalSubsidiaryDto>();
	  Optional<List<ProposalSubsidiaryDto>> maxListOptional = Optional.of(new ArrayList<ProposalSubsidiaryDto>());
	  Optional<List<ProposalSubsidiaryDto>> subsidiaryList = this.proposalSubsidiaryRepository
				.findByProposalKey(proposal.getProposalSaKey());
		if (subsidiaryList.isPresent()) {
			List<ProposalSubsidiaryDto> proposalSubsidiaries = subsidiaryList.get();
			ProposalDto maxEstUrvProposal = getMaxEstUrvProposal(proposal, 0);
			if(maxEstUrvProposal!=null) {
				maxListOptional = this.proposalSubsidiaryRepository
						.findByProposalKey(maxEstUrvProposal.getProposalSaKey());
			}
				if (maxListOptional.isPresent()) {
					 maxList = maxListOptional.get();}
					for (ProposalSubsidiaryDto subsidiary : proposalSubsidiaries) {
						boolean isSubFinPartOfEstUrv = false;
						for (ProposalSubsidiaryDto maxSubsidiary : maxList) {
							Long finMasterKey = subsidiary.getProposalSubsidiaryPK().getSubFinMaster()
							.getFinMasterKey();
							if (maxSubsidiary.getProposalSubsidiaryPK().getSubFinMaster()
									.getFinMasterKey().equals(finMasterKey) ) {

								// if subFin is part of EST then verify if its still
								// active and eligible fin
								
								FinMasterDto activeEligFinMaster = this.finMasterRepository.findActiveAndEligibleFinMasterByFinMaster(finMasterKey);
								if(activeEligFinMaster==null ) {
									validSubFin = false;
									genericResponseWrapper
							         .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_SUB_FIN));
								}
								
								isSubFinPartOfEstUrv = true;
								break;
							}

						}
						
						if(!isSubFinPartOfEstUrv) {
							Optional<FinMasterDto> eligibleFinBySubFinProposalYearCountry = this.finMasterRepository.findEligibleFinBySubFinProposalYearCountry(subsidiary.getProposalSubsidiaryPK().getSubFinMaster().getFinCode()
									, proposal.getPyDefinition().getProposalYearCode(), apiParams.getCountryCd());
							if(eligibleFinBySubFinProposalYearCountry.isEmpty()) {
								
								GenericResponse genericResponse= responseBuilder.generateResponse(ResponseCodes.INVALID_FIN);
								genericResponse.setMsgDesc(MessageFormat.format(genericResponse.getMsgDesc(),subsidiary.getProposalSubsidiaryPK().getSubFinMaster().getFinCode()));
								genericResponseWrapper.setGenericResponse(genericResponse);
								
							}
							
						}
					
					}
			
		}

		return genericResponseWrapper;
	  
  }
  
  private ProposalDto getMaxEstUrvProposal(ProposalDto p, int incrementYear) {
		int year = p.getPyDefinition().getProposalYearCode() + incrementYear;
		Long key = p.getFinMasterKey().getFinMasterKey();
		Optional<ProposalDto> maxProp = this.proposalRepository
				.getMaxEstOrUrvOnProposalByProposalYearFinMaster(year, key);
		if (maxProp.isEmpty()) {
			return null;
		} else {
			return maxProp.get();
		}
}

		
  
}