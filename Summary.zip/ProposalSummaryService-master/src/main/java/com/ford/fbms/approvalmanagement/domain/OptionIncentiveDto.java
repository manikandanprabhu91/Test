package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMA05_OPTION_INCENTIVE database table.
 * 
 */
@Entity
@Table(name = OptionIncentiveDto.TABLE_NAME)
// @NamedQuery(name="OptionIncentive.findAll", query="SELECT m FROM
// OptionIncentive m")

public class OptionIncentiveDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMA05_OPTION_INCENTIVE";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMA05_PD_K")
	private Long productDefenitionSaKey;

	@Column(name = "FBMA05_OPT_INCTV_A")
	private BigDecimal optInctvA;

	@Column(name = "FBMA05_OPT_INCTV_P")
	private BigDecimal optInctvP;

	@Column(name = "FBMA05_OPT_TAKE_RATE_R")
	private BigDecimal optTakeRate;

	@Column(name = "FBMA05_USC_X")
	private String uscDescription;

	// bi-directional many-to-one association to Mfbma04ProposalVehlnInctv
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMA04_PVI_K")
	private ProposalVehicleLineIncentiveDto proposalVehicleLineIncentive;

	// bi-directional many-to-one association to Mfbma23PaymentRoute
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMA23_PAYMENT_ROUTE_C")
	private PaymentRouteDto paymentRoute;

	// bi-directional many-to-one association to Mfbmd54EspFuelType
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD54_ESP_FUEL_TYPE_C")
	private EspFuelTypeDto espFuelType;

	// bi-directional many-to-one association to Mfbmd70CommonOption
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD70_COMMON_OPTION_C")
	private CommonOptionDto commonOption;

	// bi-directional many-to-one association to Mfbmd79EspOption
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBMD79_EO_K")
	private EspOptionDto espOption;

	// bi-directional many-to-one association to Mfbme02VocodeOption
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "FBME02_VOCODE_K")
	private VoCodeOptionDto vocodeOption;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumns(value = { @JoinColumn(name = "FBME48_USC_C", referencedColumnName = "FBME48_USC_C"),
			@JoinColumn(name = "FBME41_PD_MARKET_C", referencedColumnName = "FBME41_PD_MARKET_C"),
			@JoinColumn(name = "FBME48_MODEL_C", referencedColumnName = "FBME48_MODEL_C") })
	private UscOptionDto uscOption;

	/*
	 * //bi-directional many-to-one association to Mfbme48UscOption
	 * 
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumns({
	 * 
	 * @JoinColumn(name="FBME41_PD_MARKET_C",
	 * referencedColumnName="FBME41_PD_MARKET_C"),
	 * 
	 * @JoinColumn(name="FBME48_MODEL_C", referencedColumnName="FBME48_MODEL_C"),
	 * 
	 * @JoinColumn(name="FBME48_USC_C", referencedColumnName="FBME48_USC_C") })
	 * private UscOption uscOption;
	 */
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME71_WERS_OPTION_K")
	private WERSOptionDto wersOption;
	
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA05_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMA05_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMA05_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA05_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMA05_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMA05_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
