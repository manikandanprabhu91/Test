package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBMC14_ACCOUNT_NOTE database table.
 * 
 */
@Entity
@Table(name = AccountNote.TABLE_NAME)
public class AccountNote implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMC14_ACCOUNT_NOTE";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMC14_AN_K")
	private long accountNoteSaKey;

	@Column(name = "FBMC14_ACCT_NOTE_S")
	private Timestamp accountNoteTS;

	@Column(name = "FBMC14_ACCT_NOTE_X")
	private String accountNoteDescription;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD03_CDSID_C")
	private FordPersonDto fordPerson;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD21_FORG_C")
	private FordOrganization fordOrganization;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBME15_FOU_K")
	private FinOpUnitMaster finOpUnitMaster;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC14_CREATE_S")
	private Date createdTimeStamp;

	@JsonIgnore
	@Column(name = "FBMC14_CREATE_PROCESS_C")
	private String createdProcess;

	@JsonIgnore
	@Column(name = "FBMC14_CREATE_USER_C")
	private String createdUser;

	@JsonIgnore
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMC14_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@JsonIgnore
	@Column(name = "FBMC14_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@JsonIgnore
	@Column(name = "FBMC14_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
