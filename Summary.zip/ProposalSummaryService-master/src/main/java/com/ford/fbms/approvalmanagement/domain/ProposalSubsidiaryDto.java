package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;

import lombok.Getter;
import lombok.Setter;


	
	@Entity
	@Table(name = ProposalSubsidiaryDto.TABLE_NAME)
	@Getter
	@Setter
	public class ProposalSubsidiaryDto extends GenericResponse implements Serializable {

		private static final long serialVersionUID = 1L;

		public static final String TABLE_NAME = "MFBMA07_PROPOSAL_SUBSIDIARY";

		@EmbeddedId
		private ProposalSubsidiaryPK proposalSubsidiaryPK;

		@Column(name = "FBMA07_EST_INCLUDED_F")
		private String estIncludedFlag;

		@Temporal(TemporalType.DATE)
		@Column(name = "FBMA07_SUBSIDIARY_ADDED_Y")
		private Date subsidiaryAddedYear;

		/*
		 * //bi-directional many-to-one association to Mfbma01Proposal
		 * 
		 * @ManyToOne(fetch=FetchType.LAZY)
		 * 
		 * @JoinColumn(name="FBMA01_PROPOSAL_K") private Proposal proposal;
		 * 
		 * //bi-directional many-to-one association to Mfbme01FinMaster
		 * 
		 * @ManyToOne(fetch=FetchType.LAZY)
		 * 
		 * @JoinColumn(name="FBME01_SUBS_FIN_K") private FinMaster finMaster;
		 */

		// bi-directional many-to-one association to Mfbma08SubsidiaryDetail
		/*
		 * @OneToMany(mappedBy = "proposalSubsidiary") private List<SubsidiaryDetail>
		 * subsidiaryDetails;
		 */

		@Temporal(TemporalType.TIMESTAMP)
		@Column(name = "FBMA07_CREATE_S")
		private Date createdTimeStamp;

		@Column(name = "FBMA07_CREATE_PROCESS_C")
		private String createdProcess;

		@Column(name = "FBMA07_CREATE_USER_C")
		private String createdUser;

		@Temporal(TemporalType.TIMESTAMP)
		@Column(name = "FBMA07_LAST_UPDT_S")
		private Date lastUpdatedTimeStamp;

		@Column(name = "FBMA07_LAST_UPDT_PROCESS_C")
		private String lastUpdatedProcess;

		@Column(name = "FBMA07_LAST_UPDT_USER_C")
		private String lastUpdatedUser;
	}


