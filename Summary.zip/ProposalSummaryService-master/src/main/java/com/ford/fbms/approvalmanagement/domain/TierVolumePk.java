package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the MFBMA03_TIER_VOLUME database table.
 */
@Getter
@Setter
@Embeddable
public class TierVolumePk implements Serializable {
  // default serial version id, required for serializable classes.
  private static final long serialVersionUID = 1L;

  // bi-directional many-to-one association to Mfbma01Proposal
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "FBMA01_PROPOSAL_K")
  private ProposalDto proposalKey;

  @Column(name = "FBMA03_TIER_LEVEL_R")
  private long tierLevel;

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((proposalKey == null) ? 0 : proposalKey.hashCode());
    result = prime * result + (int) (tierLevel ^ (tierLevel >>> 32));
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true; }
    if (obj == null) {
      return false; }
    if (!(obj instanceof TierVolumePk)) {
      return false; }
    TierVolumePk other = (TierVolumePk) obj;
    if (proposalKey == null) {
      if (other.proposalKey != null) {
        return false; }
    } else if (!proposalKey.equals(other.proposalKey)){
      return false; }
    if (tierLevel != other.tierLevel){
      return false; }
    return true;
  }

}
