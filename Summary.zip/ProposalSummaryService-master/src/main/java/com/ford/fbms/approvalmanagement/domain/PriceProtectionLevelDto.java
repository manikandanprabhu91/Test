package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD04_PRICE_PROTECTION_LEVEL database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = PriceProtectionLevelDto.TABLE_NAME)
// @NamedQuery(name="PriceProtectionLevelDto.findAll", query="SELECT m FROM
// PriceProtectionLevelDto m")
public class PriceProtectionLevelDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD04_PRICE_PROTECTION_LEVEL";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD04_PPL_C")
	private String pplCode;

	@Column(name = "FBMD04_PPL_X")
	private String pplX;

	/*
	 * //bi-directional many-to-one association to Proposal
	 * 
	 * @OneToMany(mappedBy="priceProtectionLevel") private List<Proposal> proposals;
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD04_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD04_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD04_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD04_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD04_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD04_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
