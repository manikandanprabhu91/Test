package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD61_PROPOSAL_ASSIGN_ATTR database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = ProposalAssignAttributeDto.TABLE_NAME)
// @NamedQuery(name="Mfbmd61ProposalAssignAttr.findAll", query="SELECT m FROM
// Mfbmd61ProposalAssignAttr m")
public class ProposalAssignAttributeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD61_PROPOSAL_ASSIGN_ATTR";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD58_AA_K")
	private long saKey;

	@Column(name = "FBMD61_ACTIVE_F")
	private String active;

	@Column(name = "FBMD61_APPLY_AUTOEARLY_F")
	private String applyAutoearlyFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD61_ASSIGNMENT_Y")
	private Date assignmentYear;

	@Column(name = "FBMD61_SELLING_DLR_ASGN_F")
	private String sellingDlrAsgnFlag;

	// bi-directional one-to-one association to Mfbmd58AccountAssignment
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD58_AA_K")
	private AccountAssignmentDto accountAssignment;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD61_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD61_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD61_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD61_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD61_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD61_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
