package com.ford.fbms.approvalmanagement.validators;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;

import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MexApprovalChainValidator implements Validator {

	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;
	@Autowired
	protected ReportLevelRepository reportLevelRepository;
	@Autowired
	protected FordPersonRepository fordPersonRepository;
	@Autowired
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;
	@Autowired
	protected PviExtraInfoRepository pviExtraInfoRepository;

	@Override
	@LogAround
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams, final Object approvalRequest,
			final MasterRuleEngine masterRuleEngine, final HttpServletRequest httpRequest) {
		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log,
				logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
						.country(apiParams.getCountryCd()).country(apiParams.getCountryCd())
						.message("Inside ApprovalChainValidator"));
		Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("Proposal is invalid"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
		} else if (ApprovalConstants.NEW
				.equals(proposalDtoOptional.get().getProposalStatus().getProposalStatusCode())) {
			LoggerBuilder.printInfo(log,
					logger -> logger.methodName("populateApprovalChain").userId(apiParams.getUserId())
							.country(apiParams.getCountryCd())
							.message("Proposal (" + proposalDtoOptional.get().getProposalSaKey() + ") is in "
									+ proposalDtoOptional.get().getProposalStatus().getProposalStatusCode()
									+ " status. approval chain is not generated."));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.APPROVAL_CHAIN_NOT_EXISTS));
		} else {
			List<ApprovalChainVO> approvalChainVOList = populateApprovalChain(apiParams, proposalDtoOptional.get());
			genericResponseWrapper.setApprovalChainList(approvalChainVOList);
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	private List<ApprovalChainVO> populateApprovalChain(final ApiParams apiParams, ProposalDto proposal) {
		List<ApprovalChainVO> approvalChain = null;
		String status = proposal.getProposalStatus().getProposalStatusCode();
		int maxApprovalLevel = proposal.getReportLevel().getCode();
		boolean ignoreChain = true;
		boolean completedChain = true;
		boolean errorInApprovalChainGeneration = false;

		String maxApprovalLevelTitle = proposal.getReportLevel().getTitleCode();
		boolean businessCaseExist = isProposalBusinessCase(proposal);
		// Consider Max Approver as GVP before Finance Analyst submitted/approve the
		// proposal with providing the fleet incentive
		FordPersonDto fNMFordPersonRO = null;

		if (ApprovalConstants.NEW.equals(status)) {
			LoggerBuilder.printInfo(log,
					logger -> logger.methodName("populateApprovalChain").userId(apiParams.getUserId())
							.country(apiParams.getCountryCd())
							.message("Proposal (" + proposal.getProposalSaKey() + ") is in "
									+ proposal.getProposalStatus().getProposalStatusCode()
									+ " status. approval chain is not generated."));

		} else if (ApprovalConstants.SUBMITTED.equals(status) || ApprovalConstants.REVISED.equals(status)) {
			ignoreChain = false;
			completedChain = false;
		} else {
			ignoreChain = false;
			completedChain = true;
		}

		if (!ignoreChain) {
			approvalChain = buildPresentMexChain(proposal.getProposalSaKey(), proposal.getFordPerson().getCdsid(),
					businessCaseExist);
			if (approvalChain != null && !(approvalChain.isEmpty())) {

				// now complete the logic till GVP
				int reportLevel = approvalChain.get(approvalChain.size() - 1).getRole();
				String lcdsid = approvalChain.get(approvalChain.size() - 1).getCdsid();
				for (ApprovalChainVO chainVO : approvalChain) {
					if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.FNM)) {
						Optional<FordPersonDto> fordPerson = fordPersonRepository.findById(chainVO.getCdsid());
						if (fordPerson.isPresent()) {
							fNMFordPersonRO = fordPerson.get();
						}
					}
				}
				// now if the chain is at CTL then you have to go back to prior
				// and
				// build the remaining chain
				if (reportLevel != 11) {// CEO
					List<ApprovalChainVO> rChain = buildRemainingMexChain(lcdsid, maxApprovalLevel,
							maxApprovalLevelTitle, completedChain, fNMFordPersonRO, proposal);
					if (rChain != null && !(rChain.isEmpty())) {
						for (ApprovalChainVO chainVO : rChain) {
							approvalChain.add(chainVO);
						}
					}
				}

			} else {
				errorInApprovalChainGeneration = true;
				approvalChain = new ArrayList<ApprovalChainVO>();
				ApprovalChainVO errorChain = new ApprovalChainVO(-1, "Account Manager",
						"Approval Chain not available for this version.", "Not Applicable", null);
				approvalChain.add(errorChain);

			}
		}

		setOrderandDefaultDesc(approvalChain, businessCaseExist);
		return approvalChain;
	}

	public List<ApprovalChainVO> buildPresentMexChain(Long proposalSaKey, String namCdsid, boolean businessCaseExist) {
		List<ApprovalChainVO> approvalChain = buildMexChain(proposalSaKey, namCdsid, true, businessCaseExist);

		if (approvalChain != null && !(approvalChain.isEmpty())) {
			String lastStatus = null;
			String lastApprovedCdsid = null;

			lastStatus = approvalChain.get(approvalChain.size() - 1).getStatus();
			if (!(ApprovalConstants.NOT_REQUIRED.equals(lastStatus)
					|| ApprovalConstants.SUBMITTED.equals(lastStatus))) {
				lastApprovedCdsid = approvalChain.get(approvalChain.size() - 1).getCdsid();
				// add loop logic.....
				boolean nextChain = true;
				int loopCounter = 0;
				while (nextChain) {
					loopCounter = loopCounter + 1;
					ApprovalChainVO queue = null;
					queue = buildMexChain(proposalSaKey, lastApprovedCdsid);

					if (queue != null) {
						approvalChain.add(queue);
						lastStatus = queue.getStatus();
						if (!(ApprovalConstants.NOT_REQUIRED.equals(lastStatus)
								|| ApprovalConstants.SUBMITTED.equals(lastStatus))) {
							lastApprovedCdsid = queue.getCdsid();
						} else {
							nextChain = false;
						}

					} else {
						nextChain = false;
					}

					// Exit the infinite loop due to user data issue. expected
					// records should not be 10 or more.
					if (loopCounter > 10) {
						nextChain = false;
						break;
					}
				}

			}

		}

		return approvalChain;

	}

	public List<ApprovalChainVO> buildRemainingMexChain(String startCdsid, int maxApproval,
			String maxApprovalLevelTitle, boolean ignoreMaxApproval, FordPersonDto fNMFordPersonRO,
			ProposalDto proposal) {
		String lcdsid = null;
		String fNMSuprvr = null;
		FordPersonDto lastFordPerson = null;
		List<ApprovalChainVO> approvalChain = new ArrayList<ApprovalChainVO>();
		boolean reachedCEO = false;
		// Get the proposal

		Optional<FordPersonDto> fordPerson = fordPersonRepository.findById(startCdsid);
		if (fordPerson.isPresent()) {
			lastFordPerson = fordPerson.get();
			if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.FNM)) {
				lcdsid = proposal.getFordPerson().getSprcdsidDescription();
				fNMSuprvr = lastFordPerson.getSprcdsidDescription();
			} else if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.DFO)) {
				if (fNMSuprvr == null) {
					lcdsid = fNMFordPersonRO.getSprcdsidDescription();
				} else {
					lcdsid = fNMSuprvr;
					}
			} else if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.CTL)
					&& lastFordPerson.getCdsid().equalsIgnoreCase(ApprovalConstants.DEFAULT_CONTROLLER_MEX)) {
				lcdsid = getMexController().getSprcdsidDescription();
			} else {
				lcdsid = lastFordPerson.getSprcdsidDescription();
			}
		}
		int i = 0;
		while (!reachedCEO && i < 10) {
			int role = -1;
			String title = null;
			String cdsid = null;
			String status = null;
			Date statusDate = null;

			Optional<FordPersonDto> fordPerson_lcdsid = fordPersonRepository.findById(lcdsid);
			if (fordPerson_lcdsid.isPresent()) {
				lastFordPerson = fordPerson_lcdsid.get();
			} else {
				break;
			}
			role = lastFordPerson.getReportLevel().getCode();
			title = lastFordPerson.getReportLevel().getTitleCode();
			cdsid = lcdsid;
			// commented 5046401-Approval Chain Change
			/* 5046401-Approval Chain Change */
			if (((title.equalsIgnoreCase(ApprovalConstants.CEO) || title.equalsIgnoreCase(ApprovalConstants.GVP))
					&& (!maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.CEO)
							&& !maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.GVP)))
					|| ignoreMaxApproval) {
				status = ApprovalConstants.NOT_REQUIRED;
			}
			if (((title.equalsIgnoreCase(ApprovalConstants.DFO) || title.equalsIgnoreCase(ApprovalConstants.FSM))
					&& (!maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.CEO)
							&& !maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.GVP)
							&& !maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.DFO)
							&& !maxApprovalLevelTitle.equalsIgnoreCase(ApprovalConstants.FSM)))
					|| ignoreMaxApproval) {
				status = ApprovalConstants.NOT_REQUIRED;
			}
			/* 5046401-Approval Chain Change */

			approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));

			if (title.equalsIgnoreCase(ApprovalConstants.CEO)) {
				reachedCEO = true;
				break;
			}

			if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.FNM)) {
				lcdsid = proposal.getFordPerson().getSprcdsidDescription();
				fNMSuprvr = lastFordPerson.getSprcdsidDescription();
			} else if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.DFO)) {
				if (fNMSuprvr == null) {
					lcdsid = fNMFordPersonRO.getSprcdsidDescription();
				} else {
					lcdsid = fNMSuprvr;
					}
			} else if (lastFordPerson.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.CTL)
					&& lastFordPerson.getCdsid().equalsIgnoreCase(ApprovalConstants.DEFAULT_CONTROLLER_MEX)) {
				lcdsid = getMexController().getSprcdsidDescription();
			} else {
				lcdsid = lastFordPerson.getSprcdsidDescription();
			}
			i++;
		}

		return approvalChain;
	}

	public List<ApprovalChainVO> buildMexChain(Long proposal, String fordPerson, boolean addSubmittedBy,
			boolean businessCaseExist) {
		int role = -1;
		String title = null;
		String cdsid = null;
		String status = null;
		Date statusDate = null;
		List<ApprovalChainVO> approvalChain = new ArrayList<ApprovalChainVO>();
		List<ApprovalProcessDto> firstApprovalQueue = approvalProcessRepository
				.findApprovalProcessByProposalFordPerson(proposal, fordPerson, ApprovalConstants.FNA_RL_CODE);

		if (firstApprovalQueue != null && !(firstApprovalQueue.isEmpty())) {
			for (int i = 0; i < firstApprovalQueue.size(); i++) {
				status = firstApprovalQueue.get(i).getProposalStatus().getProposalStatusCode();
				role = firstApprovalQueue.get(i).getReportLevel().getCode();
				title = firstApprovalQueue.get(i).getReportLevel().getTitleCode();

				// first time it's Account Manager who submitted the proposal.
				// get details if requested.
				if (addSubmittedBy && i == 0) {
					String amTitle = ApprovalConstants.ACCOUNT_MANAGER_RL_TITLE;

					cdsid = firstApprovalQueue.get(i).getSubmittedById().getCdsid();
					statusDate = firstApprovalQueue.get(i).getSubmittedTime();
					int namRole = 7 * 2;
					// as this is created by account manager we can always say
					// status as Submitted and role as 7*2 just to place NAM
					// prior to controller
					approvalChain
							.add(new ApprovalChainVO(namRole, amTitle, cdsid, ApprovalConstants.SUBMITTED, statusDate));
				}

				if (ApprovalConstants.APPROVED.equals(status) || ApprovalConstants.REJECTED.equals(status)) {

					if (businessCaseExist) {
						cdsid = firstApprovalQueue.get(i).getApprovedById().getCdsid();
						statusDate = firstApprovalQueue.get(i).getApprovedTime();
					} else {
						cdsid = firstApprovalQueue.get(i).getSubmittedToId().getCdsid();
						statusDate = null;
					}

					approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));
				} else {
					// not yet approved in this queue
					cdsid = firstApprovalQueue.get(i).getSubmittedToId().getCdsid();
					status = ApprovalConstants.PENDING;
					statusDate = null;

					approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));
				}

			}
		} 
		return approvalChain;
	}

	public ApprovalChainVO buildMexChain(Long proposal, String fordPerson) {
		int role = -1;
		String title = null;
		String cdsid = null;
		String status = null;
		Date statusDate = null;
		ApprovalProcessDto approvalQueue = null;
		ApprovalChainVO approvalChain = null;

		approvalQueue = approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(proposal,
				fordPerson);

		if (approvalQueue != null) {
			role = approvalQueue.getReportLevel().getCode();
			title = approvalQueue.getReportLevel().getTitleCode();
			status = approvalQueue.getProposalStatus().getProposalStatusCode();

			if (ApprovalConstants.APPROVED.equals(status) || ApprovalConstants.REJECTED.equals(status)) {
				cdsid = approvalQueue.getApprovedById().getCdsid();
				statusDate = approvalQueue.getApprovedTime();
			} else {
				// not yet approved in this queue
				cdsid = approvalQueue.getSubmittedToId().getCdsid();
				status = ApprovalConstants.PENDING;
			}
			approvalChain = new ApprovalChainVO(role, title, cdsid, status, statusDate);

		}

		return approvalChain;

	}

	public FordPersonDto getMexController() {
		FordPersonDto mexController = null;
		List<FordPersonDto> fordPersonROList = fordPersonRepository.queryEligibleFordPersonAsController();
		if (fordPersonROList != null && !(fordPersonROList.isEmpty())) {
			for (FordPersonDto fordPersonRO : fordPersonROList) {
				if (fordPersonRO.getCdsid() != null && (!("").equals(fordPersonRO.getCdsid()))
						&& (fordPersonRO.getCountryCode().equals(ApprovalConstants.MEX))
						&& (!fordPersonRO.getCdsid().equalsIgnoreCase(ApprovalConstants.DEFAULT_CONTROLLER_MEX))) {
					mexController = fordPersonRO;
					break;
				}
			}
		}
		return mexController;
	}

	/**
	 * This method returns true if the proposal has a business case
	 * 
	 * @return boolean
	 */
	public boolean isProposalBusinessCase(ProposalDto p) {
		boolean businessCaseExists = false;

		Optional<List<ProposalVehicleLineIncentiveDto>> vehicleLineList = proposalVehicleLineIncentiveRepository
				.findByProposal(p);

		if (vehicleLineList.isPresent()) {
			for (ProposalVehicleLineIncentiveDto vehicleLineIncentiveRO : vehicleLineList.get()) {
				Optional<PviExtraInfoDto> PviExtraInfoBO = pviExtraInfoRepository
						.findById(vehicleLineIncentiveRO.getPviSaKey());
				if (PviExtraInfoBO.isPresent()) {
					PviExtraInfoDto pviExtraInfoRO = PviExtraInfoBO.get();
					if (ApprovalConstants.BUSINESS_CASE.equalsIgnoreCase(pviExtraInfoRO.getFleetRating())) {
						businessCaseExists = true;
						break;
					}
				}
			}
		}
		return businessCaseExists;
	}

	/**
	 * @param approvalChain
	 */
	public void setOrderandDefaultDesc(List<ApprovalChainVO> approvalChain, boolean businessCaseExist) {
		boolean fom_ctl_approved = false; 
		if (approvalChain != null && !(approvalChain.isEmpty())) {
			// change the CDSID to Any text if Default values are used
			for (ApprovalChainVO chainVO : approvalChain) {
				if (chainVO.getStatusDate() != null
						&& ApprovalConstants.CONTROLLER_CODE.equalsIgnoreCase(chainVO.getTitle())) {
					fom_ctl_approved = true;
				}
					if ((chainVO.getStatusDate() == null)&&(chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_ROM)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_CONTROLLER)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_FSM)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_DFO)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_GVP)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_FNA)
							|| chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_CONTROLLER_MEX)
							/* 5046401-Approval Chain Change */
							|| (ApprovalConstants.FNM.equalsIgnoreCase(chainVO.getTitle()) && !fom_ctl_approved)
							|| (ApprovalConstants.GVP.equalsIgnoreCase(chainVO.getTitle()) && !fom_ctl_approved)
					/* 5046401-Approval Chain Change */)) {
						chainVO.setCdsid(ApprovalConstants.ANY_DESCRIPTION);
					}

				if (("Account Manager").equalsIgnoreCase(chainVO.getTitle())) {
					chainVO.setOrderChain(100);
				} else if (ApprovalConstants.FNA.equalsIgnoreCase(chainVO.getTitle())) {
					chainVO.setOrderChain(90);
					if (!businessCaseExist) {
						chainVO.setStatus(ApprovalConstants.NOT_REQUIRED);
						chainVO.setStatusDate(null);
					}
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.CTL)) {
					chainVO.setOrderChain(80);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.FNM)) {
					chainVO.setOrderChain(70);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.RSM)) {
					chainVO.setOrderChain(60);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.FSM)) {
					chainVO.setOrderChain(50);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.DFO)) {
					chainVO.setOrderChain(40);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.GVP)) {
					chainVO.setOrderChain(30);
				} else if (chainVO.getTitle().equalsIgnoreCase(ApprovalConstants.CEO)) {
					chainVO.setOrderChain(20);
				}
			}

			// Sort the approval chain prior to display/return
			FbmsUtil.sort(approvalChain, "orderChain", false);
		}

	}
}