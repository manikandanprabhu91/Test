package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

/**
 * The primary key class for the MFBME06_TARGET_BAND database table.
 * 
 */
@Getter
@Setter
@Embeddable
public class TargetBandPKDto implements Serializable {

	private static final long serialVersionUID = 1L;


	// bi-directional many-to-one association to Mfbmd09Segment
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD09_SEG_C")
	private SegmentDto segment;

	// bi-directional many-to-one association to Mfbmd42Country
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "FBMD42_COUNTRY_ISO3_C")
	private CountryDto country;
	
	@JsonIgnore
	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME06_EFFECTIVE_Y")
	private Date effectiveYear;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((effectiveYear == null) ? 0 : effectiveYear.hashCode());
		result = prime * result + ((segment == null) ? 0 : segment.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true; }
		if (obj == null){
			return false; }
		if (!(obj instanceof TargetBandPKDto)) {
			return false; }
		TargetBandPKDto other = (TargetBandPKDto) obj;
		if (country == null) {
			if (other.country != null) {
				return false; }
		} else if (!country.equals(other.country)) {
			return false; }
		if (effectiveYear == null) {
			if (other.effectiveYear != null){
				return false; }
		} else if (!effectiveYear.equals(other.effectiveYear)){
			return false; }
		if (segment == null) {
			if (other.segment != null){
				return false; }
		} else if (!segment.equals(other.segment)){
			return false; }
		return true;
	}

}