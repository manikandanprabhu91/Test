package com.ford.fbms.approvalmanagement.validators;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ControllerThresholdDto;
import com.ford.fbms.approvalmanagement.domain.FinProfileDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;

@Service
@Slf4j

public class SubmitProcessValidator implements Validator{
	
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	private  ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected FinProfileRepository finProfileRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepo;
	
	@Override
	public Future<GenericResponseWrapper> validateAndConstruct(ApiParams apiParams, Object approvalRequest,
                                                             MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {
		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside submit process"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
			ApprovalResponseVo approvalResponseVo = submitProposal(apiParams, proposal);
			genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	private ApprovalResponseVo submitProposal(ApiParams apiParams, ProposalDto proposal) {
		apiParams.setVolumeFinancialDataSource(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE);
		List<ProposalFinancialVO> puFinancialList = proposalManager.buildProposalFinancialsEstimate(apiParams,
				proposal);
		List<FinancialDetailedVO> financialDetailedVOList = proposalManager.populateFinancialsForEstimate(apiParams,
				proposal, puFinancialList);

		ApprovalResponseVo approvalResponseVO = new ApprovalResponseVo();
		boolean isRentalProposal = false;
		boolean isNonFinancialSubmit = false; 
		if((proposal.getNonFinancialFlag()!=null)&&(proposal.getNonFinancialFlag())) {
			isNonFinancialSubmit = proposal.getNonFinancialFlag();
		}

		if (ApprovalConstants.RENTAL.equalsIgnoreCase(proposal.getFinMasterKey().getSegment().getSegmentCode())) {
			isRentalProposal = true;
		}

		// Submit if Non financial edit flag is set to NO
		if (!isNonFinancialSubmit) {

			// run the financial calculations
			approvalResponseVO = populateFinancialsForSubmitProcess(financialDetailedVOList);
			ReportLevelDto maxReportLevel = null;

			Optional<FinProfileDto> finProfile = finProfileRepo
					.findIdAndAccountClass(proposal.getFinMasterKey().getFinMasterKey());
			boolean controllerApprovalRequired = false;

			if (finProfile.isPresent()) {
				maxReportLevel = calculateMaxApproverForMajorRentalFin(apiParams);
				controllerApprovalRequired = true;
			} else {
				maxReportLevel = calculateMaxApprover(apiParams, proposal, financialDetailedVOList);
				controllerApprovalRequired = isControllerApprovalRequired(apiParams, proposal, approvalResponseVO);
			}
			boolean autoApvFlag = isEligibleForAutoApproval(apiParams, proposal, controllerApprovalRequired,
					financialDetailedVOList);

			String submitUser = apiParams.getUserId();
			String submitStatus = null;

			if (autoApvFlag) {
				submitStatus = ApprovalConstants.APPROVED;
			} else {
				submitStatus = ApprovalConstants.SUBMITTED;
			}

			if (maxReportLevel != null) {
				approvalResponseVO.setMaxReportLevel(maxReportLevel);
			}
			approvalResponseVO.setControllerApprovalRequired(controllerApprovalRequired);

			FordPersonDto submittedToFordPerson = new FordPersonDto();
			String asubmittedToFordPerson = null;
			Long submittedToReportLevel = null;

			if (isRentalProposal) {
				submittedToFordPerson = fordPersonRepo.findById(ApprovalConstants.DEFAULT_ROM).get();
				asubmittedToFordPerson = submittedToFordPerson.getCdsid();
				submittedToReportLevel = submittedToFordPerson.getReportLevel().getSaKey();
			} else {
				Optional<FordPersonDto> dealAuthorizedFlag = fordPersonRepo.findById(submitUser.toUpperCase());
				if (dealAuthorizedFlag.isPresent()) {
					if ("Y".equalsIgnoreCase(dealAuthorizedFlag.get().getUnassignedFinsFlag())) {
						asubmittedToFordPerson = dealAuthorizedFlag.get().getCdsid();
						submittedToReportLevel = dealAuthorizedFlag.get().getReportLevel().getSaKey();
					} else {
						submittedToFordPerson = fordPersonRepo.findById(apiParams.getUserId()).get();
						asubmittedToFordPerson = submittedToFordPerson.getSprcdsidDescription();
						submittedToReportLevel = fordPersonRepo.findById(asubmittedToFordPerson).get().getReportLevel().getSaKey();  
					}
				}

			}
			if (autoApvFlag) {
				Optional<FordPersonDto> fordPersonAutoApv = fordPersonRepo.findById(ApprovalConstants.AUTOAPV);
				approvalResponseVO.setSubmittedToFordPerson(fordPersonAutoApv.get().getCdsid());
				approvalResponseVO.setApprovedByFordPerson(fordPersonAutoApv.get());
				approvalResponseVO.setProposalStatus(submitStatus);
				approvalResponseVO.setApprovedTime(new Date());
			} else {
				approvalResponseVO.setSubmittedToFordPerson(asubmittedToFordPerson);
			}
			if(submittedToReportLevel!=null) {
			approvalResponseVO.setReportlevel(submittedToReportLevel.intValue());
			}
			approvalResponseVO.setProposalStatus(submitStatus);
			approvalResponseVO.setSubmittedByFordPerson(submitUser);

		} 		
		return approvalResponseVO;
	}
	
	@LogAround
	private ReportLevelDto calculateMaxApprover(ApiParams apiParams, ProposalDto proposal,
			List<FinancialDetailedVO> financialDetailedList) {
		ReportLevelDto maxReportLevel;
		// FoM chnages: passing the country code to get the max report level
		String countryCode = apiParams.getCountryCd();
		long totalBwTargetVM = 0L;
		if (null != financialDetailedList && !financialDetailedList.isEmpty()) {
			for (FinancialDetailedVO fdVO : financialDetailedList) {
				if (fdVO.getRecType().toString().equalsIgnoreCase(FinancialDetailedVO.rowType.GrandTotal.toString())) {
					totalBwTargetVM = Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol());
					if (totalBwTargetVM < 0) {
						totalBwTargetVM = totalBwTargetVM * (-1);
					} else {
						totalBwTargetVM = 0L;
					}
				}
			}
		}
		maxReportLevel = reportLevelRepo.getReportLevelDataByCountryApprovalAmt(countryCode, totalBwTargetVM);
		if (maxReportLevel != null ) {
			Optional<FordPersonDto> fordPerson = fordPersonRepo.findById(apiParams.getUserId());
			Optional<ReportLevelDto> reportlevelDto_1 = reportLevelRepo.findById(fordPerson.get().getReportLevel().getSaKey());
			int userLevelCode = reportlevelDto_1.get().getCode();
			if (maxReportLevel.getCode() == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE
					&& userLevelCode == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
				Optional<FordPersonDto> submittedToFordPerson = null;
				ReportLevelDto submittedToReportLevel = null;
				Optional<FordPersonDto> fordPersonDto = fordPersonRepo.findById(apiParams.getUserId());
				submittedToFordPerson =  fordPersonRepo.findById(fordPersonDto.get().getSprcdsidDescription())  ;
				if(submittedToFordPerson.isPresent()) {
				submittedToReportLevel = submittedToFordPerson.get().getReportLevel();
				}
				maxReportLevel = submittedToReportLevel;
			}
			
			// SMW fix 5212181 end
		} else {
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelDto : reportLevelList) {
				if (ApprovalConstants.RSM.equalsIgnoreCase(reportLevelDto.getTitleCode())) {
					maxReportLevel = reportLevelDto;
				}
			}
		}
		return maxReportLevel;
	}
	
	@LogAround
	private boolean isControllerApprovalRequired(ApiParams apiparams, ProposalDto proposal,
			ApprovalResponseVo approvalResponseVO) {
		boolean isControllerApprovalRequired = false;
		boolean isExceptionRulesProcessReq = true;
		if (0 != proposalManager.getAggregateIncentiv(proposal)) {
			isControllerApprovalRequired = true;
			return true;
		}
		if ((proposalManager.getMultiYearTerm(proposal) != null)
				|| (proposal.getPplYoy().getPriceProLevYrOverYearCode() != null
						&& !"NON".equalsIgnoreCase(proposal.getPplYoy().getPriceProLevYrOverYearCode()))) {
			isControllerApprovalRequired = true;
			isExceptionRulesProcessReq = false;
			return true;
		}
		if ((approvalResponseVO.isMatrixTargetLimit()) && proposal.getVersionNumber() == 1) {
			isControllerApprovalRequired = true;
			return true;
		} else if (((approvalResponseVO.isMatrixTargetLimit()) && proposal.getVersionNumber() != 1)&&(approvalResponseVO.isMatrixTargetLimitOnNewPerUnit())) {
				isControllerApprovalRequired = true;
				return true;
		}
		if ((!isControllerApprovalRequired) && (approvalResponseVO.isControllerLimitExceeded())) {
				isControllerApprovalRequired = true;
				isExceptionRulesProcessReq = false;
		}
			if ((!isControllerApprovalRequired)&&(approvalResponseVO.isTotalVMLimitExceeded())) {
				isControllerApprovalRequired = true;
			} else if ((!isControllerApprovalRequired)&&(approvalResponseVO.isTotalBwTargetLimitExceeded()
					|| approvalResponseVO.isBwTargetLimitExceededOnAnyPerUnit())) {
				isControllerApprovalRequired = true;
			}
		
		if (isExceptionRulesProcessReq && isControllerApprovalRequired) {
			ProposalDto pvProposal = proposalManager.identifyPriorProposals(proposal);
			String pvProposalStatus = (pvProposal == null) ? " "
					: pvProposal.getProposalStatus().getProposalStatusCode();
			if (pvProposalStatus.equalsIgnoreCase(ApprovalConstants.APPROVED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.DECLINED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.ESTABLISHED)
					|| pvProposalStatus.equalsIgnoreCase(ApprovalConstants.UNDER_REVIEW)) {
				List<TierVolumeDto> pTierVolumeList = proposalManager.getTierVolumeList(proposal);
				List<TierVolumeDto> pvTierVolumeList = proposalManager.getTierVolumeList(pvProposal);
				boolean isAllTierVolumesMatch = true;
				boolean isNoOfTiersMatch = true;
				if (pTierVolumeList.size() == pvTierVolumeList.size()) {
					for (TierVolumeDto pTierVolume : pTierVolumeList) {
						for (TierVolumeDto pvTierVolume : pvTierVolumeList) {
							if ((pTierVolume.getTierVolumePk().getTierLevel() == pvTierVolume.getTierVolumePk()
									.getTierLevel())&&(pTierVolume.getTierVolume() != pvTierVolume.getTierVolume())) {
									isAllTierVolumesMatch = false;
							}
						}
					}
				} else {
					isNoOfTiersMatch = false;
				}
				if (isAllTierVolumesMatch && isNoOfTiersMatch) {
					if (!approvalResponseVO.isTotalBwPrevVerLimitExceeded()
							&& !approvalResponseVO.isBwPrevVerLimitExceededOnAnyPerUnit()
							&& !approvalResponseVO.isBwTargetLimitExceededOnNewPerUnit()) {
						isControllerApprovalRequired = false;
					}
				}
			}
		}
		if (!approvalResponseVO.isMatrixTargetLimit()) {
			isControllerApprovalRequired = false;
		}
		if ((approvalResponseVO.isMatrixTargetLimit())&&(!approvalResponseVO.isMatrixTargetLimitOnNewPerUnit())) {
				isControllerApprovalRequired = false;
		}
		return isControllerApprovalRequired;
	}

	@LogAround		
	private ReportLevelDto calculateMaxApproverForMajorRentalFin(ApiParams apiParams) {
				return reportLevelRepo.getReportLevelDataByCountryTitleCode(apiParams.getCountryCd(),ApprovalConstants.CTL);
			}
			
			
	@LogAround		
	private ApprovalResponseVo populateFinancialsForSubmitProcess(
					List<FinancialDetailedVO> financialDetailedList) {

		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
				approvalResponseVo.setMatrixTargetLimit(false);
				approvalResponseVo.setBwTargetLimitExceededOnAnyPerUnit(false);

				// run the financial calculations without Submit process validation
				Date today = new Date();
				long ctlRoutingLimit = 0L;
				long newPerUnitTargetVMLimit = 0L;
				long perUnitBwPriorVerVMLimit = 0L;
				long perUnitBwTargetVMLimit = 0L;
				long totalBwPriorVerVMLimit = 0L;
				long totalBwTargetVMLimit = 0L;
				long totalVMLimit = 0L;

				ctlRoutingLimit = getControllerThresholdAmount(ApprovalConstants.CTL_ROUTING_LIMIT, today);

				newPerUnitTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.NEW_PU_BW_TARGET_VM_LIMIT,
						today);
				perUnitBwPriorVerVMLimit = getControllerThresholdAmount(ApprovalConstants.PU_BW_PRIOR_VER_VM_LIMIT,
						today);
				perUnitBwTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.PU_BW_TARGET_VM_LIMIT, today);
				totalBwPriorVerVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_BW_PRIOR_VER_VM_LIMIT,
						today);
				totalBwTargetVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_BW_TARGET_VM_LIMIT, today);
				totalVMLimit = getControllerThresholdAmount(ApprovalConstants.TOTAL_VM_LIMIT, today);

				long totalBwTargetVM = 0L;
				if (financialDetailedList != null && !financialDetailedList.isEmpty()) {

					for (FinancialDetailedVO f : financialDetailedList) {
						if (f.isPresentProposal()
								&& f.getRecType().name().equals(FinancialDetailedVO.rowType.VehicleLine.name())) {
							if (f.getPresentKey() > 0L) {
								if ((int)f.getPriorPYVM() != 0) {
									if (Math.abs(f.getPresentVM()) > Math.abs(f.getPriorPYVM())
											&& Math.abs(f.getPriorPYVM()) - Math.abs(f.getPresentVM())
													+ f.getYoyTarget() < 0) {
										if (Math.abs(f.getPresentVM()) > Math.abs(f.getMatrixTargetVM())) {
											approvalResponseVo.setMatrixTargetLimit(true);
											break;
										}
									}

								} else {
									if (Math.abs(f.getPresentVM()) > Math.abs(f.getTargetVM())) {
										approvalResponseVo.setMatrixTargetLimit(true);
										break;
									}
								}
							}
						}

					}

					for (FinancialDetailedVO fdVO : financialDetailedList) {
						if (fdVO.isPresentProposal()
								&& fdVO.getRecType().equals(FinancialDetailedVO.rowType.VehicleLine)) {
							if (fdVO.getPresentKey() > 0L) {
								if (Math.round(fdVO.getBwTargetVM()) <= perUnitBwTargetVMLimit) {
									approvalResponseVo.setBwTargetLimitExceededOnAnyPerUnit(true);
								}

								if (fdVO.getPresentKey() == fdVO.getPrevVerKey()) {
									if (Math.round(fdVO.getBwPrevVerVM()) < perUnitBwPriorVerVMLimit) {
										approvalResponseVo.setBwPrevVerLimitExceededOnAnyPerUnit(true);
										
											if (((int)fdVO.getPriorPYVM() != 0)&&((Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getPriorPYVM())
													&& Math.abs(fdVO.getPriorPYVM()) - Math.abs(fdVO.getPresentVM())
															+ fdVO.getYoyTarget() < 0))) {
												if (Math.abs(fdVO.getPresentVM()) > Math
														.abs(fdVO.getMatrixTargetVM())) {
													approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
													break;
												}
											} else {
											if (Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getTargetVM())) {
												approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
												break;
											}
										}
									}
								} else {
									// new vehicle add in this version
									if (Math.round(fdVO.getBwTargetVM()) <= newPerUnitTargetVMLimit) {
										approvalResponseVo.setBwTargetLimitExceededOnNewPerUnit(true);
											if (((int)fdVO.getPriorPYVM() != 0)&&((Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getPriorPYVM())
													&& Math.abs(fdVO.getPriorPYVM()) - Math.abs(fdVO.getPresentVM())
															+ fdVO.getYoyTarget() < 0))) {
												if (Math.abs(fdVO.getPresentVM()) > Math
														.abs(fdVO.getMatrixTargetVM())) {
													approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
													break;
												}
											} else {
											if (Math.abs(fdVO.getPresentVM()) > Math.abs(fdVO.getTargetVM())) {
												approvalResponseVo.setMatrixTargetLimitOnNewPerUnit(true);
												break;
											}
										}
									}
								}

							}
						}

						if (fdVO.getRecType().equals(FinancialDetailedVO.rowType.GrandTotal)) {
							if (Math.round(fdVO.getPresentVM() * fdVO.getPresentVol()) <= totalVMLimit) {
								approvalResponseVo.setTotalVMLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol()) < totalBwTargetVMLimit) {
								approvalResponseVo.setTotalBwTargetLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwTargetVM() * fdVO.getPresentVol()) <= ctlRoutingLimit) {
								approvalResponseVo.setControllerLimitExceeded(true);
							}
							if (Math.round(fdVO.getBwPrevVerVM() * fdVO.getPresentVol()) < totalBwPriorVerVMLimit) {
								approvalResponseVo.setTotalBwPrevVerLimitExceeded(true);
							}
						}
					}
				}
				return approvalResponseVo;
			}
			
			
	@LogAround		
	private long getControllerThresholdAmount(String code,
					Date effectiveDate) {

				ControllerThresholdDto controllerThresholdDto = controllerThresholdRepo
						.controllerThresholdByCodeEffectiveDate(code, effectiveDate);
				return controllerThresholdDto.getThresholdAmount();
			}
			
	@LogAround		
	private boolean isEligibleForAutoApproval(ApiParams apiParams,
					ProposalDto proposal, boolean controllerApprovalRequired,
					List<FinancialDetailedVO> financialDetailedVOList) {
				boolean isAutoApv = false;
				long totalMktVariance = 0L;
				if (null != financialDetailedVOList && !financialDetailedVOList.isEmpty()) {
					for (FinancialDetailedVO fdVO : financialDetailedVOList) {
						if (fdVO.getRecType().equals(FinancialDetailedVO.rowType.GrandTotal)) {
							totalMktVariance = Math.round(fdVO.getPresentVM() * fdVO.getPresentVol());
						}
					}
				}
				List<ReportLevelDto> firstLvlApvThreshold = reportLevelRepo.getReportLevelDataByCountryReportLevelCode(
						apiParams.getCountryCd(), ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE);
				if (firstLvlApvThreshold != null) {
					for (ReportLevelDto reportLevelDto : firstLvlApvThreshold) {
						if ((proposal.getProposalMlv().longValue() <= ApprovalConstants.TOT_DEAL_MLV)
								&& (totalMktVariance <= reportLevelDto.getMaxApprovalAmount().longValue())
								&& (!controllerApprovalRequired )) {
							isAutoApv = true;
						}
					}
				}
				return isAutoApv;
			}
}
