package com.ford.fbms.approvalmanagement.validators;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;

import com.ford.fbms.approvalmanagement.transport.ApprovalChainVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ApprovalChainValidator implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  protected ProposalRepository proposalRepository;
  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;
  @Autowired
  protected ReportLevelRepository reportLevelRepository;
  @Autowired
  protected FordPersonRepository fordPersonRepository;
  
  private static final String POPULATE_APPROVAL_CHAIN = "populateApprovalChain";

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest,
                                                             final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
        .country(apiParams.getCountryCd()).country(apiParams.getCountryCd()).message("Inside ApprovalChainValidator"));
    Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDtoOptional.isEmpty()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("Proposal is invalid"));
      genericResponseWrapper
          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    } else if(ApprovalConstants.NEW.equals(proposalDtoOptional.get().getProposalStatus().getProposalStatusCode())) {
    	LoggerBuilder.printInfo(log, logger -> logger.methodName(POPULATE_APPROVAL_CHAIN)
    	          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message(ApprovalConstants.PROPOSAL+ApprovalConstants.FONT_BEGIN_BRACE + proposalDtoOptional.get().getProposalSaKey() + ApprovalConstants.FONT_END_BRACE+proposalDtoOptional.get().getProposalStatus().getProposalStatusCode() 
    	              + " status. approval chain is not generated."));
    	genericResponseWrapper
        .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.APPROVAL_CHAIN_NOT_EXISTS));
    } else {
      List<ApprovalChainVO> approvalChainVOList = populateApprovalChain(apiParams, proposalDtoOptional.get());
      genericResponseWrapper.setApprovalChainList(approvalChainVOList);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }

  @LogAround
  private List<ApprovalChainVO> populateApprovalChain(final ApiParams apiParams, ProposalDto proposal) {
    String startFordPerson = null;
    List<ApprovalChainVO> approvalChain = null;
    List<ApprovalChainVO> approvalChainList = null;
    String status = proposal.getProposalStatus().getProposalStatusCode();
    int maxApprovalLevel = proposal.getReportLevel().getCode();
    boolean isCTLAppRequired = proposal.getCntlReqdFlag();
    boolean ignoreChain = true;
    boolean completedChain = true;
    boolean autoApvFlag = false;
    List<ApprovalProcessDto> approvalProcessList = approvalProcessRepository
        .findApprovalProcessById(proposal.getProposalSaKey());
    if (!(approvalProcessList.isEmpty())) {
      for (ApprovalProcessDto apprProcRO : approvalProcessList) {
        if (apprProcRO.getSubmittedToId().getCdsid().equals(ApprovalConstants.AUTOAPV)) {
          autoApvFlag = true;
        }
      }
    }
     if (ApprovalConstants.SUBMITTED.equals(status) || ApprovalConstants.REVISED.equals(status)) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName(POPULATE_APPROVAL_CHAIN)
          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message(ApprovalConstants.PROPOSAL+ApprovalConstants.FONT_BEGIN_BRACE + proposal.getProposalSaKey() + ApprovalConstants.FONT_END_BRACE+ status
              + " status and approval chain is NOT completed." + " Generating approval chain."));
      ignoreChain = false;
      completedChain = false;
    } else {
      ignoreChain = false;
      completedChain = true;
      LoggerBuilder.printInfo(log, logger -> logger.methodName(POPULATE_APPROVAL_CHAIN)
          .userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message(ApprovalConstants.PROPOSAL+ApprovalConstants.FONT_BEGIN_BRACE + proposal.getProposalSaKey() + ApprovalConstants.FONT_END_BRACE+status
              + " status and approval chain is completed." + " Generating approval chain."));
       }
    if (!ignoreChain) {
      approvalChain = buildPresentChain(proposal.getProposalSaKey(), proposal.getFordPerson().getCdsid(),
          autoApvFlag);
      if (approvalChain != null && !approvalChain.isEmpty()) {
        // now complete the logic till GVP
        int reportLevel = approvalChain.get(approvalChain.size() - 1).getRole();
        String lcdsid = approvalChain.get(approvalChain.size() - 1).getCdsid();
        if (reportLevel == 8) {
          reportLevel = approvalChain.get(approvalChain.size() - 2).getRole();
          lcdsid = approvalChain.get(approvalChain.size() - 2).getCdsid();
        }
        if (reportLevel != 2) {
          if (autoApvFlag) {
            Optional<FordPersonDto> fordPerson = fordPersonRepository
                .findById(proposal.getFordPerson().getCdsid());
            if (fordPerson.isPresent()) {
              startFordPerson = fordPerson.get().getCdsid();
              lcdsid = fordPerson.get().getSprcdsidDescription();
            }
          }
          List<ApprovalChainVO> rChain = buildRemainingChain(lcdsid, maxApprovalLevel, completedChain,
              autoApvFlag);
          if (rChain != null && !rChain.isEmpty()) {
            for (ApprovalChainVO chainVO : rChain) {
              approvalChain.add(chainVO);
            }
          }
        }

        ApprovalChainVO controllerChain = null;
        if (completedChain) {
          controllerChain = addController(approvalChain, false);
        } else {
          controllerChain = addController(approvalChain, isCTLAppRequired);
        }

        if (controllerChain != null) {
          approvalChain.add(controllerChain);
        }

      } else {
        approvalChain = new ArrayList<>();
        ApprovalChainVO errorChain = new ApprovalChainVO(-1, "Account Manager",
            "Approval Chain not available for this version.", "Not Applicable", null);
        approvalChain.add(errorChain);
      }
    }

    if (approvalChain != null && !approvalChain.isEmpty()) {
      // change the CDSID to Any text if Default values are used
      for (ApprovalChainVO chainVO : approvalChain) {
          if (chainVO.getStatusDate() == null &&chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_ROM)
              || chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_CONTROLLER)
              || chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_FSM)
              || chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_DFO)
              || chainVO.getCdsid().equals(ApprovalConstants.DEFAULT_GVP)) {
            chainVO.setCdsid(ApprovalConstants.ANY_DESCRIPTION);
          }
      }
      // Sort the approval chain prior to display/return
      FbmsUtil.sort(approvalChain, "role", false);
      approvalChainList = approvalChain;
    }
    return approvalChainList;
  }


  @LogAround
  private List<ApprovalChainVO> buildPresentChain(long proposalSaKey, String namCdsid, boolean autoApvFlag) {
    List<ApprovalChainVO> approvalChain = buildChain(proposalSaKey, namCdsid, true, autoApvFlag);
    String startcdsid = null;
    if (approvalChain != null && !approvalChain.isEmpty()) {
      String lastStatus;
      String prevLastStatus; 
      String lastApprovedCdsid;
      String prevLastApprovedCdsid; 
      lastStatus = approvalChain.get(approvalChain.size() - 1).getStatus();
      if (!(ApprovalConstants.NOT_REQUIRED.equals(lastStatus)
          || ApprovalConstants.SUBMITTED.equals(lastStatus))) {
        lastApprovedCdsid = approvalChain.get(approvalChain.size() - 1).getCdsid();
        // add loop logic.....
        boolean nextChain = true;
        /* ROM / RSM Deal Authoring Enhancement */
        prevLastStatus = lastStatus;
        prevLastApprovedCdsid = lastApprovedCdsid;
        Optional<FordPersonDto> fordPerson = fordPersonRepository.findById(namCdsid);
        if (fordPerson.isPresent()) {
          startcdsid = fordPerson.get().getSprcdsidDescription();
        }
        int loopCounter = 0;
        while (nextChain) {
          loopCounter = loopCounter + 1;
          ApprovalChainVO queue = null;
          if (autoApvFlag) {
            queue = buildChain(proposalSaKey, startcdsid, autoApvFlag);
          } else {
            queue = buildChain(proposalSaKey, lastApprovedCdsid, autoApvFlag);
          }
          if (queue != null) {
            /* ROM / RSM Deal Authoring Enhancement */

            if (prevLastStatus.equals(queue.getStatus())
                && prevLastApprovedCdsid.equals(queue.getCdsid())) {
              nextChain = false;
              break;
            }
            /* ROM / RSM Deal Authoring Enhancement */
            approvalChain.add(queue);
            lastStatus = queue.getStatus();
            if (!(ApprovalConstants.NOT_REQUIRED.equals(lastStatus)
                || ApprovalConstants.SUBMITTED.equals(lastStatus))) {
              lastApprovedCdsid = queue.getCdsid();
            } else {
              nextChain = false;
            }

          } else {
            nextChain = false;
          }
          // Exit the infinite loop due to user data issue. expected records should not be 10 or more.
          if (loopCounter > 10) {
            nextChain = false;
            break;
          }
        }
      }
    }

    return approvalChain;
  }

  @LogAround
  public List<ApprovalChainVO> buildChain(Long proposal, String fordPerson,
                                          boolean addSubmittedBy, boolean autoApv) {
    int role = -1;
    String title;
    String cdsid;
    String status;
    Date statusDate;
    List<ApprovalChainVO> approvalChain = new ArrayList<ApprovalChainVO>();
    int reportLevelCode = ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE;
    List<ApprovalProcessDto> firstApprovalQueue = approvalProcessRepository
        .findApprovalProcessByProposalFordPerson(proposal, fordPerson,reportLevelCode);
    if (firstApprovalQueue != null && !(firstApprovalQueue.isEmpty())) {
      for (int i = 0; i < firstApprovalQueue.size(); i++) {
        status = firstApprovalQueue.get(i).getProposalStatus().getProposalStatusCode();
        role = firstApprovalQueue.get(i).getReportLevel().getCode();
        title = firstApprovalQueue.get(i).getReportLevel().getTitleCode();
        if (role == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE
            || role == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
          role = role * 2;
        }
        // first time it's Account Manager who submitted the proposal.
        if (addSubmittedBy && i == 0) {
          String amTitle = ApprovalConstants.ACCOUNT_MANAGER_RL_TITLE;
          cdsid = firstApprovalQueue.get(i).getSubmittedById().getCdsid();
          statusDate = firstApprovalQueue.get(i).getSubmittedTime();
          int namRole = 7 * 2;
          // as this is created by account manager we can always say status as Submitted and role as 7*2 just to place NAM
          // prior to controller
          approvalChain
              .add(new ApprovalChainVO(namRole, amTitle, cdsid, ApprovalConstants.SUBMITTED, statusDate));
        }
        if (ApprovalConstants.APPROVED.equals(status) || ApprovalConstants.REJECTED.equals(status)) {
          cdsid = firstApprovalQueue.get(i).getApprovedById().getCdsid();
          statusDate = firstApprovalQueue.get(i).getApprovedTime();
          approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));
        } else {
          // not yet approved in this queue
          cdsid = firstApprovalQueue.get(i).getSubmittedToId().getCdsid();
          status = ApprovalConstants.PENDING;
          statusDate = null;
          approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));
        }
      }
    }
    return approvalChain;
  }

  @LogAround
  public ApprovalChainVO buildChain(Long proposal, String fordPerson, boolean autoApvFlag) {
    int role = -1;
    String title;
    String cdsid;
    String status;
    Date statusDate = null;
    ApprovalProcessDto approvalQueue;
    ApprovalChainVO approvalChain = null;
    approvalQueue = approvalProcessRepository.findApprovalProcessByProposalandSubmittedByFordPerson(proposal,
        fordPerson);
    if (approvalQueue != null) {
      role = approvalQueue.getReportLevel().getCode();
      title = approvalQueue.getReportLevel().getTitleCode();
      status = approvalQueue.getProposalStatus().getProposalStatusCode();
      if (role == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE
          || role == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
        role = role * 2;
      }
      if (ApprovalConstants.APPROVED.equals(status) || ApprovalConstants.REJECTED.equals(status)) {
        cdsid = approvalQueue.getApprovedById().getCdsid();
        statusDate = approvalQueue.getApprovedTime();
      } else {     
        cdsid = approvalQueue.getSubmittedToId().getCdsid();
        status = ApprovalConstants.PENDING;
      }
      if (autoApvFlag) {
        status = ApprovalConstants.NOT_REQUIRED;
      }
      approvalChain = new ApprovalChainVO(role, title, cdsid, status, statusDate);
    }
    return approvalChain;
  }

  @LogAround
  public List<ApprovalChainVO> buildRemainingChain(String startCdsid,
                                                   int maxApproval, boolean ignoreMaxApproval, boolean autoApvFlag) {
    String lcdsid = null;
    String lastFordPerson = null;
    List<ApprovalChainVO> approvalChain = new ArrayList<ApprovalChainVO>();
    boolean reachedGVP = false;
    Optional<FordPersonDto> fordPerson = fordPersonRepository.findById(startCdsid);
    if (fordPerson.isPresent()) {
      lastFordPerson = fordPerson.get().getCdsid();
      lcdsid = fordPerson.get().getSprcdsidDescription();
    }
    while (!reachedGVP) {
      int role = -1;
      String title;
      String cdsid;
      String status;
      Date statusDate = null;
      Optional<FordPersonDto> fordPerson_lcdsid = fordPersonRepository.findById(lcdsid);
      if (fordPerson_lcdsid.isPresent()) {
        lastFordPerson = fordPerson_lcdsid.get().getCdsid();
        role = fordPerson_lcdsid.get().getReportLevel().getCode();
        title = fordPerson_lcdsid.get().getReportLevel().getTitleCode();
        cdsid = lcdsid;
      } else {
        break;
      }
      if (autoApvFlag) {
        status = ApprovalConstants.NOT_REQUIRED;
      } else {
        if (ignoreMaxApproval) {
          status = ApprovalConstants.NOT_REQUIRED;
        } else {
          if (role >= maxApproval) {
            status = ApprovalConstants.PENDING;
          } else {
            status = ApprovalConstants.NOT_REQUIRED;
          }
        }
      }
      if (role == ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE
          || role == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
        role = role * 2;
      }
      approvalChain.add(new ApprovalChainVO(role, title, cdsid, status, statusDate));
      if (role == ApprovalConstants.GVP_RL_CODE) {
        reachedGVP = true;
        break;
      }
      lcdsid = fordPerson_lcdsid.get().getSprcdsidDescription();
    }
    return approvalChain;
  }

  @LogAround
  public ApprovalChainVO addController(
      List<ApprovalChainVO> approvalChainList,
      boolean controllerApprovalRequired) {
    ApprovalChainVO approvalChain = null;
    String status = ApprovalConstants.NOT_REQUIRED;
    boolean controllerPresent = false;
    for (ApprovalChainVO chainVO : approvalChainList) {
      if (chainVO.getRole() == ApprovalConstants.CONTROLLER_RL_CODE) {
        controllerPresent = true;
        break;
      }
    }
    if (!controllerPresent) {
      if (controllerApprovalRequired) {
        status = ApprovalConstants.PENDING;
      }
      approvalChain = new ApprovalChainVO(ApprovalConstants.CONTROLLER_RL_CODE, ApprovalConstants.CONTROLLER_CODE,
          ApprovalConstants.DEFAULT_CONTROLLER, status, null);
    }
    return approvalChain;
  }
}