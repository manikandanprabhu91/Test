package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBME63_DLR_ASSGMT_TYPE database table.
 * 
 */
@Entity
@Table(name = DealerAssignmentType.TABLE_NAME)
// @NamedQuery(name = "DlrAssgmtType.findAll", query = "SELECT m FROM
// DlrAssgmtType m")
public class DealerAssignmentType implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME63_DLR_ASSGMT_TYPE";
	@Id
	@Column(name = "FBME63_DLR_ASSGMT_TYPE_C")
	private String dealerAssgnmentTypeCode;

	@Column(name = "FBME63_DLR_ASSGMT_TYPE_X")
	private String dealerAssgnmentTypeDesc;

	/*
	 * // bi-directional many-to-one association to Mfbme31FinProfile
	 * 
	 * @OneToMany(mappedBy = "mfbme63DlrAssgmtType") private List<FinProfile>
	 * mfbme31FinProfiles;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME63_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME63_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME63_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME63_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME63_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME63_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
