package com.ford.fbms.approvalmanagement.executor;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.context.request.RequestContextHolder;


/**
 * A class for RequestScopeAwareExecutor.
 *
 * @author SNITHY11 on 2/7/2021.
 */
public class RequestScopeAwareExecutor extends ThreadPoolTaskExecutor {

  private static final long serialVersionUID = -4290350695871756360L;

  @Override
  public <T> Future<T> submit(final Callable<T> task) {
    return super.submit(
        new RequestScopeAwareCallable<T>(task, RequestContextHolder.currentRequestAttributes()));
  }

  @Override
  public Future<?> submit(final Runnable task) {
    return super.submit(
        new RequestScopeAwareRunnable(task, RequestContextHolder.currentRequestAttributes()));
  }

  @Override
  public <T> ListenableFuture<T> submitListenable(final Callable<T> task) {
    return super.submitListenable(
        new RequestScopeAwareCallable<T>(task, RequestContextHolder.currentRequestAttributes()));
  }

  @Override
  public ListenableFuture<?> submitListenable(final Runnable task) {
    return super.submitListenable(
        new RequestScopeAwareRunnable(task, RequestContextHolder.currentRequestAttributes()));
  }

}
