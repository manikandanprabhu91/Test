package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME51_USC_STATUS database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = UscStatusDto.TABLE_NAME)
// @NamedQuery(name="UscStatus.findAll", query="SELECT m FROM UscStatus m")
public class UscStatusDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME51_USC_STATUS";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME51_USC_STATUS_C")
	private String uscStatusCode;

	@Column(name = "FBME51_USC_STATUS_X")
	private String uscStatusDesc;

	/*
	 * //bi-directional many-to-one association to Mfbme48UscOption
	 * 
	 * @OneToMany(mappedBy="uscStatus") private List<UscOption> uscOptions;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbme49VehicleEntity
	 * 
	 * @OneToMany(mappedBy="uscStatus") private List<VehicleEntity> vehicleEntities;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME51_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME51_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME51_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME51_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME51_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME51_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
