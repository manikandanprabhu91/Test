package com.ford.fbms.approvalmanagement.transport;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;

import lombok.Getter;
import lombok.Setter;

/**
 * A class for Approval request.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Setter
@Getter
public class ApprovalResponseVo {

	/* Approver level */
	private int Reportlevel;

	private int level;

	/* Approver Role Title */
	private String title;

	/* CDSID of Approver */
	private String cdsid;

	/* Status and Status Date */
	private String proposalStatus;
	
	
	private List<FinancialDetailedVO> financialDetailedList;
	
	private Map VolumeFinanicailsOptions;
	private List<ApprovalProcessDto> approvalChain;

	private ReportLevelDto maxReportLevel;

	private boolean controllerApprovalRequired;

	private boolean highPriorityFlag;

	private String submitUser;

	private String submittedToFordPerson;

	private FordPersonDto approvedByFordPerson;

	private String submittedByFordPerson;

	private boolean matrixTargetLimit;

	private boolean bwTargetLimitExceededOnAnyPerUnit;

	private boolean bwPrevVerLimitExceededOnAnyPerUnit;

	private boolean matrixTargetLimitOnNewPerUnit;

	private boolean bwTargetLimitExceededOnNewPerUnit;

	private boolean totalVMLimitExceeded;

	private boolean totalBwTargetLimitExceeded;

	private boolean controllerLimitExceeded;

	private boolean totalBwPrevVerLimitExceeded;

	private boolean sendBackProcessFlag;

	private List<ApprovalChainVO> approvalChainVOList;

	private Date approvedTime;

	private Date submittedTime;

	private Date controllerApprovalYear;

	private boolean accountManagerFlag;
	
	private List<FinancialMexDetailedVO> financialDetailedMexList;
	
	private boolean proposalInRevise;
	
	private boolean approvalPriorityFlag;
	
	private Date statusDate;
	
	private boolean proposalApproved;
	
	private String nextApproverCdsid;
	
	private ProposalDto sourceProposalDto;
	
	private boolean controllerApproved;
	
	private String presentReportLevelTitle;
	
	
}
