package com.ford.fbms.approvalmanagement.util;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.util.Calendar;
import java.util.Random;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

/**
 * A class for building response.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Component
@PropertySource(value = "classpath:git.properties", ignoreResourceNotFound = true)
public class ResponseBuilder {

  @Value("${DATA_CENTER}")
  private  String dataCenter;

  @Value("${ENVIRONMENT}")
  private  String environment;

  @Value("${APP_NAME}")
  private  String appName;

  @Value("${git.commit.id.abbrev}")
  private  String commitIdAbbrev;

  @Value("${VERSION}")
  private  String version;

  @Autowired
  private  CacheUtil cacheUtil;

  /**
   * To generate response to the caller.
   *
   * @param responseCode {@link ResponseCodes}
   * @return {@link GenericResponse}
   */
  public GenericResponse generateResponse(final ResponseCodes responseCode) {
    return new GenericResponse(responseCode.getHttpStatus(),
        responseCode.getMsgId(), cacheUtil.getMsgDesc(responseCode.getMsgId()),
        Calendar.getInstance().getTime());
  }

  /**
   * To store, request header attributes in MDC for logging purpose.
   */
  @LogAround
  public void storeRequestHeaderAttributes(final HttpServletRequest request) {
    String correlationId = request.getHeader(Constants.CORRELATION_ID_HEADER_NAME);
    if (GenericAssister.isEmptyString(correlationId)) {
      final Random rand = new Random(System.currentTimeMillis());
      correlationId = Long.toHexString(rand.nextLong());
    }
    MDC.put(Constants.CORRELATION_ID_HEADER_NAME, correlationId);
    MDC.put(Constants.REQUEST_SERVICE_ID, appName + Constants.HYPHEN + version);
    MDC.put(Constants.VCAP_REQUEST_HEADER_NAME,
        request.getHeader(Constants.VCAP_REQUEST_HEADER_NAME));
    MDC.put(Constants.BUILD_VERSION_HEADER_NAME, frameBuildVersionHeaderName());
    MDC.put(Constants.REQUEST_SERVICE_ID, appName + Constants.HYPHEN + version);
    if (null != request.getHeader(Constants.TRACE_ID_HEADER_NAME)) {
      MDC.put(Constants.TRACE_ID_HEADER_NAME, request.getHeader(Constants.TRACE_ID_HEADER_NAME));
    }
  }

  /**
   * To frame project's build version header name by environment variables.
   *
   * @return a string represents build version header name
   */
  private String frameBuildVersionHeaderName() {
    String dataCenterShort = "";
    if (null != dataCenter && dataCenter.length() > 2) {
      dataCenterShort = dataCenter.substring(0, 2);
    }
    return new StringBuilder().append(appName).append(Constants.HYPHEN)
        .append(Constants.SERVICE_FIELD_NAME).append(Constants.HYPHEN)
        .append(dataCenterShort).append(Constants.HYPHEN).append(environment)
        .append(Constants.HYPHEN)
        .append(version).append(Constants.HYPHEN).append(commitIdAbbrev).toString();
  }

  /**
   * To set response header attributes.
   */
  public void setResponseHeaderAttributes(final HttpServletResponse response) {
    response.setHeader(Constants.TRACE_ID_HEADER_NAME, MDC.get(Constants.TRACE_ID_HEADER_NAME));
    response.setHeader(Constants.CORRELATION_ID_HEADER_NAME,
        MDC.get(Constants.CORRELATION_ID_HEADER_NAME));
    response.setHeader(Constants.BUILD_VERSION_HEADER_NAME,
        MDC.get(Constants.BUILD_VERSION_HEADER_NAME));
  }
}