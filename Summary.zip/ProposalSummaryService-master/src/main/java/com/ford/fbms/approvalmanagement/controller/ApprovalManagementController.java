package com.ford.fbms.approvalmanagement.controller;

import java.nio.charset.StandardCharsets;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ford.fbms.approvalmanagement.service.ApprovalManagementService;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.CreateProposalRequest;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApiResponseDetails;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.Constants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.RequestMode;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
 * A main controller class to receive requests.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Slf4j
@RestController
@RequestMapping(path = "/proposals")
@Api("To initiate web service development for FBMS")
@Validated
public class ApprovalManagementController {

  @Autowired
  private ApprovalManagementService approvalManagementService;

  @PreAuthorize("hasPermission('aud', 'createResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To process approval based on action", notes = "To submit approval for the FIN")
  @PostMapping(value = "/v1/submit-actions", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse processProposal(
      @ApiParam(value = Constants.REQUESTER_ID, required = true)
      @RequestParam @Pattern(regexp = Constants.REQUESTERID_REGEX,
          message = Constants.INVALID_REQUESTID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTID)
      @NotBlank final String cdsId,
      @ApiParam(value = Constants.COUNTRY_CODE, required = true)
      @RequestParam @Pattern(regexp = Constants.COUNTRYCODE_REGEX,
          message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @NotBlank final String countryCd,
      @Valid @RequestBody final CreateProposalRequest createProposalRequest,
      @ApiParam(value = "Proposal Key.", required = true)
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @RequestParam
      @NotNull final Long proposalKey,
      @ApiParam(value = "Action.", required = true)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String action,
      @ApiParam(value = "HighPriorityFlag.", required = false)
      @RequestParam final boolean highPriorityFlag,
			final HttpServletRequest httpRequest, final HttpServletResponse response) {
		GenericResponse genericResponse = new GenericResponse();
		final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, createProposalRequest,
				proposalKey, action, highPriorityFlag);
		if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.SUBMIT_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.SUBMIT_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.RECALL_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.RECALL_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.SAVE_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.SAVE_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.SENDBACK_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.SENDBACK_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.REJECT_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.REJECT_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.REVISE_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.REVISE_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.APPROVE_PROPOSAL)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.APPROVE_PROPOSAL, response);
		} else if (apiParams.getAction().equalsIgnoreCase(ApprovalConstants.NEXTDEAL_APPROVE)) {
			genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
					RequestMode.NEXTDEAL_APPROVE, response);
		}
		response.setStatus(genericResponse.getHttpStatus().value());
		return genericResponse;
	}

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get financial list", notes = "To get financial list for the FIN")
  @GetMapping(value = "/v1/financial-data", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse getFinancialList(
      @ApiParam(value = Constants.REQUESTER_ID, required = true)
      @RequestParam @Pattern(regexp = Constants.REQUESTERID_REGEX,
          message = Constants.INVALID_REQUESTID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTID)
      @NotBlank final String cdsId,
      @ApiParam(value = Constants.COUNTRY_CODE, required = true)
      @RequestParam @Pattern(regexp = Constants.COUNTRYCODE_REGEX,
          message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key.", required = true)
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @RequestParam
      @NotNull final Long proposalKey,
      @ApiParam(value = "Proposal Year", required = true)
      @Min(value = 1L, message = "Invalid length of Proposal Year")
      @Max(value = 9999L, message = "Invalid length of Proposal Year")
      @RequestParam
      @NotNull final Integer proposalYr,
      @ApiParam(value = "version.", required = true)
      @Min(value = 1, message = "Invalid length of Proposal Version")
      @Max(value = 99999L, message = "Invalid length of Proposal Version")
      @RequestParam
      @NotNull final Integer proposalYrVer,
      @ApiParam(value = "Fin key.", required = true)
      @RequestParam
      @Min(value = 1L, message = "Invalid length of Fin Key")
      @Max(value = 999999999L, message = "Invalid length of Fin Key")
      @NotNull final Long finKey,
      @ApiParam(value = "Volume Financial Data Source.", required = true)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String volumeFinancialDataSource,
      @ApiParam(value = "Fleet Rating.", required = false)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String fleetRating,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {
    // Populate preliminary fields
	  GenericResponse genericResponse = new GenericResponse();
    final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer, finKey,
        volumeFinancialDataSource,fleetRating);

    if (apiParams.getVolumeFinancialDataSource()
        .equalsIgnoreCase(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE)) {
      genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
          RequestMode.GET_FINANCIAL_LIST,response);
    } else if (apiParams.getVolumeFinancialDataSource()
        .equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE)
        || (ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))
        || (ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
     genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
          RequestMode.GET_ACTUAL_LIST,response);
    } else if (apiParams.getVolumeFinancialDataSource()
        .equalsIgnoreCase(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE)
        || (ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource()))) {
     genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
          RequestMode.GET_FORECAST_LIST,response);
    }
    response.setStatus(genericResponse.getHttpStatus().value());
	return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get approval chain", notes = "To get approval chain")
  @GetMapping(value = "/v1/approval-chain", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse populateApprovalChain(
      @ApiParam(value = Constants.REQUESTER_ID, required = true)
      @RequestParam @Pattern(regexp = Constants.REQUESTERID_REGEX,
          message = Constants.INVALID_REQUESTID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTID)
      @NotBlank final String cdsId,
      @ApiParam(value = Constants.COUNTRY_CODE, required = true)
      @RequestParam @Pattern(regexp = Constants.COUNTRYCODE_REGEX,
          message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key.", required = true)
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @RequestParam
      @NotNull final Long proposalKey,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey);
    GenericResponse genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
        RequestMode.APPROVAL_CHAIN,response);
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }


  /**
   * To trigger the stored procedure for the proposal.
   *
   * @param cdsId       requester's ID
   * @param countryCd   requesting country code
   * @param httpRequest {@link HttpServletRequest}
   * @param proposalKey requesting proposal key
   * @param response    {@link HttpServletResponse}
   * @return {@link GenericResponse}
   */
  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To trigger the stored procedure for the financial Data",
      notes = "To trigger stored procedure for the proposal")
  @GetMapping(value = "/v1/financial-data-trigger",
      produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponse financialDataStoredProcedure(
      @ApiParam(value = Constants.REQUESTER_ID, required = true)
      @RequestParam @Pattern(regexp = Constants.REQUESTERID_REGEX,
          message = Constants.INVALID_REQUESTID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTID)
      @NotBlank final String cdsId,
      @ApiParam(value = Constants.COUNTRY_CODE, required = true)
      @RequestParam @Pattern(regexp = Constants.COUNTRYCODE_REGEX,
          message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_LENGTH_COUNTRYCODE)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key.", required = true)
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @RequestParam
      @NotNull final Long proposalKey,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey);
    final GenericResponse genericResponse = approvalManagementService.financialDataStoredProcedure(apiParams,
        httpRequest, RequestMode.MAINTAIN_FINANCIAL_DATA_SP);
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  /**
   * To get Proposal Notes from the database.
   *
   * @param cdsId       requester's ID
   * @param countryCd   requesting country code
   * @param finKey      requesting finKey
   * @param httpRequest {@link HttpServletRequest}
   * @param response    {@link HttpServletResponse}
   * @return {@link GenericResponse}
   */

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get proposal Notes data",
      notes = "To get approval Notes details for the FIN")
  @GetMapping(value = "/v1/notes", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public GenericResponseWrapper retrieveProposalNotesDetails(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = "Invalid Requester ID")
      @Size(min = 1, max = 30, message = "Invalid length of Requester ID")
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = "Invalid Country Code")
      @Size(min = 3, max = 3, message = "Invalid length of Country Code")
      @NotBlank final String countryCd,
      @ApiParam(value = "Fin Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_FIN_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_FIN_KEY_LENGTH)
      @NotNull final Long finKey,
			final HttpServletRequest httpRequest, final HttpServletResponse response) {
		// Populate preliminary fields
		final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, null, finKey, null, null,
				null, null);
		return approvalManagementService.getProposalNotesDetails(apiParams, httpRequest, RequestMode.GET_PROSAL_NOTES);
	}

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get Multi Year Price Protection data",
      notes = "To get Multi Year Price Protection data")
  @GetMapping(value = "/v1/multi-year-price-protection", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public String retrieveMultiYrPriceProtDetails(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = "Invalid Requester ID")
      @Size(min = 1, max = 30, message = "Invalid length of Requester ID")
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = "Invalid Country Code")
      @Size(min = 3, max = 3, message = "Invalid length of Country Code")
      @NotBlank final String countryCd,
      @ApiParam(value = "Fin key.", required = true)
      @RequestParam
      @NotNull final Long finKey,
      @ApiParam(value = "Proposal key.", required = true)
      @RequestParam final Long proposalKey,
      @ApiParam(value = "Proposal Year.", required = true)
      @RequestParam
      @NotNull final Integer proposalYr,
      @ApiParam(value = "version.", required = true)
      @RequestParam
      @NotNull final Integer proposalYrVer,
			final HttpServletRequest httpRequest, final HttpServletResponse response) {

		// Populate preliminary fields
		final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, finKey, proposalKey,
				proposalYr, proposalYrVer, null, null);

		return approvalManagementService.getMultiYearPriceProtectionDetails(apiParams, httpRequest,
				RequestMode.GET_MULTIYR_PP);
	}


  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiOperation(value = "To get Volume Financial options for dropdown" ,
      notes = "To get Volume Financial options for dropdown")
  @GetMapping(value = "/v1/volume-financial-options")
  @LogAround
  public GenericResponse getVolumeFinancialOption(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = Constants.INVALID_REQUESTER_ID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTER_ID_LENGTH)
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = Constants.INVALID_COUNTRY_CODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_COUNTRY_CODE_LENGTH)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @NotNull final Long proposalKey,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    final ApiParams apiParams = approvalManagementService
        .buildApiParams(cdsId, countryCd, proposalKey);

    final GenericResponse genericResponse = approvalManagementService
        .processSummaryAndSubmit(apiParams, httpRequest, RequestMode.GET_VOLUME_FINANCIAL_OPTIONS,response);
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get Total and average value of VM and CM",
      notes = "To get Total and average value of VM and CM")
  @GetMapping(value = "/v1/totals-avg-financial")
  @LogAround
  public GenericResponse getTotalAvgFinancials(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = Constants.INVALID_REQUESTER_ID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTER_ID_LENGTH)
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = Constants.INVALID_COUNTRY_CODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_COUNTRY_CODE_LENGTH)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @NotNull final Long proposalKey,
      @ApiParam(value = "Volume Financial Data Source.", required = true)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String volumeFinancialDataSource,
      @ApiParam(value = "Fleet Rating.", required = true)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String fleetRating,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {
	  
	  final ApiParams apiParams = approvalManagementService.buildApiParams(cdsId, countryCd, proposalKey, 
		        volumeFinancialDataSource,fleetRating);
	  GenericResponse genericResponse = new GenericResponse();
	  
	  
		   genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest,
		          RequestMode.GET_TOTALS_AVG_FINANICIALS,response);
		
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "To get the valid action for proposal",
  notes = "To get the valid action for proposal")
  @GetMapping(value = "/v1/validate-actions")
  @LogAround
  public GenericResponse getValidateActions(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = Constants.INVALID_REQUESTER_ID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTER_ID_LENGTH)
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = Constants.INVALID_COUNTRY_CODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_COUNTRY_CODE_LENGTH)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @NotNull final Long proposalKey,
      final HttpServletRequest httpRequest, final HttpServletResponse response) {

    final ApiParams apiParams = approvalManagementService
        .buildApiParams(cdsId, countryCd, proposalKey);

    final GenericResponse genericResponse = approvalManagementService
        .processSummaryAndSubmit(apiParams, httpRequest, RequestMode.VALIDATE_ACTIONS,response);
    response.setStatus(genericResponse.getHttpStatus().value());
    return genericResponse;
  }

  @PreAuthorize("hasPermission('aud', 'readResource')")
  @ApiResponseDetails
  @ApiOperation(value = "Download Proposal to Excel", notes = "Download Proposal to Excel")
  @GetMapping(value = "/v1/download", produces = MediaType.APPLICATION_JSON_VALUE)
  @LogAround
  public ResponseEntity<byte[]> downloadProposal(
      @ApiParam(value = "Requester ID.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z0-9]{1,30}$", message = Constants.INVALID_REQUESTER_ID)
      @Size(min = 1, max = 30, message = Constants.INVALID_REQUESTER_ID_LENGTH)
      @NotBlank final String cdsId,
      @ApiParam(value = "Country Code.", required = true)
      @RequestParam @Pattern(regexp = "^[A-Za-z]{3}$", message = Constants.INVALID_COUNTRY_CODE)
      @Size(min = 3, max = 3, message = Constants.INVALID_COUNTRY_CODE_LENGTH)
      @NotBlank final String countryCd,
      @ApiParam(value = "Proposal Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_PROPOSAL_KEY_LENGTH)
      @NotNull final Long proposalKey,
      @ApiParam(value = "Proposal Year", required = true)
      @RequestParam
      @Min(value = 1L, message = "Invalid length of Proposal year")
      @Max(value = 999999999L, message = "Invalid length of Proposal year")
      @NotNull final Integer proposalYr,
      @ApiParam(value = "Proposal Year Version", required = true)
      @RequestParam
      @Min(value = 1L, message = "Invalid length of Proposal year version")
      @Max(value = 999999999L, message = "Invalid length of Proposal year version")
      @NotNull final Integer proposalYrVer,
      @ApiParam(value = "Fin Key", required = true)
      @RequestParam
      @Min(value = 1L, message = Constants.INVALID_FIN_KEY_LENGTH)
      @Max(value = 999999999L, message = Constants.INVALID_FIN_KEY_LENGTH)
      @NotNull final Long finKey,
      @ApiParam(value = "Full or partial download", required = true)
      @RequestParam final boolean isComplete,
      @ApiParam(value = "Volume Financial Data Source.", required = true)
      @RequestParam @Size(min = 1, max = 50, message = Constants.INVALID_REQUESTID)
      @NotBlank final String volumeFinancialDataSource,
      final HttpServletRequest httpRequest,
      final HttpServletResponse response) {

    //Populate preliminary fields
    final ApiParams apiParams = approvalManagementService
        .buildApiParams(cdsId, countryCd, proposalKey, proposalYr, proposalYrVer, finKey, isComplete, volumeFinancialDataSource);

    final GenericResponse genericResponse = approvalManagementService.processSummaryAndSubmit(apiParams, httpRequest, RequestMode.DOWNLOAD_PROPOSAL,response);

    GenericResponseWrapper genericResponseWrapper =
        (GenericResponseWrapper) genericResponse;
    String proposalStr = genericResponseWrapper.getProposalDownload();
    if (null != proposalStr) {
      return ResponseEntity.ok()
          .header(HttpHeaders.CONTENT_DISPOSITION,
              "attachment; filename=ProposalReport.xls")
          .contentType(MediaType.valueOf("application/x-msexcel"))
          .contentLength(proposalStr.length())
          .body(proposalStr.getBytes(StandardCharsets.UTF_8));
    } else {
      return ResponseEntity.unprocessableEntity().build();
    }
  }

  }
