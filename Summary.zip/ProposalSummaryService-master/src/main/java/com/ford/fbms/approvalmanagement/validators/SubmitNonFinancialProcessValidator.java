package com.ford.fbms.approvalmanagement.validators;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSubsidiaryDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalStatusRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSubsidiaryRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@EnableAsync(proxyTargetClass = true)
public class SubmitNonFinancialProcessValidator implements Validator {

	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;
	@Autowired
	protected ProposalSummaryViewRepository proposalSummaryViewRepository;
	@Autowired
	protected ProposalStatusRepository proposalStatusRepo;
	@Autowired
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineRepo;
	@Autowired
	protected ProposalSubsidiaryRepository proposalSubsidiaryRepository;

	@Override
	public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams, final Object approvalRequest,
			final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.VALIDATE_METHOD)
				.userId(apiParams.getUserId()).message("Inside submit process"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.VALIDATE_METHOD)
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.INVALID_FIELDS_PROVIDED));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
			ApprovalResponseVo approvalResponseVo = submitNonFinancialProposal(apiParams, proposal);
			if (ApprovalConstants.URV_EXISTS.equals(approvalResponseVo.getProposalStatus())) {
				genericResponseWrapper.setGenericResponse(
						responseBuilder.generateResponse(ResponseCodes.NONFINANCIAL_ESTABLISHED_URV));
			}
			genericResponseWrapper.setApprovalResponseNonFinancialVo(approvalResponseVo);
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	public ApprovalResponseVo submitNonFinancialProposal(ApiParams apiParams, ProposalDto proposal) {
		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
		// Get the proposal
		Optional<ProposalDto> sourceProposalDto;
		String sourceProposalStatus = null;
		if (proposal.getNonFinancialFlag() != null && proposal.getNonFinancialFlag()) {
			sourceProposalDto = proposalRepository.findById(proposal.getSourceProposalCode());
			if (sourceProposalDto.isPresent()) {
				if (proposal.getSourceProposalStatusCode() != null) {
					sourceProposalStatus = proposal.getSourceProposalStatusCode().getProposalStatusCode();
				}
				if (sourceProposalStatus != null) {
					ProposalDto sourceProposal = sourceProposalDto.get();
					String tobeProposalStatus = getNonFinancialSubmitStatus(apiParams, proposal, sourceProposal,
							sourceProposalStatus);
					if (ApprovalConstants.UNDER_REVIEW.equals(tobeProposalStatus)) {
						LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.VALIDATE_METHOD)
								.userId(apiParams.getUserId()).message(
										"Please take a decision on Under review version or Make non MLV type change to save this proposal as Approved version."));
					} else if (ApprovalConstants.APPROVED.equals(tobeProposalStatus)
							|| ApprovalConstants.ESTABLISHED.equals(tobeProposalStatus)) {
						approvalResponseVo.setSourceProposalDto(sourceProposal);
						approvalResponseVo.setSubmittedTime(sourceProposal.getProposalSubYear());
						approvalResponseVo.setMaxReportLevel(sourceProposal.getReportLevel());
						approvalResponseVo.setControllerApprovalRequired(sourceProposal.getCntlReqdFlag());
						approvalResponseVo.setControllerApprovalYear(sourceProposal.getCntlApproveYear());
						approvalResponseVo.setProposalStatus(tobeProposalStatus);
					} else if (ApprovalConstants.URV_EXISTS.equals(tobeProposalStatus)) {
						approvalResponseVo.setProposalStatus(tobeProposalStatus);
					}
				}
			}
		}
		return approvalResponseVo;
	}

	private String getNonFinancialSubmitStatus(ApiParams apiParams, ProposalDto proposal, ProposalDto sourceProposal,
			String sourceProposalStatus) {
		String tobeProposalStatus = null;
		if (ApprovalConstants.APPROVED.endsWith(sourceProposalStatus)) {
			tobeProposalStatus = ApprovalConstants.APPROVED;
		} else if (ApprovalConstants.ESTABLISHED.equals(sourceProposalStatus)) {
			boolean isChangeOtherThanMlv = false;
			// NA
			if (isChangeInQfcOption(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in QFC Options"));
				// NA
			} else if (isChangeInXplan(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
						.userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("Change in X-Plan"));
			} else if (isChangeInPaymentType(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in Payment Type"));
				// NA
			} else if (isChangeInCpaLetterMin(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in CPA Letter Min"));
			} else if (isChangeInPaymentRouting(proposal, sourceProposal)) {
				// proposal.getP
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in Payment Routing"));
			} else if (isChangeInTier1Flag(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in Tier1 Flag"));
			} else if (isChangeInSubFins(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log, logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
						.userId(apiParams.getUserId()).country(apiParams.getCountryCd()).message("Change in SubFins"));
			} else if (isChangeInNoOfDemoVehicles(proposal, sourceProposal)) {
				isChangeOtherThanMlv = true;
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in No of Longterm demo vehicles"));
			} else {
				LoggerBuilder.printInfo(log,
						logger -> logger.methodName(ApprovalConstants.NON_FINANCIAL_STATUS)
								.userId(apiParams.getUserId()).country(apiParams.getCountryCd())
								.message("Change in Proposal MLV"));
				// ignore this change
			}

			if (isChangeOtherThanMlv) {
				tobeProposalStatus = ApprovalConstants.APPROVED;
			} else {
				// verify if there are any URV proposal exists if so it
				// can't be submitted at all.
				if (isHigherUnderReviewProposalExists(proposal)) {
					// Can't be submitted
					tobeProposalStatus = ApprovalConstants.URV_EXISTS;
				} else {
					Optional<ProposalDto> mP = getMaxEstUrvProposal(proposal, 0);
					if (mP.isPresent()) {
						if (sourceProposal.getProposalSaKey() == mP.get().getProposalSaKey()) {
							tobeProposalStatus = mP.get().getProposalStatus().getProposalStatusCode();
						} else {
							tobeProposalStatus = ApprovalConstants.APPROVED;
						}
					}
				}
			}
		}

		return tobeProposalStatus;
	}

	private boolean isChangeInPaymentRouting(ProposalDto p, ProposalDto sP) {
		boolean isChangeInPaymentRouting = false;
		if (!populatePaymentRouting(p).equalsIgnoreCase(populatePaymentRouting(sP))) {
			isChangeInPaymentRouting = true;
		}

		return isChangeInPaymentRouting;
	}

	private String populatePaymentRouting(ProposalDto p) {
		String paymentRouting = null;

		Optional<ProposalSummaryViewDto> ps = proposalSummaryViewRepository.findById(p.getProposalSaKey());
		if (ps.isPresent()) {
			if (ApprovalConstants.SDA.equalsIgnoreCase(ps.get().getPaymentRouting())) {
				paymentRouting = "Selling Dealer Assigned";
			} else {
				paymentRouting = ps.get().getPaymentRouting();
			}
		}

		return paymentRouting;

	}

	/**
	 * Returns if the input proposals are having same CPA letter minimum requirement
	 * value or not.
	 *
	 * @param p
	 * @param sP
	 * @return
	 */
	private boolean isChangeInCpaLetterMin(ProposalDto p, ProposalDto sP) {

		boolean isChangeInCpaLetterMin = false;
		if (!(p.getLetterMinQty().equals(sP.getLetterMinQty()))) {
			isChangeInCpaLetterMin = true;
		}
		return isChangeInCpaLetterMin;
	}

	/**
	 * Returns if the input proposals are having same QFC option value or not.
	 *
	 * @param p
	 * @param sP
	 * @return
	 */
	private boolean isChangeInQfcOption(ProposalDto p, ProposalDto sP) {

		boolean isChangeInQfcOption = false;
		if (p.getQfcFlag() != sP.getQfcFlag()) {
			isChangeInQfcOption = true;
		}
		return isChangeInQfcOption;
	}

	/**
	 * Returns if the input proposals are having same X-Plan option value or not.
	 *
	 * @param p
	 * @param sP
	 * @return
	 */
	private boolean isChangeInXplan(ProposalDto p, ProposalDto sP) {
		boolean isChangeInXplan = false;
		if (p.getXplanRequiredFlag() != sP.getXplanRequiredFlag()) {
			isChangeInXplan = true;
		}
		return isChangeInXplan;
	}

	/**
	 * /** Returns if the input proposals are having same No of long term demo
	 * vehicles or not.
	 *
	 * @param p
	 * @param sP
	 * @return
	 */
	private boolean isChangeInNoOfDemoVehicles(ProposalDto p, ProposalDto sP) {
		boolean isChangeInNoOfDemoVehicles = false;
		if (!(p.getLongTermDemoR().equals(sP.getLongTermDemoR()))) {
			isChangeInNoOfDemoVehicles = true;
		}
		return isChangeInNoOfDemoVehicles;
	}

	private boolean isChangeInTier1Flag(ProposalDto p, ProposalDto sP) {

		boolean isChangeInProposalTier1Flag = false;
		List<ProposalVehicleLineIncentiveDto> oList = getVehicleLineIncentiveList(p);
		List<ProposalVehicleLineIncentiveDto> sList = getVehicleLineIncentiveList(sP);

		for (ProposalVehicleLineIncentiveDto o : oList) {
			long pBS = -1L;
			if (o.getBodyStyle() != null) {
				pBS = o.getBodyStyle().getBodyStyleSaKey();
			}
			for (ProposalVehicleLineIncentiveDto s : sList) {
				long sBS = -1L;
				if (s.getBodyStyle() != null) {
					sBS = s.getBodyStyle().getBodyStyleSaKey();
				}
				if (pBS == sBS) {
					// Change in tier1 flag at perUnit level
					if (!(o.getTier1InctvToDlrFlag().equalsIgnoreCase(s.getTier1InctvToDlrFlag()))) {
						isChangeInProposalTier1Flag = true;
					}
					// break internal for loop as match is found
					break;
				}
			}
			// break the outer for loop if any change is identified
			if (isChangeInProposalTier1Flag) {
				break;
			}
		}

		return isChangeInProposalTier1Flag;
	}

	private List<ProposalVehicleLineIncentiveDto> getVehicleLineIncentiveList(ProposalDto proposal) {
		List<ProposalVehicleLineIncentiveDto> vehLineList = null;
		Optional<List<ProposalVehicleLineIncentiveDto>> vehLineList_Final = proposalVehicleLineRepo
				.findByProposal(proposal);
		if (vehLineList_Final.isPresent()) {
			return vehLineList_Final.get();
		}
		return vehLineList;
	}

	private Optional<ProposalDto> getMaxEstUrvProposal(ProposalDto p, int incrementYear) {
		int year = p.getPyDefinition().getProposalYearCode() + incrementYear;
		Long finMasterKey = p.getFinMasterKey().getFinMasterKey();
		return proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(year, finMasterKey);
	}

	private boolean isChangeInPaymentType(ProposalDto p, ProposalDto sP) {
		boolean isChangeInPaymentType = false;
		if (!p.getPaymentType().getPaymentTypeCode().equalsIgnoreCase(sP.getPaymentType().getPaymentTypeCode())) {
			isChangeInPaymentType = true;
		}
		return isChangeInPaymentType;
	}

	private boolean isChangeInSubFins(ProposalDto p, ProposalDto sP) {
		boolean isChangeInSubFins = false;
		List<ProposalSubsidiaryDto> oList = getProposalSubsidiaryList(p);
		List<ProposalSubsidiaryDto> sList = getProposalSubsidiaryList(sP);
		if (oList != null && sList != null) {
			if (oList.isEmpty() && sList.isEmpty()) {
				isChangeInSubFins = false;
			} else {
				// identify added SubFins to the proposal
				for (ProposalSubsidiaryDto o : oList) {
					boolean finPresent = false;
					for (ProposalSubsidiaryDto s : sList) {
						if (o.getProposalSubsidiaryPK().getSubFinMaster().getFinMasterKey() == s
								.getProposalSubsidiaryPK().getSubFinMaster().getFinMasterKey()) {
							finPresent = true;
							// break the inner for loop
							break;
						}
					}
					if (!finPresent) {
						isChangeInSubFins = true;
						// break the outer for loop
						break;
					}
				}
				if (!isChangeInSubFins) {
					// identify removed SubFins from the proposal
					for (ProposalSubsidiaryDto s : sList) {
						boolean finPresent = false;
						for (ProposalSubsidiaryDto o : oList) {
							if (o.getProposalSubsidiaryPK().getSubFinMaster().getFinMasterKey() == s
									.getProposalSubsidiaryPK().getSubFinMaster().getFinMasterKey()) {
								finPresent = true;
								// break the inner for loop
								break;
							}
						}
						if (!finPresent) {
							isChangeInSubFins = true;
							// break the outer for loop
							break;
						}
					}
				}
			}

		} else {
			// one of the list is null so validate the other list size is greater than 0
			if ((oList == null) && (sList != null && !(sList.isEmpty()))) {
				isChangeInSubFins = true;
			}
			if ((sList == null) && (oList != null && !(oList.isEmpty()))) {
				isChangeInSubFins = true;
			}
		}
		return isChangeInSubFins;
	}

	private List<ProposalSubsidiaryDto> getProposalSubsidiaryList(ProposalDto p) {
		List<ProposalSubsidiaryDto> oList = new ArrayList<ProposalSubsidiaryDto>();
		Optional<List<ProposalSubsidiaryDto>> oList_final = proposalSubsidiaryRepository
				.findByProposalKey(p.getProposalSaKey());
		if (oList_final.isPresent()) {
			return oList_final.get();
		}
		return oList;
	}

	private boolean isHigherUnderReviewProposalExists(ProposalDto p) {

		boolean isItURV = false;
		Optional<ProposalDto> maxURVProposal;
		maxURVProposal = proposalRepository.getMaxEstOrUrvOnProposalByProposalYearFinMaster(
				p.getPyDefinition().getProposalYearCode(), p.getFinMasterKey().getFinMasterKey());

		if ((maxURVProposal.isPresent()) && (ApprovalConstants.UNDER_REVIEW
				.equals(maxURVProposal.get().getProposalStatus().getProposalStatusCode()))) {
			isItURV = true;
		}

		return isItURV;
	}

}