package com.ford.fbms.approvalmanagement.transport;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;

/**
 * A class for defining response class.
 *
 * @author NACHUTHA on 3/2/2021.
 */
@Getter
@Setter
@Validated
public class GenericResponse {

  // Ignore this field sending back to caller always
  @JsonIgnore
  private HttpStatus httpStatus;

  // Ignore this field sending back to caller when it is null
  @ApiModelProperty(notes = "Error Message ID", example = "MSG-0100")
  @Pattern(regexp = "\\w*", message = "Invalid errorMsgId")
  @Size(max = 10, message = "Invalid length of errorMsgId")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String msgId;

  // Ignore this field sending back to caller when it is null
  @ApiModelProperty(notes = "Error Message", example = "Invalid app id")
  @Pattern(regexp = "\\w*", message = "Invalid errorMsg")
  @Size(max = 50, message = "Invalid length of errorMsg")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private String msgDesc;

  // Ignore this field sending back to caller when it is null
  @ApiModelProperty(notes = "Time at which error occurred", example = "2020-01-13T20:00:00.000Z",
      required = true)
  //@Pattern(regexp = "^\\d.+Z{24,24}$", message = "Invalid errorTime")
  //@Size(max = 24, message = "Invalid length of errorTime")
  @JsonInclude(JsonInclude.Include.NON_NULL)
  private Date timeStamp;

  /**
   * To generate {@link GenericResponse} for success response.
   */
  public GenericResponse() {
  }

  /**
   * To generate {@link GenericResponse} for success response.
   *
   * @param httpStatus HttpStatus
   */
  public GenericResponse(final HttpStatus httpStatus) {
    this.httpStatus = httpStatus;
  }

  /**
   * To generate {@link GenericResponse} for failure response.
   *
   * @param httpStatus HttpStatus
   * @param msgId      Error message ID
   * @param msgDesc    Error message
   * @param timeStamp  When error happened
   */
  public GenericResponse(
      final HttpStatus httpStatus, final String msgId, final String msgDesc,
      final Date timeStamp) {
    this.httpStatus = httpStatus;
    this.msgId = msgId;
    this.msgDesc = msgDesc;
    this.timeStamp = timeStamp;
  }


}