package com.ford.fbms.approvalmanagement.transport;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProposalSubsidiariesVO implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String accountName;
	private String fin;
	private String city;
	private String state;
	private String stateCode;
	private String enteredDate;
	private String highlightItem;
	private long proposalKey;
    private long subFinKey;
}