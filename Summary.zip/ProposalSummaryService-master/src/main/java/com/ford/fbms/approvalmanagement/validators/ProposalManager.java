package com.ford.fbms.approvalmanagement.validators;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.AccountSalesSummaryDto;
import com.ford.fbms.approvalmanagement.domain.AggregateIncentiveViewDto;
import com.ford.fbms.approvalmanagement.domain.BodyFinancialDto;
import com.ford.fbms.approvalmanagement.domain.FVADataDto;
import com.ford.fbms.approvalmanagement.domain.FinProfileDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;
import com.ford.fbms.approvalmanagement.domain.MultiYearTermViewDto;
import com.ford.fbms.approvalmanagement.domain.NewBodyStyleViewDtO;
import com.ford.fbms.approvalmanagement.domain.PerUnitNewViewDto;
import com.ford.fbms.approvalmanagement.domain.PerUnitOptViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalBodyFinancialViewDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import com.ford.fbms.approvalmanagement.domain.TargetBandDto;
import com.ford.fbms.approvalmanagement.domain.TierVolumeDto;
import com.ford.fbms.approvalmanagement.repository.AccountSalesSummaryRepository;
import com.ford.fbms.approvalmanagement.repository.AggregateIncentiveViewRepository;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.BodyFinancialRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FVADataRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearBonusRepository;
import com.ford.fbms.approvalmanagement.repository.MultiYearTermViewRepository;
import com.ford.fbms.approvalmanagement.repository.NewBodyStyleRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitIncentiveNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitNewViewRepository;
import com.ford.fbms.approvalmanagement.repository.PerUnitOptViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalBodyFinancialViewRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalSummaryViewRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.TargetBandRepository;
import com.ford.fbms.approvalmanagement.repository.TierVolumeRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.FinancialDetailedVO;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ProposalFinancialVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

/**
 * A class to get proposal details.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Service
@Slf4j
public class ProposalManager implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  protected ProposalRepository proposalRepository;
  @Autowired
  protected ProposalBodyFinancialViewRepository proposalBodyFinancialViewRepo;
  @Autowired
  protected TargetBandRepository targetBandRepo;
  @Autowired
  protected PerUnitOptViewRepository perUnitOptViewRepository;
  @Autowired
  protected ApprovalManagementValidator approvalManagementValidator;
  @Autowired
  protected ApprovalManagementCreateValidator approvalManagementCreateValidator;
  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;
  @Autowired
  protected ControllerThresholdRepository controllerThresholdRepository;
  @Autowired
  protected MultiYearBonusRepository multiYearBonusRepository;
  @Autowired
  protected MultiYearTermViewRepository multiYearTermViewRepository;
  @Autowired
  protected AggregateIncentiveViewRepository aggregateIncentiveViewRepository;
  @Autowired
  protected TierVolumeRepository tierVolumeRepository;
  @Autowired
  protected ProposalSummaryViewRepository proposalSummaryViewRepository;
  @Autowired
  protected AccountSalesSummaryRepository accountSalesSummaryRepository;
  @Autowired
  protected BodyFinancialRepository bodyFinancialRepo;
  @Autowired
  protected PerUnitIncentiveNewViewRepository perUnitIncentiveNewViewRepo;
  @Autowired
  protected NewBodyStyleRepository newBodyStyleRepo;
  @Autowired
  protected ReportLevelRepository reportLevelRepo;
  @Autowired
  protected FordPersonRepository fordPersonRepo;
  @Autowired
  protected FVADataRepository fvaDataRepo;
  @Autowired
  protected PerUnitNewViewRepository perUnitNewViewRepo;
  @Autowired
  protected FinProfileRepository finProfileRepo;

  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest, final MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {

    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
        .message("Inside ProposalManager"));
    Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDtoOptional.isEmpty()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
      genericResponseWrapper
          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    } else {
      ProposalDto proposal = proposalDtoOptional.get();
      genericResponseWrapper.setProposalDataDto(proposal);
      List<ProposalFinancialVO> puFinanceList = buildProposalFinancialsEstimate(apiParams, proposal);
      List<FinancialDetailedVO> financialDetailedVOList = this.populateFinancialsForEstimate(apiParams, proposal,
          puFinanceList);
      genericResponseWrapper.setFinancialDetailedVOList(financialDetailedVOList);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }

  /**
   * Returns Estimate Vs Estimate ProposalFinancials
   *
   * @param apiParams
   * @return List
   * @throws Exception
   */
  @LogAround
  public List<ProposalFinancialVO> buildProposalFinancialsEstimate(final ApiParams apiParams, ProposalDto proposal) {

    LoggerBuilder.printInfo(log, logger -> logger.methodName("buildProposalFinancialsEstimate")
        .userId(apiParams.getUserId()).message("inside build proposal financial estimate"));
    // Initialize unique List for present Vehicle Lines
    LinkedHashMap<String, String> presentVehicleLine = new LinkedHashMap<String, String>();
    List<ProposalFinancialVO> fList = new ArrayList<ProposalFinancialVO>();
    fList = getProposalFinancialList(apiParams, proposal, true);
    if (fList != null && !(fList.isEmpty())) {
      for (ProposalFinancialVO o : fList) {
        presentVehicleLine.put(o.getModelYear() + " " + o.getVehicleLineDescription(),
            o.getModelYear() + " " + o.getVehicleLineDescription());
      }
    }
    ProposalDto pvProposal = identifyPriorProposals(proposal);
    if (pvProposal != null) {
      // add the prior version Proposal
      List<ProposalFinancialVO> pvList = getProposalFinancialList(apiParams, pvProposal, false);
      if (fList == null) {
        fList = new ArrayList<ProposalFinancialVO>();
      }
      addPriorVerProposal(fList, pvList);
    }

    Optional<ProposalDto> pyProposal = identifyPriorPYProposals(proposal);
    if (pyProposal.isPresent()) {
      // add the prior year Proposal
      List<ProposalFinancialVO> pyList = getPriorYearProposalFinancialList(pyProposal.get(),apiParams);
      addPriorYearProposal(fList, pyList, pyProposal.get(), proposal);
    }
    
    // now flag the records for present proposal

    for (Map.Entry<String, String> entry : presentVehicleLine.entrySet()) {
      String vlKey = entry.getValue();
      for (ProposalFinancialVO o : fList) {
        String vldesc = o.getModelYear() + " " + o.getVehicleLineDescription();
        if (vlKey.equalsIgnoreCase(vldesc)) {
          o.setPresentVehicleLine(true);
        }
      }
    }
    
    FbmsUtil.sort(fList, "modelYear");
    FbmsUtil.sort(fList, "vehicleLineDescription");

    return fList;
  }

  @LogAround
  protected boolean proposalTierChanged(long propTier, long prevVerTier, long priorYrTier) {
		boolean proposalTierChanged = false;
		long prevTier = prevVerTier != 0L ? prevVerTier : (priorYrTier != 0L ? priorYrTier : 0L);
		if ((propTier > 0L) && (propTier != prevTier)) {
			proposalTierChanged = true;
		}
		return proposalTierChanged;
	}
  
  @LogAround
	protected boolean totalTierChanged(long propTier, long prevVerTier, long priorYrTier) {
		boolean totalTierChanged = false;
		long prevTier = prevVerTier != 0L ? prevVerTier : (priorYrTier != 0L ? priorYrTier : 0L);
		if ((propTier > 0L) && (propTier != prevTier)) {
			totalTierChanged = true;
		}
		return totalTierChanged;
	}
	
  @LogAround
	protected long showProposalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long proposalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getProposalTier() != 0L)) {
					proposalTierFinal = financialVO.getProposalTier();
					break;
			}
		}
		return proposalTierFinal;
	}
  
  @LogAround
	protected long showTotalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long totalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getTotalTier() != 0L)) {
					totalTierFinal = financialVO.getTotalTier();
					break;
			}
		}
		return totalTierFinal;
	}

  @LogAround
	protected long showPriorVerProposalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long priorproposalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getPriorVerProposalTier() != 0L)) {
					priorproposalTierFinal = financialVO.getPriorVerProposalTier();
					break;
			}
		}
		return priorproposalTierFinal;
	}
  
  @LogAround
	protected long showPriorVerTotalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long priortotalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getPriorVerTotalTier() != 0L)) {
					priortotalTierFinal = financialVO.getPriorVerTotalTier();
					break;
			}
		}
		return priortotalTierFinal;
	}
  
  @LogAround
	protected long showPriorYearProposalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long priorYearproposalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getPriorYearProposalTier() != 0L)) {
					priorYearproposalTierFinal = financialVO.getPriorYearProposalTier();
					break;
			}
		}
		return priorYearproposalTierFinal;
	}
  
  @LogAround
	protected long showPriorYearTotalTier(List<FinancialDetailedVO> financialDetaiedList) {
		long priorYearTotalTierFinal = 0L;
		for (FinancialDetailedVO financialVO : financialDetaiedList) {
			if ((financialVO != null)&&(financialVO.getPriorYearTotalTier() != 0L)) {
					priorYearTotalTierFinal = financialVO.getPriorYearTotalTier();
					break;
			}
		}
		return priorYearTotalTierFinal;
	}



@LogAround
public List<ProposalFinancialVO> getProposalFinancialList(final ApiParams apiParams, ProposalDto proposal,
                                                               boolean isPresent) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("buildProposalFinancialsEstimate")
        .userId(apiParams.getUserId()).message("ProposalDto" + proposal.getProposalSaKey()));
    List<ProposalFinancialVO> financialList = new ArrayList<ProposalFinancialVO>();

    // Initialize the List
    List<ProposalFinancialVO> targetList = getTargetFinancialList(proposal, isPresent, !isPresent, false);

    List<PerUnitOptViewDto> perUnitIncentiveViewList = perUnitOptViewRepository
        .findByProposalKey(proposal.getProposalSaKey());

    long agg = getAggregateIncentiv(proposal);
    long manualBonus = getManualBonus(proposal);
    long proposalTier = getProposalTier(proposal, isPresentVMbasedOnActualVolume(apiParams));
    int tTier = getTotalTier(proposal);
    if (tTier == 0) {
      tTier = 1;
    }
    if (perUnitIncentiveViewList != null && !(perUnitIncentiveViewList.isEmpty())) {
      for (PerUnitOptViewDto viewDto : perUnitIncentiveViewList) {
        ProposalFinancialVO perUnit;
        if (isPresent) {
          perUnit = new ProposalFinancialVO(viewDto.getBodyStyleKey(), 0L, 0L);
        } else {
          perUnit = new ProposalFinancialVO(0L, 0L, viewDto.getBodyStyleKey());
        }
        
        perUnit.setPerUnitDescription(viewDto.getBodyStyleCode());
        perUnit.setModelYear(viewDto.getModelYear());
        perUnit.setVehicleLineDescription(viewDto.getVehicleLineDesc());
        perUnit.setVehLineCode(viewDto.getVehicleLineCode());
        if ("Y".equalsIgnoreCase(viewDto.getBodyGroupIndicator())) {
          perUnit.setBodyGroup(true);
        }

        long cPA = 0L;
        if (proposalTier == 1) {
          cPA = viewDto.getTier1Incentive();
        }
        if (proposalTier == 2) {
          cPA = viewDto.getTier2Incentive();
        }
        if (proposalTier == 3) {  
          cPA = viewDto.getTier3Incentive();
        }
        if (proposalTier == 4) {
          cPA = viewDto.getTier4Incentive();
        }
        if (proposalTier == 5) {
          cPA = viewDto.getTier5Incentive();
        }
        if (proposalTier == 6) {
          cPA = viewDto.getTier6Incentive();
        }

        if (isPresent) {
          perUnit.setProposalTier(proposalTier);
          perUnit.setTotalTier(tTier);
          perUnit.setAGG((agg + manualBonus) * (-1));
          perUnit.setCPA(cPA * (-1));
          perUnit.setESP((viewDto.getESPIncentive() / tTier) * (-1));
          perUnit.setOPT(
              Math.round(((viewDto.getMLBIncentive() + viewDto.getOptionIncentive()) /(double) tTier)) * (-1));
          perUnit.setVM((agg + manualBonus + cPA + Math.round(
              (viewDto.getESPIncentive() + viewDto.getMLBIncentive() + viewDto.getOptionIncentive())
                  / (double)tTier))
              * (-1));
          perUnit.setVolume(viewDto.getMlv());
          perUnit.setTier1(viewDto.getTier1Incentive() * (-1));
          perUnit.setTier2(viewDto.getTier2Incentive() * (-1));
          perUnit.setTier3(viewDto.getTier3Incentive() * (-1));
          perUnit.setTier4(viewDto.getTier4Incentive() * (-1));
          perUnit.setTier5(viewDto.getTier5Incentive() * (-1));
          perUnit.setTier6(viewDto.getTier6Incentive() * (-1));
        } else {
          perUnit.setPriorVerProposalTier(proposalTier);
          perUnit.setPriorVerTotalTier(tTier);
          perUnit.setPriorVerAGG((agg + manualBonus) * (-1));
          perUnit.setPriorVerCPA(cPA * (-1));
          perUnit.setPriorVerESP(Math.round((viewDto.getESPIncentive() / (double)tTier)) * (-1));
          perUnit.setPriorVerOPT(
              (Math.round((viewDto.getMLBIncentive() + viewDto.getOptionIncentive()) /(double) tTier)) * (-1));
          perUnit.setPriorVerVM((agg + manualBonus + cPA + Math.round(
              (viewDto.getESPIncentive() + viewDto.getMLBIncentive() + viewDto.getOptionIncentive())
                  / (double)tTier))
              * (-1));
          perUnit.setPriorVerVolume(viewDto.getMlv());
          perUnit.setPriorVerTier1(viewDto.getTier1Incentive() * (-1));
          perUnit.setPriorVerTier2(viewDto.getTier2Incentive() * (-1));
          perUnit.setPriorVerTier3(viewDto.getTier3Incentive() * (-1));
          perUnit.setPriorVerTier4(viewDto.getTier4Incentive() * (-1));
          perUnit.setPriorVerTier5(viewDto.getTier5Incentive() * (-1));
          perUnit.setPriorVerTier6(viewDto.getTier6Incentive() * (-1));
        }

        ProposalFinancialVO tPerUnit = null;
        if (isPresent) {
          tPerUnit = new ProposalFinancialVO(viewDto.getBodyStyleKey(), 0L, 0L);
        } else {
          tPerUnit = new ProposalFinancialVO(0L, 0L, viewDto.getBodyStyleKey());
        }
        if (targetList.contains(tPerUnit)) {
          tPerUnit = targetList.get(targetList.indexOf(tPerUnit));
          if (isPresent) {
            perUnit.setYoyTargetVM(tPerUnit.getYoyTargetVM());
            perUnit.setTier1Target(tPerUnit.getTier1Target());
            perUnit.setTier2Target(tPerUnit.getTier2Target());
            perUnit.setTier3Target(tPerUnit.getTier3Target());
            perUnit.setTier4Target(tPerUnit.getTier4Target());
            perUnit.setTier5Target(tPerUnit.getTier5Target());
            perUnit.setNewTargetVM(tPerUnit.getNewTargetVM());
            perUnit.setEstCC(tPerUnit.getEstCC());
            perUnit.setEstRevenue(tPerUnit.getEstRevenue());
            perUnit.setTargetEstCC(tPerUnit.getTargetEstCC());
            perUnit.setTargetEstRevenue(tPerUnit.getTargetEstRevenue());
          } else {
            perUnit.setPriorVerEstCC(tPerUnit.getPriorVerEstCC());
            perUnit.setPriorVerEstRevenue(tPerUnit.getPriorVerEstRevenue());
          }
        }

        financialList.add(perUnit);
      }
    }
    return financialList;
  }

  @LogAround
  public long getAggregateIncentiv(ProposalDto proposal) {
    long inc = 0L;
    // AggIncentive
    Optional<AggregateIncentiveViewDto> aggregateViewDto = aggregateIncentiveViewRepository
        .findById(proposal.getProposalSaKey());
    if (aggregateViewDto.isPresent()) {
      if (proposal.getProposalMlv().intValue() > 0) {
        inc = (Math.round((double)(aggregateViewDto.get().getIncentive()) / proposal.getProposalMlv().intValue()));
      } else {
        inc = (Math.round((double)aggregateViewDto.get().getIncentive()));
      }
    }
    return inc;
  }

  @LogAround
  private List<ProposalFinancialVO> getTargetFinancialList(ProposalDto proposalDto, boolean fillPresent,
                                                           boolean fillPriorVer, boolean fillPriorYear) {
    int tBand = 0;
    List<ProposalFinancialVO> targetFinancialList = new ArrayList<ProposalFinancialVO>();
    Optional<ProposalDto> priorYearESTProposal = identifyPriorPYProposals(proposalDto);
    List<ProposalBodyFinancialViewDto> proposalBodyFinancialViewList = proposalBodyFinancialViewRepo
        .findProposalBodyFinancials(proposalDto.getProposalSaKey());
    if (fillPresent) {
      tBand = getTargetBandLevel(proposalDto.getProposalSaKey());
    }
    if (proposalBodyFinancialViewList != null && !(proposalBodyFinancialViewList.isEmpty())) {
      for (ProposalBodyFinancialViewDto proposalBodyFinancialViewDto : proposalBodyFinancialViewList) {
        if (proposalBodyFinancialViewDto != null) {
          long bodystyle = proposalBodyFinancialViewDto.getBodyStyle();
          long perUnitKey = fillPresent ? bodystyle : 0L;
          long pyPerUnitKey = fillPriorYear ? bodystyle : 0L;
          long pvPerUnitKey = fillPriorVer ? bodystyle : 0L;
          ProposalFinancialVO targetPerUnit = new ProposalFinancialVO(perUnitKey, pyPerUnitKey, pvPerUnitKey);
          if (fillPresent) {
            targetPerUnit.setYoyTargetVM(proposalBodyFinancialViewDto.getYearOverYearTarget());
            targetPerUnit.setTier1Target(proposalBodyFinancialViewDto.getTier1Target() * (-1));
            targetPerUnit.setTier2Target(proposalBodyFinancialViewDto.getTier2Target() * (-1));
            targetPerUnit.setTier3Target(proposalBodyFinancialViewDto.getTier3Target() * (-1));
            targetPerUnit.setTier4Target(proposalBodyFinancialViewDto.getTier4Target() * (-1));
            targetPerUnit.setTier5Target(proposalBodyFinancialViewDto.getTier5Target() * (-1));

            if (tBand == 1) {
              targetPerUnit.setNewTargetVM(targetPerUnit.getTier1Target());
            }
            if (tBand == 2) {
              targetPerUnit.setNewTargetVM(targetPerUnit.getTier2Target());
            }
            if (tBand == 3) {
              targetPerUnit.setNewTargetVM(targetPerUnit.getTier3Target());
            }
            if (tBand == 4) {
              targetPerUnit.setNewTargetVM(targetPerUnit.getTier4Target());
            }
            if (tBand == 5) {
              targetPerUnit.setNewTargetVM(targetPerUnit.getTier5Target());
            }
            //
            int pyPgmYCode = proposalDto.getPyDefinition().getProposalYearCode() - 1;
            // Added for CM enhancement 2018
            long estCC = 0L;
            long estRevenue = 0L;
            long oldBodyStyleKey = 0L;
            long currentYrCC = 0L;
            long currentYrR = 0L;

            if (null != proposalBodyFinancialViewDto.getCurrentYrContributionCost()) {
              currentYrCC = proposalBodyFinancialViewDto.getCurrentYrContributionCost();
            } else {
              currentYrCC = 0;
            }
            if (null != proposalBodyFinancialViewDto.getCurrentYrRevenue()) {
              currentYrR = proposalBodyFinancialViewDto.getCurrentYrRevenue();
            } else {
              currentYrR = 0;
            }

            if (priorYearESTProposal.isPresent()) {
              NewBodyStyleViewDtO newBodyStyleDto = newBodyStyleRepo
                  .findNewBodystyleByOldBodyStyle(bodystyle);
              if (newBodyStyleDto != null) {
                oldBodyStyleKey = newBodyStyleDto.getNewBodyStylePK().getOldBodyStyle();
              }
            }
            List<FVADataDto> fvadatadtoList = fvaDataRepo.findFVADataByFinBdyStylePropYr(
                proposalDto.getFinMasterKey().getFinMasterKey(), oldBodyStyleKey, pyPgmYCode);
            if (fvadatadtoList != null && !(fvadatadtoList.isEmpty())) {
              for (FVADataDto fvadatadto : fvadatadtoList) {
                if (fvadatadto.getAverageContributionCost() != 0) {
                  estCC = fvadatadto.getAverageContributionCost() + currentYrCC;
                  estRevenue = fvadatadto.getAverageRevenue() + currentYrR;
                }
              }
            } else {
              estCC = proposalBodyFinancialViewDto.getContributionCost() + currentYrCC;
              estRevenue = proposalBodyFinancialViewDto.getRevenue() + currentYrR;
            }
            targetPerUnit.setEstCC((estCC) * (-1));
            targetPerUnit.setEstRevenue(estRevenue);
            targetPerUnit.setTargetEstCC(estCC * (-1));
            targetPerUnit.setTargetEstRevenue(estRevenue);
            // Added for CM enhancement 2018
          }

          if (fillPriorVer) {
            targetPerUnit.setPriorVerEstCC(proposalBodyFinancialViewDto.getContributionCost() * (-1));
            targetPerUnit.setPriorVerEstRevenue(proposalBodyFinancialViewDto.getRevenue());
          }

          if (fillPriorYear) {
            targetPerUnit.setPriorYearEstCC(proposalBodyFinancialViewDto.getContributionCost() * (-1));
            targetPerUnit.setPriorYearEstRevenue(proposalBodyFinancialViewDto.getRevenue());
          }
          targetFinancialList.add(targetPerUnit);
        }
      }
    }
    return targetFinancialList;
  }

  @LogAround
public int getTargetBandLevel(Long proposal) {
    int bandLevel = -1;
    int totalVolume = -1;
    ProposalDto proposal1 = this.proposalRepository.findById(proposal).get();
    totalVolume = proposal1.getProposalMlv().intValue();

    TargetBandDto presentTargetBand = getTargetBand(proposal1);
    if (presentTargetBand != null) {
      if (presentTargetBand.getBand1R().intValue() <= totalVolume
          && totalVolume < presentTargetBand.getBand2R().intValue()) {
        bandLevel = 1;
      } else if (presentTargetBand.getBand2R().intValue() <= totalVolume
          && totalVolume < presentTargetBand.getBand3R().intValue()) {
        bandLevel = 2;
      } else if (presentTargetBand.getBand3R().intValue() <= totalVolume
          && totalVolume < presentTargetBand.getBand4R().intValue()) {
        bandLevel = 3;
      } else if (presentTargetBand.getBand4R().intValue() <= totalVolume
          && totalVolume < presentTargetBand.getBand5R().intValue()) {
        bandLevel = 4;
      } else if (presentTargetBand.getBand5R().intValue() <= totalVolume) {
        bandLevel = 5;
      }
    }
    return bandLevel;
  }

  @LogAround
  private TargetBandDto getTargetBand(ProposalDto proposal) {
    Date eDate;

    String segment = proposal.getFinMasterKey().getSegment().getSegmentCode();
    String status = proposal.getProposalStatus().getProposalStatusCode();
    if (ApprovalConstants.NEW.equalsIgnoreCase(status) || ApprovalConstants.REVISED.equalsIgnoreCase(status)
        || ApprovalConstants.SUBMITTED.equalsIgnoreCase(status)) {
      eDate = new Date();
    } else {
      eDate = proposal.getFordApproveYear();
    }
    return targetBandRepo.findTargetBandBySegEffDt(segment, eDate);
  }

  @LogAround
public Optional<ProposalDto> identifyPriorPYProposals(ProposalDto proposalDto) {
    return (proposalRepository.getMaxApvOrEstOrUrvOnProposalByProposalYearAndFinMaster(
        (long)proposalDto.getPyDefinition().getProposalYearCode() - 1,
        proposalDto.getFinMasterKey().getFinMasterKey()));
  }

  /**
   * Builds the ProposalFinancials based EstVsEst, ActVsAct, ActVsFct
   */
  @LogAround
  public List<FinancialDetailedVO> populateFinancialsForEstimate(final ApiParams apiParams, ProposalDto proposal,
                                                                 List<ProposalFinancialVO> puFinanceList) {
    // Initialize the form proposalFinancial list
    List<FinancialDetailedVO> financialDetaiedList = new ArrayList<FinancialDetailedVO>();

    FinancialDetailedVO v = new FinancialDetailedVO();
    FinancialDetailedVO t = new FinancialDetailedVO();
    String lastDescription = " ";
    Long lastModelYear = 0L;
    String lastVehLineCode = "";
    boolean isPresentVL = false;
    int PY = proposal.getPyDefinition().getProposalYearCode();
    if (puFinanceList != null && !(puFinanceList.isEmpty())) {
      for (int i = 0; i < puFinanceList.size(); i++) {
        ProposalFinancialVO f = puFinanceList.get(i);
        updateFinancials(t, f, PY, true, false, false);

        FinancialDetailedVO fdVO = getFinancials(FinancialDetailedVO.rowType.VehicleLine, f, PY, true, false,
            false);

        financialDetaiedList.add(fdVO);

        if (i == 0) {
          lastDescription = f.getVehicleLineDescription();
          lastModelYear = (long) f.getModelYear();
          isPresentVL = f.isPresentVehicleLine();
          lastVehLineCode=f.getVehLineCode();
          
        }
        if (f.getVehicleLineDescription().equals(lastDescription) && f.getModelYear() == lastModelYear) {
          // add this financial rec to vldata as vehicleline and model
          // year are same
          updateFinancials(v, f, PY, true, false, false);

        } else {
          FinancialDetailedVO fdVO1 = getAverageFinancials(v);
          // insert prior vl details as

          fdVO1.setModelYear(lastModelYear);
          fdVO1.setVehicleLine(lastDescription);
          fdVO1.setBodyStyle(" ");
          fdVO1.setRecType(FinancialDetailedVO.rowType.LineTotal);
          fdVO1.setPresentProposal(isPresentVL);
          fdVO1.setVehicleLineCode(lastVehLineCode);
          fdVO1.setVehDesc(lastDescription+"!"+lastModelYear);

          financialDetaiedList.add(fdVO1);
          // start next VL
          v = new FinancialDetailedVO();
          updateFinancials(v, f, PY, true, false, false);
        }
        if (i == puFinanceList.size() - 1) {
          // last record...so insert the VL record
          FinancialDetailedVO fdVO2 = getAverageFinancials(v);
          fdVO2.setVehicleLine(f.getVehicleLineDescription());
          fdVO2.setModelYear((long) f.getModelYear());
          fdVO2.setBodyStyle(" ");
          fdVO2.setRecType(FinancialDetailedVO.rowType.LineTotal);
          fdVO2.setPresentProposal(f.isPresentVehicleLine());
          fdVO2.setVehicleLineCode(f.getVehLineCode());
          fdVO2.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear());
          financialDetaiedList.add(fdVO2);
        }

        lastDescription = f.getVehicleLineDescription();
        lastModelYear = (long) f.getModelYear();
        isPresentVL = f.isPresentVehicleLine();
        lastVehLineCode = f.getVehLineCode();
      }
    }
    long totalTier = showTotalTier(financialDetaiedList);
    t.setTotalTier(totalTier);
    long propTier=showProposalTier(financialDetaiedList);
    t.setProposalTier(propTier);
    long prevVerPropTier = showPriorVerProposalTier(financialDetaiedList);
    t.setPriorVerProposalTier(prevVerPropTier);
    long prevVerTotalTier = showPriorVerTotalTier(financialDetaiedList);
    t.setPriorVerTotalTier(prevVerTotalTier);
    long priorYearproposalTier = showPriorYearProposalTier(financialDetaiedList);
    t.setPriorYearProposalTier(priorYearproposalTier);
    long priorYeartotalTier = showPriorYearTotalTier(financialDetaiedList);
    t.setPriorYearTotalTier(priorYeartotalTier);
    t.setIncludedInPriorProposal(showIncludedInPriorSection(financialDetaiedList));
    boolean proposalTierChangedflag=proposalTierChanged(propTier,prevVerPropTier,priorYearproposalTier);
    t.setProposalTierChanged(proposalTierChangedflag);
    boolean totalTierChanged = totalTierChanged(totalTier,prevVerTotalTier,priorYeartotalTier);
    t.setTotalTierChanged(totalTierChanged);
    t = getAverageFinancials(t);
    if (t.getPresentVol() > 0) {
      t.setPresentProposal(true);
    }
    FbmsUtil.sort(financialDetaiedList, "recType");
    FbmsUtil.sort(financialDetaiedList, "vehDesc");
    
    t.setRecType(FinancialDetailedVO.rowType.GrandTotal);
    financialDetaiedList.add(t);

    return financialDetaiedList;

  }

  @LogAround
  public long getManualBonus(ProposalDto proposal) {
	  MultiYearTermViewDto multiYearTermDto = getMultiYearTerm(proposal);
    if (multiYearTermDto == null) {
      return 0;
    }
    long req =  multiYearTermDto.getRequiredVolume()!=null ? multiYearTermDto.getRequiredVolume() :0;
    if (req == 0) {
      req = 1;
    }
    return (multiYearTermDto.getManualBonusAmount()!= null ? multiYearTermDto.getManualBonusAmount()/ req :0);
  }

  @LogAround
  public MultiYearTermViewDto getMultiYearTerm(ProposalDto proposal) {
    Optional<MultiYearTermViewDto> multiYearTermDto = multiYearTermViewRepository.findById(proposal.getProposalSaKey());
    if (multiYearTermDto.isPresent()) {
      if (multiYearTermDto.get().getStartYr() == 0) {
        return null;
      }
      if (multiYearTermDto.get().getEndYr() !=null && multiYearTermDto.get().getStartYr() > multiYearTermDto.get().getEndYr()) {
        return null;
      }
    }
    return (multiYearTermDto.isPresent() ? multiYearTermDto.get() : null);
  }

  @LogAround
public int getTotalTier(ProposalDto proposalDto) {
    int tTier = 0;
    Optional<ProposalSummaryViewDto> ps = proposalSummaryViewRepository.findById(proposalDto.getProposalSaKey());
    if (ps.isPresent()) {
      tTier = ps.get().getTotalTiers();
    }
    return tTier;
  }

  @LogAround
public boolean isPresentVMbasedOnActualVolume(ApiParams apiParams) {
    boolean result = false;
    if (ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = false;
    }
    if (ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = false;
    }
    if (ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE.equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = true;
    }
    if (ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = false;
    }
    if (ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = false;
    }
    if (ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE
        .equalsIgnoreCase(apiParams.getVolumeFinancialDataSource())) {
      result = false;
    }
    return result;
  }
  
  @LogAround
public boolean isPriorYearVMbasedOnActualVolume(ApiParams apiParams){
		
		boolean result= false;

		//though not need to include conditions for "false" case but for understanding 
		//all possible conditions including those if statements
		if(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_ACT_MLV_VM_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= false;
		}
		
		if(ApprovalConstants.PRIOR_ACT_CURR_ACT_MLV_VM_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= true;
		}
		if(ApprovalConstants.PRIOR_ACT_CURR_ACT_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= true;
		}
		if(ApprovalConstants.PRIOR_ACT_MLV_VM_CURR_FCT_MLV_VM_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= false;
		}
		if(ApprovalConstants.PRIOR_ACT_CURR_FCT_MLV_VM_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= true;
		}
		if(ApprovalConstants.PRIOR_EST_MLV_VM_CURR_EST_MLV_VM_CODE.equalsIgnoreCase(apiParams
				.getVolumeFinancialDataSource())){
			result= false;
		}
		return result;
		
	}	

  @LogAround
  private void updateFinancials(FinancialDetailedVO o, ProposalFinancialVO f, int PY, boolean isEstVsEst,
                               boolean isActVsFct, boolean isActVsAct) {
    if (o == null || f == null) {
      return;
    }
    o.setPY(PY);
    if (f.getPerUnit() > 0L) {
      o.setPresentKey(f.getPerUnit());
    }
    if (f.getPriorVerPerUnit() > 0L) {
      o.setPrevVerKey(f.getPriorVerPerUnit());
    }
    if (f.getPriorYearPerUnit() > 0L) {
      o.setPriorKey(f.getPriorYearPerUnit());
    }
    o.setModelYear((long) f.getModelYear());
    o.setVehicleLine(f.getVehicleLineDescription());
    o.setBodyStyle(f.getPerUnitDescription());
    o.setPresentProposal(f.isPresentVehicleLine());

    double pV = f.getVolume();
    double pvV = f.getPriorVerVolume();
    double pyV = f.getPriorYearVolume();
    if (f.getPerUnit() != 0L) {
      pV = pV + 0.000001;
    }
    if (f.getPriorVerPerUnit() != 0L) {
      pvV = pvV + 0.000001;
    }
    if (f.getPriorYearPerUnit() != 0L) {
      pyV = pyV + 0.000001;
    }
    // set volume
    o.setPresentVol(o.getPresentVol() + pV);
    o.setPriorVol(o.getPriorVol() + pyV);
    o.setPrevVerVol(o.getPrevVerVol() + pvV);
    if (o.getRecType() != null) {
      o.setPresentVM(f.getPerUnit() > 0L ? (o.getPresentVM() + (pV * f.getVM())) : 0L);
    } else {
      o.setPresentVM(o.getPresentVM() + (pV * f.getVM()));
    }
    o.setPriorPYVM(o.getPriorPYVM() + (pyV * f.getPriorYearVM()));
    if (o.getRecType() != null) {
      o.setPrevVerVM(f.getPriorVerPerUnit() > 0L ? (o.getPrevVerVM() + (pvV * f.getPriorVerVM())) : 0L);
    } else {
      o.setPrevVerVM(o.getPrevVerVM() + (pvV * f.getPriorVerVM()));
    }
    o.setTargetVM(o.getTargetVM() + (pV * f.getTargetVM()));

    // setIncentives
    o.setPresentAGG(o.getPresentAGG() + (pV * f.getAGG()));
    o.setPresentESP(o.getPresentESP() + (pV * f.getESP()));
    o.setPresentOPT(o.getPresentOPT() + (pV * f.getOPT()));
    o.setPresentCPA(o.getPresentCPA() + (pV * f.getCPA()));

    if (isEstVsEst) {
      updateEstVsEst(o, f, true);
    }

    // now do the B/(W) calculation
    updateBW(o);

  }

  @LogAround
public ProposalDto identifyPriorProposals(ProposalDto p) {
    return proposalRepository.proposalByFinMasterProposalYearVersion(p.getFinMasterKey().getFinMasterKey(),
        p.getPyDefinition().getProposalYearCode(), p.getVersionNumber() - 1);
  }

  @LogAround
  private FinancialDetailedVO getFinancials(FinancialDetailedVO.rowType rowType, ProposalFinancialVO f, int PY,
                                           boolean isEstVsEst, boolean isActVsFct, boolean isActVsAct) {
    FinancialDetailedVO o = new FinancialDetailedVO();
    o.setPY(PY);
    o.setPresentKey(f.getPerUnit());
    o.setPrevVerKey(f.getPriorVerPerUnit());
    o.setPriorKey(f.getPriorYearPerUnit());
    o.setModelYear((long) f.getModelYear());
    o.setVehicleLine(f.getVehicleLineDescription());
    o.setVehicleLineCode(f.getVehLineCode());
    o.setBodyStyle(f.getPerUnitDescription());
    o.setRecType(rowType);
    o.setPresentProposal(f.isPresentVehicleLine());
    o.setVehDesc(f.getVehicleLineDescription()+"!"+f.getModelYear()+"!"+f.getPerUnitDescription());
    // set Volume
    o.setPresentVol(f.getVolume());
    o.setPriorVol(f.getPriorYearVolume());
    o.setPrevVerVol(f.getPriorVerVolume());
    o.setProposalTier(f.getProposalTier());
    o.setPriorVerProposalTier(f.getPriorVerProposalTier());
    o.setPriorYearProposalTier(f.getPriorYearProposalTier());
    o.setTotalTier(f.getTotalTier());
    o.setPriorVerTotalTier(f.getPriorVerTotalTier());
    o.setPriorYearTotalTier(f.getPriorYearTotalTier());
    // set VM

    o.setPresentVM(f.getVM());
    o.setPriorPYVM(f.getPriorYearVM());
    o.setPrevVerVM(f.getPriorVerVM());
    o.setYoyTarget(f.getYoyTargetVM());

    // set Target VM
    o.setTargetVM(f.getTargetVM());

    // set Matrix Target VM from Maintain finance data screen
    o.setMatrixTargetVM(f.getNewTargetVM());
    // setIncentives
    o.setPresentAGG(f.getAGG());
    o.setPresentESP(f.getESP());
    o.setPresentOPT(f.getOPT());
    o.setPresentCPA(f.getCPA());
    

    updateEstVsEst(o, f, false);
    updateBW(o);
    return o;
  }

  @LogAround
	protected void updateBW(FinancialDetailedVO o) {
		o.setBwVol((o.getPresentVol() - o.getPriorVol()));
		o.setBwPrevVerVol((o.getPresentVol() - o.getPrevVerVol()));
		o.setBwPriorPYVM((o.getPresentVM() - o.getPriorPYVM()));
		o.setBwPrevVerVM((o.getPresentVM() - o.getPrevVerVM()));
		o.setBwTargetVM((o.getPresentVM() - o.getTargetVM()));
		o.setBwPriorPYNR(o.getPresentNR() - o.getPriorPYNR());
		o.setBwTargetNR(o.getPresentNR() - o.getTargetNR());
		o.setBwPriorPYCM(o.getPresentCM() - o.getPriorPYCM());
		o.setBwTargetCM(o.getPresentCM() - o.getTargetCM());
	}

  @LogAround
  private void updateEstVsEst(FinancialDetailedVO o, ProposalFinancialVO f, boolean isUpdate) {
    if (o == null || f == null) {
      return;
    }
    double pV = 1;
    double pvV = 1;
    double pyV = 1;
    if (isUpdate) {
      pV = f.getVolume();
      pvV = f.getPriorVerVolume();
      pyV = f.getPriorYearVolume();
    }
    if (f.getPerUnit() != 0L) {
      pV = pV + 0.000001;
    }
    if (f.getPriorVerPerUnit() != 0L) {
      pvV = pvV + 0.000001;
    }
    if (f.getPriorYearPerUnit() != 0L) {
      pyV = pyV + 0.000001;
    }
    // set CC,Rev,NR and CM for present
    if (o.getRecType() != null) {
      o.setPresentCC(f.getPerUnit() > 0L ? (o.getPresentCC() + (pV * f.getEstCC())) : 0L);
    } else {
      o.setPresentCC(o.getPresentCC() + (pV * f.getEstCC()));
    }
    if (o.getRecType() != null) {
      o.setPresentRevenue(
          f.getPerUnit() > 0L ? (o.getPresentRevenue() + (pV * f.getEstRevenue())) : 0L);
    } else {
      o.setPresentRevenue(o.getPresentRevenue() + (pV * f.getEstRevenue()));
    }
    if (o.getRecType() != null) {
      o.setPresentNR(
          f.getPerUnit() > 0L ? (o.getPresentNR() + (pV * (f.getEstRevenue() + f.getVM()))) : 0L);
    } else {
      o.setPresentNR(o.getPresentNR() + (pV * (f.getEstRevenue() + f.getVM())));
    }
    if (o.getRecType() != null) {
      o.setPresentCM(f.getPerUnit() > 0L
          ? (o.getPresentCM() + (pV * (f.getEstRevenue() + f.getEstCC() + f.getVM())))
          : 0L);
    } else {

      o.setPresentCM(o.getPresentCM() + (pV * (f.getEstRevenue() + f.getEstCC() + f.getVM())));
    }


    if (o.getRecType() != null) {
      o.setPriorPYCC(
          f.getPriorYearPerUnit() > 0L ? (o.getPriorPYCC() + (pyV * f.getPriorYearEstCC())) : 0L);
    } else {
      o.setPriorPYCC(o.getPriorPYCC() + (pyV * f.getPriorYearEstCC()));
    }
    if (o.getRecType() != null) {
      o.setPriorPYRevenue(f.getPriorYearPerUnit() > 0L
          ? (o.getPriorPYRevenue() + (pyV * f.getPriorYearEstRevenue()))
          : 0L);
    } else {
      o.setPriorPYRevenue(o.getPriorPYRevenue() + (pyV * f.getPriorYearEstRevenue()));
    }
    if (o.getRecType() != null) {
      o.setPriorPYNR(f.getPriorYearPerUnit() > 0L
          ? (o.getPriorPYNR() + (pyV * (f.getPriorYearEstRevenue() + f.getPriorYearVM())))
          : 0L);
    } else {
      o.setPriorPYNR(o.getPriorPYNR() + (pyV * (f.getPriorYearEstRevenue() + f.getPriorYearVM())));
    }
    if (o.getRecType() != null) {
      o.setPriorPYCM(
          f.getPriorYearPerUnit() > 0L
              ? (o.getPriorPYCM()
              + (pyV * (f.getPriorYearEstRevenue() + f.getPriorYearEstCC() + f.getPriorYearVM())))
              : 0L);
    } else {
      o.setPriorPYCM(o.getPriorPYCM()
          + (pyV * (f.getPriorYearEstRevenue() + f.getPriorYearEstCC() + f.getPriorYearVM())));
    }
    if (o.getRecType() != null) {
      o.setPrevVerCC(
          f.getPriorVerPerUnit() > 0L ? (o.getPrevVerCC() + (pvV * f.getPriorVerEstCC())) : 0L);
    } else {
      o.setPrevVerCC(o.getPrevVerCC() + (pvV * f.getPriorVerEstCC()));
    }
    if (o.getRecType() != null) {
      o.setPrevVerRevenue(
          f.getPriorVerPerUnit() > 0L ? (o.getPrevVerRevenue() + (pvV * f.getPriorVerEstRevenue()))
              : 0L);
    } else {
      o.setPrevVerRevenue(o.getPrevVerRevenue() + (pvV * f.getPriorVerEstRevenue()));
    }
    if (o.getRecType() != null) {
      o.setPrevVerNR(f.getPriorVerPerUnit() > 0L
          ? (o.getPrevVerNR() + (pvV * (f.getPriorVerEstRevenue() + f.getPriorVerVM())))
          : 0L);
    } else {
      o.setPrevVerNR(o.getPrevVerNR() + (pvV * (f.getPriorVerEstRevenue() + f.getPriorVerVM())));
    }
    if (o.getRecType() != null) {
      o.setPrevVerCM(
          f.getPriorVerPerUnit() > 0L
              ? (o.getPrevVerCM()
              + (pvV * (f.getPriorVerEstRevenue() + f.getPriorVerVM() + f.getPriorVerEstCC())))
              : 0L);
    } else {
      o.setPrevVerCM(
          o.getPrevVerCM() + (pvV * (f.getPriorVerEstRevenue() + f.getPriorVerVM() + f.getPriorVerEstCC())));
    }
    o.setTargetCC(o.getTargetCC() + (pV * f.getTargetEstCC()));
    o.setTargetRevenue(o.getTargetRevenue() + (pV * f.getTargetEstRevenue()));
    o.setTargetNR(o.getTargetNR() + (pV * (f.getTargetEstRevenue() + f.getTargetVM())));
    o.setTargetCM(o.getTargetCM() + (pV * (f.getTargetEstRevenue() + f.getTargetVM() + f.getTargetEstCC())));
  }

  @LogAround
public FinancialDetailedVO getAverageFinancials(FinancialDetailedVO o) {
    o.setVehicleLine(" ");
    o.setBodyStyle(" ");
    if (o.getPresentVol() > 0) {
      o.setPresentVM(o.getPresentVM() / o.getPresentVol());
      o.setPresentCC((o.getPresentCC() / o.getPresentVol()));
      o.setPresentRevenue((o.getPresentRevenue() / o.getPresentVol()));
      o.setPresentNR((o.getPresentNR() / o.getPresentVol()));
      o.setPresentCM((o.getPresentCM() / o.getPresentVol()));
      o.setTargetVM((o.getTargetVM() / o.getPresentVol()));
      o.setTargetCC((o.getTargetCC() / o.getPresentVol()));
      o.setTargetRevenue((o.getTargetRevenue() / o.getPresentVol()));
      o.setTargetNR((o.getTargetNR() / o.getPresentVol()));
      o.setTargetCM((o.getTargetCM() / o.getPresentVol()));
      // setIncentives
      o.setPresentAGG((o.getPresentAGG() / o.getPresentVol()));
      o.setPresentESP((o.getPresentESP() / o.getPresentVol()));
      o.setPresentOPT((o.getPresentOPT() / o.getPresentVol()));
      o.setPresentCPA((o.getPresentCPA() / o.getPresentVol()));
    }
    if (o.getPriorVol() > 0) {
      o.setPriorPYVM(o.getPriorPYVM() / o.getPriorVol());
      o.setPriorPYCC((o.getPriorPYCC() / o.getPriorVol()));
      o.setPriorPYRevenue((o.getPriorPYRevenue() / o.getPriorVol()));
      o.setPriorPYNR((o.getPriorPYNR() / o.getPriorVol()));
      o.setPriorPYCM((o.getPriorPYCM() / o.getPriorVol()));
    }
    if (o.getPrevVerVol() > 0) {
      o.setPrevVerVM(o.getPrevVerVM() / o.getPrevVerVol());
      o.setPrevVerCC(o.getPrevVerCC() / o.getPrevVerVol());
      o.setPrevVerRevenue(o.getPrevVerRevenue() / o.getPrevVerVol());
      o.setPrevVerNR(o.getPrevVerNR() / o.getPrevVerVol());
      o.setPrevVerCM(o.getPrevVerCM() / o.getPrevVerVol());
    }
    updateBW(o);
    return o;
  }

  @LogAround
  protected void addPriorVerProposal(List<ProposalFinancialVO> fList, List<ProposalFinancialVO> pvList) {
    if (pvList == null || pvList.isEmpty()) {
      return;
    }
    for (ProposalFinancialVO o : pvList) {
      ProposalFinancialVO pv = new ProposalFinancialVO(o.getPriorVerPerUnit(), 0L, 0L);
      boolean foundInList = false;
      if (fList != null && fList.contains(pv)) {
        foundInList = true;
        pv = fList.get(fList.indexOf(pv));
        pv.setPriorVerPerUnit(o.getPriorVerPerUnit());
      } else {
        pv = new ProposalFinancialVO(0L, 0L, o.getPriorVerPerUnit());
        pv.setPerUnitDescription(o.getPerUnitDescription());
        pv.setModelYear(o.getModelYear());
        pv.setVehicleLineDescription(o.getVehicleLineDescription());
        pv.setVehLineCode(o.getVehLineCode());
      }
      pv.setPriorVerVM(o.getPriorVerVM());
      pv.setPriorVerProposalTier(o.getPriorVerProposalTier());
      pv.setPriorVerTotalTier(o.getPriorVerTotalTier());
      pv.setPriorVerAGG(o.getPriorVerAGG());
      pv.setPriorVerESP(o.getPriorVerESP());
      pv.setPriorVerOPT(o.getPriorVerOPT());
      pv.setPriorVerCPA(o.getPriorVerCPA());
      pv.setPriorVerTier1(o.getPriorVerTier1());
      pv.setPriorVerTier2(o.getPriorVerTier2());
      pv.setPriorVerTier3(o.getPriorVerTier3());
      pv.setPriorVerTier4(o.getPriorVerTier4());
      pv.setPriorVerTier5(o.getPriorVerTier5());
      pv.setPriorVerTier6(o.getPriorVerTier6());
      pv.setPriorVerVolume(o.getPriorVerVolume());
      pv.setPriorVerEstCC(o.getPriorVerEstCC());
      pv.setPriorVerEstRevenue(o.getPriorVerEstRevenue());
      pv.setPriorVerActCC(o.getPriorVerActCC());
      pv.setPriorVerActRevenue(o.getPriorVerActRevenue());

      if (!foundInList && fList != null) {
        fList.add(pv);
      }
    }
  }

  @LogAround
  protected void addPriorYearProposal(List<ProposalFinancialVO> fList, List<ProposalFinancialVO> pyList,
                                      ProposalDto priorProposal, ProposalDto proposal) {
    if (pyList == null || pyList.isEmpty()) {
      return;
    }
    for (ProposalFinancialVO o : pyList) {
      ProposalFinancialVO py = null;
      boolean foundInList = false;

      if (o.getPerUnit() > 0L) {
        py = new ProposalFinancialVO(o.getPerUnit(), 0L, 0L);
        if (fList != null && fList.contains(py)) {
          foundInList = true;
        }
        if (!foundInList) {
          py = new ProposalFinancialVO(o.getPerUnit(), 0L, o.getPerUnit());
          if (fList != null && fList.contains(py)) {
            foundInList = true;
          }
        }
        if (!foundInList) {
          py = new ProposalFinancialVO(0L, 0L, o.getPerUnit());
          if (fList != null && fList.contains(py)) {
            foundInList = true;
          }
        }

        if (foundInList && fList != null) {
          py = fList.get(fList.indexOf(py));
          py.setPriorYearPerUnit(o.getPerUnit());
        } else {
          // insert
          py = new ProposalFinancialVO(0L, o.getPerUnit(), 0L);
          py.setPerUnitDescription(o.getPerUnitDescription());
          py.setModelYear(o.getModelYear());
          py.setVehicleLineDescription(o.getVehicleLineDescription());
          py.setVehLineCode(o.getVehLineCode());
        }
      } else {
        // insert
        py = new ProposalFinancialVO(0L, o.getPriorYearPerUnit(), 0L);
        py.setPerUnitDescription(o.getPerUnitDescription());
        py.setModelYear(o.getModelYear());
        py.setVehicleLineDescription(o.getVehicleLineDescription());
        py.setVehLineCode(o.getVehLineCode());
      }

      py.setPriorYearVolume(o.getPriorYearVolume());
      py.setPriorYearVM(o.getPriorYearVM());
      py.setPriorYearAGG(o.getPriorYearAGG());
      py.setPriorYearESP(o.getPriorYearESP());
      py.setPriorYearOPT(o.getPriorYearOPT());
      py.setPriorYearCPA(o.getPriorYearCPA());
      py.setPriorYearTier1(o.getPriorYearTier1());
      py.setPriorYearTier2(o.getPriorYearTier2());
      py.setPriorYearTier3(o.getPriorYearTier3());
      py.setPriorYearTier4(o.getPriorYearTier4());
      py.setPriorYearTier5(o.getPriorYearTier5());
      py.setPriorYearTier6(o.getPriorYearTier6());
      py.setPriorYearVM(o.getPriorYearVM());
      py.setPriorYearProposalTier(o.getPriorYearProposalTier());
      py.setPriorYearEstCC(o.getPriorYearEstCC());
      py.setPriorYearEstRevenue(o.getPriorYearEstRevenue());
      py.setPriorYearActCC(o.getPriorYearActCC());
      py.setPriorYearActRevenue(o.getPriorYearActRevenue());

      if (!foundInList && fList != null) {
        // at this point there is no present Estimate CC/Rev info
        // get that info before adding the perUnit to the list

        Optional<BodyFinancialDto> bf = getBodyFinancial(py.getPriorYearPerUnit(), proposal);
        if (bf.isPresent()) {
          py.setEstCC(bf.get().getContributionCostR().longValue() * (-1));
          py.setEstRevenue(bf.get().getRevenueR().intValue());
        }
        fList.add(py);

      }
    }

  }

  @LogAround
  private Optional<BodyFinancialDto> getBodyFinancial(Long bodyStyleSaKey, ProposalDto proposal) {
    Date eDate = null;
    Optional<FinProfileDto> finProfile = finProfileRepo
        .findById(proposal.getFinMasterKey().getFinMasterKey());
    String accountClass = "NONE";
    accountClass = finProfile.isPresent() ? finProfile.get().getSpecialFinClassification().getCode() : "NONE";
    String segment = proposal.getFinMasterKey().getSegment().getSegmentCode();
    String status = proposal.getProposalStatus().getProposalStatusCode();
    if (ApprovalConstants.NEW.equalsIgnoreCase(status) || ApprovalConstants.REVISED.equalsIgnoreCase(status)
        || ApprovalConstants.SUBMITTED.equalsIgnoreCase(status)) {
      eDate = new Date();
    } else {
      eDate = proposal.getFordApproveYear();
    }

    return bodyFinancialRepo
        .findBodyFinancialByBodyStyleSegmentMaxEffectiveDate(bodyStyleSaKey, segment, eDate, accountClass);
  }

  @LogAround
public int getProposalTier(ProposalDto proposalDto, boolean isBasedOnActualVolume) {
    int pTier = 0;

    if (!isBasedOnActualVolume) {
      // request is for proposalTier based on proposal MLV
      return getProposalTier(proposalDto);
    }
    // request is for proposalTier based on actual sales volume
    int actualSales = populatePresentSalesVolume(proposalDto);
    List<TierVolumeDto> tierVolumeList = getTierVolumeList(proposalDto);
    if (tierVolumeList != null && !(tierVolumeList.isEmpty())) {
      for (TierVolumeDto tierVolumeDto : tierVolumeList) {
        if (actualSales >= tierVolumeDto.getTierVolume()) {
          pTier = (int) tierVolumeDto.getTierVolumePk().getTierLevel();
        }
      }
    }
    return pTier;
  }

  @LogAround
  private int getProposalTier(ProposalDto proposalDto) {
    int pTier = 0;
    Optional<ProposalSummaryViewDto> ps = proposalSummaryViewRepository.findById(proposalDto.getProposalSaKey());
    if (ps.isPresent()) {
      pTier = ps.get().getProposalTier().intValue();
    }
    return pTier;
  }

  @LogAround
  private int populatePresentSalesVolume(ProposalDto proposalDto) {
    int presentSales = 0;
    List<AccountSalesSummaryDto> accountSalesSummary = accountSalesSummaryRepository
        .queryCalculatedOtdStdSummaryByProposal(proposalDto.getProposalSaKey());
    if (!accountSalesSummary.isEmpty()) {
      for (AccountSalesSummaryDto accountSalesSummaryDto : accountSalesSummary) {
        presentSales = accountSalesSummaryDto.getVehiclesSoldMonthToDate();
      }
    }

    return presentSales;
  }

  @LogAround
  public List<TierVolumeDto> getTierVolumeList(final ProposalDto proposal) {
	  return tierVolumeRepository.findAllByProposalKey(proposal.getProposalSaKey());
  }

  @LogAround
  private List<ProposalFinancialVO> getPriorYearProposalFinancialList(ProposalDto pyProposal,ApiParams apiParams) {
    List<ProposalFinancialVO> financialList = new ArrayList<ProposalFinancialVO>();
    // Initialize the List
    List<ProposalFinancialVO> targetList = getTargetFinancialList(pyProposal, false, false, true);

    List<PerUnitNewViewDto> pyPerUnitIncentiveNewViewList = perUnitNewViewRepo
        .findListPerUnitNewViewByProposal(pyProposal.getProposalSaKey());
    
    long pyAgg = getAggregateIncentiv(pyProposal);
    long pyManualBonus = getManualBonus(pyProposal);
    int pyProposalTier = getProposalTier(pyProposal, isPriorYearVMbasedOnActualVolume(apiParams));
    int tTier = getTotalTier(pyProposal);
    if (tTier == 0) {
      tTier = 1;
    }
    if (pyPerUnitIncentiveNewViewList != null && !(pyPerUnitIncentiveNewViewList.isEmpty())) {
      for (PerUnitNewViewDto pyViewDto : pyPerUnitIncentiveNewViewList) {
        ProposalFinancialVO pyPerUnit;
        if (pyViewDto.getNewBodyStyleKey() != null) {
          pyPerUnit = new ProposalFinancialVO(pyViewDto.getNewBodyStyleKey(), pyViewDto.getNewBodyStyleKey(),
              0L);
        } else {
          pyPerUnit = new ProposalFinancialVO(0L, pyViewDto.getId().getBodyStyleKey(), 0L);
        }
        pyPerUnit.setPerUnitDescription(pyViewDto.getBodyStyleCode());
        pyPerUnit.setModelYear(pyViewDto.getModelYear() + 1);// changed
        pyPerUnit.setVehicleLineDescription(pyViewDto.getVehicleLineDesc());
        pyPerUnit.setVehLineCode(pyViewDto.getVehicleLineCode());
        pyPerUnit.setPriorYearProposalTier(pyProposalTier);

        long pyCPA = 0L;
        if (pyProposalTier == 1) {
          pyCPA = pyViewDto.getTier1Incentive();
        }
        if (pyProposalTier == 2) {
          pyCPA = pyViewDto.getTier2Incentive();
        }
        if (pyProposalTier == 3) {
          pyCPA = pyViewDto.getTier3Incentive();
        }
        if (pyProposalTier == 4) {
          pyCPA = pyViewDto.getTier4Incentive();
        }
        if (pyProposalTier == 5) {
          pyCPA = pyViewDto.getTier5Incentive();
        }
        if (pyProposalTier == 6) {
          pyCPA = pyViewDto.getTier6Incentive();
        }

        pyPerUnit.setPriorYearAGG((pyAgg + pyManualBonus) * (-1));
        pyPerUnit.setPriorYearCPA(pyCPA * (-1));
        pyPerUnit.setPriorYearESP(Math.round((pyViewDto.geteSPIncentive() / (double)tTier)) * (-1));
        pyPerUnit.setPriorYearOPT(
            (Math.round((pyViewDto.getmLBIncentive() + pyViewDto.getOptionIncentive()) / (double)tTier)) * (-1));
        pyPerUnit.setPriorYearVM((pyAgg + pyManualBonus + pyCPA + Math.round(
            (pyViewDto.geteSPIncentive() + pyViewDto.getmLBIncentive() + pyViewDto.getOptionIncentive())
                / (double)tTier))
            * (-1));
        pyPerUnit.setPriorYearVolume(pyViewDto.getMlvForecast());
        pyPerUnit.setPriorYearTier1(pyViewDto.getTier1Incentive() * (-1));
        pyPerUnit.setPriorYearTier2(pyViewDto.getTier2Incentive() * (-1));
        pyPerUnit.setPriorYearTier3(pyViewDto.getTier3Incentive() * (-1));
        pyPerUnit.setPriorYearTier4(pyViewDto.getTier4Incentive() * (-1));
        pyPerUnit.setPriorYearTier5(pyViewDto.getTier5Incentive() * (-1));
        pyPerUnit.setPriorYearTier6(pyViewDto.getTier6Incentive() * (-1));

        ProposalFinancialVO tPerUnit = new ProposalFinancialVO(0L, pyViewDto.getId().getBodyStyleKey(), 0L);
        if (targetList != null && targetList.contains(tPerUnit)) {
          tPerUnit = targetList.get(targetList.indexOf(tPerUnit));
          pyPerUnit.setPriorYearEstCC(tPerUnit.getPriorYearEstCC());
          pyPerUnit.setPriorYearEstRevenue(tPerUnit.getPriorYearEstRevenue());
        }
        financialList.add(pyPerUnit);
      }
    }
    return financialList;
  }

  @LogAround
  protected boolean showIncludedInPriorSection(List<FinancialDetailedVO> financialDetaiedList) {
    boolean showIncludedInPrior = false;
    for (FinancialDetailedVO financialVO : financialDetaiedList) {
      if ((financialVO != null)&& (!financialVO.isPresentProposal())) {
          showIncludedInPrior = true;
          break;
      }
    }
    return showIncludedInPrior;
  }

}
