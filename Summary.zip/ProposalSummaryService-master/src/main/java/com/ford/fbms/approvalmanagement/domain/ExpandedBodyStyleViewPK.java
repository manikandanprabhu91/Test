package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Embeddable
@Getter
@Setter
public class ExpandedBodyStyleViewPK  implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Column(name = "FBME04_VEHLN_K")
	private Long vehicleLine;
	
	@Column(name = "FBME03_BDYSTL_K_EXPANDED")
	private Long expandedBodyStyleSaKey;

	@Column(name = "FBME03_BDYSTL_K")
	private Long bodyStyleSaKey;

	@Column(name = "FBME03_BDYSTL_C")
	private String bodyStyleCode;
	  
	@Column(name = "FBME03_BDYSTL_C_EXPANDED")
	private String expandedBodyStyleCode;

}
