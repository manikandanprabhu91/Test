package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD90_FIN_STATUS database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = FinStatus.TABLE_NAME)
public class FinStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD90_FIN_STATUS";
	@Id
	@Column(name = "FBMD90_FIN_STATUS_C")
	private String finStatusCode;

	@Column(name = "FBMD90_FIN_STATUS_X")
	private String finStatusDesc;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD90_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD90_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD90_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD90_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD90_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD90_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
