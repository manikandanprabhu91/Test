package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

/**
 * The persistent class for the MFBME29_VOCODE_STATUS database table.
 * 
 */
@Entity
@Table(name = VocodeStatusDto.TABLE_NAME)
// @NamedQuery(name="VocodeStatus.findAll", query="SELECT m FROM VocodeStatus
// m")
public class VocodeStatusDto implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBME29_VOCODE_STATUS";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBME29_VOCODE_STATUS_C")
	private String vocodeStatusCode;

	@Column(name = "FBME29_VOCODE_STATUS_X")
	private String vocodeStatusDescription;

	// bi-directional many-to-one association to Mfbme02VocodeOption
	/*
	 * @OneToMany(mappedBy="vocodeStatus") private List<VoCodeOption> vocodeOptions;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME29_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME29_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME29_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME29_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME29_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME29_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
