package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.cloud.cloudfoundry.com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for them MFBME41_PD_MARKET database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = CatalogFinancialDto.TABLE_NAME)
public class CatalogFinancialDto implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBME30_CATALOG_FINANCIAL";

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBME30_CATLG_FINANCE_K")
  private Long catFinKey;

  @Column(name = "FBME03_BDYSTL_K")
  private Long  bodyStyleKey;

  @Column(name = "FBME30_MKTG_PROGRAM_C")
  private String marketingProgram;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME30_EFFECTIVE_START_S")
  private Date effStartDate;

  @Column(name = "FBME30_FLEET_RATING_C")
  private String fleetRating;

  @Column(name = "FBME30_RETAIL_PRICE_R")
  private Long retailPrice;

  @Column(name = "FBME30_RETAIL_INCENTIVE_R")
  private Long retailIncentive;

  @Column(name = "FBME30_FLEET_PRICE_R")
  private Long fleetPrice;

  @Column(name = "FBME30_FLEET_INCENTIVE_R")
  private Long fleetIncentive;

  @Column(name = "FBME30_CONTR_MARGIN_R")
  private Long contMargin;

  @Column(name = "FBME30_CONTR_MARGIN_CRCY_C")
  private Double contMarginPct;

  @Column(name = "FBME30_DEALER_MARGIN_R")
  private Long dealerMargin;

  @Column(name = "FBME30_DEALER_MARGIN_PCT_R")
  private Double dealerMarginPct;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME30_CREATE_S")
  private Date createdTimeStamp;

  @JsonIgnore
  @Column(name = "FBME30_CREATE_PROCESS_C")
  private String createdProcess;

  @JsonIgnore
  @Column(name = "FBME30_CREATE_USER_C")
  private String createdUser;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBME30_LAST_UPDT_S")
  private Date lastUpdatedTimeStamp;

  @JsonIgnore
  @Column(name = "FBME30_LAST_UPDT_PROCESS_C")
  private String lastUpdatedProcess;

  @JsonIgnore
  @Column(name = "FBME30_LAST_UPDT_USER_C")
  private String lastUpdatedUser;
}