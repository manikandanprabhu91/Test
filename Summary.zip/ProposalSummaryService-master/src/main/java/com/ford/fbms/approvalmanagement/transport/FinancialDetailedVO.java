// ******************************************************************************
// * Copyright (c) 2009 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   FinancialDetailedVO.java  $
// * $Revision:   1.15  $
// * $Author:   PSIRISIN  $
// * $Date:   Jul 08 2010 12:15:36  $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.transport;


import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.util.FbmsUtil;
import lombok.Getter;
import lombok.Setter;

/**
 * This Value Object holds Detailed Volume/Financial Data
 */
@Getter
@Setter
public class FinancialDetailedVO  {
    private long presentKey;
    private long priorKey;
    private long prevVerKey;
    private Long modelYear;
    private int pY;
    private String vehicleLine;

    private String bodyStyle;

    private double presentVol;

    private double priorVol;

    private double prevVerVol;

    private double bwVol;

    private double bwPrevVerVol;

    private double presentVM;
    private double presentCPA;
    private double presentESP;
    private double presentOPT;
    private double presentAGG;
    private double priorPYVM;
    private double prevVerVM;
    private double targetVM;
    private double yoyTarget;
    private double matrixTargetVM;
    private double bwPriorPYVM;
    private double bwPrevVerVM;
    private double bwTargetVM;
    private double presentCC;
    private double priorPYCC;
    private double prevVerCC;
    private double presentRevenue;
    private double priorPYRevenue;
    private double prevVerRevenue;
    private double presentNR;
    private double priorPYNR;
    private double prevVerNR;
    private double bwPriorPYNR;
    private double bwPrevVerNR;
    private double bwTargetNR;
    private double presentCM;
    private double priorPYCM;
    private double prevVerCM;
    private double bwPriorPYCM;
    private double bwPrevVerCM;
    private double targetRevenue;
    private double targetCC;
    private double targetNR;
    private double targetCM;
    private double bwTargetRevenue;
    private double bwTargetCC;
    private double bwTargetCM;
    
    private boolean includedInPriorProposal;
    private boolean proposalTierChanged;
    private boolean totalTierChanged;

    private rowType recType;

    public enum rowType {
        /**
         * Comment for <code>VehicleLine</code>
         */
        VehicleLine,
        /**
         * Comment for <code>LineTotal</code>
         */
        LineTotal,
        /**
         * Comment for <code>GrandTotal</code>
         */
        GrandTotal
    }
    private boolean presentProposal;
    private String vehDesc;
    private String vehicleLineCode;
    
    private List<FinancialDetailedBaseVO> financialDetailedBaseVOList;
    
    public FinancialDetailedVO() {
        this.financialDetailedBaseVOList = new ArrayList<>();
    }
    
    
    private long priorVerProposalTier;
    private long proposalTier;
    private long priorYearProposalTier;
    private long priorVerTotalTier;
    private long totalTier;
    private long priorYearTotalTier;
    
    
    }
