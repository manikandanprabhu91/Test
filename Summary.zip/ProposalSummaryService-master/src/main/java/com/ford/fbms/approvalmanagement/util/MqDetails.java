package com.ford.fbms.approvalmanagement.util;

import lombok.Getter;

/**
 * A class for MQ details.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Getter
public enum MqDetails {

  EMAIL("fbms.mq.exchange", "fbms.mq.queue","fbms.mq.email");

  private String exchangeNm;
  private String queueNm;
  private String routingKeyNm;

  MqDetails(String exchangeNm, String queueNm, String routingKeyNm) {
    this.exchangeNm = exchangeNm;
    this.routingKeyNm = routingKeyNm;
  }
}
