package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.MessageLangDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between messageLang model and table.
 *
 * @author GILNAGOV on 2/15/2021.
 */
@Repository
public interface MessageLangRepository extends JpaRepository<MessageLangDto, String> {
}
