package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

/**
 * A class for constraint validation.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Slf4j
@Service
@Validated
public class ConstraintValidator {

  /**
   * To validate the request attributes.
   */
  public void isValidCreateUpdateReqAttr(@NotNull @Min(1) @Max(999999) final Integer appCd,
                                         @Pattern(regexp = "^[A-Za-z0-9]{1,30}$",
                                             message = "Invalid Requester ID")
                                         @Size(min = 1, max = 30,
                                             message = "Invalid length of Requester ID")
                                         @NotBlank final String cdsId) {
    LoggerBuilder.printInfo(log, logger -> logger.methodName("isValidCreateUpdateReqAttr")
        .message("Request constraints are passed"));
  }
}
