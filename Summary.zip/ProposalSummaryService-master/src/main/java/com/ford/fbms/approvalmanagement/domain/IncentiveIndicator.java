package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMA29_INCENTIVE_INDICATOR database table.
 * 
 */
@Getter
@Setter
@Entity
@Table(name = IncentiveIndicator.TABLE_NAME)
// @NamedQuery(name="IncentiveIndicator.findAll", query="SELECT m FROM
// IncentiveIndicator m")
public class IncentiveIndicator implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String TABLE_NAME = "MFBMA29_INCENTIVE_INDICATOR";
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMA29_INCENTIVE_INDICATOR_C")
	private String incentiveIndicatorCode;

	@Column(name = "FBMA29_INCENTIVE_INDICATOR_N")
	private String incentiveIndicatorName;

	/*
	 * //bi-directional many-to-one association to Mfbma11TierIncentive
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<TierIncentive>
	 * tierIncentives;
	 * 
	 * //bi-directional many-to-one association to Mfbma30BonusMgmt
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<BonusMgmt> bonusMgmts;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma33MktDeflt
	 * 
	 * @OneToMany(mappedBy="mktDefDitIndc") private List<MarketDefault> mktDeflts1;
	 * 
	 * //bi-directional many-to-one association to Mfbma33MktDeflt
	 * 
	 * @OneToMany(mappedBy="mktDefDitIndc") private List<MarketDefault> mktDeflts2;
	 * 
	 * //bi-directional many-to-one association to Mfbma35AprvlParm
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<AprvlParm> aprvlParms;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbma42TierIncePaymntRoute
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<TierIncePaymntRoute>
	 * tierIncePaymntRoutes;
	 * 
	 * //bi-directional many-to-one association to Mfbma45BandingPayeeDtl
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<BandingPayeeDtl>
	 * bandingPayeeDtls;
	 * 
	 * //bi-directional many-to-one association to Mfbma47PviBandPaymtDtl
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<PviBandPaymtDtl>
	 * pviBandPaymtDtls;
	 * 
	 * //bi-directional many-to-one association to Mfbmd29CountryVi
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<CountryVi> countryVis;
	 */

	/*
	 * //bi-directional many-to-one association to Mfbmd30EntityVi
	 * 
	 * @OneToMany(mappedBy="incentiveIndicator") private List<EntityVi> entityVis;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA29_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMA29_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMA29_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMA29_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMA29_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMA29_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
