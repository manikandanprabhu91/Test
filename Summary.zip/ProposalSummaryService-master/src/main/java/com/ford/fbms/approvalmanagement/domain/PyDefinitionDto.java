package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBMD12_PY_DEFINITION database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = PyDefinitionDto.TABLE_NAME)
// @NamedQuery(name="PyDefinitionDto.findAll", query="SELECT m FROM PyDefinitionDto
// m")
public class PyDefinitionDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBMD12_PY_DEFINITION";

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "FBMD12_PROPOSAL_YEAR_C")
	private int proposalYearCode;

	@Column(name = "FBMD12_ACTIVATE_AUTOEARLY_F")
	private String activateAutoearlyFlag;

	@Column(name = "FBMD12_ARCHIVE_F")
	private String archiveFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD12_ARCHIVE_Y")
	private Date archiveYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD12_AUTOEARLY_Y")
	private Date autoearlyYear;

	@Column(name = "FBMD12_CURRENT_PY_F")
	private String currentPyFlag;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD12_END_Y")
	private Date endYear;

	@Temporal(TemporalType.DATE)
	@Column(name = "FBMD12_START_Y")
	private Date startYear;

	// bi-directional many-to-one association to Mfbma01Proposal
	@OneToMany(mappedBy = "pyDefinition")
	private List<ProposalDto> proposals;

	// bi-directional many-to-one association to Mfbmd13PyCountryDefinition
	/*
	 * @OneToMany(mappedBy="pyDefinition") private List<PyCountryDefinition>
	 * pyCountryDefinitions;
	 */
	/*
	 * //bi-directional many-to-one association to Mfbmd15MetricsObjective
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<MetricsObjective>
	 * metricsObjectives;
	 * 
	 * //bi-directional many-to-one association to Mfbmd16PyVehicleDefinition
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<PyVehicleDefinition>
	 * pyVehicleDefinitions;
	 * 
	 * //bi-directional many-to-one association to Mfbmd60MetricsAssignAttr
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<MetricsAssignAttr>
	 * metricsAssignAttrs;
	 * 
	 * //bi-directional many-to-one association to Mfbmd77AssignmentProceed
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<AssignmentProceed>
	 * assignmentProceeds;
	 * 
	 * //bi-directional many-to-one association to Mfbme05FvaData
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<FvaData> fvaData;
	 * 
	 * //bi-directional many-to-one association to Mfbme08AcctSale
	 * 
	 * @OneToMany(mappedBy="pyDefinition") private List<AcctSale> acctSales;
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD12_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBMD12_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBMD12_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBMD12_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBMD12_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBMD12_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
