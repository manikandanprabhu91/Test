package com.ford.fbms.approvalmanagement.repository;


import com.ford.fbms.approvalmanagement.domain.MultiYearTermDto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * This class to manage the data between direction model and table.
 *
 * @author NACHUTHA on 3/17/2021.
 */
@Repository
public interface MultiYearBonusRepository extends JpaRepository<MultiYearTermDto, Long> {

@Query(value="Select * from {h-schema}MFBMA15_MULTI_YEAR_TERMS where FBMA01_PROPOSAL_K = :proposalKey ",nativeQuery = true)
MultiYearTermDto findByProposalKey(@Param("proposalKey")long proposalKey);
}
