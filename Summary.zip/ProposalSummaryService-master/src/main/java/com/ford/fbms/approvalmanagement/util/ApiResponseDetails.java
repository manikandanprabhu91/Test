package com.ford.fbms.approvalmanagement.util;

import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import io.swagger.annotations.ApiResponse;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * An API response details with http code and message.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@io.swagger.annotations.ApiResponses(value = {
    @ApiResponse(code = 201, message = Constants.SUCCESS_CREATE, response = GenericResponse.class),
    @ApiResponse(code = 200, message = Constants.SUCCESS_TEXT, response = GenericResponse.class),
    @ApiResponse(code = 207, message = Constants.MULTI_STATUS, response = GenericResponse.class),
    @ApiResponse(code = 400, message = Constants.BAD_REQUEST, response = GenericResponse.class),
    @ApiResponse(code = 401, message = Constants.UNAUTHORIZED, response = GenericResponse.class),
    @ApiResponse(code = 403, message = Constants.FORBIDDEN, response = GenericResponse.class),
    @ApiResponse(code = 404, message = Constants.NOT_FOUND, response = GenericResponse.class),
    @ApiResponse(code = 405, message = Constants.HTTP_REQUEST_METHOD_NOT_SUPPORTED,
        response = GenericResponse.class),
    @ApiResponse(code = 412, message = Constants.HTTP_412_API_MSG,
        response = GenericResponse.class),
    @ApiResponse(code = 415, message = Constants.HTTP_415_API_MSG,
        response = GenericResponse.class),
    @ApiResponse(code = 417, message = Constants.HTTP_417_API_MSG,
        response = GenericResponse.class),
    @ApiResponse(code = 429, message = Constants.HTTP_429_API_MSG,
        response = GenericResponse.class),
    @ApiResponse(code = 500, message = Constants.SERVER_ERROR, response = GenericResponse.class),
    @ApiResponse(code = 503, message = Constants.HTTP_503_API_MSG,
        response = GenericResponse.class)})
public @interface ApiResponseDetails {

}

