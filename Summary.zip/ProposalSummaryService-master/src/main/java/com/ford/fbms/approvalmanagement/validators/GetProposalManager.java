package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import java.util.Optional;
import java.util.concurrent.Future;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

/**
 * A class to validate User ID.
 *
 * @author SJAGATJO on 3/2/2021.
 */
@Service
@Slf4j
public class GetProposalManager implements Validator {

  @Autowired
  private ProposalRepository proposalRepository;
  @Autowired
  private ResponseBuilder responseBuilder;
 
  @Override
  @LogAround
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object request, final MasterRuleEngine masterRuleEngine,
                                                             final HttpServletRequest httpRequest) {
    GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").message("Inside GetProposalManager"));
    Optional<ProposalDto> proposalDTO = proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDTO.isPresent()) {
      genericResponseWrapper.setProposalDataDto(proposalDTO.get());
      
    } else {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).message("Invalid proposal id"));
      genericResponseWrapper
          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    }
    return new AsyncResult<>(genericResponseWrapper);
  }
}