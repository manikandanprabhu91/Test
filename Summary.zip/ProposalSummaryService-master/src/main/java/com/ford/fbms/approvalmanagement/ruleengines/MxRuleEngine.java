package com.ford.fbms.approvalmanagement.ruleengines;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalStatusDto;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.transport.ValidateActionsVO;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.RequestMode;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import com.ford.fbms.approvalmanagement.validators.Validator;

import lombok.extern.slf4j.Slf4j;

/**
 * A class for defining Mexico business rules and activities.
 *
 * @author SNITHY11 on 2/7/2021.
 */
@Slf4j
@Service
public class MxRuleEngine extends MasterRuleEngine {

  private static final String COUNTRY_CODE = "MEX";
  private static final Locale LOCALE = Locale.US;

  @Override
  public String getCountryCd() {
    return COUNTRY_CODE;
  }

  @Override
  public Locale getLocale() {
    return LOCALE;
  }

  @Override
  protected List<Validator> getValidators(final RequestMode requestMode, final ApiParams apiParams) {
    final List<Validator> validators = new ArrayList<>();
    validators.add(userIdValidator);
    switch (requestMode) {
      case GET_APPROVAL:
        validators.add(approvalManagementValidator);
        break;
      case CREATE_APPROVAL:
        validators.add(approvalManagementCreateValidator);
        break;
      case DELETE_APPROVAL:
        break;
      case MAINTAIN_FINANCIAL_DATA_SP:
        validators.add(maintainFinancialDataValidator);
        break;
      case GET_FINANCIAL_LIST:
    	  validators.add(mexProposalManager);
          break;
      case GET_TOTALS_AVG_FINANICIALS:
        validators.add(mexProposalManager);
        break;
      case GET_ACTUAL_LIST:
        validators.add(actualsManager);
        break;
      case GET_FORECAST_LIST:
        validators.add(forecastManager);
        break;
      case SUBMIT_PROPOSAL:
        validators.add(getProposalManager);
        validators.add(fordPersonManager);
        validators.add(quotationExpirationDateManager);
        validators.add(submitProcessMexValidator);
        break;
      case SAVE_PROPOSAL:
        validators.add(getProposalManager);
        break;
      case SENDBACK_PROPOSAL:
        validators.add(getProposalManager);
        validators.add(approvalManagementValidator);
        break;
      case RECALL_PROPOSAL:
        validators.add(getProposalManager);
        validators.add(recallProcessMexValidator);
        break;
      case APPROVAL_CHAIN:
        validators.add(mexApprovalChainValidator);
        break;
      case DOWNLOAD_PROPOSAL:
        validators.add(perUnitIncentiveManager);
        validators.add(proposalCommentsManager);
        validators.add(subsidiaryManager);
        validators.add(vechileLineManager);
        break;
      case GET_VOLUME_FINANCIAL_OPTIONS:
        validators.add(mexVolumeFinancialOptionsValidator);
        break;
      case VALIDATE_ACTIONS:
        validators.add(fordPersonManager);
        validators.add(actionValidator);
        validators.add(fordPersonAccessManager);
        validators.add(approvalProcessByStatusManager);
        break;
      case APPROVE_PROPOSAL:
    	  validators.add(getProposalManager);
          validators.add(quotationExpirationDateManager);
          validators.add(approvalProcessMexValidator);
  		break;
      case REVISE_PROPOSAL:
        validators.add(getProposalManager);
        break;
      case REJECT_PROPOSAL:
        validators.add(getProposalManager);
        validators.add(approvalProcessManager);
        break;
      default:
        break;
    }
    return validators;
  }

  @Override
  public GenericResponse createApproval(final ApiParams apiParams,
                                        final GenericResponseWrapper genericResponseWrapper, final RequestMode approvalRequest) {
    ApprovalResponseVo approvalResponseVo = genericResponseWrapper.getApprovalResponseVo();
    if (null != genericResponseWrapper.getProposalDataDto()) {
      final Optional<ProposalStatusDto> proposalStatusDto_final = proposalStatusRepo
          .findById(approvalResponseVo.getProposalStatus());
      ProposalDto proposalDto = genericResponseWrapper.getProposalDataDto();
      proposalDto.setProposalStatus(proposalStatusDto_final.orElse(null));
      if(ApprovalConstants.APPROVED.equalsIgnoreCase(proposalDto.getProposalStatus().getProposalStatusCode())) {
    	  proposalDto.setFordApproveYear(new Date());
      }
      proposalDto.setProposalSubYear(new Date());
      proposalDto.setStatusYear(new Date());
      proposalDto.setFordPerson(genericResponseWrapper.getFordPersonDto());
      proposalDto.setReportLevel(approvalResponseVo.getMaxReportLevel());
      proposalDto.setCntlReqdFlag(approvalResponseVo.isControllerApprovalRequired());
      proposalDto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
      proposalDto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
      proposalDto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
      proposalRepository.save(proposalDto);

      final ApprovalProcessDto approvalProcessDto = new ApprovalProcessDto();
      approvalProcessDto.setProposalKey(genericResponseWrapper.getProposalDataDto());
      approvalProcessDto
          .setProposalStatus(proposalStatusDto_final.orElse(null));
      approvalProcessDto.setSubmittedById(genericResponseWrapper.getFordPersonDto());
      approvalProcessDto.setSubmittedTime(new Timestamp(new Date().getTime()));
      Optional<FordPersonDto> submittedToId = fordPersonRepo
          .findById(approvalResponseVo.getSubmittedToFordPerson());
      approvalProcessDto.setSubmittedToId(submittedToId.orElse(null));
      approvalProcessDto.setReportLevel(reportLevelRepo
              .findById(Long.valueOf(approvalResponseVo.getReportlevel())).get());
      
      if (null != approvalResponseVo.getApprovedByFordPerson()) {
        approvalProcessDto.setApprovedById(approvalResponseVo.getApprovedByFordPerson());
      }
      approvalProcessDto.setApprovedTime(new Timestamp(new Date().getTime()));
      approvalProcessDto.setCreatedProcess(ApprovalConstants.FBMSNG);
      approvalProcessDto.setCreatedTimeStamp(new Timestamp(new Date().getTime()));
      approvalProcessDto.setCreatedUser(ApprovalConstants.FBMSNG);
      approvalProcessDto.setLastUpdatedProcess(ApprovalConstants.FBMSNG);
      approvalProcessDto.setLastUpdatedTimeStamp(new Timestamp(new Date().getTime()));
      approvalProcessDto.setLastUpdatedUser(ApprovalConstants.FBMSNG);
      approvalProcessRepository.save(approvalProcessDto);
      procedureRepository.updateFinancialData(apiParams.getProposalKey());
    }
    return responseBuilder.generateResponse(ResponseCodes.PROPOSAL_SUBMITTED_SUCCESSFULLY);
  }
  
  @Override
  public GenericResponse validateAction(ApiParams apiParams,GenericResponseWrapper consolidatedValidationResp) {
		ValidateActionsVO actionsVo = null;
		ProposalDto proposal = consolidatedValidationResp.getProposalDataDto();
		FordPersonDto user = consolidatedValidationResp.getFordPersonDto();
		int i =0;
		
		if (null != user) {
			actionsVo = new ValidateActionsVO();
			int userLevel = user.getReportLevel().getCode();
			actionsVo.setHighPriorityFlag(proposal.isApprovalPriorityFlag());
			if (null != consolidatedValidationResp.getPyCountryDefinition()
					&& "N".equals(consolidatedValidationResp.getPyCountryDefinition().getArchiveFlag())) {
				
				if(userLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE){
					userLevel = userLevel * 2;
				}
				
				if ((userLevel == ApprovalConstants.FNA_RL_CODE)
						|| userLevel == ApprovalConstants.CONTROLLER_RL_CODE) {
					userLevel = userLevel + 4;
					i=i+4;
				}
				
				String proposalStatus = proposal.getProposalStatus().getProposalStatusCode();
				boolean dealAuthorizedFlag = consolidatedValidationResp.getIsAuthorized();
				if (ApprovalConstants.NEW.equals(proposalStatus)
						&& (userLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE * 2 || dealAuthorizedFlag)) {
					if (consolidatedValidationResp.getIsProposalAssignee()) {
						actionsVo.setSubmitActionValid(true);
						actionsVo.setSaveActionValid(true);
						actionsVo.setDeleteActionValid(true);
					}
				} else if (ApprovalConstants.REVISED.equals(proposalStatus)
						|| ApprovalConstants.SUBMITTED.equals(proposalStatus)) {
					int presentQueueLevel = -1;
					if (null != consolidatedValidationResp.getApprovalProcessDto()
							&& null != consolidatedValidationResp.getApprovalProcessDto().getReportLevel()) {
						presentQueueLevel = 
								consolidatedValidationResp.getApprovalProcessDto().getReportLevel().getCode();
						
						if (presentQueueLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE) {
							presentQueueLevel = presentQueueLevel * 2;
						}
					
					if ((presentQueueLevel == ApprovalConstants.FNA_RL_CODE)
							|| presentQueueLevel == ApprovalConstants.CONTROLLER_RL_CODE) {
						presentQueueLevel = presentQueueLevel + 4;
					}
						if ((ApprovalConstants.REVISED.equals(proposalStatus))&&((userLevel == ApprovalConstants.FNA_RL_CODE +i)
								&& (userLevel == presentQueueLevel))) {
							actionsVo.setApproveActionValid(true);
							actionsVo.setRejectActionValid(true);
							actionsVo.setSendbackActionValid(true);
							actionsVo.setSaveActionValid(true);
						}
					if (ApprovalConstants.SUBMITTED.equals(proposalStatus)) {
						// See if Present approval Queue (report) level is same as user report level
						if (userLevel == presentQueueLevel) {
							actionsVo.setApproveActionValid(true);
							actionsVo.setRejectActionValid(true);
							actionsVo.setSendbackActionValid(true);
							actionsVo.setSaveActionValid(true);
							// FoM changes phase I (#23380) - added country code check for financial analyst
							if ((userLevel == ApprovalConstants.FNA_RL_CODE + i)) {
								// If the user level is 1st level approver then revise action should be
								// available
								actionsVo.setReviseActionValid(true);
							}
							if (dealAuthorizedFlag) {
								actionsVo.setRecallActionValid(true);
							}
						}
						if (userLevel < (ApprovalConstants.ACCOUNT_MANAGER_RL_CODE * 2 + 1)
								&& userLevel > presentQueueLevel) {
							// if the proposal is in higher approval queue Recall action should be available
							if (userLevel == ApprovalConstants.CONTROLLER_RL_CODE + i) {
								if (proposal.getCntlReqdFlag()) {
									actionsVo.setRecallActionValid(true);
								}
							} else {
								actionsVo.setRecallActionValid(true);
							}
						}
					}
					}
				}

			}
		}
		if (null == actionsVo) {
			return responseBuilder.generateResponse(ResponseCodes.SUCCESS_NO_CONTENT);
		} else {
			consolidatedValidationResp.setActionsVO(actionsVo);
			consolidatedValidationResp.setHttpStatus(HttpStatus.OK);
		}
		return consolidatedValidationResp;
	}


}
