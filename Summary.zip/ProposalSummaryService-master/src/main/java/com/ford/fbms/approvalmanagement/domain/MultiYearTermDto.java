package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = MultiYearTermDto.TABLE_NAME)
public class MultiYearTermDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  public static final String TABLE_NAME = "MFBMA15_MULTI_YEAR_TERMS";

    
  @Id
  @JsonManagedReference
  @Column(name = "FBMA01_PROPOSAL_K")
  private Long proposalKey;

  @Column(name = "FBMA15_MULTI_YEAR_START_Y")
  private Long startYr;

  @Column(name = "FBMA15_MULTI_YEAR_END_Y")
  private Long endYr;

  @Column(name = "FBMA15_BONUS_FIMPS_F")
  private String bonusFimpsFlag;

  @Column(name = "FBMA15_MULTIYEAR_MIN_Q")
  private Long minVolume;

  @Column(name = "FBMA15_MANUAL_BONUS_F")
  private String manualBonusFlag;

  @Column(name = "FBMA15_MULTIYEAR_MAX_Q")
  private Long maxVolume;

  @Column(name = "FBMA15_MULTIYEAR_REQUIRED_Q")
  private Long requiredVolume;

  @Column(name = "FBMA15_MANUAL_BONUS_A")
  private Long manualBonusAmount;

  @Column(name = "FBMA15_PAYMENT_MADE_F")
  private String paymentMadeFlag;

  @Column(name = "FBMA15_MICRO_CHECK_X")
  private String microCheckNumber;

  @Column(name = "FBMA15_MICRO_CHECK_Y")
  private String microCheckDate;

  @Column(name = "FBMA15_TOTAL_BONUS_PAID_A")
  private Long totalBonusPaidAmount;

  
  @JsonManagedReference
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMA01_CURRENT_VER_IN_EFF_K")
  private ProposalDto currentProposalInEffect;

  @JsonIgnore
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "FBMA01_SOURCE_VER_EFF_EST_K")
  private ProposalDto sourceProposalAtEstablishment;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA15_CREATE_S")
  protected Date createdTime;

  @JsonIgnore
  @Column(name = "FBMA15_CREATE_PROCESS_C")
  protected String createdProcessCode;

  @JsonIgnore
  @Column(name = "FBMA15_CREATE_USER_C")
  protected String createdUserCode;

  @JsonIgnore
  @Temporal(TemporalType.TIMESTAMP)
  @Column(name = "FBMA15_LAST_UPDT_S")
  protected Date updatedTime;

  @JsonIgnore
  @Column(name = "FBMA15_LAST_UPDT_USER_C")
  protected String lastUpdateUserCode;

  @JsonIgnore
  @Column(name = "FBMA15_LAST_UPDT_PROCESS_C")
  protected String lastUpdatedProcessCode;

}

