package com.ford.fbms.approvalmanagement.transport;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * Reference lists for Address and direction model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Getter
@Setter
public class ApprovalProcessResponse extends GenericResponse {
  private List<ApprovalResponseVo> approvalResponseVoList;
  
  
}
