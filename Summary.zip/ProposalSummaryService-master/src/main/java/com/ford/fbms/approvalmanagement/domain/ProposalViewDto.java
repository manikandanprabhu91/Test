package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * This class to manage the data between model and table.
 *
 * @author APARAMA2
 */
@SuppressWarnings("PMD")
@Getter
@Setter
@Entity
@Table(name = "PROPOSAL_COMMENTS_VIEW")
public class ProposalViewDto extends GenericResponse implements Serializable {

  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBMA02_PROPOSAL_NOTE_K")
  private Long proposalNoteKey;

  @Column(name = "FBMD12_PROPOSAL_YEAR_C")
  private String proposalYear;

  @Column(name = "FBMA01_VERNUM_R")
  private String proposalVersion;

  @Column(name = "FBMD03_CDSID_C")
  private String commentedBy;

  @Temporal(TemporalType.TIMESTAMP)
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
  @Column(name = "FBMA02_NOTE_S")
  private Date dateSubmitted;

  @Column(name = "FBMA02_NOTE_X")
  private String proposalComments;

  @Column(name = "FBMA02_IN_PROCESS_F")
  private String inProcess;

  @JsonIgnore
  @Column(name = "FBME01_FIN_MASTER_K")
  private String finkey;

  public Date getDateSubmitted() {
    return new Date(dateSubmitted.getTime());
  }

  public void setDateSubmitted(final Date dateSubmitted) {
    this.dateSubmitted = new Date(dateSubmitted.getTime());
  }

}
