package com.ford.fbms.approvalmanagement.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ford.fbms.approvalmanagement.transport.GenericResponse;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 * A class for Approval Process model.
 *
 * @author NACHUTHA on 3/2/2021.
 */

@Entity
@Table(name = "FBMS_PERUNIT_OPT_VIEW")

public class PerUnitOptViewDto extends GenericResponse implements Serializable {

  public Long getPviKey() {
		return pviKey;
	}

	public void setPviKey(Long pviKey) {
		this.pviKey = pviKey;
	}

	public Long getProposalKey() {
		return proposalKey;
	}

	public void setProposalKey(Long proposalKey) {
		this.proposalKey = proposalKey;
	}

	public Long getBodyStyleKey() {
		return bodyStyleKey;
	}

	public void setBodyStyleKey(Long bodyStyleKey) {
		this.bodyStyleKey = bodyStyleKey;
	}

	public int getMlv() {
		return mlv;
	}

	public void setMlv(int mlv) {
		this.mlv = mlv;
	}

	public Long getRepurchase() {
		return repurchase;
	}

	public void setRepurchase(Long repurchase) {
		this.repurchase = repurchase;
	}

	public Date getEarlyTime() {
		return earlyTime;
	}

	public void setEarlyTime(Date earlyTime) {
		this.earlyTime = earlyTime;
	}

	public String getEarlyFlag() {
		return earlyFlag;
	}

	public void setEarlyFlag(String earlyFlag) {
		this.earlyFlag = earlyFlag;
	}

	public String getBodyStyleCode() {
		return bodyStyleCode;
	}

	public void setBodyStyleCode(String bodyStyleCode) {
		this.bodyStyleCode = bodyStyleCode;
	}

	public String getBodyStyleDesc() {
		return bodyStyleDesc;
	}

	public void setBodyStyleDesc(String bodyStyleDesc) {
		this.bodyStyleDesc = bodyStyleDesc;
	}

	public String getBodyGroupIndicator() {
		return bodyGroupIndicator;
	}

	public void setBodyGroupIndicator(String bodyGroupIndicator) {
		this.bodyGroupIndicator = bodyGroupIndicator;
	}

	public String getVehicleLineCode() {
		return vehicleLineCode;
	}

	public void setVehicleLineCode(String vehicleLineCode) {
		this.vehicleLineCode = vehicleLineCode;
	}

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	public String getVehicleLineDesc() {
		return vehicleLineDesc;
	}

	public void setVehicleLineDesc(String vehicleLineDesc) {
		this.vehicleLineDesc = vehicleLineDesc;
	}

	public Long getTier6Incentive() {
		return (tier6Incentive==null?0:tier6Incentive);
	}

	public void setTier6Incentive(Long tier6Incentive) {
		this.tier6Incentive = tier6Incentive;
	}

	public Long getTier5Incentive() {
		return (tier5Incentive==null?0:tier5Incentive);
	}

	public void setTier5Incentive(Long tier5Incentive) {
		this.tier5Incentive = tier5Incentive;
	}

	public Long getTier4Incentive() {
		return (tier4Incentive==null?0:tier4Incentive);
	}

	public void setTier4Incentive(Long tier4Incentive) {
		this.tier4Incentive = tier4Incentive;
	}

	public Long getTier3Incentive() {
		return (tier3Incentive==null?0:tier3Incentive);
	}

	public void setTier3Incentive(Long tier3Incentive) {
		this.tier3Incentive = tier3Incentive;
	}

	public Long getTier2Incentive() {
		return (tier2Incentive==null?0:tier2Incentive);
	}

	public void setTier2Incentive(Long tier2Incentive) {
		this.tier2Incentive = tier2Incentive;
	}

	public Long getTier1Incentive() {
		return (tier1Incentive==null?0:tier1Incentive);
	}

	public void setTier1Incentive(Long tier1Incentive) {
		this.tier1Incentive = tier1Incentive;
	}

	public Long getESPIncentive() {
		
		return (ESPIncentive==null?0:ESPIncentive);
	}

	public void setESPIncentive(Long eSPIncentive) {
		ESPIncentive = eSPIncentive;
	}

	public Long getMLBIncentive() {
		return (MLBIncentive==null?0:MLBIncentive);
	}

	public void setMLBIncentive(Long mLBIncentive) {
		MLBIncentive = mLBIncentive;
	}

	public Long getOptionIncentive() {
		return (optionIncentive==null?0:optionIncentive);
	}

	public void setOptionIncentive(Long optionIncentive) {
		this.optionIncentive = optionIncentive;
	}

private static final Long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "FBMA04_PVI_K")
  private Long pviKey;

  @Column(name = "FBMA01_PROPOSAL_K")
  private Long proposalKey;

  @Column(name = "FBME03_BDYSTL_K")
  private Long bodyStyleKey;

  @Column(name="FBMA04_MLV_Q")
  private int mlv;

  @Column(name = "FBMA04_REPURCHASE_Q")
  private Long repurchase;

  @Column(name = "FBMA04_SYS_ADDED_EARLY_S")
  private Date earlyTime;

  @Column(name = "FBMA04_SYS_ADDED_EARLY_F")
  private String earlyFlag;

  @Column(name = "FBME03_BDYSTL_C")
  private String bodyStyleCode;

  @Column(name = "FBME03_BDYSTL_X")
  private String bodyStyleDesc;

  @Column(name = "FBME03_BODY_GROUP_IND_F")
  private String bodyGroupIndicator;

  @Column(name = "FBME04_VEHLN_C")
  private String vehicleLineCode;

  @Column(name = "FBME04_VEHLN_MDLYR_C")
  private int modelYear;

  @Column(name = "FBME04_VEHLN_X")
  private String vehicleLineDesc;

  @Column(name="FBMA11_Tier_Inctv_A_6")
  private Long tier6Incentive;

  @Column(name="FBMA11_Tier_Inctv_A_5")
  private Long tier5Incentive;

  @Column(name="FBMA11_Tier_Inctv_A_4")
  private Long tier4Incentive;

  @Column(name="FBMA11_Tier_Inctv_A_3")
  private Long tier3Incentive;

  @Column(name="FBMA11_Tier_Inctv_A_2")
  private Long tier2Incentive;

  @Column(name="FBMA11_Tier_Inctv_A_1")
  private Long tier1Incentive;

  @Column(name = "ESP" )
  private Long ESPIncentive;

  @Column(name = "MLB")
  private Long MLBIncentive;

  @Column(name = "OTHER")
  private Long optionIncentive;
}
