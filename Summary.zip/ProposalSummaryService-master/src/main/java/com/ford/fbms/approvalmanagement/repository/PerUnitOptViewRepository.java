package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.PerUnitOptViewDto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PerUnitOptViewRepository extends JpaRepository<PerUnitOptViewDto, Long> {
	
	 List<PerUnitOptViewDto> findByProposalKey(@Param("proposalKey") long proposalKey);
}
