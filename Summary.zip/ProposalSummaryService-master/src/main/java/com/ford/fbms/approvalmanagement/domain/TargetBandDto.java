package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;



import lombok.Getter;
import lombok.Setter;

/**
 * The persistent class for the MFBME06_TARGET_BAND database table.
 * 
 */
@Entity
@Getter
@Setter
@Table(name = "MFBME06_TARGET_BAND")
// @NamedQuery(name="Mfbme06TargetBand.findAll", query="SELECT m FROM
// Mfbme06TargetBand m")
public class TargetBandDto implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "MFBME06_TARGET_BAND";

	@EmbeddedId
	private TargetBandPKDto targetBandPK;

	@Column(name = "FBME06_BAND1_R")
	private BigDecimal band1R;

	@Column(name = "FBME06_BAND2_R")
	private BigDecimal band2R;

	@Column(name = "FBME06_BAND3_R")
	private BigDecimal band3R;

	@Column(name = "FBME06_BAND4_R")
	private BigDecimal band4R;

	@Column(name = "FBME06_BAND5_R")
	private BigDecimal band5R;

	/*
	 * //bi-directional many-to-one association to Mfbmd09Segment
	 * 
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumn(name="FBMD09_SEG_C") private Segment segment;
	 * 
	 * //bi-directional many-to-one association to Mfbmd42Country
	 * 
	 * @ManyToOne(fetch=FetchType.LAZY)
	 * 
	 * @JoinColumn(name="FBMD42_COUNTRY_ISO3_C") private Country country;
	 */

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME06_CREATE_S")
	private Date createdTimeStamp;

	@Column(name = "FBME06_CREATE_PROCESS_C")
	private String createdProcess;

	@Column(name = "FBME06_CREATE_USER_C")
	private String createdUser;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "FBME06_LAST_UPDT_S")
	private Date lastUpdatedTimeStamp;

	@Column(name = "FBME06_LAST_UPDT_PROCESS_C")
	private String lastUpdatedProcess;

	@Column(name = "FBME06_LAST_UPDT_USER_C")
	private String lastUpdatedUser;
}
