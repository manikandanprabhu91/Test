package com.ford.fbms.approvalmanagement.validators;

import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.domain.ProposalVehicleLineIncentiveDto;
import com.ford.fbms.approvalmanagement.domain.PviExtraInfoDto;
import com.ford.fbms.approvalmanagement.domain.ReportLevelDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.ControllerThresholdRepository;
import com.ford.fbms.approvalmanagement.repository.FinProfileRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalVehicleLineIncentiveRepository;
import com.ford.fbms.approvalmanagement.repository.PviExtraInfoRepository;
import com.ford.fbms.approvalmanagement.repository.ReportLevelRepository;
import com.ford.fbms.approvalmanagement.repository.VehicleLineRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

@Service
@Slf4j

public class ApprovalProcessMexValidator implements Validator{

	@Autowired
	protected ProposalRepository proposalRepository;
	@Autowired
	private ResponseBuilder responseBuilder;
	@Autowired
	protected ProposalManager proposalManager;
	@Autowired
	protected FinProfileRepository finProfileRepo;
	@Autowired
	protected FordPersonRepository fordPersonRepo;
	@Autowired
	protected ReportLevelRepository reportLevelRepo;
	@Autowired
	protected ControllerThresholdRepository controllerThresholdRepo;
	@Autowired
	protected VehicleLineRepository vehicleLineRepository;
	@Autowired
	protected PviExtraInfoRepository pviExtraInfoRepository;
	@Autowired
	protected ProposalVehicleLineIncentiveRepository proposalVehicleLineIncentiveRepository;
	@Autowired
	protected ApprovalProcessRepository approvalProcessRepository;

	@Override
	public Future<GenericResponseWrapper> validateAndConstruct(ApiParams apiParams, Object approvalRequest,
																														 MasterRuleEngine masterRuleEngine, HttpServletRequest httpRequest) {
		final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
		LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
				.message("Inside submit process"));
		Optional<ProposalDto> proposalDtoOptional = this.proposalRepository.findById(apiParams.getProposalKey());
		if (proposalDtoOptional.isEmpty()) {
			LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
					.userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
			genericResponseWrapper
					.setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
		} else {
			ProposalDto proposal = proposalDtoOptional.get();
			ApprovalResponseVo approvalResponseVo = approvalProcess(apiParams, proposal);
			genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
		}
		return new AsyncResult<>(genericResponseWrapper);
	}

	@LogAround
	private ApprovalResponseVo approvalProcess(ApiParams apiParams, ProposalDto proposalDto) {
		ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
		Date updatedDate = new Date();
		ProposalDto proposal = proposalDto;
		// Get the present Queue RO that will be with SUB status
		ApprovalProcessDto presentQueue
				= approvalProcessRepository.findLatestApprovalProcessByProposalStatus(proposal.getProposalSaKey(),
				ApprovalConstants.SUBMITTED);
		int maxApprovalLevelCode = proposal.getReportLevel().getCode();
		String maxApprovalLevelTitle = proposal.getReportLevel().getTitleCode();
		boolean isControllerApprovalRequired = proposal.getCntlReqdFlag();
		boolean isControllerApproved = false;
		boolean isProposalApproved = false;
		boolean isProposalInRevise = false;

		FordPersonDto approverUser = null;
		Optional<FordPersonDto> approverUserId = fordPersonRepo.findById(apiParams.getUserId());
		if(approverUserId.isPresent()){
			approverUser = approverUserId.get();
		}
		String nextApproverCdsid = null;
		int presentReportLevelCode = -1;
		String presentReportLevelTitle = null;
		int firstLevelApproverReportLevelCode = -1;

		ReportLevelDto maxReportLevel = null;

		if (ApprovalConstants.REVISED.equals(proposal.getProposalStatus().getProposalStatusCode())) {
			isProposalInRevise = true;

			if(approverUser.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.FNA)){
				long totalAmount = reCalculateTotalInctvAmnt(proposal);
				maxReportLevel = calculateMaxApproverForMex(apiParams,totalAmount);
				maxApprovalLevelCode=maxReportLevel.getCode();
				log.info("Re-calculating Max approver at FNA approves:"+maxReportLevel);
			}
		}

		presentReportLevelCode = presentQueue.getReportLevel().getCode();
		presentReportLevelTitle = presentQueue.getReportLevel().getTitleCode();
		approvalResponseVo.setPresentReportLevelTitle(presentReportLevelTitle);

		firstLevelApproverReportLevelCode = ApprovalConstants.FIRST_LEVEL_APPROVER_RL_CODE_MEX;

		if (presentReportLevelCode == firstLevelApproverReportLevelCode) {
			if (isControllerApprovalRequired) {
				// Submit to controller queue without checking max approval
					nextApproverCdsid = ApprovalConstants.DEFAULT_CONTROLLER_MEX;
			} else {
				if (maxApprovalLevelCode == presentReportLevelCode) {
					// proposal is Approved and no need to create next queue
					isProposalApproved = true;
					approvalResponseVo.setProposalApproved(isProposalApproved);
					
				} else {
						// Create supervisor approval queue
						nextApproverCdsid = approverUser.getSprcdsidDescription();
				}
			}
		} else if (presentReportLevelCode == ApprovalConstants.CONTROLLER_RL_CODE) {
			isControllerApproved = true;
			nextApproverCdsid = approverUser.getSprcdsidDescription();
			approvalResponseVo.setNextApproverCdsid(nextApproverCdsid);
		} else {
			if (maxApprovalLevelCode == presentReportLevelCode) {
				// proposal is Approved and no need to create next queue
				isProposalApproved = true;
				approvalResponseVo.setProposalApproved(isProposalApproved);
			} else {
					// create supervisor approval queue
					nextApproverCdsid = approverUser.getSprcdsidDescription();
					approvalResponseVo.setNextApproverCdsid(nextApproverCdsid);
			}
		}
		if(maxApprovalLevelTitle.equalsIgnoreCase(presentReportLevelTitle)){
			// proposal is Approved and no need to create next queue
			isProposalApproved = true;
			approvalResponseVo.setProposalApproved(isProposalApproved);
		}else{
			if(approverUser.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.FNM)){
				nextApproverCdsid=proposal.getFordPerson().getSprcdsidDescription();
				String fNMSuprvr = approverUser.getSprcdsidDescription();
			} else if(approverUser.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.DFO)){
				ApprovalProcessDto fNAApvProRO
						= approvalProcessRepository.findApprovalProcessByProposalReportLevel(proposal.getProposalSaKey(),
						ApprovalConstants.FNM_RL_CODE);
				nextApproverCdsid=fNAApvProRO.getSubmittedToId().getSprcdsidDescription();
				approvalResponseVo.setNextApproverCdsid(nextApproverCdsid);
			}
		}
		String approveStatus = ApprovalConstants.APPROVED;
		String approveUser = apiParams.getUserId();

		approvalResponseVo.setProposalStatus(approveStatus);
		Optional<FordPersonDto> approvedByFordPerson = fordPersonRepo.findById(approveUser);
		approvalResponseVo.setApprovedByFordPerson(approvedByFordPerson.get());
		approvalResponseVo.setApprovedTime(updatedDate);

		if (isProposalApproved || isControllerApproved
				|| isProposalInRevise) {
			if (isProposalInRevise) {
				// Get the submitted status
				String submitStatus = ApprovalConstants.SUBMITTED;
				approvalResponseVo.setProposalStatus(submitStatus);
				approvalResponseVo.setMaxReportLevel(maxReportLevel);
				approvalResponseVo.setControllerApprovalRequired(isControllerApprovalRequired);
				approvalResponseVo.setProposalInRevise(isProposalInRevise);
			}
			if (isProposalApproved) {
				// update the proposal with status Approved
				approvalResponseVo.setProposalStatus(approveStatus);
				approvalResponseVo.setApprovedTime(updatedDate);

				log
						.info("Proposal is approved by ALL required approvers and Proposal Status is changed to Approve(APV). This proposal is now Out of Approval process.");
			}

			if (isControllerApproved) {
				// update controller approval details
				approvalResponseVo.setControllerApprovalYear(updatedDate);

				log
						.info("Present Approver is a Controller(CTL) and hence updated the controller approved date on Proposal.");
			}
		} else {
			if(approverUser.getReportLevel().getTitleCode().equalsIgnoreCase(ApprovalConstants.FNA)){
				long totalAmount = reCalculateTotalInctvAmnt(proposal);
				// Get max approver report level
				maxReportLevel = calculateMaxApproverForMex(apiParams, totalAmount);
				approvalResponseVo.setMaxReportLevel(maxReportLevel);
			}
		}

		if (!isProposalApproved) {
			String submitStatus = ApprovalConstants.SUBMITTED;
			Long nextReportLevel = null;
			FordPersonDto anextApproverCdsid = fordPersonRepo.findById(nextApproverCdsid).get();
			nextReportLevel = anextApproverCdsid.getReportLevel().getSaKey();
			approvalResponseVo.setProposalStatus(submitStatus);
			approvalResponseVo.setSubmittedByFordPerson(apiParams.getUserId());
			approvalResponseVo.setSubmittedTime(updatedDate);
			approvalResponseVo.setReportlevel(nextReportLevel.intValue());
			approvalResponseVo.setNextApproverCdsid(nextApproverCdsid);
		}
		return approvalResponseVo;
	}

	@LogAround
	private long reCalculateTotalInctvAmnt(ProposalDto proposal) {
		long totalAmount = 0;
		List<ProposalVehicleLineIncentiveDto> vehInctList = null;
		long fleetIncentive =0;
		long mlv =0;
		long totalFleetIncentive = 0;
		long totalMLV = 0 ;

		vehInctList = proposalVehicleLineIncentiveRepository
				.getVehicleLineIncentiveDetailsByProposal(proposal.getProposalSaKey());

		for(ProposalVehicleLineIncentiveDto vehicleLineIncentiveDto: vehInctList){

			Optional<PviExtraInfoDto> pviExtraInfoDto
					= pviExtraInfoRepository.findById(vehicleLineIncentiveDto.getPviSaKey());

			if (pviExtraInfoDto.isPresent()&&(ApprovalConstants.BUSINESS_CASE.equalsIgnoreCase(pviExtraInfoDto.get().getFleetRating()))) {
					mlv = vehicleLineIncentiveDto.getMlv();
					fleetIncentive = pviExtraInfoDto.get().getFleetIncentive();

					totalMLV = totalMLV + mlv;
					totalFleetIncentive = totalFleetIncentive + fleetIncentive;
				}
		}
		totalAmount =  totalFleetIncentive*totalMLV;

		return totalAmount;
	}


	@LogAround
	private ReportLevelDto calculateMaxApproverForMex(ApiParams apiParams, long totalAmount) {
		String countryCode = apiParams.getCountryCd();
		ReportLevelDto maxReportLevel = null;
		maxReportLevel = reportLevelRepo.getReportLevelDataByCountryApprovalAmt(countryCode, totalAmount);
		if (maxReportLevel != null) {
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelRO : reportLevelList) {
				if(ApprovalConstants.FNA.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.CONTROLLER_CODE.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.FNM.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.RSM.equalsIgnoreCase(maxReportLevel.getTitleCode())) {
					if(ApprovalConstants.RSM.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
						maxReportLevel = reportLevelRO;
					}
				} else if(ApprovalConstants.FSM.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.DFO.equalsIgnoreCase(maxReportLevel.getTitleCode())) {
					if(ApprovalConstants.DFO.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
						maxReportLevel = reportLevelRO;
					}
				} else if((ApprovalConstants.CEO.equalsIgnoreCase(maxReportLevel.getTitleCode())
						||ApprovalConstants.GVP.equalsIgnoreCase(maxReportLevel.getTitleCode()))&&(ApprovalConstants.CEO.equalsIgnoreCase(reportLevelRO.getTitleCode()))) {
						maxReportLevel = reportLevelRO;
				}
			}
		} else{
			List<ReportLevelDto> reportLevelList = reportLevelRepo.getReportLevelDataByCountry(countryCode);
			for (ReportLevelDto reportLevelRO : reportLevelList) {

				if (ApprovalConstants.FNA.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.DFO.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.GVP.equalsIgnoreCase(reportLevelRO.getTitleCode())
						|| ApprovalConstants.CEO.equalsIgnoreCase(reportLevelRO.getTitleCode())) {
					maxReportLevel = reportLevelRO;

				}
			}
		}
		return maxReportLevel;

	}

	@LogAround
	private boolean isControllerApprovalRequiredForMex() {
		return true;
	}
}