package com.ford.fbms.approvalmanagement.repository;

import com.ford.fbms.approvalmanagement.domain.ProposalSummaryViewDto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProposalSummaryViewRepository extends JpaRepository<ProposalSummaryViewDto, Long> {

}
