package com.ford.fbms.approvalmanagement.validators;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;


import com.ford.fbms.approvalmanagement.domain.ApprovalProcessDto;
import com.ford.fbms.approvalmanagement.domain.FordPersonDto;
import com.ford.fbms.approvalmanagement.domain.ProposalDto;
import com.ford.fbms.approvalmanagement.repository.ApprovalProcessRepository;
import com.ford.fbms.approvalmanagement.repository.FordPersonRepository;
import com.ford.fbms.approvalmanagement.repository.ProposalRepository;
import com.ford.fbms.approvalmanagement.ruleengines.MasterRuleEngine;
import com.ford.fbms.approvalmanagement.transport.ApiParams;
import com.ford.fbms.approvalmanagement.transport.ApprovalResponseVo;
import com.ford.fbms.approvalmanagement.transport.GenericResponseWrapper;
import com.ford.fbms.approvalmanagement.util.ApprovalConstants;
import com.ford.fbms.approvalmanagement.util.LogAround;
import com.ford.fbms.approvalmanagement.util.LoggerBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseBuilder;
import com.ford.fbms.approvalmanagement.util.ResponseCodes;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class RecallProcessValidator implements Validator {

  @Autowired
  private ResponseBuilder responseBuilder;
  @Autowired
  protected ProposalRepository proposalRepository;
  @Autowired
  protected FordPersonRepository fordPersonRepository;
  @Autowired
  protected ApprovalProcessRepository approvalProcessRepository;

  @Override
  public Future<GenericResponseWrapper> validateAndConstruct(final ApiParams apiParams,
                                                             final Object approvalRequest, final MasterRuleEngine masterRuleEngine,
                                                             HttpServletRequest httpRequest) {
    final GenericResponseWrapper genericResponseWrapper = new GenericResponseWrapper();
    LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct").userId(apiParams.getUserId())
        .message("Inside recall proposal"));
    Optional<ProposalDto> proposalDtoOptional = proposalRepository.findById(apiParams.getProposalKey());
    if (proposalDtoOptional.isEmpty()) {
      LoggerBuilder.printInfo(log, logger -> logger.methodName("validateAndConstruct")
          .userId(apiParams.getUserId()).message("proposalDtoOptional is Empty()"));
      genericResponseWrapper
          .setGenericResponse(responseBuilder.generateResponse(ResponseCodes.PROPOSAL_KEY_NOT_EXISTS));
    } else {
      ApprovalResponseVo approvalResponseVo = recallProposalDetails(apiParams, proposalDtoOptional.get(), genericResponseWrapper);
      ApprovalProcessDto updateRecalledQueue = approvalProcessRepository.findApprovalProcessByProposalReportLevelCode(apiParams.getProposalKey(),
          approvalResponseVo.getReportlevel());
      genericResponseWrapper.setUpdateRecalledQueue(updateRecalledQueue);
      genericResponseWrapper.setApprovalResponseVo(approvalResponseVo);
    }
    return new AsyncResult<>(genericResponseWrapper);
  }

  @LogAround
  private ApprovalResponseVo recallProposalDetails(ApiParams apiParams, ProposalDto proposal, GenericResponseWrapper genericResponseWrapper) {
    ApprovalResponseVo approvalResponseVo = new ApprovalResponseVo();
    List<ApprovalProcessDto> higherApprovalChain;
    FordPersonDto recalledUser_final = null;
    int userReportLevel = -1;
    boolean isAccountManager = false;
    // Get the logged in user RO
    Optional<FordPersonDto> recalledUser = fordPersonRepository.findById(apiParams.getUserId());
    // Get the report level of the user
    if (recalledUser.isPresent()) {
      recalledUser_final = recalledUser.get();
      genericResponseWrapper.setFordPersonDto(recalledUser_final);
      userReportLevel = recalledUser_final.getReportLevel().getCode();
    }
    approvalResponseVo.setReportlevel(userReportLevel);
    if (userReportLevel == ApprovalConstants.ACCOUNT_MANAGER_RL_CODE || (recalledUser_final!=null&&  null!=recalledUser_final.getGenericNamCdsid())) {
      isAccountManager = true;
      higherApprovalChain = approvalProcessRepository.findApprovalProcessById(proposal.getProposalSaKey());
    } else {
      higherApprovalChain = approvalProcessRepository
          .findListHigherApprovalProcessByProposalReportLevelCode(proposal.getProposalSaKey(),userReportLevel);
    }
    approvalResponseVo.setApprovalChain(higherApprovalChain);
    approvalResponseVo.setAccountManagerFlag(isAccountManager);
    if (isAccountManager) { 
      approvalResponseVo.setProposalStatus(ApprovalConstants.NEW);
      approvalResponseVo.setCdsid(recalledUser_final!=null?recalledUser_final.getCdsid():"");
    } else {
      approvalResponseVo.setProposalStatus(ApprovalConstants.SUBMITTED);
      approvalResponseVo.setSubmittedByFordPerson(recalledUser_final!=null?recalledUser_final.getCdsid():"");
    }
    return approvalResponseVo;
  }
}
