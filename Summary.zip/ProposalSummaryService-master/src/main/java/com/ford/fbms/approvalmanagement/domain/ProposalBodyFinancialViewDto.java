package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "FBMS_E18_A04_VIEW")

public class ProposalBodyFinancialViewDto implements Serializable {
	
	public Long getVehicleLineIncentiveSaKey() {
		return vehicleLineIncentiveSaKey;
	}

	public void setVehicleLineIncentiveSaKey(Long vehicleLineIncentiveSaKey) {
		this.vehicleLineIncentiveSaKey = vehicleLineIncentiveSaKey;
	}

	public Long getProposalSaKey() {
		return proposalSaKey;
	}

	public void setProposalSaKey(Long proposalSaKey) {
		this.proposalSaKey = proposalSaKey;
	}

	public Long getBodyStyle() {
		return bodyStyle;
	}

	public void setBodyStyle(Long bodyStyle) {
		this.bodyStyle = bodyStyle;
	}

	public Long getContributionCost() {
		return contributionCost;
	}

	public void setContributionCost(Long contributionCost) {
		this.contributionCost = contributionCost;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Long getRevenue() {
		return revenue;
	}

	public void setRevenue(Long revenue) {
		this.revenue = revenue;
	}

	public String getSegmentGroup() {
		return segmentGroup;
	}

	public void setSegmentGroup(String segmentGroup) {
		this.segmentGroup = segmentGroup;
	}

	public long getTier1Target() {
		return tier1Target;
	}

	public void setTier1Target(long tier1Target) {
		this.tier1Target = tier1Target;
	}

	public long getTier2Target() {
		return tier2Target;
	}

	public void setTier2Target(long tier2Target) {
		this.tier2Target = tier2Target;
	}

	public long getTier3Target() {
		return tier3Target;
	}

	public void setTier3Target(long tier3Target) {
		this.tier3Target = tier3Target;
	}

	public long getTier4Target() {
		return tier4Target;
	}

	public void setTier4Target(long tier4Target) {
		this.tier4Target = tier4Target;
	}

	public long getTier5Target() {
		return tier5Target;
	}

	public void setTier5Target(long tier5Target) {
		this.tier5Target = tier5Target;
	}

	public long getYearOverYearTarget() {
		return yearOverYearTarget;
	}

	public void setYearOverYearTarget(long yearOverYearTarget) {
		this.yearOverYearTarget = yearOverYearTarget;
	}

	public String getAccountClassCode() {
		return accountClassCode;
	}

	public void setAccountClassCode(String accountClassCode) {
		this.accountClassCode = accountClassCode;
	}

	public Long getCurrentYrRevenue() {
		return currentYrRevenue;
	}

	public void setCurrentYrRevenue(Long currentYrRevenue) {
		this.currentYrRevenue = currentYrRevenue;
	}

	public Long getCurrentYrContributionCost() {
		return currentYrContributionCost;
	}

	public void setCurrentYrContributionCost(Long currentYrContributionCost) {
		this.currentYrContributionCost = currentYrContributionCost;
	}

	private static final long serialVersionUID = 1L;

	public static final String TABLE_NAME = "FBMS_E18_A04_VIEW";

	@Id
	@Column(name = "FBMA04_PVI_K")
	private Long vehicleLineIncentiveSaKey;
	
	@Column(name = "FBMA01_PROPOSAL_K")
    private Long proposalSaKey;
	
/*	@Column(name = "FBME03_BDYSTL_K_1")
    private Long bodyStyle;*/
	
	@Column(name = "FBME03_BDYSTL_K")
	private Long bodyStyle;
	
	@Column(name = "FBME18_CONTRIBUTION_COST_R")
    private Long contributionCost;
	
	@Column(name = "FBME18_EFFECTIVE_S")
    private Date effectiveDate;
	
	@Column(name = "FBME18_REVENUE_R")
    private Long revenue;
	
	@Column(name = "FBMD99_SEGMENT_GROUP_TYPE_C")
    private String segmentGroup;
	
	@Column(name = "FBME18_TIER1_TARGET_R")
    private long tier1Target;
	
	@Column(name = "FBME18_TIER2_TARGET_R")
    private long tier2Target;
	
	@Column(name = "FBME18_TIER3_TARGET_R")
    private long tier3Target;
	
	@Column(name = "FBME18_TIER4_TARGET_R")
    private long tier4Target;
	
	@Column(name = "FBME18_TIER5_TARGET_R")
    private long tier5Target;
	
	@Column(name = "FBME18_MY_OVER_MY_TARGET_R")
    private long yearOverYearTarget;
	
	@Column(name = "FBME50_ACCOUNT_CLASS_C")
    private String accountClassCode;
	
	@Column(name = "FBME18_EST_CURT_YR_REVN_CHNG_A")
    private Long currentYrRevenue;
	
	@Column(name = "FBME18_EST_CURT_YR_CONTB_CST_A")
    private Long currentYrContributionCost;
	
	@Column(name = "FBME18_BDY_STYL_THRSHLD_P")
    private Long bodyStyleThrshld;
	
	public Long getBodyStyleThrshld() {
		return (bodyStyleThrshld==null?0:bodyStyleThrshld);
	}

	public void setBodyStyleThrshld(Long bodyStyleThrshld) {
		this.bodyStyleThrshld = bodyStyleThrshld;
	}
	

}
