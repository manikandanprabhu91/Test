// ******************************************************************************
// * Copyright (c) 2010 Ford Motor Company. All Rights Reserved.
// * Original author: Ford Motor Company - FBMS
// *
// * $Workfile:   ActualSalesFinancialViewBO.java  $
// * $Revision:   1.1  $
// * $Author : PSIRISIN $
// * $Date : $
// *
// ******************************************************************************
package com.ford.fbms.approvalmanagement.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "FBMS_D80_E22_SUBFIN_VIEW")
@Getter
@Setter
public class ActualSalesFinancialViewDto implements Serializable  {
    
    private static final long serialVersionUID = 1L;
    
    @EmbeddedId
    private ActualSalesFinancialViewPk id;
    
    @Column(name = "FBMD12_PROPOSAL_YEAR_C")
    private Long proposalYear;
    
    @Column(name = "FBME01_FIN_MASTER_K")
    private Long finMasterSaKey;
    
    @Column(name = "FBMD80_AVG_REVENUE_R")
    private Long revenue;
    
    @Column(name = "FBMD80_AVG_CNTRB_COST_R")
    private Long contributionCost;
    
    @Column(name = "FBME22_SLD_MTD_R")
    private int soldToDate;

}
